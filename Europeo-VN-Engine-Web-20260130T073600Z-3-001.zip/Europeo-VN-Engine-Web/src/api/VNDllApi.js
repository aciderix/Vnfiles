/**
 * VNDllApi - DLL API emulation
 * 
 * EXACT PORT from vndllapi.dll exports
 * Functions: InitVNCommandMessage, DirectDrawEnabled, VNDLLVarFind, VNDLLVarAddModify
 * 
 * @original_file vndllapi.dll (13KB)
 * @original_exports 5 functions
 */

/**
 * VNDllApi - Main DLL API interface
 * Emulates the vndllapi.dll functionality
 */
class VNDllApi {
    constructor(engine = null) {
        this.engine = engine;
        this.initialized = false;
        
        // Variable storage (shared with engine)
        this.variables = new Map();
        
        // Command message handler
        this.commandCallback = null;
        
        // DirectDraw state
        this.directDrawEnabled = true;
    }

    /**
     * InitVNCommandMessage - Initialize command message handler
     * @original_export InitVNCommandMessage @ 0x00401480
     * 
     * Sets up the callback for command messages between
     * the DLL and the main application.
     */
    initVNCommandMessage(callback) {
        this.commandCallback = callback;
        this.initialized = true;
        return true;
    }

    /**
     * DirectDrawEnabled - Check/set DirectDraw status
     * @original_export DirectDrawEnabled @ 0x0040148f
     * 
     * Returns whether DirectDraw acceleration is enabled.
     * In the web port, this always returns true (Canvas 2D).
     */
    directDrawEnabled(enable = undefined) {
        if (enable !== undefined) {
            this.directDrawEnabled = !!enable;
        }
        return this.directDrawEnabled;
    }

    /**
     * VNDLLVarFind - Find a variable by name
     * @original_export VNDLLVarFind @ 0x00401499
     * 
     * Searches for a variable in the variable storage.
     * Returns the variable value or null if not found.
     */
    vnDllVarFind(name) {
        if (!name) return null;
        
        const key = name.toLowerCase();
        
        // Check local storage first
        if (this.variables.has(key)) {
            return this.variables.get(key);
        }
        
        // Check engine variables
        if (this.engine && this.engine.variables) {
            const value = this.engine.variables.get(name);
            if (value !== null && value !== undefined) {
                return value;
            }
        }
        
        return null;
    }

    /**
     * VNDLLVarAddModify - Add or modify a variable
     * @original_export VNDLLVarAddModify @ 0x004014dd
     * 
     * Adds a new variable or modifies an existing one.
     * Returns true on success.
     */
    vnDllVarAddModify(name, value) {
        if (!name) return false;
        
        const key = name.toLowerCase();
        
        // Store locally
        this.variables.set(key, value);
        
        // Also update engine if available
        if (this.engine && this.engine.variables) {
            this.engine.variables.set(name, value);
        }
        
        return true;
    }

    /**
     * Send command to the engine
     */
    sendCommand(command) {
        if (this.commandCallback) {
            this.commandCallback(command);
            return true;
        }
        
        if (this.engine) {
            this.engine.executeCommand(command);
            return true;
        }
        
        return false;
    }

    /**
     * Get all variables
     */
    getAllVariables() {
        const result = {};
        this.variables.forEach((value, key) => {
            result[key] = value;
        });
        return result;
    }

    /**
     * Clear all variables
     */
    clearVariables() {
        this.variables.clear();
    }
}

/**
 * VNResModApi - Resource module API emulation
 * Port of vnresmod.dll
 * @original_file vnresmod.dll (40KB)
 */
class VNResModApi {
    constructor(engine = null) {
        this.engine = engine;
        
        // Resource cache
        this.resources = new Map();
        
        // Resource types
        this.RESOURCE_BITMAP = 1;
        this.RESOURCE_WAVE = 2;
        this.RESOURCE_MIDI = 3;
        this.RESOURCE_AVI = 4;
        this.RESOURCE_HTML = 5;
        this.RESOURCE_TEXT = 6;
    }

    /**
     * Load resource by name
     */
    async loadResource(name, type) {
        const key = `${type}_${name.toLowerCase()}`;
        
        // Check cache
        if (this.resources.has(key)) {
            return this.resources.get(key);
        }
        
        // Load based on type
        let resource = null;
        
        switch (type) {
            case this.RESOURCE_BITMAP:
                resource = await this._loadBitmap(name);
                break;
            case this.RESOURCE_WAVE:
            case this.RESOURCE_MIDI:
                resource = await this._loadAudio(name);
                break;
            case this.RESOURCE_AVI:
                resource = await this._loadVideo(name);
                break;
            case this.RESOURCE_HTML:
            case this.RESOURCE_TEXT:
                resource = await this._loadText(name);
                break;
        }
        
        if (resource) {
            this.resources.set(key, resource);
        }
        
        return resource;
    }

    /**
     * Load bitmap resource
     */
    async _loadBitmap(name) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = () => reject(new Error(`Failed to load bitmap: ${name}`));
            img.src = this._getResourcePath(name);
        });
    }

    /**
     * Load audio resource
     */
    async _loadAudio(name) {
        return new Promise((resolve, reject) => {
            const audio = new Audio();
            audio.oncanplaythrough = () => resolve(audio);
            audio.onerror = () => reject(new Error(`Failed to load audio: ${name}`));
            audio.src = this._getResourcePath(name);
        });
    }

    /**
     * Load video resource
     */
    async _loadVideo(name) {
        return new Promise((resolve, reject) => {
            const video = document.createElement('video');
            video.oncanplaythrough = () => resolve(video);
            video.onerror = () => reject(new Error(`Failed to load video: ${name}`));
            video.src = this._getResourcePath(name);
        });
    }

    /**
     * Load text resource
     */
    async _loadText(name) {
        try {
            const response = await fetch(this._getResourcePath(name));
            return await response.text();
        } catch (e) {
            throw new Error(`Failed to load text: ${name}`);
        }
    }

    /**
     * Get resource path
     */
    _getResourcePath(name) {
        // Default asset path
        const basePath = this.engine?.assetPath || 'assets/';
        return `${basePath}${name}`;
    }

    /**
     * Free resource
     */
    freeResource(name, type) {
        const key = `${type}_${name.toLowerCase()}`;
        
        if (this.resources.has(key)) {
            const resource = this.resources.get(key);
            
            // Clean up based on type
            if (resource instanceof HTMLAudioElement) {
                resource.pause();
                resource.src = '';
            } else if (resource instanceof HTMLVideoElement) {
                resource.pause();
                resource.src = '';
            }
            
            this.resources.delete(key);
            return true;
        }
        
        return false;
    }

    /**
     * Free all resources
     */
    freeAllResources() {
        this.resources.forEach((resource) => {
            if (resource instanceof HTMLAudioElement || 
                resource instanceof HTMLVideoElement) {
                resource.pause();
                resource.src = '';
            }
        });
        
        this.resources.clear();
    }
}

/**
 * VNOptionApi - Options module API emulation
 * Port of vnoption.dll
 * @original_file vnoption.dll (23KB)
 */
class VNOptionApi {
    constructor(engine = null) {
        this.engine = engine;
        
        // Default options
        this.options = {
            // Display
            fullscreen: false,
            width: 800,
            height: 600,
            colorDepth: 32,
            
            // Audio
            soundEnabled: true,
            musicEnabled: true,
            soundVolume: 100,
            musicVolume: 100,
            
            // Playback
            autoPlay: true,
            loopVideo: false,
            
            // Performance
            useDirectDraw: true,
            vsync: true,
            
            // Language
            language: 'en'
        };
        
        // Load saved options
        this._loadOptions();
    }

    /**
     * Get option value
     */
    getOption(name) {
        return this.options[name];
    }

    /**
     * Set option value
     */
    setOption(name, value) {
        if (name in this.options) {
            this.options[name] = value;
            this._saveOptions();
            
            // Apply certain options immediately
            this._applyOption(name, value);
            
            return true;
        }
        return false;
    }

    /**
     * Apply option immediately
     */
    _applyOption(name, value) {
        if (!this.engine) return;
        
        switch (name) {
            case 'soundEnabled':
                if (this.engine.audio) {
                    this.engine.audio.setMuted(!value);
                }
                break;
            case 'musicEnabled':
                if (this.engine.music) {
                    this.engine.music.setMuted(!value);
                }
                break;
            case 'soundVolume':
                if (this.engine.audio) {
                    this.engine.audio.setVolume(value / 100);
                }
                break;
            case 'musicVolume':
                if (this.engine.music) {
                    this.engine.music.setVolume(value / 100);
                }
                break;
        }
    }

    /**
     * Get all options
     */
    getAllOptions() {
        return { ...this.options };
    }

    /**
     * Reset to defaults
     */
    resetToDefaults() {
        this.options = {
            fullscreen: false,
            width: 800,
            height: 600,
            colorDepth: 32,
            soundEnabled: true,
            musicEnabled: true,
            soundVolume: 100,
            musicVolume: 100,
            autoPlay: true,
            loopVideo: false,
            useDirectDraw: true,
            vsync: true,
            language: 'en'
        };
        this._saveOptions();
    }

    /**
     * Save options to localStorage
     */
    _saveOptions() {
        try {
            localStorage.setItem('vn_options', JSON.stringify(this.options));
        } catch (e) {
            console.warn('VNOptionApi: Failed to save options', e);
        }
    }

    /**
     * Load options from localStorage
     */
    _loadOptions() {
        try {
            const saved = localStorage.getItem('vn_options');
            if (saved) {
                const parsed = JSON.parse(saved);
                this.options = { ...this.options, ...parsed };
            }
        } catch (e) {
            console.warn('VNOptionApi: Failed to load options', e);
        }
    }

    /**
     * Show options dialog
     */
    showOptionsDialog() {
        if (this.engine && this.engine.ui) {
            // Create options dialog
            const dialog = {
                title: 'Options',
                width: 400,
                height: 300,
                fields: [
                    { name: 'soundEnabled', type: 'checkbox', label: 'Sound Effects', value: this.options.soundEnabled },
                    { name: 'musicEnabled', type: 'checkbox', label: 'Music', value: this.options.musicEnabled },
                    { name: 'soundVolume', type: 'slider', label: 'Sound Volume', value: this.options.soundVolume, min: 0, max: 100 },
                    { name: 'musicVolume', type: 'slider', label: 'Music Volume', value: this.options.musicVolume, min: 0, max: 100 },
                    { name: 'fullscreen', type: 'checkbox', label: 'Fullscreen', value: this.options.fullscreen }
                ],
                onSave: (values) => {
                    for (const [name, value] of Object.entries(values)) {
                        this.setOption(name, value);
                    }
                }
            };
            
            this.engine.ui.showDialog(dialog);
        }
    }
}

// Export all classes
export {
    VNDllApi,
    VNResModApi,
    VNOptionApi
};
