/**
 * Europeo VN Engine - Web Port
 * Main Export Index
 * 
 * Complete port of the Europeo Visual Novel Engine
 * From Windows (Borland C++ 1996) to Modern Web (ES6+)
 * 
 * Original binaries analyzed:
 * - europeo.exe (214KB, 666 functions)
 * - vndllapi.dll (13KB, 33 functions)
 * - vnoption.dll (23KB)
 * - vnresmod.dll (40KB)
 * 
 * Total: 57,861 lines of assembly ported to JavaScript
 */

// ============================================
// Core Engine
// ============================================
export { VNEngine } from './core/VNEngine.js';
export { 
    VNStreamable, 
    VNObject, 
    VNIndexDependant 
} from './core/VNObject.js';

export { 
    VNApplication, 
    VNApplicationInfo, 
    VNProjectInfo, 
    VNVersion, 
    VNDisplayMode, 
    VNPaletteEntries 
} from './core/VNApplication.js';

// ============================================
// Command System (49 commands)
// ============================================
export { VNCommandParser } from './core/VNCommandParser.js';
export { 
    VNCommand, 
    VNCommandArray, 
    VNEventCommand, 
    VNEventCommandArray, 
    VNCommandQueue 
} from './core/VNCommand.js';

// ============================================
// Parameter Classes (25 types)
// ============================================
export {
    VNBaseParms,
    VNStringParms,
    VNFileNameParms,
    VNSceneParms,
    VNImageParms,
    VNImgObjParms,
    VNImgSeqParms,
    VNTextParms,
    VNTextObjParms,
    VNFontParms,
    VNHtmlParms,
    VNDigitParms,
    VNMidiParms,
    VNCDAParms,
    VNExecParms,
    VNIfParms,
    VNSetVarParms,
    VNIncVarParms,
    VNDecVarParms,
    VNConditionParms,
    VNTimeParms,
    VNHotspotParms,
    VNRectParms,
    VNProjectParms,
    VNCommandParms
} from './core/VNParms.js';

// ============================================
// Scene Management
// ============================================
export { 
    VNScene, 
    VNSceneArray 
} from './core/VNScene.js';

// ============================================
// Variable System
// ============================================
export { 
    VNVariable, 
    VNVariableArray, 
    VNVariableManager 
} from './core/VNVariable.js';

// ============================================
// Timer & Effects
// ============================================
export {
    VNTimerProperties,
    VNTimerRes,
    VNTimer,
    VNTimerBasedFx,
    VNTimerManager
} from './core/VNTimer.js';

export {
    VNZoomFx,
    VNScrollFx,
    VNFadeEffect,
    VNSlideEffect,
    VNShakeEffect,
    VNTransitionEffect
} from './core/VNEffects.js';

// ============================================
// Graphics & Bitmap
// ============================================
export {
    VNGdiObject,
    VNGdiObjectArray,
    VNBitmap,
    VNBmpImg,
    VNTransparentBmp,
    VNBkTexture,
    VNBitmapCache
} from './core/VNBitmap.js';

// ============================================
// Save/Load System
// ============================================
export { 
    VNSaveLoad, 
    VNSaveSlot, 
    VNSaveManager 
} from './core/VNSaveLoad.js';

// ============================================
// History & Navigation
// ============================================
export {
    VNHistData,
    VNHistQueue,
    VNNavigationManager
} from './core/VNHistory.js';

// ============================================
// HTML Text & Anchor Links
// ============================================
export {
    VNAnchLink,
    VNAnchLinkArray,
    VNPageContext,
    VNHtmlText
} from './core/VNHtml.js';

// ============================================
// Window System
// ============================================
export {
    VNWindow,
    VNFrame,
    VNMenu,
    VNPopupMenu
} from './core/VNWindow.js';

// ============================================
// Resource Management
// ============================================
export {
    VNResourceType,
    VNResourceState,
    VNResource,
    VNImageResource,
    VNAudioResource,
    VNVideoResource,
    VNResourceManager
} from './core/VNResource.js';

// ============================================
// Registry (Settings Storage)
// ============================================
export {
    VNRegRoot,
    VNRegType,
    VNRegistryKey,
    VNRegistry,
    vnRegistry
} from './core/VNRegistry.js';

// ============================================
// Protection & Plugins
// ============================================
export {
    VNProtectFlags,
    VNProtectData,
    VNPluginData,
    VNPluginManager
} from './core/VNProtect.js';

// ============================================
// Media - Audio
// ============================================
export { 
    VNAudioManager, 
    VNAudioChannel 
} from './media/VNAudio.js';

export {
    VNMciBase,
    VNWaveMedia,
    VNMidiMedia,
    VNCDAMedia,
    VNVideoBaseMedia,
    VNAviMedia,
    VNHiddenMedia,
    VNMediaManager
} from './media/VNMciMedia.js';

// ============================================
// Media - Video
// ============================================
export { 
    VNVideoPlayer 
} from './media/VNVideo.js';

// ============================================
// Media - Base
// ============================================
export { 
    VNMediaBase 
} from './media/VNMedia.js';

// ============================================
// UI Components
// ============================================
export { 
    VNDialog 
} from './ui/VNDialog.js';

export { 
    VNHotspot, 
    VNHotspotArray 
} from './ui/VNHotspot.js';

export { 
    VNImageObject 
} from './ui/VNImageObject.js';

export { 
    VNTextObject 
} from './ui/VNTextObject.js';

export {
    VNToolBar,
    VNToolBarButton,
    VNToolBarProperties
} from './ui/VNToolbar.js';

export {
    VNBaseDialog,
    VNAboutDialog,
    VNLoadingDialog,
    VNUserPrefsDialog,
    VNProjectCapsDialog,
    VNMessageBox,
    injectDialogStyles
} from './ui/VNDialogs.js';

// ============================================
// Graphics - DirectDraw Emulation
// ============================================
export {
    DDSCAPS,
    DDBLT,
    VNDirectDrawSurface,
    VNDirectDrawClipper,
    VNDirectDrawPalette,
    VNDirectDraw
} from './graphics/VNDirectDraw.js';

// ============================================
// Utilities
// ============================================
export { EventEmitter } from './utils/EventEmitter.js';

// ============================================
// Default Export - Main Engine
// ============================================
import { VNEngine } from './core/VNEngine.js';
export default VNEngine;

/**
 * Version info
 */
export const VERSION = {
    major: 2,
    minor: 0,
    patch: 0,
    build: 'web',
    string: '2.0.0-web',
    original: '1.x (1996 Borland C++)',
    portDate: '2026-01-30'
};

/**
 * Quick start helper
 */
export async function createEngine(containerId, projectPath) {
    const engine = new VNEngine(containerId);
    if (projectPath) {
        await engine.loadProject(projectPath);
    }
    return engine;
}
