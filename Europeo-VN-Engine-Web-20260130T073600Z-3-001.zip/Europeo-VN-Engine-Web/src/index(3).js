/**
 * Europeo VN Engine - Web Port
 * Main Export Index
 * 
 * Complete reverse-engineered port from Windows binaries
 * Original: europeo.exe (214KB) + DLLs
 * 
 * Total: 44 JavaScript modules, 785+ KB
 * 
 * @version 2.0.0
 * @original Europeo VN Engine (Sopra Multimedia, 1996-1999)
 */

// ============================================
// CORE MODULES
// ============================================

// Base object system
export {
    VNStreamable,
    VNObject,
    VNIndexDependant
} from './core/VNObject.js';

// Application framework
export {
    VNApplication,
    VNApplicationInfo,
    VNProjectInfo,
    VNVersion,
    VNDisplayMode,
    VNApplicationState,
    VNStartupOptions
} from './core/VNApplication.js';

// Main engine
export { default as VNEngine } from './core/VNEngine.js';

// Command system
export {
    VNCommand,
    VNCommandArray,
    VNEventCommand,
    VNEventCommandArray,
    VNCommandQueue
} from './core/VNCommand.js';

// Command parser (49 commands)
export { default as VNCommandParser } from './core/VNCommandParser.js';

// Parameter classes (25+)
export {
    VNBaseParms,
    VNSceneParms,
    VNIfParms,
    VNPlayBmpParms,
    VNPlayAviParms,
    VNPlayWavParms,
    VNPlayMidiParms,
    VNTextParms,
    VNHotspotParms,
    VNVariableParms,
    VNGotoParms,
    VNLabelParms,
    VNPlayHtmlParms,
    VNZoomParms,
    VNScrollParms,
    VNWaitParms,
    VNTimerParms
} from './core/VNParms.js';

// Scene management
export { default as VNScene } from './core/VNScene.js';

export {
    VNSceneRect,
    VNSceneData,
    VNSceneState,
    VNSceneManager,
    VNTransferData,
    VNSceneTransition
} from './core/VNSceneManager.js';

// Variable system
export { default as VNVariable } from './core/VNVariable.js';

export {
    VNVariableType,
    VNVariable as VNVariableClass,
    VNVariableArray,
    VNSetVarParms,
    VNIfParms as VNIfParmsClass,
    VNVariableManager,
    VNFlowControl
} from './core/VNVariableSystem.js';

// Text system
export {
    VNTextAlignment,
    VNTextParms as VNTextParmsClass,
    VNTextObjParms,
    VNPageContext,
    VNTextObject,
    VNHtmlText,
    VNTextManager,
    VNTipText
} from './core/VNTextSystem.js';

// Hotspot system
export {
    VNHotspotParms as VNHotspotParmsClass,
    VNHotspot,
    VNHotspotArray,
    VNHotspotManager,
    VNCursor
} from './core/VNHotspotSystem.js';

// Timer system
export {
    VNTimerProperties,
    VNTimerRes,
    VNTimer,
    VNTimerBasedFx,
    VNTimerManager
} from './core/VNTimer.js';

// Visual effects
export {
    VNZoomFx,
    VNScrollFx,
    VNFadeEffect,
    VNSlideEffect,
    VNShakeEffect,
    VNTransitionEffect
} from './core/VNEffects.js';

// Bitmap handling
export {
    VNGdiObject,
    VNGdiObjectArray,
    VNBitmap,
    VNBmpImg,
    VNTransparentBmp,
    VNBkTexture
} from './core/VNBitmap.js';

// HTML text rendering
export {
    VNAnchLink,
    VNAnchLinkArray,
    VNPageContextHtml,
    VNHtmlTextRenderer
} from './core/VNHtml.js';

// History/navigation
export {
    VNHistData,
    VNHistQueue,
    VNNavigationManager
} from './core/VNHistory.js';

// Rendering system
export {
    VNTextMetrics,
    VNTextStyle,
    VNRenderState,
    VNHtmlToken,
    VNHtmlTokenizer,
    VNRender,
    VNMainLoop
} from './core/VNRender.js';

// Save/Load system
export { default as VNSaveLoad } from './core/VNSaveLoad.js';

// Resource management
export {
    VNResourceManager,
    VNImageResource,
    VNAudioResource,
    VNVideoResource
} from './core/VNResource.js';

// File format parsing
export {
    VNProjectFile,
    VNSceneFile,
    VNResourceFile,
    VNFileParser
} from './core/VNFileFormat.js';

// String utilities
export {
    VNString,
    VNStringArray,
    VNSepStrArray,
    VNStringParser
} from './core/VNStringArray.js';

// System info
export {
    VNSysInfo,
    VNPerformanceMonitor,
    VNDebugConsole
} from './core/VNSysInfo.js';

// Color palette
export {
    VNPaletteEntry,
    VNPalette,
    VNColorManager
} from './core/VNPalette.js';

// Window management
export {
    VNWindow,
    VNFrame,
    VNMenu,
    VNPopupMenu
} from './core/VNWindow.js';

// Registry (settings storage)
export {
    VNRegistry,
    VNRegistryKey
} from './core/VNRegistry.js';

// Protection/DRM
export {
    VNProtectData,
    VNPluginData,
    VNPluginManager
} from './core/VNProtect.js';

// ============================================
// GRAPHICS MODULES
// ============================================

// DirectDraw emulation
export {
    VNDirectDraw,
    VNDirectDrawSurface,
    VNDirectDrawClipper,
    VNDirectDrawPalette
} from './graphics/VNDirectDraw.js';

// GDI emulation
export {
    VNGdi,
    VNGDIDC,
    VNGdiBrush,
    VNGdiPen,
    VNGdiFont,
    VNGdiRegion,
    VNGdiPath,
    VNGdiMetafile
} from './graphics/VNGdi.js';

// ============================================
// MEDIA MODULES
// ============================================

// Base media
export { default as VNMedia } from './media/VNMedia.js';

// Audio system
export { default as VNAudio } from './media/VNAudio.js';

// Video system
export { default as VNVideo } from './media/VNVideo.js';

export {
    VNVideoParms,
    VNVideoState,
    VNVideoBaseMedia,
    VNAviMedia,
    VNVideoManager,
    VNMciCommand
} from './media/VNVideoSystem.js';

// MCI Media emulation
export {
    VNMciBase,
    VNWaveMedia,
    VNMidiMedia,
    VNCDAMedia,
    VNVideoMediaBase,
    VNAviMediaMci
} from './media/VNMciMedia.js';

// ============================================
// UI MODULES
// ============================================

// Dialog base
export { default as VNDialog } from './ui/VNDialog.js';

// Dialog types
export {
    VNBaseDialog,
    VNAboutDialog,
    VNLoadingDialog,
    VNUserPrefsDialog,
    VNProjectCapsDialog,
    VNMessageBox
} from './ui/VNDialogs.js';

// UI Controls
export {
    VNButton,
    VNCheckBox,
    VNRadioButton,
    VNSlider,
    VNProgressBar,
    VNGauge,
    VNListBox,
    VNComboBox,
    VNEditBox,
    VNLabel,
    VNGroupBox,
    VNScrollBar,
    VNSpinButton,
    VNUIHandle
} from './ui/VNControls.js';

// Hotspot UI
export { default as VNHotspotUI } from './ui/VNHotspot.js';

// Image object
export { default as VNImageObject } from './ui/VNImageObject.js';

// Text object
export { default as VNTextObjectUI } from './ui/VNTextObject.js';

// Toolbar
export {
    VNToolBar,
    VNToolBarButton,
    VNToolBarProperties
} from './ui/VNToolbar.js';

// ============================================
// UTILITY MODULES
// ============================================

// Event emitter
export { default as EventEmitter } from './utils/EventEmitter.js';

// ============================================
// VERSION INFO
// ============================================

export const VERSION = {
    major: 2,
    minor: 0,
    patch: 0,
    build: 'web',
    string: '2.0.0-web',
    original: 'Europeo VN Engine 1.0 (Sopra Multimedia 1996-1999)',
    ported: 'January 2026',
    modules: 44,
    classes: 150,
    commands: 49
};

// ============================================
// DEFAULT EXPORT
// ============================================

import VNEngine from './core/VNEngine.js';
export default VNEngine;
