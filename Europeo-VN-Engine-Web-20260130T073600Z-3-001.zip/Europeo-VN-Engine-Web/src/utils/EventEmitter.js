/**
 * EventEmitter - Simple event system for VN Engine
 * Mirrors the Windows message system used in the original
 */
class EventEmitter {
    constructor() {
        this._events = {};
    }

    /**
     * Register an event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     * @returns {Function} Unsubscribe function
     */
    on(event, callback) {
        if (!this._events[event]) {
            this._events[event] = [];
        }
        this._events[event].push(callback);
        
        // Return unsubscribe function
        return () => this.off(event, callback);
    }

    /**
     * Register a one-time event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function
     */
    once(event, callback) {
        const wrapper = (...args) => {
            this.off(event, wrapper);
            callback.apply(this, args);
        };
        this.on(event, wrapper);
    }

    /**
     * Remove an event listener
     * @param {string} event - Event name
     * @param {Function} callback - Callback function to remove
     */
    off(event, callback) {
        if (!this._events[event]) return;
        
        const index = this._events[event].indexOf(callback);
        if (index > -1) {
            this._events[event].splice(index, 1);
        }
    }

    /**
     * Emit an event
     * @param {string} event - Event name
     * @param {...any} args - Arguments to pass to listeners
     */
    emit(event, ...args) {
        if (!this._events[event]) return;
        
        this._events[event].forEach(callback => {
            try {
                callback.apply(this, args);
            } catch (error) {
                console.error(`Error in event handler for "${event}":`, error);
            }
        });
    }

    /**
     * Remove all listeners for an event (or all events)
     * @param {string} [event] - Optional event name
     */
    removeAllListeners(event) {
        if (event) {
            delete this._events[event];
        } else {
            this._events = {};
        }
    }
}

// VN-specific event names (matching original wm_vncommand)
const VNEvents = {
    // Scene events
    EV_ONINIT: 'EV_ONINIT',
    EV_AFTERINIT: 'EV_AFTERINIT',
    EV_ONCLICK: 'EV_ONCLICK',
    EV_ONFOCUS: 'EV_ONFOCUS',
    
    // Media events
    MEDIA_LOADED: 'MEDIA_LOADED',
    MEDIA_ERROR: 'MEDIA_ERROR',
    MEDIA_ENDED: 'MEDIA_ENDED',
    
    // Video events
    VIDEO_STARTED: 'VIDEO_STARTED',
    VIDEO_ENDED: 'VIDEO_ENDED',
    
    // Audio events
    AUDIO_STARTED: 'AUDIO_STARTED',
    AUDIO_ENDED: 'AUDIO_ENDED',
    
    // UI events
    TEXT_COMPLETE: 'TEXT_COMPLETE',
    DIALOG_CLICK: 'DIALOG_CLICK',
    HOTSPOT_CLICK: 'HOTSPOT_CLICK',
    HOTSPOT_FOCUS: 'HOTSPOT_FOCUS',
    
    // Engine events
    SCENE_CHANGE: 'SCENE_CHANGE',
    COMMAND_EXECUTE: 'COMMAND_EXECUTE',
    SAVE_COMPLETE: 'SAVE_COMPLETE',
    LOAD_COMPLETE: 'LOAD_COMPLETE',
    
    // Variable events
    VAR_CHANGED: 'VAR_CHANGED'
};

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { EventEmitter, VNEvents };
}
