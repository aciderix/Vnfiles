/**
 * VNProfile - Profile and Configuration System
 * 
 * EXACT PORT from europeo.exe TProfile class
 * Handles .INI file format and preferences
 * 
 * Original functions from disassembly:
 * - TProfile_WriteInt_qpxci @ 0x004390ba
 * - TProfile constructor/destructor
 * 
 * Strings found:
 * - "prefs" @ 0x0043f777
 * - "PREFS" @ 0x004477ae
 * - ".INI" @ 0x00442b30
 * - "HKEY_CURRENT_CONFIG" @ 0x0044e87e
 */

/**
 * VNProfile - INI file profile manager
 * Port of TProfile from OWL
 */
export class VNProfile {
    /**
     * @param {string} filename - INI filename
     * @param {string} section - Default section
     */
    constructor(filename = 'europeo.ini', section = 'General') {
        this.filename = filename;
        this.section = section;
        this.data = new Map();
        this.dirty = false;
        
        // Storage key prefix
        this.storagePrefix = 'vn_profile_';
    }

    /**
     * Get storage key
     * @returns {string}
     */
    getStorageKey() {
        return `${this.storagePrefix}${this.filename}`;
    }

    /**
     * Load profile from storage
     * @returns {boolean}
     */
    load() {
        try {
            const stored = localStorage.getItem(this.getStorageKey());
            if (stored) {
                const parsed = JSON.parse(stored);
                this.data = new Map(Object.entries(parsed));
                return true;
            }
        } catch (e) {
            console.warn('Failed to load profile:', e);
        }
        return false;
    }

    /**
     * Save profile to storage
     * @returns {boolean}
     */
    save() {
        try {
            const obj = {};
            for (const [section, values] of this.data) {
                obj[section] = values;
            }
            localStorage.setItem(this.getStorageKey(), JSON.stringify(obj));
            this.dirty = false;
            return true;
        } catch (e) {
            console.warn('Failed to save profile:', e);
            return false;
        }
    }

    /**
     * Get section data
     * @param {string} section 
     * @returns {Object}
     */
    getSection(section = this.section) {
        if (!this.data.has(section)) {
            this.data.set(section, {});
        }
        return this.data.get(section);
    }

    /**
     * Read string value
     * Port of TProfile::GetString
     * @param {string} key 
     * @param {string} defaultValue 
     * @param {string} section 
     * @returns {string}
     */
    getString(key, defaultValue = '', section = this.section) {
        const sectionData = this.getSection(section);
        return sectionData[key] !== undefined ? String(sectionData[key]) : defaultValue;
    }

    /**
     * Write string value
     * Port of TProfile::WriteString
     * @param {string} key 
     * @param {string} value 
     * @param {string} section 
     */
    writeString(key, value, section = this.section) {
        const sectionData = this.getSection(section);
        sectionData[key] = value;
        this.dirty = true;
    }

    /**
     * Read integer value
     * Port of TProfile::GetInt
     * @param {string} key 
     * @param {number} defaultValue 
     * @param {string} section 
     * @returns {number}
     */
    getInt(key, defaultValue = 0, section = this.section) {
        const sectionData = this.getSection(section);
        if (sectionData[key] !== undefined) {
            const parsed = parseInt(sectionData[key], 10);
            return isNaN(parsed) ? defaultValue : parsed;
        }
        return defaultValue;
    }

    /**
     * Write integer value
     * Port of TProfile_WriteInt_qpxci @ 0x004390ba
     * @param {string} key 
     * @param {number} value 
     * @param {string} section 
     */
    writeInt(key, value, section = this.section) {
        // Original ASM:
        // push [esp+12]    ; section
        // push [esp+12]    ; key  
        // mov eax, [esp+12] ; value
        // call sprintf with "%d"
        // push result
        // call WritePrivateProfileString
        
        const sectionData = this.getSection(section);
        sectionData[key] = value;
        this.dirty = true;
    }

    /**
     * Read boolean value
     * @param {string} key 
     * @param {boolean} defaultValue 
     * @param {string} section 
     * @returns {boolean}
     */
    getBool(key, defaultValue = false, section = this.section) {
        const value = this.getString(key, '', section).toLowerCase();
        if (value === '') return defaultValue;
        return value === 'true' || value === '1' || value === 'yes';
    }

    /**
     * Write boolean value
     * @param {string} key 
     * @param {boolean} value 
     * @param {string} section 
     */
    writeBool(key, value, section = this.section) {
        this.writeString(key, value ? '1' : '0', section);
    }

    /**
     * Read float value
     * @param {string} key 
     * @param {number} defaultValue 
     * @param {string} section 
     * @returns {number}
     */
    getFloat(key, defaultValue = 0.0, section = this.section) {
        const sectionData = this.getSection(section);
        if (sectionData[key] !== undefined) {
            const parsed = parseFloat(sectionData[key]);
            return isNaN(parsed) ? defaultValue : parsed;
        }
        return defaultValue;
    }

    /**
     * Write float value
     * @param {string} key 
     * @param {number} value 
     * @param {string} section 
     */
    writeFloat(key, value, section = this.section) {
        this.writeString(key, String(value), section);
    }

    /**
     * Delete key
     * @param {string} key 
     * @param {string} section 
     */
    deleteKey(key, section = this.section) {
        const sectionData = this.getSection(section);
        delete sectionData[key];
        this.dirty = true;
    }

    /**
     * Delete section
     * @param {string} section 
     */
    deleteSection(section = this.section) {
        this.data.delete(section);
        this.dirty = true;
    }

    /**
     * Check if key exists
     * @param {string} key 
     * @param {string} section 
     * @returns {boolean}
     */
    hasKey(key, section = this.section) {
        const sectionData = this.getSection(section);
        return key in sectionData;
    }

    /**
     * Get all keys in section
     * @param {string} section 
     * @returns {string[]}
     */
    getKeys(section = this.section) {
        const sectionData = this.getSection(section);
        return Object.keys(sectionData);
    }

    /**
     * Get all sections
     * @returns {string[]}
     */
    getSections() {
        return Array.from(this.data.keys());
    }

    /**
     * Import from INI string
     * @param {string} iniString 
     */
    importINI(iniString) {
        const lines = iniString.split(/\r?\n/);
        let currentSection = this.section;
        
        for (const line of lines) {
            const trimmed = line.trim();
            
            // Skip empty lines and comments
            if (!trimmed || trimmed.startsWith(';') || trimmed.startsWith('#')) {
                continue;
            }
            
            // Section header
            const sectionMatch = trimmed.match(/^\[(.+)\]$/);
            if (sectionMatch) {
                currentSection = sectionMatch[1];
                continue;
            }
            
            // Key=Value
            const kvMatch = trimmed.match(/^([^=]+)=(.*)$/);
            if (kvMatch) {
                const key = kvMatch[1].trim();
                const value = kvMatch[2].trim();
                this.writeString(key, value, currentSection);
            }
        }
    }

    /**
     * Export to INI string
     * @returns {string}
     */
    exportINI() {
        const lines = [];
        
        for (const [section, values] of this.data) {
            lines.push(`[${section}]`);
            for (const [key, value] of Object.entries(values)) {
                lines.push(`${key}=${value}`);
            }
            lines.push('');
        }
        
        return lines.join('\r\n');
    }
}

/**
 * VNPreferences - User preferences
 * Port of TVNUserPrefsDlg settings
 */
export class VNPreferences {
    constructor() {
        this.profile = new VNProfile('europeo.ini', 'PREFS');
        this.defaults = {
            // Display
            fullscreen: false,
            width: 640,
            height: 480,
            colorDepth: 24,
            showToolbar: true,
            showMenu: true,
            
            // Audio
            musicVolume: 100,
            soundVolume: 100,
            voiceVolume: 100,
            musicEnabled: true,
            soundEnabled: true,
            voiceEnabled: true,
            
            // Text
            textSpeed: 50,
            autoAdvance: false,
            autoAdvanceDelay: 3000,
            skipUnread: false,
            
            // System
            language: 'en',
            saveSlots: 10,
            lastSaveSlot: 0,
            
            // Cursor
            defCursor: 'default',
            customCursors: true
        };
        
        this.values = { ...this.defaults };
    }

    /**
     * Load preferences
     */
    load() {
        if (this.profile.load()) {
            for (const key of Object.keys(this.defaults)) {
                const type = typeof this.defaults[key];
                if (type === 'boolean') {
                    this.values[key] = this.profile.getBool(key, this.defaults[key]);
                } else if (type === 'number') {
                    this.values[key] = this.profile.getInt(key, this.defaults[key]);
                } else {
                    this.values[key] = this.profile.getString(key, this.defaults[key]);
                }
            }
        }
    }

    /**
     * Save preferences
     */
    save() {
        for (const [key, value] of Object.entries(this.values)) {
            const type = typeof value;
            if (type === 'boolean') {
                this.profile.writeBool(key, value);
            } else if (type === 'number') {
                this.profile.writeInt(key, value);
            } else {
                this.profile.writeString(key, value);
            }
        }
        this.profile.save();
    }

    /**
     * Get preference
     * @param {string} key 
     * @returns {*}
     */
    get(key) {
        return this.values[key];
    }

    /**
     * Set preference
     * @param {string} key 
     * @param {*} value 
     */
    set(key, value) {
        this.values[key] = value;
    }

    /**
     * Reset to defaults
     */
    reset() {
        this.values = { ...this.defaults };
    }

    /**
     * Get all preferences
     * @returns {Object}
     */
    getAll() {
        return { ...this.values };
    }
}

/**
 * VNCursor - Cursor management
 * Port of cursor handling from europeo.exe
 * 
 * Functions:
 * - LoadCursorFromFileA @ 0x00451ff8
 * - LoadCursorA @ 0x0045201a
 * - SetCursor @ 0x00452168
 * - ShowCursor @ 0x00452126
 * - DestroyCursor @ 0x004520c8
 * - GetCursorPos @ 0x00451f1c
 */
export class VNCursor {
    constructor() {
        // Cursor types mapping
        this.cursorTypes = {
            'default': 'default',
            'arrow': 'default',
            'hand': 'pointer',
            'pointer': 'pointer',
            'text': 'text',
            'ibeam': 'text',
            'crosshair': 'crosshair',
            'move': 'move',
            'wait': 'wait',
            'busy': 'wait',
            'help': 'help',
            'not-allowed': 'not-allowed',
            'no-drop': 'no-drop',
            'grab': 'grab',
            'grabbing': 'grabbing',
            'zoom-in': 'zoom-in',
            'zoom-out': 'zoom-out',
            'n-resize': 'n-resize',
            's-resize': 's-resize',
            'e-resize': 'e-resize',
            'w-resize': 'w-resize',
            'ne-resize': 'ne-resize',
            'nw-resize': 'nw-resize',
            'se-resize': 'se-resize',
            'sw-resize': 'sw-resize',
            'ew-resize': 'ew-resize',
            'ns-resize': 'ns-resize',
            'nesw-resize': 'nesw-resize',
            'nwse-resize': 'nwse-resize',
            'col-resize': 'col-resize',
            'row-resize': 'row-resize'
        };

        // Custom cursors (loaded from files)
        this.customCursors = new Map();
        
        // Current cursor
        this.currentCursor = 'default';
        this.cursorVisible = true;
        
        // Target element
        this.targetElement = null;
    }

    /**
     * Set target element
     * @param {HTMLElement} element 
     */
    setTarget(element) {
        this.targetElement = element;
        this._applyCursor();
    }

    /**
     * Load cursor from file (image)
     * Port of LoadCursorFromFileA
     * @param {string} name - Cursor name
     * @param {string} url - Image URL
     * @param {number} hotspotX - Hotspot X position
     * @param {number} hotspotY - Hotspot Y position
     * @returns {Promise<boolean>}
     */
    async loadFromFile(name, url, hotspotX = 0, hotspotY = 0) {
        // Original ASM:
        // push [esp+4]    ; filename
        // call LoadCursorFromFileA
        // test eax, eax
        // jz .fail
        
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                this.customCursors.set(name, {
                    url: url,
                    hotspotX: hotspotX,
                    hotspotY: hotspotY
                });
                resolve(true);
            };
            img.onerror = () => {
                console.warn(`Failed to load cursor: ${url}`);
                resolve(false);
            };
            img.src = url;
        });
    }

    /**
     * Load standard cursor
     * Port of LoadCursorA
     * @param {string} name 
     * @returns {boolean}
     */
    loadCursor(name) {
        // Original ASM:
        // push [esp+4]    ; cursor resource ID
        // push 0          ; hInstance (null for system cursor)
        // call LoadCursorA
        
        return name in this.cursorTypes;
    }

    /**
     * Set cursor
     * Port of SetCursor @ 0x00452168
     * @param {string} name 
     */
    setCursor(name) {
        // Original ASM:
        // push [esp+4]    ; hCursor
        // call SetCursor
        // ret
        
        this.currentCursor = name;
        this._applyCursor();
    }

    /**
     * Show/hide cursor
     * Port of ShowCursor @ 0x00452126
     * @param {boolean} show 
     * @returns {number} - Display counter
     */
    showCursor(show) {
        // Original ShowCursor increments/decrements a counter
        // We simplify to boolean visibility
        this.cursorVisible = show;
        this._applyCursor();
        return show ? 1 : 0;
    }

    /**
     * Destroy custom cursor
     * Port of DestroyCursor @ 0x004520c8
     * @param {string} name 
     */
    destroyCursor(name) {
        this.customCursors.delete(name);
    }

    /**
     * Get cursor position
     * Port of GetCursorPos @ 0x00451f1c
     * @returns {{x: number, y: number}}
     */
    getCursorPos() {
        // In browser, we need to track this via mousemove
        // Return cached position
        return { x: this._lastX || 0, y: this._lastY || 0 };
    }

    /**
     * Update cursor position (call from mousemove)
     * @param {number} x 
     * @param {number} y 
     */
    updatePosition(x, y) {
        this._lastX = x;
        this._lastY = y;
    }

    /**
     * Apply cursor to target element
     * @private
     */
    _applyCursor() {
        if (!this.targetElement) return;

        if (!this.cursorVisible) {
            this.targetElement.style.cursor = 'none';
            return;
        }

        const cursor = this.currentCursor;

        // Check custom cursor
        if (this.customCursors.has(cursor)) {
            const custom = this.customCursors.get(cursor);
            this.targetElement.style.cursor = 
                `url('${custom.url}') ${custom.hotspotX} ${custom.hotspotY}, auto`;
            return;
        }

        // Check standard cursor
        if (cursor in this.cursorTypes) {
            this.targetElement.style.cursor = this.cursorTypes[cursor];
            return;
        }

        // Default
        this.targetElement.style.cursor = cursor;
    }

    /**
     * Reset to default cursor
     */
    reset() {
        this.setCursor('default');
    }
}

/**
 * VNConfig - Global configuration manager
 */
export class VNConfig {
    constructor() {
        this.profiles = new Map();
        this.preferences = new VNPreferences();
        this.cursor = new VNCursor();
        
        // Default profile
        this.defaultProfile = new VNProfile('europeo.ini');
    }

    /**
     * Get or create profile
     * @param {string} filename 
     * @returns {VNProfile}
     */
    getProfile(filename) {
        if (!this.profiles.has(filename)) {
            const profile = new VNProfile(filename);
            profile.load();
            this.profiles.set(filename, profile);
        }
        return this.profiles.get(filename);
    }

    /**
     * Initialize configuration
     */
    init() {
        this.defaultProfile.load();
        this.preferences.load();
    }

    /**
     * Save all profiles
     */
    saveAll() {
        this.defaultProfile.save();
        this.preferences.save();
        for (const profile of this.profiles.values()) {
            profile.save();
        }
    }

    /**
     * Get value from default profile
     * @param {string} key 
     * @param {*} defaultValue 
     * @param {string} section 
     * @returns {*}
     */
    get(key, defaultValue, section = 'General') {
        const type = typeof defaultValue;
        if (type === 'boolean') {
            return this.defaultProfile.getBool(key, defaultValue, section);
        } else if (type === 'number') {
            return this.defaultProfile.getInt(key, defaultValue, section);
        }
        return this.defaultProfile.getString(key, defaultValue, section);
    }

    /**
     * Set value in default profile
     * @param {string} key 
     * @param {*} value 
     * @param {string} section 
     */
    set(key, value, section = 'General') {
        const type = typeof value;
        if (type === 'boolean') {
            this.defaultProfile.writeBool(key, value, section);
        } else if (type === 'number') {
            this.defaultProfile.writeInt(key, value, section);
        } else {
            this.defaultProfile.writeString(key, value, section);
        }
    }
}

// Singleton instance
export const vnConfig = new VNConfig();

export default {
    VNProfile,
    VNPreferences,
    VNCursor,
    VNConfig,
    vnConfig
};
