/**
 * VNStringArray - String array and parsing classes
 * 
 * Port of T0SepStrArray, string parsing utilities from europeo.exe
 * Original source: lib/strarray.cpp @ 0x0043a0e5
 * 
 * Handles separator-based string parsing used in VN script commands
 */

/**
 * T0SepStrArray - Separator-based string array
 * Port of T0SepStrArray @ 0x0040fb82
 * 
 * Parses strings like "value1,value2,value3" into arrays
 */
export class T0SepStrArray {
    /**
     * @param {string} str - Input string to parse
     * @param {string} separator - Separator character (default ',')
     */
    constructor(str = '', separator = ',') {
        this.items = [];
        this.separator = separator;
        this.originalString = str;
        
        if (str) {
            this.parse(str);
        }
    }
    
    /**
     * Parse string into array
     * @param {string} str
     */
    parse(str) {
        this.originalString = str;
        this.items = [];
        
        if (!str || str.length === 0) {
            return;
        }
        
        // Handle quoted strings specially
        let current = '';
        let inQuotes = false;
        let quoteChar = '';
        
        for (let i = 0; i < str.length; i++) {
            const char = str[i];
            
            if (!inQuotes && (char === '"' || char === "'")) {
                inQuotes = true;
                quoteChar = char;
            } else if (inQuotes && char === quoteChar) {
                inQuotes = false;
                quoteChar = '';
            } else if (!inQuotes && char === this.separator) {
                this.items.push(current.trim());
                current = '';
            } else {
                current += char;
            }
        }
        
        // Add last item
        if (current.length > 0 || str.endsWith(this.separator)) {
            this.items.push(current.trim());
        }
    }
    
    /**
     * Get item count
     * @returns {number}
     */
    getCount() {
        return this.items.length;
    }
    
    /**
     * Get item at index
     * @param {number} index
     * @returns {string|null}
     */
    getItem(index) {
        if (index < 0 || index >= this.items.length) {
            return null;
        }
        return this.items[index];
    }
    
    /**
     * Get item as integer
     * @param {number} index
     * @param {number} defaultValue
     * @returns {number}
     */
    getInt(index, defaultValue = 0) {
        const item = this.getItem(index);
        if (item === null) return defaultValue;
        const value = parseInt(item, 10);
        return isNaN(value) ? defaultValue : value;
    }
    
    /**
     * Get item as float
     * @param {number} index
     * @param {number} defaultValue
     * @returns {number}
     */
    getFloat(index, defaultValue = 0.0) {
        const item = this.getItem(index);
        if (item === null) return defaultValue;
        const value = parseFloat(item);
        return isNaN(value) ? defaultValue : value;
    }
    
    /**
     * Get item as boolean
     * @param {number} index
     * @param {boolean} defaultValue
     * @returns {boolean}
     */
    getBool(index, defaultValue = false) {
        const item = this.getItem(index);
        if (item === null) return defaultValue;
        
        const lower = item.toLowerCase();
        if (lower === 'true' || lower === 'yes' || lower === '1' || lower === 'on') {
            return true;
        }
        if (lower === 'false' || lower === 'no' || lower === '0' || lower === 'off') {
            return false;
        }
        return defaultValue;
    }
    
    /**
     * Set item at index
     * @param {number} index
     * @param {string} value
     */
    setItem(index, value) {
        while (this.items.length <= index) {
            this.items.push('');
        }
        this.items[index] = value;
    }
    
    /**
     * Add item to end
     * @param {string} value
     */
    add(value) {
        this.items.push(value);
    }
    
    /**
     * Remove item at index
     * @param {number} index
     */
    remove(index) {
        if (index >= 0 && index < this.items.length) {
            this.items.splice(index, 1);
        }
    }
    
    /**
     * Clear all items
     */
    clear() {
        this.items = [];
    }
    
    /**
     * Convert back to string
     * @returns {string}
     */
    toString() {
        return this.items.join(this.separator);
    }
    
    /**
     * Iterate over items
     * @param {Function} callback - function(item, index)
     */
    forEach(callback) {
        this.items.forEach(callback);
    }
    
    /**
     * Get all items as array
     * @returns {string[]}
     */
    toArray() {
        return [...this.items];
    }
}

/**
 * VNCommandLineParser - Command line argument parser
 * Used for parsing VN script command arguments
 */
export class VNCommandLineParser {
    /**
     * Parse command line string into arguments
     * @param {string} cmdLine
     * @returns {string[]}
     */
    static parse(cmdLine) {
        const args = [];
        let current = '';
        let inQuotes = false;
        let quoteChar = '';
        
        for (let i = 0; i < cmdLine.length; i++) {
            const char = cmdLine[i];
            
            if (!inQuotes && (char === '"' || char === "'")) {
                inQuotes = true;
                quoteChar = char;
            } else if (inQuotes && char === quoteChar) {
                inQuotes = false;
                quoteChar = '';
            } else if (!inQuotes && (char === ' ' || char === '\t')) {
                if (current.length > 0) {
                    args.push(current);
                    current = '';
                }
            } else {
                current += char;
            }
        }
        
        if (current.length > 0) {
            args.push(current);
        }
        
        return args;
    }
    
    /**
     * Parse named parameters (key=value format)
     * @param {string} str
     * @returns {Object}
     */
    static parseNamedParams(str) {
        const params = {};
        const pairs = new T0SepStrArray(str, ',');
        
        pairs.forEach((pair) => {
            const eqIndex = pair.indexOf('=');
            if (eqIndex > 0) {
                const key = pair.substring(0, eqIndex).trim().toUpperCase();
                let value = pair.substring(eqIndex + 1).trim();
                
                // Remove quotes if present
                if ((value.startsWith('"') && value.endsWith('"')) ||
                    (value.startsWith("'") && value.endsWith("'"))) {
                    value = value.slice(1, -1);
                }
                
                params[key] = value;
            }
        });
        
        return params;
    }
}

/**
 * VNPathParser - File path parsing utilities
 */
export class VNPathParser {
    /**
     * Get file extension
     * @param {string} path
     * @returns {string}
     */
    static getExtension(path) {
        const lastDot = path.lastIndexOf('.');
        if (lastDot < 0) return '';
        return path.substring(lastDot + 1).toLowerCase();
    }
    
    /**
     * Get filename without extension
     * @param {string} path
     * @returns {string}
     */
    static getBaseName(path) {
        let name = path;
        
        // Remove directory path
        const lastSlash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        if (lastSlash >= 0) {
            name = path.substring(lastSlash + 1);
        }
        
        // Remove extension
        const lastDot = name.lastIndexOf('.');
        if (lastDot > 0) {
            name = name.substring(0, lastDot);
        }
        
        return name;
    }
    
    /**
     * Get directory path
     * @param {string} path
     * @returns {string}
     */
    static getDirectory(path) {
        const lastSlash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        if (lastSlash < 0) return '';
        return path.substring(0, lastSlash);
    }
    
    /**
     * Get filename with extension
     * @param {string} path
     * @returns {string}
     */
    static getFileName(path) {
        const lastSlash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        if (lastSlash < 0) return path;
        return path.substring(lastSlash + 1);
    }
    
    /**
     * Combine paths
     * @param {...string} parts
     * @returns {string}
     */
    static combine(...parts) {
        return parts
            .filter(p => p && p.length > 0)
            .map((p, i) => {
                if (i === 0) {
                    return p.replace(/[\/\\]+$/, '');
                }
                return p.replace(/^[\/\\]+/, '').replace(/[\/\\]+$/, '');
            })
            .join('/');
    }
    
    /**
     * Normalize path separators
     * @param {string} path
     * @returns {string}
     */
    static normalize(path) {
        return path.replace(/\\/g, '/').replace(/\/+/g, '/');
    }
    
    /**
     * Check if path is absolute
     * @param {string} path
     * @returns {boolean}
     */
    static isAbsolute(path) {
        // Windows absolute: C:\ or \\
        // Unix absolute: /
        return /^([A-Za-z]:)?[\/\\]/.test(path);
    }
}

/**
 * VNHtmlParser - HTML tag parsing for VN text
 * Used for playhtml command parsing
 */
export class VNHtmlParser {
    /**
     * Parse simple HTML tags
     * @param {string} text
     * @returns {Array<{type: string, content: string, attributes: Object}>}
     */
    static parseTags(text) {
        const result = [];
        const tagRegex = /<(\/?[a-zA-Z]+)([^>]*)>/g;
        let lastIndex = 0;
        let match;
        
        while ((match = tagRegex.exec(text)) !== null) {
            // Add text before tag
            if (match.index > lastIndex) {
                result.push({
                    type: 'text',
                    content: text.substring(lastIndex, match.index),
                    attributes: {}
                });
            }
            
            // Parse tag
            const tagName = match[1].toLowerCase();
            const attrString = match[2].trim();
            const attributes = this.parseAttributes(attrString);
            
            result.push({
                type: 'tag',
                content: tagName,
                attributes: attributes
            });
            
            lastIndex = tagRegex.lastIndex;
        }
        
        // Add remaining text
        if (lastIndex < text.length) {
            result.push({
                type: 'text',
                content: text.substring(lastIndex),
                attributes: {}
            });
        }
        
        return result;
    }
    
    /**
     * Parse HTML attributes
     * @param {string} attrString
     * @returns {Object}
     */
    static parseAttributes(attrString) {
        const attrs = {};
        const attrRegex = /([a-zA-Z-]+)\s*=\s*["']([^"']*)["']/g;
        let match;
        
        while ((match = attrRegex.exec(attrString)) !== null) {
            attrs[match[1].toLowerCase()] = match[2];
        }
        
        return attrs;
    }
    
    /**
     * Extract links from HTML text
     * @param {string} text
     * @returns {Array<{href: string, text: string}>}
     */
    static extractLinks(text) {
        const links = [];
        const linkRegex = /<a[^>]+href\s*=\s*["']([^"']*)["'][^>]*>([^<]*)<\/a>/gi;
        let match;
        
        while ((match = linkRegex.exec(text)) !== null) {
            links.push({
                href: match[1],
                text: match[2]
            });
        }
        
        return links;
    }
    
    /**
     * Strip HTML tags from text
     * @param {string} text
     * @returns {string}
     */
    static stripTags(text) {
        return text.replace(/<[^>]*>/g, '');
    }
    
    /**
     * Decode HTML entities
     * @param {string} text
     * @returns {string}
     */
    static decodeEntities(text) {
        const entities = {
            '&amp;': '&',
            '&lt;': '<',
            '&gt;': '>',
            '&quot;': '"',
            '&#39;': "'",
            '&apos;': "'",
            '&nbsp;': ' '
        };
        
        let result = text;
        for (const [entity, char] of Object.entries(entities)) {
            result = result.replace(new RegExp(entity, 'g'), char);
        }
        
        // Handle numeric entities
        result = result.replace(/&#(\d+);/g, (match, code) => {
            return String.fromCharCode(parseInt(code, 10));
        });
        result = result.replace(/&#x([0-9a-fA-F]+);/g, (match, code) => {
            return String.fromCharCode(parseInt(code, 16));
        });
        
        return result;
    }
}

/**
 * VNExpressionParser - Expression parsing for if/condition commands
 */
export class VNExpressionParser {
    /**
     * Parse comparison expression
     * @param {string} expr
     * @returns {{left: string, operator: string, right: string}|null}
     */
    static parseComparison(expr) {
        // Supported operators: ==, !=, <, >, <=, >=, =
        const operators = ['==', '!=', '<=', '>=', '<', '>', '='];
        
        for (const op of operators) {
            const index = expr.indexOf(op);
            if (index > 0) {
                return {
                    left: expr.substring(0, index).trim(),
                    operator: op === '=' ? '==' : op,
                    right: expr.substring(index + op.length).trim()
                };
            }
        }
        
        return null;
    }
    
    /**
     * Parse arithmetic expression
     * @param {string} expr
     * @param {Object} variables - Variable lookup
     * @returns {number}
     */
    static evaluateArithmetic(expr, variables = {}) {
        // Replace variable references
        let processed = expr.replace(/\[([^\]]+)\]/g, (match, varName) => {
            const value = variables[varName.toUpperCase()];
            return value !== undefined ? String(value) : '0';
        });
        
        // Simple arithmetic evaluation (secure, no eval)
        try {
            // Only allow numbers and basic operators
            if (!/^[\d\s\+\-\*\/\(\)\.]+$/.test(processed)) {
                return 0;
            }
            
            // Use Function constructor for safe evaluation
            const fn = new Function('return ' + processed);
            const result = fn();
            return isNaN(result) ? 0 : result;
        } catch (e) {
            return 0;
        }
    }
    
    /**
     * Parse boolean expression
     * @param {string} expr
     * @param {Object} variables
     * @returns {boolean}
     */
    static evaluateBoolean(expr, variables = {}) {
        const comparison = this.parseComparison(expr);
        if (!comparison) {
            // Try to evaluate as truthy
            const value = this.evaluateArithmetic(expr, variables);
            return value !== 0;
        }
        
        const left = this.evaluateArithmetic(comparison.left, variables);
        const right = this.evaluateArithmetic(comparison.right, variables);
        
        switch (comparison.operator) {
            case '==': return left === right;
            case '!=': return left !== right;
            case '<': return left < right;
            case '>': return left > right;
            case '<=': return left <= right;
            case '>=': return left >= right;
            default: return false;
        }
    }
}

export default T0SepStrArray;
