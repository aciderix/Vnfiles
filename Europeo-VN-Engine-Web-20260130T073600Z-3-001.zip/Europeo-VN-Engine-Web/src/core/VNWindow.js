/**
 * VNWindow - Window and Frame classes
 * 
 * Port of TVNWindow, TVNFrame from europeo.exe
 * Based on OWL TWindow, TFrameWindow
 * 
 * Original addresses:
 * - TVNWindow vtable references throughout europeo.exe
 * - TVNFrame constructor/destructor in main window setup
 */

import { VNStreamable } from './VNObject.js';
import { EventEmitter } from '../utils/EventEmitter.js';

/**
 * TVNWindow - Base window class
 * Port of OWL TWindow wrapper
 */
export class VNWindow extends VNStreamable {
    constructor(options = {}) {
        super();
        
        // Window properties (from TWindow)
        this.hwnd = null;           // Window handle (DOM element)
        this.parent = options.parent || null;
        this.title = options.title || '';
        this.x = options.x ?? 0;
        this.y = options.y ?? 0;
        this.width = options.width ?? 800;
        this.height = options.height ?? 600;
        
        // Window state
        this.visible = false;
        this.enabled = true;
        this.focused = false;
        this.minimized = false;
        this.maximized = false;
        
        // Window style flags (from Windows API)
        this.style = options.style || {
            border: true,
            caption: true,
            sysmenu: true,
            minimizeBox: true,
            maximizeBox: true,
            resizable: true
        };
        
        // Child windows
        this.children = [];
        
        // Event emitter
        this._events = new EventEmitter();
        
        // Message handlers (WndProc simulation)
        this._messageHandlers = new Map();
        this._setupDefaultHandlers();
    }

    /**
     * Setup default message handlers
     */
    _setupDefaultHandlers() {
        // WM_CREATE equivalent
        this._messageHandlers.set('create', () => this.onCreate());
        
        // WM_DESTROY equivalent
        this._messageHandlers.set('destroy', () => this.onDestroy());
        
        // WM_PAINT equivalent
        this._messageHandlers.set('paint', (dc, rect) => this.onPaint(dc, rect));
        
        // WM_SIZE equivalent
        this._messageHandlers.set('size', (width, height) => this.onSize(width, height));
        
        // WM_CLOSE equivalent
        this._messageHandlers.set('close', () => this.onClose());
        
        // WM_COMMAND equivalent
        this._messageHandlers.set('command', (id, hwnd, code) => this.onCommand(id, hwnd, code));
        
        // Mouse messages
        this._messageHandlers.set('mousemove', (x, y) => this.onMouseMove(x, y));
        this._messageHandlers.set('mousedown', (x, y, button) => this.onMouseDown(x, y, button));
        this._messageHandlers.set('mouseup', (x, y, button) => this.onMouseUp(x, y, button));
        this._messageHandlers.set('click', (x, y) => this.onClick(x, y));
        this._messageHandlers.set('dblclick', (x, y) => this.onDoubleClick(x, y));
        
        // Keyboard messages
        this._messageHandlers.set('keydown', (key, code) => this.onKeyDown(key, code));
        this._messageHandlers.set('keyup', (key, code) => this.onKeyUp(key, code));
        this._messageHandlers.set('keypress', (char) => this.onKeyPress(char));
    }

    /**
     * Create window (DOM element)
     */
    create() {
        if (this.hwnd) return true;
        
        // Create DOM element
        this.hwnd = document.createElement('div');
        this.hwnd.className = 'vn-window';
        this.hwnd.style.cssText = `
            position: absolute;
            left: ${this.x}px;
            top: ${this.y}px;
            width: ${this.width}px;
            height: ${this.height}px;
            display: none;
            overflow: hidden;
        `;
        
        // Add to parent or body
        const parentEl = this.parent?.hwnd || document.body;
        parentEl.appendChild(this.hwnd);
        
        // Setup event listeners
        this._setupEventListeners();
        
        // Trigger create message
        this._sendMessage('create');
        
        // Setup window
        this.setupWindow();
        
        return true;
    }

    /**
     * Setup DOM event listeners
     */
    _setupEventListeners() {
        if (!this.hwnd) return;
        
        // Mouse events
        this.hwnd.addEventListener('mousemove', (e) => {
            const rect = this.hwnd.getBoundingClientRect();
            this._sendMessage('mousemove', e.clientX - rect.left, e.clientY - rect.top);
        });
        
        this.hwnd.addEventListener('mousedown', (e) => {
            const rect = this.hwnd.getBoundingClientRect();
            this._sendMessage('mousedown', e.clientX - rect.left, e.clientY - rect.top, e.button);
        });
        
        this.hwnd.addEventListener('mouseup', (e) => {
            const rect = this.hwnd.getBoundingClientRect();
            this._sendMessage('mouseup', e.clientX - rect.left, e.clientY - rect.top, e.button);
        });
        
        this.hwnd.addEventListener('click', (e) => {
            const rect = this.hwnd.getBoundingClientRect();
            this._sendMessage('click', e.clientX - rect.left, e.clientY - rect.top);
        });
        
        this.hwnd.addEventListener('dblclick', (e) => {
            const rect = this.hwnd.getBoundingClientRect();
            this._sendMessage('dblclick', e.clientX - rect.left, e.clientY - rect.top);
        });
        
        // Keyboard events (when focused)
        this.hwnd.setAttribute('tabindex', '0');
        
        this.hwnd.addEventListener('keydown', (e) => {
            this._sendMessage('keydown', e.key, e.code);
        });
        
        this.hwnd.addEventListener('keyup', (e) => {
            this._sendMessage('keyup', e.key, e.code);
        });
        
        this.hwnd.addEventListener('keypress', (e) => {
            this._sendMessage('keypress', e.key);
        });
        
        // Focus events
        this.hwnd.addEventListener('focus', () => {
            this.focused = true;
            this._events.emit('focus');
        });
        
        this.hwnd.addEventListener('blur', () => {
            this.focused = false;
            this._events.emit('blur');
        });
    }

    /**
     * Send message to window (WndProc simulation)
     */
    _sendMessage(message, ...args) {
        const handler = this._messageHandlers.get(message);
        if (handler) {
            return handler(...args);
        }
        return this.defaultProcessing(message, ...args);
    }

    /**
     * Default message processing
     */
    defaultProcessing(message, ...args) {
        // Override in subclasses
        return 0;
    }

    /**
     * Setup window (called after creation)
     * Override in subclasses
     */
    setupWindow() {
        // Override in subclasses
    }

    /**
     * Show window
     */
    show(showCmd = 1) {
        if (!this.hwnd) this.create();
        
        this.hwnd.style.display = 'block';
        this.visible = true;
        
        if (showCmd === 3) { // SW_MAXIMIZE
            this.maximize();
        } else if (showCmd === 6) { // SW_MINIMIZE
            this.minimize();
        }
        
        this._events.emit('show');
        return true;
    }

    /**
     * Hide window
     */
    hide() {
        if (this.hwnd) {
            this.hwnd.style.display = 'none';
        }
        this.visible = false;
        this._events.emit('hide');
        return true;
    }

    /**
     * Close window
     */
    close(retVal = 0) {
        if (this.canClose()) {
            this._sendMessage('close');
            this.destroy();
            return true;
        }
        return false;
    }

    /**
     * Can close? (override to prevent close)
     */
    canClose() {
        return true;
    }

    /**
     * Destroy window
     */
    destroy() {
        this._sendMessage('destroy');
        
        // Remove children
        for (const child of this.children) {
            child.destroy();
        }
        this.children = [];
        
        // Remove from DOM
        if (this.hwnd && this.hwnd.parentNode) {
            this.hwnd.parentNode.removeChild(this.hwnd);
        }
        this.hwnd = null;
        
        // Remove from parent
        if (this.parent) {
            this.parent.removeChild(this);
        }
        
        this._events.emit('destroy');
    }

    /**
     * Add child window
     */
    addChild(child) {
        child.parent = this;
        this.children.push(child);
    }

    /**
     * Remove child window
     */
    removeChild(child) {
        const index = this.children.indexOf(child);
        if (index !== -1) {
            this.children.splice(index, 1);
            child.parent = null;
        }
    }

    /**
     * Set window position
     */
    setPosition(x, y) {
        this.x = x;
        this.y = y;
        if (this.hwnd) {
            this.hwnd.style.left = `${x}px`;
            this.hwnd.style.top = `${y}px`;
        }
    }

    /**
     * Set window size
     */
    setSize(width, height) {
        this.width = width;
        this.height = height;
        if (this.hwnd) {
            this.hwnd.style.width = `${width}px`;
            this.hwnd.style.height = `${height}px`;
        }
        this._sendMessage('size', width, height);
    }

    /**
     * Set window title/caption
     */
    setCaption(title) {
        this.title = title;
        this._events.emit('captionchange', title);
    }

    /**
     * Get client rect
     */
    getClientRect() {
        return {
            left: 0,
            top: 0,
            right: this.width,
            bottom: this.height,
            width: this.width,
            height: this.height
        };
    }

    /**
     * Get window rect
     */
    getWindowRect() {
        return {
            left: this.x,
            top: this.y,
            right: this.x + this.width,
            bottom: this.y + this.height,
            width: this.width,
            height: this.height
        };
    }

    /**
     * Enable/disable window
     */
    enable(enable = true) {
        this.enabled = enable;
        if (this.hwnd) {
            this.hwnd.style.pointerEvents = enable ? 'auto' : 'none';
            this.hwnd.style.opacity = enable ? '1' : '0.5';
        }
    }

    /**
     * Set focus to window
     */
    setFocus() {
        if (this.hwnd) {
            this.hwnd.focus();
        }
    }

    /**
     * Maximize window
     */
    maximize() {
        if (this.hwnd) {
            this.hwnd.style.left = '0';
            this.hwnd.style.top = '0';
            this.hwnd.style.width = '100%';
            this.hwnd.style.height = '100%';
        }
        this.maximized = true;
        this.minimized = false;
    }

    /**
     * Minimize window
     */
    minimize() {
        if (this.hwnd) {
            this.hwnd.style.display = 'none';
        }
        this.minimized = true;
        this.maximized = false;
    }

    /**
     * Restore window
     */
    restore() {
        if (this.hwnd) {
            this.hwnd.style.left = `${this.x}px`;
            this.hwnd.style.top = `${this.y}px`;
            this.hwnd.style.width = `${this.width}px`;
            this.hwnd.style.height = `${this.height}px`;
            this.hwnd.style.display = 'block';
        }
        this.maximized = false;
        this.minimized = false;
    }

    /**
     * Invalidate window (request repaint)
     */
    invalidate(erase = true) {
        this._events.emit('invalidate', erase);
    }

    /**
     * Update window
     */
    update() {
        // Force repaint
        this._events.emit('update');
    }

    // Message handlers (override in subclasses)
    onCreate() { return 0; }
    onDestroy() { return 0; }
    onPaint(dc, rect) { return 0; }
    onSize(width, height) { return 0; }
    onClose() { return 0; }
    onCommand(id, hwnd, code) { return 0; }
    onMouseMove(x, y) { return 0; }
    onMouseDown(x, y, button) { return 0; }
    onMouseUp(x, y, button) { return 0; }
    onClick(x, y) { return 0; }
    onDoubleClick(x, y) { return 0; }
    onKeyDown(key, code) { return 0; }
    onKeyUp(key, code) { return 0; }
    onKeyPress(char) { return 0; }

    /**
     * Event subscription
     */
    on(event, handler) {
        this._events.on(event, handler);
        return this;
    }

    off(event, handler) {
        this._events.off(event, handler);
        return this;
    }
}

/**
 * TVNFrame - Main application frame window
 * Port of OWL TFrameWindow
 */
export class VNFrame extends VNWindow {
    constructor(options = {}) {
        super(options);
        
        // Frame-specific properties
        this.menu = options.menu || null;
        this.clientWindow = null;
        this.icon = options.icon || null;
        this.iconSm = options.iconSm || null;
        
        // Status bar
        this.statusBar = null;
        this.showStatusBar = options.showStatusBar || false;
        
        // Toolbar
        this.toolbar = null;
        this.showToolbar = options.showToolbar || false;
    }

    /**
     * Create frame window
     */
    create() {
        if (this.hwnd) return true;
        
        // Create main container
        this.hwnd = document.createElement('div');
        this.hwnd.className = 'vn-frame';
        this.hwnd.style.cssText = `
            position: fixed;
            left: ${this.x}px;
            top: ${this.y}px;
            width: ${this.width}px;
            height: ${this.height}px;
            display: none;
            flex-direction: column;
            background: #1a1a2e;
            border: 1px solid #333;
        `;
        
        // Create title bar
        this._createTitleBar();
        
        // Create menu bar
        if (this.menu) {
            this._createMenuBar();
        }
        
        // Create toolbar
        if (this.showToolbar) {
            this._createToolbar();
        }
        
        // Create client area
        this._clientArea = document.createElement('div');
        this._clientArea.className = 'vn-frame-client';
        this._clientArea.style.cssText = `
            flex: 1;
            position: relative;
            overflow: hidden;
        `;
        this.hwnd.appendChild(this._clientArea);
        
        // Create status bar
        if (this.showStatusBar) {
            this._createStatusBar();
        }
        
        // Add to parent
        const parentEl = this.parent?.hwnd || document.body;
        parentEl.appendChild(this.hwnd);
        
        // Setup event listeners
        this._setupEventListeners();
        this._sendMessage('create');
        this.setupWindow();
        
        return true;
    }

    /**
     * Create title bar
     */
    _createTitleBar() {
        const titleBar = document.createElement('div');
        titleBar.className = 'vn-frame-titlebar';
        titleBar.style.cssText = `
            height: 30px;
            background: linear-gradient(to bottom, #3d3d5c, #2d2d4a);
            display: flex;
            align-items: center;
            padding: 0 10px;
            user-select: none;
        `;
        
        // Icon
        if (this.icon) {
            const iconEl = document.createElement('img');
            iconEl.src = this.icon;
            iconEl.style.cssText = 'width: 16px; height: 16px; margin-right: 8px;';
            titleBar.appendChild(iconEl);
        }
        
        // Title
        this._titleEl = document.createElement('span');
        this._titleEl.textContent = this.title;
        this._titleEl.style.cssText = 'flex: 1; color: #fff; font-size: 12px;';
        titleBar.appendChild(this._titleEl);
        
        // Window buttons
        const buttons = document.createElement('div');
        buttons.style.cssText = 'display: flex; gap: 5px;';
        
        if (this.style.minimizeBox) {
            const minBtn = this._createWindowButton('−', () => this.minimize());
            buttons.appendChild(minBtn);
        }
        
        if (this.style.maximizeBox) {
            const maxBtn = this._createWindowButton('□', () => {
                this.maximized ? this.restore() : this.maximize();
            });
            buttons.appendChild(maxBtn);
        }
        
        const closeBtn = this._createWindowButton('×', () => this.close());
        closeBtn.style.background = '#c42b1c';
        buttons.appendChild(closeBtn);
        
        titleBar.appendChild(buttons);
        
        // Dragging
        this._setupDragging(titleBar);
        
        this.hwnd.appendChild(titleBar);
    }

    /**
     * Create window button
     */
    _createWindowButton(text, onClick) {
        const btn = document.createElement('button');
        btn.textContent = text;
        btn.style.cssText = `
            width: 30px;
            height: 20px;
            border: none;
            background: transparent;
            color: #fff;
            cursor: pointer;
            font-size: 14px;
        `;
        btn.addEventListener('click', onClick);
        btn.addEventListener('mouseover', () => btn.style.background = 'rgba(255,255,255,0.1)');
        btn.addEventListener('mouseout', () => btn.style.background = 'transparent');
        return btn;
    }

    /**
     * Setup window dragging
     */
    _setupDragging(element) {
        let isDragging = false;
        let startX, startY, startLeft, startTop;
        
        element.addEventListener('mousedown', (e) => {
            if (e.target.tagName === 'BUTTON') return;
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            startLeft = this.x;
            startTop = this.y;
        });
        
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            this.setPosition(startLeft + dx, startTop + dy);
        });
        
        document.addEventListener('mouseup', () => {
            isDragging = false;
        });
    }

    /**
     * Create menu bar
     */
    _createMenuBar() {
        this._menuBar = document.createElement('div');
        this._menuBar.className = 'vn-frame-menubar';
        this._menuBar.style.cssText = `
            height: 25px;
            background: #2d2d4a;
            display: flex;
            align-items: center;
            padding: 0 5px;
            border-bottom: 1px solid #3d3d5c;
        `;
        
        // Build menu from definition
        if (this.menu && this.menu.items) {
            for (const item of this.menu.items) {
                const menuItem = document.createElement('div');
                menuItem.textContent = item.label;
                menuItem.style.cssText = `
                    padding: 4px 10px;
                    color: #ddd;
                    font-size: 12px;
                    cursor: pointer;
                `;
                menuItem.addEventListener('mouseover', () => menuItem.style.background = 'rgba(255,255,255,0.1)');
                menuItem.addEventListener('mouseout', () => menuItem.style.background = 'transparent');
                menuItem.addEventListener('click', () => {
                    if (item.onClick) item.onClick();
                    this._sendMessage('command', item.id, null, 0);
                });
                this._menuBar.appendChild(menuItem);
            }
        }
        
        this.hwnd.appendChild(this._menuBar);
    }

    /**
     * Create toolbar area
     */
    _createToolbar() {
        this._toolbarArea = document.createElement('div');
        this._toolbarArea.className = 'vn-frame-toolbar';
        this._toolbarArea.style.cssText = `
            height: 32px;
            background: #2a2a3e;
            border-bottom: 1px solid #3d3d5c;
        `;
        this.hwnd.appendChild(this._toolbarArea);
    }

    /**
     * Create status bar
     */
    _createStatusBar() {
        this._statusBar = document.createElement('div');
        this._statusBar.className = 'vn-frame-statusbar';
        this._statusBar.style.cssText = `
            height: 22px;
            background: #2d2d4a;
            border-top: 1px solid #3d3d5c;
            display: flex;
            align-items: center;
            padding: 0 10px;
            color: #999;
            font-size: 11px;
        `;
        this._statusBar.textContent = 'Ready';
        this.hwnd.appendChild(this._statusBar);
    }

    /**
     * Set client window
     */
    setClientWindow(window) {
        if (this.clientWindow) {
            this.removeChild(this.clientWindow);
        }
        this.clientWindow = window;
        if (window) {
            this.addChild(window);
            if (this._clientArea && window.hwnd) {
                this._clientArea.appendChild(window.hwnd);
            }
        }
    }

    /**
     * Get client window
     */
    getClientWindow() {
        return this.clientWindow;
    }

    /**
     * Set menu
     */
    setMenu(menu) {
        this.menu = menu;
        // Rebuild menu bar
    }

    /**
     * Set icon
     */
    setIcon(icon) {
        this.icon = icon;
    }

    /**
     * Set status text
     */
    setStatusText(text) {
        if (this._statusBar) {
            this._statusBar.textContent = text;
        }
    }

    /**
     * Override set caption
     */
    setCaption(title) {
        super.setCaption(title);
        if (this._titleEl) {
            this._titleEl.textContent = title;
        }
    }
}

/**
 * Menu class
 */
export class VNMenu {
    constructor(items = []) {
        this.items = items;
        this.handle = null;
    }

    /**
     * Add menu item
     */
    addItem(item) {
        this.items.push(item);
        return this;
    }

    /**
     * Add separator
     */
    addSeparator() {
        this.items.push({ separator: true });
        return this;
    }

    /**
     * Get item by ID
     */
    getItem(id) {
        return this.items.find(item => item.id === id);
    }

    /**
     * Enable/disable item
     */
    enableItem(id, enable = true) {
        const item = this.getItem(id);
        if (item) {
            item.enabled = enable;
        }
    }

    /**
     * Check/uncheck item
     */
    checkItem(id, checked = true) {
        const item = this.getItem(id);
        if (item) {
            item.checked = checked;
        }
    }
}

/**
 * Popup menu
 */
export class VNPopupMenu extends VNMenu {
    constructor(items = []) {
        super(items);
        this._element = null;
    }

    /**
     * Show popup menu at position
     */
    show(x, y) {
        this.hide();
        
        this._element = document.createElement('div');
        this._element.className = 'vn-popup-menu';
        this._element.style.cssText = `
            position: fixed;
            left: ${x}px;
            top: ${y}px;
            background: #2d2d4a;
            border: 1px solid #3d3d5c;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.5);
            z-index: 10000;
            min-width: 150px;
        `;
        
        for (const item of this.items) {
            if (item.separator) {
                const sep = document.createElement('div');
                sep.style.cssText = 'height: 1px; background: #3d3d5c; margin: 4px 0;';
                this._element.appendChild(sep);
            } else {
                const menuItem = document.createElement('div');
                menuItem.textContent = item.label;
                menuItem.style.cssText = `
                    padding: 8px 12px;
                    color: ${item.enabled !== false ? '#ddd' : '#666'};
                    font-size: 12px;
                    cursor: ${item.enabled !== false ? 'pointer' : 'default'};
                `;
                
                if (item.enabled !== false) {
                    menuItem.addEventListener('mouseover', () => menuItem.style.background = 'rgba(255,255,255,0.1)');
                    menuItem.addEventListener('mouseout', () => menuItem.style.background = 'transparent');
                    menuItem.addEventListener('click', () => {
                        if (item.onClick) item.onClick();
                        this.hide();
                    });
                }
                
                this._element.appendChild(menuItem);
            }
        }
        
        document.body.appendChild(this._element);
        
        // Close on click outside
        setTimeout(() => {
            document.addEventListener('click', this._closeHandler = () => this.hide(), { once: true });
        }, 0);
    }

    /**
     * Hide popup menu
     */
    hide() {
        if (this._element && this._element.parentNode) {
            this._element.parentNode.removeChild(this._element);
            this._element = null;
        }
    }
}

export default {
    VNWindow,
    VNFrame,
    VNMenu,
    VNPopupMenu
};
