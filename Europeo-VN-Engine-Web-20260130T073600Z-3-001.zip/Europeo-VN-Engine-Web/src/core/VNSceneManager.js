/**
 * VNSceneManager - Scene Loading and Management
 * 
 * EXACT PORT from fcn.004335a4 (2481 bytes, 758 lines ASM)
 * Called from fcn.00427d34 and fcn.00434070
 * 
 * This handles scene loading, transitions, and resource management.
 * 
 * @original_address 0x004335a4
 * @original_size 2481 bytes
 */

/**
 * VNSceneRect - Scene rectangle structure
 * Corresponds to [ebx + 0x108] structure (16 bytes)
 * @original_address structure at offset 0x108
 */
class VNSceneRect {
    constructor() {
        // 4 DWORD structure at [ebx + 0x108]
        this.left = 0;    // offset 0x108
        this.top = 0;     // offset 0x10c
        this.right = 0;   // offset 0x110
        this.bottom = 0;  // offset 0x114
    }

    /**
     * Copy from another rect
     * @original_address 0x004335ef - rep movsd (copy 4 dwords)
     */
    copyFrom(other) {
        this.left = other.left;
        this.top = other.top;
        this.right = other.right;
        this.bottom = other.bottom;
    }

    get width() {
        return this.right - this.left;
    }

    get height() {
        return this.bottom - this.top;
    }

    contains(x, y) {
        return x >= this.left && x < this.right && y >= this.top && y < this.bottom;
    }
}

/**
 * VNSceneData - Scene data structure
 * Corresponds to [ebx + 0xb2] pointer structure
 * @original_address structure at offset 0xb2
 */
class VNSceneData {
    constructor() {
        // Offsets from scene data pointer
        this.flags = 0;           // offset 0x00
        this.width = 0;           // offset 0x04 (vtable + 4 call)
        this.height = 0;          // offset 0x05 (vtable + 8 call)
        this.data = null;         // image data
        this.loaded = false;
    }

    /**
     * Get width via vtable call
     * @original_address 0x00433619 - call dword [eax + 4]
     */
    getWidth() {
        return this.width;
    }

    /**
     * Get height via vtable call
     * @original_address 0x00433608 - call dword [edx + 8]
     */
    getHeight() {
        return this.height;
    }
}

/**
 * VNSceneState - Scene state flags
 * Corresponds to [eax + 4] and [eax + 0x60] checks
 * @original_address flags at various offsets
 */
class VNSceneState {
    // Flag at [eax + 4] bit 7 (0x80)
    static FLAG_SCALING = 0x80;
    
    // Flag at [eax + 0x60] bit 0
    static FLAG_ACTIVE = 0x01;

    constructor() {
        this.flags = 0;
        this.stateFlags = 0;
    }

    get isScaling() {
        return (this.flags & VNSceneState.FLAG_SCALING) !== 0;
    }

    get isActive() {
        return (this.stateFlags & VNSceneState.FLAG_ACTIVE) !== 0;
    }
}

/**
 * VNSceneManager - Main scene management class
 * Port of fcn.004335a4
 * @original_address 0x004335a4
 */
class VNSceneManager {
    constructor(engine) {
        this.engine = engine;
        
        // Scene stack for navigation
        this.sceneStack = [];
        this.currentScene = null;
        
        // Viewport rect at [ebx + 0x108]
        this.viewport = new VNSceneRect();
        
        // Scene data at [ebx + 0xb2]
        this.sceneData = null;
        
        // Transition state
        this.transition = {
            active: false,
            type: 0,
            progress: 0,
            duration: 1000,
            startTime: 0
        };
        
        // Scaling factors from 0x004336a8 (fdivrp calculations)
        this.scaleX = 1.0;
        this.scaleY = 1.0;
        
        // Cursor state from 0x004335cd (mov edi, 0xa)
        this.cursorId = 10;
        
        // Loading state
        this.loading = false;
        this.loadPromise = null;
    }

    /**
     * Initialize scene manager
     * @original_address 0x004335b7 - call fcn.004331cb
     */
    initialize() {
        // Initialize viewport to canvas size
        this.viewport.left = 0;
        this.viewport.top = 0;
        this.viewport.right = this.engine.canvas.width;
        this.viewport.bottom = this.engine.canvas.height;
        
        return this;
    }

    /**
     * Load scene from file/URL
     * @original_address 0x004335a4 entry point
     * @param scenePath Path to scene file
     * @param transition Transition type (0 = none)
     */
    async loadScene(scenePath, transition = 0) {
        // Check validity at 0x004335c5
        if (!scenePath) {
            console.warn('VNSceneManager: Invalid scene path');
            return false;
        }

        // Store current scene rect at 0x004335e5-0x004335fd
        const prevRect = new VNSceneRect();
        if (this.sceneData) {
            prevRect.copyFrom(this.viewport);
        }

        // Set loading state
        this.loading = true;
        
        try {
            // Load scene data
            const sceneData = await this._loadSceneData(scenePath);
            
            if (!sceneData) {
                this.loading = false;
                return false;
            }

            // Store scene data at 0x004335fe
            this.sceneData = sceneData;

            // Get scene dimensions at 0x00433604-0x0043361d
            const width = sceneData.getWidth();    // vtable + 4
            const height = sceneData.getHeight();  // vtable + 8
            
            // Store dimensions at var_10h, var_ch
            const sceneWidth = width;
            const sceneHeight = height;

            // Get current window state at 0x0043362a - vtable + 0x7c
            const windowState = this.engine.getWindowState();
            
            // Check scaling flag at 0x00433634
            if (windowState && (windowState.flags & 0x80)) {
                // Calculate scale factors at 0x0043369c-0x004336cd
                // Uses floating point division (fdivrp)
                this.scaleX = this.viewport.width / sceneWidth;
                this.scaleY = this.viewport.height / sceneHeight;
            } else {
                this.scaleX = 1.0;
                this.scaleY = 1.0;
            }

            // Handle transition if specified
            if (transition > 0) {
                await this._doTransition(transition, prevRect);
            }

            // Update current scene
            this.currentScene = {
                path: scenePath,
                data: sceneData,
                width: sceneWidth,
                height: sceneHeight,
                loaded: true
            };

            // Add to scene stack for back navigation
            this.sceneStack.push(this.currentScene);

            this.loading = false;
            return true;

        } catch (error) {
            console.error('VNSceneManager: Error loading scene:', error);
            this.loading = false;
            return false;
        }
    }

    /**
     * Internal scene data loading
     * @original_address various loading calls
     */
    async _loadSceneData(scenePath) {
        return new Promise((resolve, reject) => {
            const sceneData = new VNSceneData();
            
            // Determine resource type
            const ext = scenePath.split('.').pop().toLowerCase();
            
            if (ext === 'bmp' || ext === 'jpg' || ext === 'png' || ext === 'gif') {
                // Load image
                const img = new Image();
                img.crossOrigin = 'anonymous';
                
                img.onload = () => {
                    sceneData.width = img.width;
                    sceneData.height = img.height;
                    sceneData.data = img;
                    sceneData.loaded = true;
                    resolve(sceneData);
                };
                
                img.onerror = () => {
                    reject(new Error(`Failed to load scene image: ${scenePath}`));
                };
                
                img.src = this.engine.resolvePath(scenePath);
                
            } else if (ext === 'vns') {
                // Load VN scene script
                fetch(this.engine.resolvePath(scenePath))
                    .then(response => response.text())
                    .then(script => {
                        sceneData.data = script;
                        sceneData.loaded = true;
                        resolve(sceneData);
                    })
                    .catch(reject);
            } else {
                // Unknown format, try as JSON
                fetch(this.engine.resolvePath(scenePath))
                    .then(response => response.json())
                    .then(data => {
                        sceneData.data = data;
                        if (data.width) sceneData.width = data.width;
                        if (data.height) sceneData.height = data.height;
                        sceneData.loaded = true;
                        resolve(sceneData);
                    })
                    .catch(reject);
            }
        });
    }

    /**
     * Perform scene transition
     * @original_address transition handling section
     */
    async _doTransition(type, prevRect) {
        this.transition.active = true;
        this.transition.type = type;
        this.transition.progress = 0;
        this.transition.startTime = performance.now();

        return new Promise((resolve) => {
            const animate = () => {
                const elapsed = performance.now() - this.transition.startTime;
                this.transition.progress = Math.min(1, elapsed / this.transition.duration);
                
                if (this.transition.progress >= 1) {
                    this.transition.active = false;
                    resolve();
                } else {
                    requestAnimationFrame(animate);
                }
            };
            animate();
        });
    }

    /**
     * Go back to previous scene
     * @original_address scene stack handling
     */
    async goBack() {
        if (this.sceneStack.length > 1) {
            // Remove current scene
            this.sceneStack.pop();
            
            // Get previous scene
            const prevScene = this.sceneStack[this.sceneStack.length - 1];
            
            if (prevScene) {
                this.currentScene = prevScene;
                this.sceneData = prevScene.data;
                return true;
            }
        }
        return false;
    }

    /**
     * Render current scene
     * @original_address render section
     */
    render(ctx) {
        if (!this.sceneData || !this.sceneData.loaded) {
            return;
        }

        const data = this.sceneData.data;
        
        // Handle image scenes
        if (data instanceof Image || data instanceof HTMLImageElement) {
            // Apply transition effect
            if (this.transition.active) {
                ctx.save();
                ctx.globalAlpha = this.transition.progress;
            }
            
            // Draw with scaling
            ctx.drawImage(
                data,
                this.viewport.left,
                this.viewport.top,
                this.viewport.width * this.scaleX,
                this.viewport.height * this.scaleY
            );
            
            if (this.transition.active) {
                ctx.restore();
            }
        }
    }

    /**
     * Clear scene
     */
    clear() {
        this.currentScene = null;
        this.sceneData = null;
        this.sceneStack = [];
    }

    /**
     * Get scene at point (for hotspot detection)
     * @original_address point/rect testing
     */
    getSceneAtPoint(x, y) {
        if (this.currentScene && this.viewport.contains(x, y)) {
            return this.currentScene;
        }
        return null;
    }
}

/**
 * VNTransferData - Dialog data transfer
 * Port of fcn.0042b90b (2312 bytes)
 * Handles checkbox states and dialog data
 * @original_address 0x0042b90b
 */
class VNTransferData {
    // Transfer direction constants
    static TRANSFER_TO_DIALOG = 0;
    static TRANSFER_FROM_DIALOG = 1;

    constructor() {
        // Checkbox flags at [ebx + 0x19]
        this.flags = 0;
        
        // Checkbox control IDs at various offsets
        this.checkboxes = {
            option1: null,  // [ebx + 0x1d]
            option2: null,  // [ebx + 0x21]
            option3: null,  // [ebx + 0x25]
            option4: null,  // [ebx + 0x29]
            option5: null,  // [ebx + 0x2d]
            option6: null,  // [ebx + 0x31]
            option7: null   // [ebx + 0x35] (from test byte 0x40)
        };
    }

    /**
     * Transfer data to/from dialog
     * @original_address 0x0042b931 - TWindow_TransferData
     * @param direction Transfer direction
     */
    transfer(direction) {
        if (direction === VNTransferData.TRANSFER_TO_DIALOG) {
            // Transfer to dialog (set checkbox states)
            // 0x00433943-0x00433a01 - series of SetCheck calls
            this._setCheckboxState('option1', (this.flags & 0x01) !== 0);
            this._setCheckboxState('option2', (this.flags & 0x02) !== 0);
            this._setCheckboxState('option3', (this.flags & 0x04) !== 0);
            this._setCheckboxState('option4', (this.flags & 0x08) !== 0);
            this._setCheckboxState('option5', (this.flags & 0x10) !== 0);
            this._setCheckboxState('option6', (this.flags & 0x20) !== 0);
            this._setCheckboxState('option7', (this.flags & 0x40) !== 0);
        } else {
            // Transfer from dialog (get checkbox states)
            this.flags = 0;
            if (this._getCheckboxState('option1')) this.flags |= 0x01;
            if (this._getCheckboxState('option2')) this.flags |= 0x02;
            if (this._getCheckboxState('option3')) this.flags |= 0x04;
            if (this._getCheckboxState('option4')) this.flags |= 0x08;
            if (this._getCheckboxState('option5')) this.flags |= 0x10;
            if (this._getCheckboxState('option6')) this.flags |= 0x20;
            if (this._getCheckboxState('option7')) this.flags |= 0x40;
        }
    }

    _setCheckboxState(name, checked) {
        const checkbox = this.checkboxes[name];
        if (checkbox && checkbox.element) {
            checkbox.element.checked = checked;
        }
    }

    _getCheckboxState(name) {
        const checkbox = this.checkboxes[name];
        if (checkbox && checkbox.element) {
            return checkbox.element.checked;
        }
        return false;
    }

    /**
     * Bind checkbox element
     */
    bindCheckbox(name, element) {
        this.checkboxes[name] = { element };
    }
}

/**
 * VNSceneTransition - Scene transition effects
 * @original_address transition handling
 */
class VNSceneTransition {
    static TYPE_NONE = 0;
    static TYPE_FADE = 1;
    static TYPE_SLIDE_LEFT = 2;
    static TYPE_SLIDE_RIGHT = 3;
    static TYPE_SLIDE_UP = 4;
    static TYPE_SLIDE_DOWN = 5;
    static TYPE_WIPE = 6;
    static TYPE_DISSOLVE = 7;
    static TYPE_ZOOM_IN = 8;
    static TYPE_ZOOM_OUT = 9;

    constructor(type = VNSceneTransition.TYPE_NONE) {
        this.type = type;
        this.duration = 500;
        this.easing = 'linear';
    }

    /**
     * Apply transition effect to context
     */
    apply(ctx, progress, prevImage, nextImage, rect) {
        switch (this.type) {
            case VNSceneTransition.TYPE_FADE:
                this._applyFade(ctx, progress, prevImage, nextImage, rect);
                break;
                
            case VNSceneTransition.TYPE_SLIDE_LEFT:
                this._applySlide(ctx, progress, prevImage, nextImage, rect, -1, 0);
                break;
                
            case VNSceneTransition.TYPE_SLIDE_RIGHT:
                this._applySlide(ctx, progress, prevImage, nextImage, rect, 1, 0);
                break;
                
            case VNSceneTransition.TYPE_SLIDE_UP:
                this._applySlide(ctx, progress, prevImage, nextImage, rect, 0, -1);
                break;
                
            case VNSceneTransition.TYPE_SLIDE_DOWN:
                this._applySlide(ctx, progress, prevImage, nextImage, rect, 0, 1);
                break;
                
            case VNSceneTransition.TYPE_DISSOLVE:
                this._applyDissolve(ctx, progress, prevImage, nextImage, rect);
                break;
                
            case VNSceneTransition.TYPE_ZOOM_IN:
                this._applyZoom(ctx, progress, prevImage, nextImage, rect, true);
                break;
                
            case VNSceneTransition.TYPE_ZOOM_OUT:
                this._applyZoom(ctx, progress, prevImage, nextImage, rect, false);
                break;
                
            default:
                // No transition, just draw next
                if (nextImage) {
                    ctx.drawImage(nextImage, rect.left, rect.top, rect.width, rect.height);
                }
        }
    }

    _applyFade(ctx, progress, prevImage, nextImage, rect) {
        if (prevImage) {
            ctx.globalAlpha = 1 - progress;
            ctx.drawImage(prevImage, rect.left, rect.top, rect.width, rect.height);
        }
        if (nextImage) {
            ctx.globalAlpha = progress;
            ctx.drawImage(nextImage, rect.left, rect.top, rect.width, rect.height);
        }
        ctx.globalAlpha = 1;
    }

    _applySlide(ctx, progress, prevImage, nextImage, rect, dirX, dirY) {
        const offsetX = rect.width * dirX * progress;
        const offsetY = rect.height * dirY * progress;
        
        if (prevImage) {
            ctx.drawImage(prevImage, 
                rect.left + offsetX, rect.top + offsetY, 
                rect.width, rect.height);
        }
        if (nextImage) {
            ctx.drawImage(nextImage, 
                rect.left + offsetX - rect.width * dirX, 
                rect.top + offsetY - rect.height * dirY, 
                rect.width, rect.height);
        }
    }

    _applyDissolve(ctx, progress, prevImage, nextImage, rect) {
        // Simple dissolve using alpha
        this._applyFade(ctx, progress, prevImage, nextImage, rect);
    }

    _applyZoom(ctx, progress, prevImage, nextImage, rect, zoomIn) {
        const scale = zoomIn ? progress : (1 - progress) + 1;
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.scale(scale, scale);
        ctx.translate(-centerX, -centerY);
        
        if (nextImage) {
            ctx.globalAlpha = progress;
            ctx.drawImage(nextImage, rect.left, rect.top, rect.width, rect.height);
        }
        
        ctx.restore();
    }
}

// Export all classes
export {
    VNSceneRect,
    VNSceneData,
    VNSceneState,
    VNSceneManager,
    VNTransferData,
    VNSceneTransition
};
