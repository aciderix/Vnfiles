/**
 * VNCollections - Collection Classes
 * 
 * EXACT PORT from Borland C++ template collections
 * 
 * Original classes from RTTI:
 * - TArray<T> @ various addresses
 * - TArrayAsVector<T>
 * - TVectorImpBase<T,TStandardAllocator>
 * - TMVectorImp<T,TStandardAllocator>
 * - TMCVectorImp<T,TStandardAllocator>
 * - TMArrayAsVector<T,TStandardAllocator>
 * - TArrayAsVectorImp<T>
 * 
 * Used for:
 * - TVNCommandArray
 * - TVNEventCommandArray
 * - TVNHotspotArray
 * - TVNSceneArray
 * - TVNVariableArray
 * - TVNGdiObjectArray
 */

/**
 * TStandardAllocator equivalent
 * Memory allocation strategy
 */
export class VNStandardAllocator {
    /**
     * Allocate array of size
     * @param {number} size 
     * @returns {Array}
     */
    static allocate(size) {
        return new Array(size);
    }

    /**
     * Deallocate array
     * @param {Array} arr 
     */
    static deallocate(arr) {
        arr.length = 0;
    }

    /**
     * Reallocate array
     * @param {Array} arr 
     * @param {number} newSize 
     * @returns {Array}
     */
    static reallocate(arr, newSize) {
        arr.length = newSize;
        return arr;
    }
}

/**
 * TShouldDelete equivalent
 * Ownership strategy
 */
export const VNOwnership = {
    NoDelete: 0,      // Don't delete contained objects
    Delete: 1         // Delete contained objects when container is destroyed
};

/**
 * VNVectorBase - Base vector implementation
 * Port of TVectorImpBase
 */
export class VNVectorBase {
    constructor() {
        this.data = [];
        this.limit = 0;
        this.delta = 10; // Growth increment
    }

    /**
     * Get count of items
     * @returns {number}
     */
    count() {
        return this.data.length;
    }

    /**
     * Get limit (capacity)
     * @returns {number}
     */
    getLimit() {
        return this.limit;
    }

    /**
     * Check if empty
     * @returns {boolean}
     */
    isEmpty() {
        return this.data.length === 0;
    }

    /**
     * Check bounds
     * @param {number} index 
     * @returns {boolean}
     */
    boundCheck(index) {
        return index >= 0 && index < this.data.length;
    }

    /**
     * Get item at index
     * @param {number} index 
     * @returns {*}
     */
    at(index) {
        return this.data[index];
    }

    /**
     * Set item at index
     * @param {number} index 
     * @param {*} item 
     */
    atPut(index, item) {
        if (index >= this.data.length) {
            this._grow(index + 1);
        }
        this.data[index] = item;
    }

    /**
     * Add item to end
     * @param {*} item 
     * @returns {number} - Index of added item
     */
    add(item) {
        this.data.push(item);
        return this.data.length - 1;
    }

    /**
     * Insert item at index
     * @param {number} index 
     * @param {*} item 
     */
    insert(index, item) {
        this.data.splice(index, 0, item);
    }

    /**
     * Remove item at index
     * @param {number} index 
     * @returns {*}
     */
    remove(index) {
        return this.data.splice(index, 1)[0];
    }

    /**
     * Remove item
     * @param {*} item 
     * @returns {boolean}
     */
    removeItem(item) {
        const index = this.data.indexOf(item);
        if (index !== -1) {
            this.data.splice(index, 1);
            return true;
        }
        return false;
    }

    /**
     * Clear all items
     */
    flush() {
        this.data = [];
    }

    /**
     * Find item index
     * @param {*} item 
     * @returns {number} - Index or -1
     */
    find(item) {
        return this.data.indexOf(item);
    }

    /**
     * Find with predicate
     * @param {Function} predicate 
     * @returns {*}
     */
    findWhere(predicate) {
        return this.data.find(predicate);
    }

    /**
     * Grow to new size
     * @private
     */
    _grow(minSize) {
        while (this.limit < minSize) {
            this.limit += this.delta;
        }
    }

    /**
     * Iterate over items
     * @param {Function} callback 
     */
    forEach(callback) {
        this.data.forEach(callback);
    }

    /**
     * Map items
     * @param {Function} callback 
     * @returns {Array}
     */
    map(callback) {
        return this.data.map(callback);
    }

    /**
     * Filter items
     * @param {Function} predicate 
     * @returns {Array}
     */
    filter(predicate) {
        return this.data.filter(predicate);
    }

    /**
     * Sort items
     * @param {Function} compareFn 
     */
    sort(compareFn) {
        this.data.sort(compareFn);
    }

    /**
     * Get iterator
     */
    [Symbol.iterator]() {
        return this.data[Symbol.iterator]();
    }
}

/**
 * VNArray - Dynamic array
 * Port of TArray<T>
 */
export class VNArray extends VNVectorBase {
    /**
     * @param {number} upperBound - Initial upper bound
     * @param {number} lowerBound - Lower bound (usually 0)
     * @param {number} delta - Growth delta
     */
    constructor(upperBound = 0, lowerBound = 0, delta = 10) {
        super();
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.delta = delta;
        
        if (upperBound > lowerBound) {
            this.data = new Array(upperBound - lowerBound + 1);
        }
    }

    /**
     * Get array bounds
     * @returns {{lower: number, upper: number}}
     */
    bounds() {
        return {
            lower: this.lowerBound,
            upper: this.lowerBound + this.data.length - 1
        };
    }

    /**
     * Resize array
     * @param {number} newSize 
     */
    resize(newSize) {
        this.data.length = newSize;
        this.upperBound = this.lowerBound + newSize - 1;
    }

    /**
     * Add item (adjusting bounds)
     * @param {*} item 
     * @returns {number}
     */
    add(item) {
        const index = super.add(item);
        this.upperBound = this.lowerBound + this.data.length - 1;
        return index + this.lowerBound;
    }

    /**
     * Has member
     * @param {*} item 
     * @returns {boolean}
     */
    hasMember(item) {
        return this.find(item) !== -1;
    }

    /**
     * First that matches
     * @param {Function} predicate 
     * @returns {*}
     */
    firstThat(predicate) {
        return this.findWhere(predicate);
    }

    /**
     * Last that matches
     * @param {Function} predicate 
     * @returns {*}
     */
    lastThat(predicate) {
        for (let i = this.data.length - 1; i >= 0; i--) {
            if (predicate(this.data[i])) {
                return this.data[i];
            }
        }
        return undefined;
    }

    /**
     * Destroy and flush
     */
    destroy() {
        this.flush();
    }
}

/**
 * VNSortedArray - Sorted array
 */
export class VNSortedArray extends VNArray {
    /**
     * @param {Function} compareFn - Comparison function
     */
    constructor(compareFn = (a, b) => a - b) {
        super();
        this.compareFn = compareFn;
    }

    /**
     * Add item (maintaining sort order)
     * @param {*} item 
     * @returns {number}
     */
    add(item) {
        // Binary search for insertion point
        let lo = 0;
        let hi = this.data.length;
        
        while (lo < hi) {
            const mid = (lo + hi) >>> 1;
            if (this.compareFn(this.data[mid], item) < 0) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        
        this.insert(lo, item);
        return lo;
    }

    /**
     * Binary search
     * @param {*} item 
     * @returns {number}
     */
    search(item) {
        let lo = 0;
        let hi = this.data.length - 1;
        
        while (lo <= hi) {
            const mid = (lo + hi) >>> 1;
            const cmp = this.compareFn(this.data[mid], item);
            
            if (cmp === 0) {
                return mid;
            } else if (cmp < 0) {
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        
        return -1;
    }
}

/**
 * VNStack - Stack (LIFO)
 */
export class VNStack {
    constructor() {
        this.data = [];
    }

    /**
     * Push item onto stack
     * @param {*} item 
     */
    push(item) {
        this.data.push(item);
    }

    /**
     * Pop item from stack
     * @returns {*}
     */
    pop() {
        return this.data.pop();
    }

    /**
     * Peek at top item
     * @returns {*}
     */
    top() {
        return this.data[this.data.length - 1];
    }

    /**
     * Check if empty
     * @returns {boolean}
     */
    isEmpty() {
        return this.data.length === 0;
    }

    /**
     * Get count
     * @returns {number}
     */
    count() {
        return this.data.length;
    }

    /**
     * Clear stack
     */
    flush() {
        this.data = [];
    }
}

/**
 * VNQueue - Queue (FIFO)
 */
export class VNQueue {
    constructor() {
        this.data = [];
    }

    /**
     * Enqueue item
     * @param {*} item 
     */
    enqueue(item) {
        this.data.push(item);
    }

    /**
     * Dequeue item
     * @returns {*}
     */
    dequeue() {
        return this.data.shift();
    }

    /**
     * Peek at front item
     * @returns {*}
     */
    front() {
        return this.data[0];
    }

    /**
     * Peek at back item
     * @returns {*}
     */
    back() {
        return this.data[this.data.length - 1];
    }

    /**
     * Check if empty
     * @returns {boolean}
     */
    isEmpty() {
        return this.data.length === 0;
    }

    /**
     * Get count
     * @returns {number}
     */
    count() {
        return this.data.length;
    }

    /**
     * Clear queue
     */
    flush() {
        this.data = [];
    }
}

/**
 * VNMap - Key-value map
 * Port of TMap/TDictionary
 */
export class VNMap {
    constructor() {
        this.data = new Map();
    }

    /**
     * Get value by key
     * @param {*} key 
     * @returns {*}
     */
    get(key) {
        return this.data.get(key);
    }

    /**
     * Set value
     * @param {*} key 
     * @param {*} value 
     */
    set(key, value) {
        this.data.set(key, value);
    }

    /**
     * Check if has key
     * @param {*} key 
     * @returns {boolean}
     */
    has(key) {
        return this.data.has(key);
    }

    /**
     * Remove by key
     * @param {*} key 
     * @returns {boolean}
     */
    remove(key) {
        return this.data.delete(key);
    }

    /**
     * Get all keys
     * @returns {Array}
     */
    keys() {
        return Array.from(this.data.keys());
    }

    /**
     * Get all values
     * @returns {Array}
     */
    values() {
        return Array.from(this.data.values());
    }

    /**
     * Get count
     * @returns {number}
     */
    count() {
        return this.data.size;
    }

    /**
     * Check if empty
     * @returns {boolean}
     */
    isEmpty() {
        return this.data.size === 0;
    }

    /**
     * Clear map
     */
    flush() {
        this.data.clear();
    }

    /**
     * Iterate
     * @param {Function} callback 
     */
    forEach(callback) {
        this.data.forEach(callback);
    }
}

/**
 * VNSet - Unique value set
 */
export class VNSet {
    constructor() {
        this.data = new Set();
    }

    /**
     * Add item
     * @param {*} item 
     * @returns {boolean} - True if added (wasn't present)
     */
    add(item) {
        const had = this.data.has(item);
        this.data.add(item);
        return !had;
    }

    /**
     * Remove item
     * @param {*} item 
     * @returns {boolean}
     */
    remove(item) {
        return this.data.delete(item);
    }

    /**
     * Check if has item
     * @param {*} item 
     * @returns {boolean}
     */
    has(item) {
        return this.data.has(item);
    }

    /**
     * Get count
     * @returns {number}
     */
    count() {
        return this.data.size;
    }

    /**
     * Check if empty
     * @returns {boolean}
     */
    isEmpty() {
        return this.data.size === 0;
    }

    /**
     * Clear set
     */
    flush() {
        this.data.clear();
    }

    /**
     * To array
     * @returns {Array}
     */
    toArray() {
        return Array.from(this.data);
    }

    /**
     * Iterate
     * @param {Function} callback 
     */
    forEach(callback) {
        this.data.forEach(callback);
    }

    /**
     * Union with another set
     * @param {VNSet} other 
     * @returns {VNSet}
     */
    union(other) {
        const result = new VNSet();
        this.data.forEach(item => result.add(item));
        other.data.forEach(item => result.add(item));
        return result;
    }

    /**
     * Intersection with another set
     * @param {VNSet} other 
     * @returns {VNSet}
     */
    intersection(other) {
        const result = new VNSet();
        this.data.forEach(item => {
            if (other.has(item)) {
                result.add(item);
            }
        });
        return result;
    }

    /**
     * Difference from another set
     * @param {VNSet} other 
     * @returns {VNSet}
     */
    difference(other) {
        const result = new VNSet();
        this.data.forEach(item => {
            if (!other.has(item)) {
                result.add(item);
            }
        });
        return result;
    }
}

export default {
    VNStandardAllocator,
    VNOwnership,
    VNVectorBase,
    VNArray,
    VNSortedArray,
    VNStack,
    VNQueue,
    VNMap,
    VNSet
};
