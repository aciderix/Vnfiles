/**
 * VNHotspotSystem - Hotspot and Click Detection System
 * 
 * EXACT PORT from hotspot.cpp functions
 * Main handler: fcn.00428373 (1742 bytes)
 * 
 * Classes ported:
 * - TVNHotspot (from 0x00414342)
 * - TVNHotspotArray (from 0x004142aa)
 * - TVNHotspotParms (from 0x00410ad2)
 * 
 * @original_file hotspot.cpp
 * @original_address 0x00428373
 */

/**
 * VNHotspotParms - Hotspot parameter structure
 * @original_address 0x00410ad2 (TVNHotspotParms)
 */
class VNHotspotParms {
    constructor() {
        // Parameters from command parsing
        this.name = '';           // hotspot name/id
        this.left = 0;            // rect left
        this.top = 0;             // rect top
        this.right = 0;           // rect right
        this.bottom = 0;          // rect bottom
        this.cursor = 'pointer';  // defcursor string at 0x0043f823
        this.onClick = '';        // EV_ONCLICK string at 0x0043f8da
        this.enabled = true;      // enabled flag
        this.visible = true;      // visible flag
        this.zorder = 0;          // z-order for layering
    }

    /**
     * Parse from command string
     * Format: hotspot,name,left,top,right,bottom[,cursor][,onclick]
     * @original_address command parsing in fcn.00428373
     */
    static parse(args) {
        const parms = new VNHotspotParms();
        
        if (!args || args.length === 0) {
            return parms;
        }

        // Parse comma-separated values
        const parts = args.split(',').map(s => s.trim());
        
        // name,left,top,right,bottom format
        if (parts.length >= 5) {
            parms.name = parts[0];
            parms.left = parseInt(parts[1]) || 0;
            parms.top = parseInt(parts[2]) || 0;
            parms.right = parseInt(parts[3]) || 0;
            parms.bottom = parseInt(parts[4]) || 0;
        }
        
        // Optional cursor
        if (parts.length >= 6) {
            parms.cursor = parts[5] || 'pointer';
        }
        
        // Optional onclick handler
        if (parts.length >= 7) {
            parms.onClick = parts[6];
        }

        return parms;
    }

    /**
     * Create rect from parameters
     */
    getRect() {
        return {
            left: this.left,
            top: this.top,
            right: this.right,
            bottom: this.bottom,
            width: this.right - this.left,
            height: this.bottom - this.top
        };
    }
}

/**
 * VNHotspot - Single hotspot object
 * @original_address 0x00414342 (TVNHotspot)
 */
class VNHotspot {
    // Hotspot ID counter for auto-naming (HOTSPOT_%u at 0x0044138a)
    static _idCounter = 0;

    constructor(parms = null) {
        // Generate unique ID
        this.id = VNHotspot._idCounter++;
        
        // Name (or auto-generated)
        this.name = parms?.name || `HOTSPOT_${this.id}`;
        
        // Bounding rectangle
        this.rect = {
            left: parms?.left || 0,
            top: parms?.top || 0,
            right: parms?.right || 0,
            bottom: parms?.bottom || 0
        };
        
        // Cursor to show on hover
        this.cursor = parms?.cursor || 'pointer';
        
        // Event handlers
        this.onClick = parms?.onClick || null;
        this.onEnter = null;
        this.onLeave = null;
        
        // State flags
        this.enabled = parms?.enabled !== false;
        this.visible = parms?.visible !== false;
        this.hovered = false;
        this.pressed = false;
        
        // Z-order for layering
        this.zorder = parms?.zorder || 0;
        
        // Associated data
        this.userData = null;
        
        // Reference to parent scene/container
        this.parent = null;
    }

    /**
     * Get width
     */
    get width() {
        return this.rect.right - this.rect.left;
    }

    /**
     * Get height
     */
    get height() {
        return this.rect.bottom - this.rect.top;
    }

    /**
     * Check if point is inside hotspot
     * @original_address point testing in handler
     */
    containsPoint(x, y) {
        if (!this.enabled || !this.visible) {
            return false;
        }
        return x >= this.rect.left && x < this.rect.right &&
               y >= this.rect.top && y < this.rect.bottom;
    }

    /**
     * Set rectangle from parameters
     */
    setRect(left, top, right, bottom) {
        this.rect.left = left;
        this.rect.top = top;
        this.rect.right = right;
        this.rect.bottom = bottom;
    }

    /**
     * Move hotspot by offset
     */
    move(dx, dy) {
        this.rect.left += dx;
        this.rect.right += dx;
        this.rect.top += dy;
        this.rect.bottom += dy;
    }

    /**
     * Handle mouse enter
     */
    handleEnter() {
        if (!this.enabled) return;
        
        this.hovered = true;
        
        if (this.onEnter) {
            if (typeof this.onEnter === 'function') {
                this.onEnter(this);
            } else if (typeof this.onEnter === 'string') {
                // Command string to execute
                return { command: this.onEnter, hotspot: this };
            }
        }
        return null;
    }

    /**
     * Handle mouse leave
     */
    handleLeave() {
        this.hovered = false;
        this.pressed = false;
        
        if (this.onLeave) {
            if (typeof this.onLeave === 'function') {
                this.onLeave(this);
            } else if (typeof this.onLeave === 'string') {
                return { command: this.onLeave, hotspot: this };
            }
        }
        return null;
    }

    /**
     * Handle click
     * @original_address EV_ONCLICK handling
     */
    handleClick() {
        if (!this.enabled) return null;
        
        if (this.onClick) {
            if (typeof this.onClick === 'function') {
                this.onClick(this);
            } else if (typeof this.onClick === 'string') {
                // Command string to execute (EV_ONCLICK)
                return { command: this.onClick, hotspot: this };
            }
        }
        return null;
    }

    /**
     * Handle mouse down
     */
    handleMouseDown() {
        if (!this.enabled) return;
        this.pressed = true;
    }

    /**
     * Handle mouse up
     */
    handleMouseUp() {
        const wasPressed = this.pressed;
        this.pressed = false;
        
        // Trigger click if was pressed and still hovered
        if (wasPressed && this.hovered) {
            return this.handleClick();
        }
        return null;
    }
}

/**
 * VNHotspotArray - Array/collection of hotspots
 * Port of TMIArrayAsVector<TVNHotspot,TStandardAllocator>
 * @original_address 0x004142aa (TVNHotspotArray)
 */
class VNHotspotArray {
    constructor() {
        // Internal array
        this.items = [];
        
        // Index by name for fast lookup
        this.byName = new Map();
    }

    /**
     * Get count
     */
    get length() {
        return this.items.length;
    }

    /**
     * Add hotspot
     * @original_address array add method
     */
    add(hotspot) {
        this.items.push(hotspot);
        
        if (hotspot.name) {
            this.byName.set(hotspot.name.toLowerCase(), hotspot);
        }
        
        // Sort by z-order
        this.items.sort((a, b) => a.zorder - b.zorder);
        
        return hotspot;
    }

    /**
     * Remove hotspot
     */
    remove(hotspot) {
        const index = this.items.indexOf(hotspot);
        if (index >= 0) {
            this.items.splice(index, 1);
            if (hotspot.name) {
                this.byName.delete(hotspot.name.toLowerCase());
            }
            return true;
        }
        return false;
    }

    /**
     * Get by index
     */
    get(index) {
        return this.items[index] || null;
    }

    /**
     * Find by name
     */
    findByName(name) {
        return this.byName.get(name.toLowerCase()) || null;
    }

    /**
     * Find hotspot at point (topmost)
     * @original_address point testing loop
     */
    findAtPoint(x, y) {
        // Iterate in reverse order (topmost first)
        for (let i = this.items.length - 1; i >= 0; i--) {
            const hotspot = this.items[i];
            if (hotspot.containsPoint(x, y)) {
                return hotspot;
            }
        }
        return null;
    }

    /**
     * Find all hotspots at point
     */
    findAllAtPoint(x, y) {
        const result = [];
        for (const hotspot of this.items) {
            if (hotspot.containsPoint(x, y)) {
                result.push(hotspot);
            }
        }
        return result;
    }

    /**
     * Clear all hotspots
     */
    clear() {
        this.items = [];
        this.byName.clear();
    }

    /**
     * Iterate over hotspots
     */
    forEach(callback) {
        this.items.forEach(callback);
    }

    /**
     * Get iterator
     */
    [Symbol.iterator]() {
        return this.items[Symbol.iterator]();
    }
}

/**
 * VNHotspotManager - Main hotspot management system
 * Port of fcn.00428373 and related functions
 * @original_address 0x00428373
 */
class VNHotspotManager {
    constructor(engine) {
        this.engine = engine;
        
        // Hotspot collection
        this.hotspots = new VNHotspotArray();
        
        // Currently hovered hotspot
        this.hoveredHotspot = null;
        
        // Currently pressed hotspot
        this.pressedHotspot = null;
        
        // Default cursor (DEFCURSOR at 0x0044298a)
        this.defaultCursor = 'default';
        
        // Current cursor
        this.currentCursor = this.defaultCursor;
        
        // Global flags from [0x44ec4c]
        this.globalFlags = 0;
        
        // Event listeners
        this._boundMouseMove = this._onMouseMove.bind(this);
        this._boundMouseDown = this._onMouseDown.bind(this);
        this._boundMouseUp = this._onMouseUp.bind(this);
        this._boundClick = this._onClick.bind(this);
    }

    /**
     * Initialize and attach event listeners
     * @original_address initialization section
     */
    initialize(canvas) {
        this.canvas = canvas;
        
        canvas.addEventListener('mousemove', this._boundMouseMove);
        canvas.addEventListener('mousedown', this._boundMouseDown);
        canvas.addEventListener('mouseup', this._boundMouseUp);
        canvas.addEventListener('click', this._boundClick);
        
        return this;
    }

    /**
     * Cleanup
     */
    destroy() {
        if (this.canvas) {
            this.canvas.removeEventListener('mousemove', this._boundMouseMove);
            this.canvas.removeEventListener('mousedown', this._boundMouseDown);
            this.canvas.removeEventListener('mouseup', this._boundMouseUp);
            this.canvas.removeEventListener('click', this._boundClick);
        }
        
        this.hotspots.clear();
    }

    /**
     * Create hotspot from parameters
     * @original_address hotspot creation in handler
     */
    createHotspot(parms) {
        const hotspot = new VNHotspot(parms);
        hotspot.parent = this;
        this.hotspots.add(hotspot);
        return hotspot;
    }

    /**
     * Create hotspot from command string
     * @param argsString Command arguments string
     */
    createFromCommand(argsString) {
        const parms = VNHotspotParms.parse(argsString);
        return this.createHotspot(parms);
    }

    /**
     * Remove hotspot
     */
    removeHotspot(hotspot) {
        if (this.hoveredHotspot === hotspot) {
            this.hoveredHotspot = null;
            this._updateCursor();
        }
        return this.hotspots.remove(hotspot);
    }

    /**
     * Remove hotspot by name
     */
    removeByName(name) {
        const hotspot = this.hotspots.findByName(name);
        if (hotspot) {
            return this.removeHotspot(hotspot);
        }
        return false;
    }

    /**
     * Clear all hotspots
     * @original_address NHOTSPOT command handler
     */
    clearAll() {
        this.hoveredHotspot = null;
        this.pressedHotspot = null;
        this.hotspots.clear();
        this._updateCursor();
    }

    /**
     * Get canvas-relative coordinates
     */
    _getCanvasCoords(event) {
        const rect = this.canvas.getBoundingClientRect();
        return {
            x: event.clientX - rect.left,
            y: event.clientY - rect.top
        };
    }

    /**
     * Mouse move handler
     * @original_address cursor handling section
     */
    _onMouseMove(event) {
        const coords = this._getCanvasCoords(event);
        const hotspot = this.hotspots.findAtPoint(coords.x, coords.y);
        
        // Handle leave
        if (this.hoveredHotspot && this.hoveredHotspot !== hotspot) {
            const result = this.hoveredHotspot.handleLeave();
            if (result && result.command) {
                this._executeCommand(result.command);
            }
        }
        
        // Handle enter
        if (hotspot && hotspot !== this.hoveredHotspot) {
            const result = hotspot.handleEnter();
            if (result && result.command) {
                this._executeCommand(result.command);
            }
        }
        
        this.hoveredHotspot = hotspot;
        this._updateCursor();
    }

    /**
     * Mouse down handler
     */
    _onMouseDown(event) {
        if (event.button !== 0) return; // Left button only
        
        const coords = this._getCanvasCoords(event);
        const hotspot = this.hotspots.findAtPoint(coords.x, coords.y);
        
        if (hotspot) {
            hotspot.handleMouseDown();
            this.pressedHotspot = hotspot;
        }
    }

    /**
     * Mouse up handler
     */
    _onMouseUp(event) {
        if (event.button !== 0) return;
        
        if (this.pressedHotspot) {
            const result = this.pressedHotspot.handleMouseUp();
            if (result && result.command) {
                this._executeCommand(result.command);
            }
            this.pressedHotspot = null;
        }
    }

    /**
     * Click handler (backup for click event)
     */
    _onClick(event) {
        // Click is already handled by mouseup, but this is a backup
        const coords = this._getCanvasCoords(event);
        const hotspot = this.hotspots.findAtPoint(coords.x, coords.y);
        
        if (hotspot && hotspot.enabled) {
            // Only trigger if not already triggered by mouseup
            if (!this.pressedHotspot) {
                const result = hotspot.handleClick();
                if (result && result.command) {
                    this._executeCommand(result.command);
                }
            }
        }
    }

    /**
     * Update cursor based on hovered hotspot
     * @original_address cursor update at 0x0042843f
     */
    _updateCursor() {
        if (this.hoveredHotspot && this.hoveredHotspot.enabled) {
            this.currentCursor = this.hoveredHotspot.cursor;
        } else {
            this.currentCursor = this.defaultCursor;
        }
        
        if (this.canvas) {
            this.canvas.style.cursor = this.currentCursor;
        }
    }

    /**
     * Execute command string
     * @original_address command execution in handler
     */
    _executeCommand(command) {
        if (this.engine && this.engine.executeCommand) {
            this.engine.executeCommand(command);
        }
    }

    /**
     * Render hotspots (debug mode)
     */
    renderDebug(ctx) {
        ctx.save();
        
        for (const hotspot of this.hotspots) {
            if (!hotspot.visible) continue;
            
            // Draw rectangle
            ctx.strokeStyle = hotspot.enabled ? 
                (hotspot.hovered ? '#00ff00' : '#0000ff') : '#888888';
            ctx.lineWidth = hotspot.hovered ? 2 : 1;
            
            ctx.strokeRect(
                hotspot.rect.left,
                hotspot.rect.top,
                hotspot.width,
                hotspot.height
            );
            
            // Draw name
            ctx.fillStyle = '#ffffff';
            ctx.font = '10px Arial';
            ctx.fillText(
                hotspot.name,
                hotspot.rect.left + 2,
                hotspot.rect.top + 12
            );
        }
        
        ctx.restore();
    }

    /**
     * Enable/disable hotspot by name
     */
    setEnabled(name, enabled) {
        const hotspot = this.hotspots.findByName(name);
        if (hotspot) {
            hotspot.enabled = enabled;
            if (!enabled && this.hoveredHotspot === hotspot) {
                this.hoveredHotspot = null;
                this._updateCursor();
            }
        }
    }

    /**
     * Show/hide hotspot by name
     */
    setVisible(name, visible) {
        const hotspot = this.hotspots.findByName(name);
        if (hotspot) {
            hotspot.visible = visible;
            if (!visible && this.hoveredHotspot === hotspot) {
                this.hoveredHotspot = null;
                this._updateCursor();
            }
        }
    }

    /**
     * Get hotspot by name
     */
    getByName(name) {
        return this.hotspots.findByName(name);
    }

    /**
     * Get all hotspots
     */
    getAll() {
        return this.hotspots.items.slice();
    }
}

/**
 * VNCursor - Cursor management
 * Port of cursor handling code
 * @original_address LoadCursorA/LoadCursorFromFileA imports
 */
class VNCursor {
    // Standard cursor mappings
    static CURSORS = {
        'default': 'default',
        'pointer': 'pointer',
        'hand': 'pointer',
        'text': 'text',
        'wait': 'wait',
        'progress': 'progress',
        'help': 'help',
        'crosshair': 'crosshair',
        'move': 'move',
        'not-allowed': 'not-allowed',
        'no-drop': 'no-drop',
        'grab': 'grab',
        'grabbing': 'grabbing',
        'zoom-in': 'zoom-in',
        'zoom-out': 'zoom-out',
        // Resize cursors
        'n-resize': 'n-resize',
        's-resize': 's-resize',
        'e-resize': 'e-resize',
        'w-resize': 'w-resize',
        'ne-resize': 'ne-resize',
        'nw-resize': 'nw-resize',
        'se-resize': 'se-resize',
        'sw-resize': 'sw-resize',
        'ew-resize': 'ew-resize',
        'ns-resize': 'ns-resize',
        'nesw-resize': 'nesw-resize',
        'nwse-resize': 'nwse-resize',
        'col-resize': 'col-resize',
        'row-resize': 'row-resize'
    };

    // Custom cursor cache
    static _customCursors = new Map();

    /**
     * Get CSS cursor value
     * @param cursorName Cursor name or URL
     */
    static getCursor(cursorName) {
        // Check standard cursors
        const standard = this.CURSORS[cursorName.toLowerCase()];
        if (standard) {
            return standard;
        }

        // Check custom cursor cache
        if (this._customCursors.has(cursorName)) {
            return this._customCursors.get(cursorName);
        }

        // Assume it's a URL/file path
        if (cursorName.includes('.') || cursorName.includes('/')) {
            const cursorUrl = `url(${cursorName}), auto`;
            this._customCursors.set(cursorName, cursorUrl);
            return cursorUrl;
        }

        return 'default';
    }

    /**
     * Load custom cursor from file
     * @original_address LoadCursorFromFileA
     */
    static loadFromFile(path) {
        // In web context, we use CSS cursor with URL
        const cursorUrl = `url(${path}), auto`;
        this._customCursors.set(path, cursorUrl);
        return cursorUrl;
    }

    /**
     * Preload cursor image
     */
    static preload(path) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(path);
            img.onerror = reject;
            img.src = path;
        });
    }
}

// Export all classes
export {
    VNHotspotParms,
    VNHotspot,
    VNHotspotArray,
    VNHotspotManager,
    VNCursor
};
