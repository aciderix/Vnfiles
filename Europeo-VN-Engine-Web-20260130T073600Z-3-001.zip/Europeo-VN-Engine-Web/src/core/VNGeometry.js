/**
 * VNGeometry - Geometry classes (TRect, TPoint, TSize, TRegion)
 * 
 * EXACT PORT from OWL (Object Windows Library) geometry classes
 * Based on Borland C++ structures
 * 
 * Original methods from disassembly:
 * - @TRect@$brand$qrx5TRect @ 0x0004eb0a (AND operation)
 * - @TRect@Offset$qii @ 0x0004eb5a
 * - @TRect@Normalize$qv @ 0x0004eb8a
 * - @TRect@Inflate$qii @ 0x0004ebea
 * - @TRect@$bror$qrx5TRect @ 0x0004ecac (OR operation)
 * - @TWindow@GetWindowRect$xqr5TRect @ 0x000500c0
 * - @TWindow@GetClientRect$xqr5TRect @ 0x00050134
 */

/**
 * VNPoint - Point structure
 * Port of TPoint (Windows POINT structure)
 */
export class VNPoint {
    /**
     * @param {number} x 
     * @param {number} y 
     */
    constructor(x = 0, y = 0) {
        this.x = x;
        this.y = y;
    }

    /**
     * Create from object
     * @param {{x: number, y: number}} obj 
     * @returns {VNPoint}
     */
    static from(obj) {
        return new VNPoint(obj.x || 0, obj.y || 0);
    }

    /**
     * Clone this point
     * @returns {VNPoint}
     */
    clone() {
        return new VNPoint(this.x, this.y);
    }

    /**
     * Offset point by dx, dy
     * @param {number} dx 
     * @param {number} dy 
     * @returns {VNPoint}
     */
    offset(dx, dy) {
        this.x += dx;
        this.y += dy;
        return this;
    }

    /**
     * Add another point
     * @param {VNPoint} other 
     * @returns {VNPoint}
     */
    add(other) {
        return new VNPoint(this.x + other.x, this.y + other.y);
    }

    /**
     * Subtract another point
     * @param {VNPoint} other 
     * @returns {VNPoint}
     */
    subtract(other) {
        return new VNPoint(this.x - other.x, this.y - other.y);
    }

    /**
     * Check equality
     * @param {VNPoint} other 
     * @returns {boolean}
     */
    equals(other) {
        return this.x === other.x && this.y === other.y;
    }

    /**
     * Distance to another point
     * @param {VNPoint} other 
     * @returns {number}
     */
    distanceTo(other) {
        const dx = this.x - other.x;
        const dy = this.y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Convert to plain object
     * @returns {{x: number, y: number}}
     */
    toObject() {
        return { x: this.x, y: this.y };
    }

    toString() {
        return `(${this.x}, ${this.y})`;
    }
}

/**
 * VNSize - Size structure
 * Port of TSize (Windows SIZE structure)
 */
export class VNSize {
    /**
     * @param {number} cx - Width
     * @param {number} cy - Height
     */
    constructor(cx = 0, cy = 0) {
        this.cx = cx;
        this.cy = cy;
    }

    /**
     * Create from object
     * @param {{cx: number, cy: number}|{width: number, height: number}} obj 
     * @returns {VNSize}
     */
    static from(obj) {
        if ('width' in obj) {
            return new VNSize(obj.width, obj.height);
        }
        return new VNSize(obj.cx || 0, obj.cy || 0);
    }

    /**
     * Clone this size
     * @returns {VNSize}
     */
    clone() {
        return new VNSize(this.cx, this.cy);
    }

    /**
     * Get width (alias for cx)
     */
    get width() {
        return this.cx;
    }

    set width(value) {
        this.cx = value;
    }

    /**
     * Get height (alias for cy)
     */
    get height() {
        return this.cy;
    }

    set height(value) {
        this.cy = value;
    }

    /**
     * Check if empty (zero area)
     * @returns {boolean}
     */
    isEmpty() {
        return this.cx <= 0 || this.cy <= 0;
    }

    /**
     * Check equality
     * @param {VNSize} other 
     * @returns {boolean}
     */
    equals(other) {
        return this.cx === other.cx && this.cy === other.cy;
    }

    /**
     * Scale by factor
     * @param {number} factor 
     * @returns {VNSize}
     */
    scale(factor) {
        return new VNSize(this.cx * factor, this.cy * factor);
    }

    /**
     * Convert to plain object
     * @returns {{cx: number, cy: number}}
     */
    toObject() {
        return { cx: this.cx, cy: this.cy };
    }

    toString() {
        return `${this.cx}x${this.cy}`;
    }
}

/**
 * VNRect - Rectangle structure
 * Port of TRect (Windows RECT structure)
 * 
 * EXACT implementation of OWL TRect methods
 */
export class VNRect {
    /**
     * @param {number} left 
     * @param {number} top 
     * @param {number} right 
     * @param {number} bottom 
     */
    constructor(left = 0, top = 0, right = 0, bottom = 0) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    /**
     * Create from object
     * @param {{left: number, top: number, right: number, bottom: number}} obj 
     * @returns {VNRect}
     */
    static from(obj) {
        return new VNRect(
            obj.left || 0,
            obj.top || 0,
            obj.right || 0,
            obj.bottom || 0
        );
    }

    /**
     * Create from position and size
     * @param {number} x 
     * @param {number} y 
     * @param {number} width 
     * @param {number} height 
     * @returns {VNRect}
     */
    static fromXYWH(x, y, width, height) {
        return new VNRect(x, y, x + width, y + height);
    }

    /**
     * Create from two points
     * @param {VNPoint} topLeft 
     * @param {VNPoint} bottomRight 
     * @returns {VNRect}
     */
    static fromPoints(topLeft, bottomRight) {
        return new VNRect(topLeft.x, topLeft.y, bottomRight.x, bottomRight.y);
    }

    /**
     * Clone this rectangle
     * @returns {VNRect}
     */
    clone() {
        return new VNRect(this.left, this.top, this.right, this.bottom);
    }

    /**
     * Get width
     * @returns {number}
     */
    get width() {
        return this.right - this.left;
    }

    set width(value) {
        this.right = this.left + value;
    }

    /**
     * Get height
     * @returns {number}
     */
    get height() {
        return this.bottom - this.top;
    }

    set height(value) {
        this.bottom = this.top + value;
    }

    /**
     * Get top-left point
     * @returns {VNPoint}
     */
    topLeft() {
        return new VNPoint(this.left, this.top);
    }

    /**
     * Get top-right point
     * @returns {VNPoint}
     */
    topRight() {
        return new VNPoint(this.right, this.top);
    }

    /**
     * Get bottom-left point
     * @returns {VNPoint}
     */
    bottomLeft() {
        return new VNPoint(this.left, this.bottom);
    }

    /**
     * Get bottom-right point
     * @returns {VNPoint}
     */
    bottomRight() {
        return new VNPoint(this.right, this.bottom);
    }

    /**
     * Get center point
     * @returns {VNPoint}
     */
    center() {
        return new VNPoint(
            (this.left + this.right) / 2,
            (this.top + this.bottom) / 2
        );
    }

    /**
     * Get size
     * @returns {VNSize}
     */
    size() {
        return new VNSize(this.width, this.height);
    }

    /**
     * Normalize rectangle (ensure left < right, top < bottom)
     * Port of @TRect@Normalize$qv @ 0x0004eb8a
     * @returns {VNRect}
     */
    normalize() {
        // Original ASM:
        // mov eax, [this+left]
        // cmp eax, [this+right]
        // jle .no_swap_x
        // xchg eax, [this+right]
        // mov [this+left], eax
        // .no_swap_x:
        // mov eax, [this+top]
        // cmp eax, [this+bottom]
        // jle .no_swap_y
        // xchg eax, [this+bottom]
        // mov [this+top], eax
        // .no_swap_y:
        // ret
        
        if (this.left > this.right) {
            [this.left, this.right] = [this.right, this.left];
        }
        if (this.top > this.bottom) {
            [this.top, this.bottom] = [this.bottom, this.top];
        }
        return this;
    }

    /**
     * Offset rectangle by dx, dy
     * Port of @TRect@Offset$qii @ 0x0004eb5a
     * @param {number} dx 
     * @param {number} dy 
     * @returns {VNRect}
     */
    offset(dx, dy) {
        // Original ASM:
        // mov eax, [esp+4]    ; dx
        // add [this+left], eax
        // add [this+right], eax
        // mov eax, [esp+8]    ; dy
        // add [this+top], eax
        // add [this+bottom], eax
        // ret
        
        this.left += dx;
        this.right += dx;
        this.top += dy;
        this.bottom += dy;
        return this;
    }

    /**
     * Inflate rectangle by dx, dy
     * Port of @TRect@Inflate$qii @ 0x0004ebea
     * @param {number} dx 
     * @param {number} dy 
     * @returns {VNRect}
     */
    inflate(dx, dy) {
        // Original ASM:
        // mov eax, [esp+4]    ; dx
        // sub [this+left], eax
        // add [this+right], eax
        // mov eax, [esp+8]    ; dy
        // sub [this+top], eax
        // add [this+bottom], eax
        // ret
        
        this.left -= dx;
        this.right += dx;
        this.top -= dy;
        this.bottom += dy;
        return this;
    }

    /**
     * Deflate rectangle by dx, dy
     * @param {number} dx 
     * @param {number} dy 
     * @returns {VNRect}
     */
    deflate(dx, dy) {
        return this.inflate(-dx, -dy);
    }

    /**
     * Set to empty (0,0,0,0)
     * @returns {VNRect}
     */
    setEmpty() {
        this.left = this.top = this.right = this.bottom = 0;
        return this;
    }

    /**
     * Check if rectangle is empty
     * @returns {boolean}
     */
    isEmpty() {
        return this.left >= this.right || this.top >= this.bottom;
    }

    /**
     * Check if rectangle is null (all zeros)
     * @returns {boolean}
     */
    isNull() {
        return this.left === 0 && this.top === 0 && 
               this.right === 0 && this.bottom === 0;
    }

    /**
     * Check if point is inside rectangle
     * @param {VNPoint|{x: number, y: number}} point 
     * @returns {boolean}
     */
    contains(point) {
        return point.x >= this.left && point.x < this.right &&
               point.y >= this.top && point.y < this.bottom;
    }

    /**
     * Check if another rectangle is inside this one
     * @param {VNRect} other 
     * @returns {boolean}
     */
    containsRect(other) {
        return other.left >= this.left && other.right <= this.right &&
               other.top >= this.top && other.bottom <= this.bottom;
    }

    /**
     * Check if this rectangle touches another
     * @param {VNRect} other 
     * @returns {boolean}
     */
    touches(other) {
        return this.left < other.right && this.right > other.left &&
               this.top < other.bottom && this.bottom > other.top;
    }

    /**
     * Intersect with another rectangle (AND operation)
     * Port of @TRect@$brand$qrx5TRect @ 0x0004eb0a
     * @param {VNRect} other 
     * @returns {VNRect}
     */
    intersect(other) {
        // Original ASM (operator &=):
        // mov eax, [other+left]
        // cmp eax, [this+left]
        // jle .no_left
        // mov [this+left], eax
        // .no_left:
        // mov eax, [other+top]
        // cmp eax, [this+top]
        // jle .no_top
        // mov [this+top], eax
        // .no_top:
        // mov eax, [other+right]
        // cmp eax, [this+right]
        // jge .no_right
        // mov [this+right], eax
        // .no_right:
        // mov eax, [other+bottom]
        // cmp eax, [this+bottom]
        // jge .no_bottom
        // mov [this+bottom], eax
        // .no_bottom:
        // ret
        
        this.left = Math.max(this.left, other.left);
        this.top = Math.max(this.top, other.top);
        this.right = Math.min(this.right, other.right);
        this.bottom = Math.min(this.bottom, other.bottom);
        return this;
    }

    /**
     * Union with another rectangle (OR operation)
     * Port of @TRect@$bror$qrx5TRect @ 0x0004ecac
     * @param {VNRect} other 
     * @returns {VNRect}
     */
    union(other) {
        // Original ASM (operator |=):
        // mov eax, [other+left]
        // cmp eax, [this+left]
        // jge .no_left
        // mov [this+left], eax
        // .no_left:
        // mov eax, [other+top]
        // cmp eax, [this+top]
        // jge .no_top
        // mov [this+top], eax
        // .no_top:
        // mov eax, [other+right]
        // cmp eax, [this+right]
        // jle .no_right
        // mov [this+right], eax
        // .no_right:
        // mov eax, [other+bottom]
        // cmp eax, [this+bottom]
        // jle .no_bottom
        // mov [this+bottom], eax
        // .no_bottom:
        // ret
        
        this.left = Math.min(this.left, other.left);
        this.top = Math.min(this.top, other.top);
        this.right = Math.max(this.right, other.right);
        this.bottom = Math.max(this.bottom, other.bottom);
        return this;
    }

    /**
     * Get intersection with another rectangle (non-mutating)
     * @param {VNRect} other 
     * @returns {VNRect}
     */
    getIntersection(other) {
        return this.clone().intersect(other);
    }

    /**
     * Get union with another rectangle (non-mutating)
     * @param {VNRect} other 
     * @returns {VNRect}
     */
    getUnion(other) {
        return this.clone().union(other);
    }

    /**
     * Check equality
     * @param {VNRect} other 
     * @returns {boolean}
     */
    equals(other) {
        return this.left === other.left && this.top === other.top &&
               this.right === other.right && this.bottom === other.bottom;
    }

    /**
     * Move to position (keeping size)
     * @param {number} x 
     * @param {number} y 
     * @returns {VNRect}
     */
    moveTo(x, y) {
        const w = this.width;
        const h = this.height;
        this.left = x;
        this.top = y;
        this.right = x + w;
        this.bottom = y + h;
        return this;
    }

    /**
     * Resize rectangle (keeping position)
     * @param {number} width 
     * @param {number} height 
     * @returns {VNRect}
     */
    resize(width, height) {
        this.right = this.left + width;
        this.bottom = this.top + height;
        return this;
    }

    /**
     * Scale rectangle
     * @param {number} factorX 
     * @param {number} factorY 
     * @returns {VNRect}
     */
    scale(factorX, factorY = factorX) {
        const cx = this.center().x;
        const cy = this.center().y;
        const hw = (this.width * factorX) / 2;
        const hh = (this.height * factorY) / 2;
        this.left = cx - hw;
        this.right = cx + hw;
        this.top = cy - hh;
        this.bottom = cy + hh;
        return this;
    }

    /**
     * Convert to plain object
     * @returns {{left: number, top: number, right: number, bottom: number}}
     */
    toObject() {
        return {
            left: this.left,
            top: this.top,
            right: this.right,
            bottom: this.bottom
        };
    }

    /**
     * Convert to XYWH format
     * @returns {{x: number, y: number, width: number, height: number}}
     */
    toXYWH() {
        return {
            x: this.left,
            y: this.top,
            width: this.width,
            height: this.height
        };
    }

    /**
     * Convert to CSS string
     * @returns {string}
     */
    toCSSRect() {
        return `rect(${this.top}px, ${this.right}px, ${this.bottom}px, ${this.left}px)`;
    }

    toString() {
        return `[${this.left}, ${this.top}, ${this.right}, ${this.bottom}]`;
    }
}

/**
 * VNRegion - Region structure for complex shapes
 * Port of TRegion
 * 
 * Uses a simplified polygon representation
 */
export class VNRegion {
    constructor() {
        this.rects = []; // Array of VNRect
        this.bounds = new VNRect();
    }

    /**
     * Create from rectangle
     * @param {VNRect} rect 
     * @returns {VNRegion}
     */
    static fromRect(rect) {
        const region = new VNRegion();
        region.rects.push(rect.clone());
        region.bounds = rect.clone();
        return region;
    }

    /**
     * Create from array of rectangles
     * @param {VNRect[]} rects 
     * @returns {VNRegion}
     */
    static fromRects(rects) {
        const region = new VNRegion();
        for (const rect of rects) {
            region.addRect(rect);
        }
        return region;
    }

    /**
     * Add rectangle to region
     * @param {VNRect} rect 
     */
    addRect(rect) {
        this.rects.push(rect.clone());
        if (this.rects.length === 1) {
            this.bounds = rect.clone();
        } else {
            this.bounds.union(rect);
        }
    }

    /**
     * Check if point is inside region
     * @param {VNPoint|{x: number, y: number}} point 
     * @returns {boolean}
     */
    contains(point) {
        if (!this.bounds.contains(point)) {
            return false;
        }
        for (const rect of this.rects) {
            if (rect.contains(point)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get bounding rectangle
     * @returns {VNRect}
     */
    getBounds() {
        return this.bounds.clone();
    }

    /**
     * Check if region is empty
     * @returns {boolean}
     */
    isEmpty() {
        return this.rects.length === 0;
    }

    /**
     * Clear region
     */
    clear() {
        this.rects = [];
        this.bounds.setEmpty();
    }

    /**
     * Offset region
     * @param {number} dx 
     * @param {number} dy 
     */
    offset(dx, dy) {
        for (const rect of this.rects) {
            rect.offset(dx, dy);
        }
        this.bounds.offset(dx, dy);
    }

    /**
     * Combine with another region (union)
     * @param {VNRegion} other 
     */
    combine(other) {
        for (const rect of other.rects) {
            this.addRect(rect);
        }
    }

    /**
     * Subtract another region
     * @param {VNRegion} other 
     */
    subtract(other) {
        // Simplified: remove overlapping rectangles
        this.rects = this.rects.filter(rect => {
            for (const otherRect of other.rects) {
                if (rect.touches(otherRect)) {
                    return false;
                }
            }
            return true;
        });
        this.recalculateBounds();
    }

    /**
     * Recalculate bounding rectangle
     */
    recalculateBounds() {
        if (this.rects.length === 0) {
            this.bounds.setEmpty();
            return;
        }
        this.bounds = this.rects[0].clone();
        for (let i = 1; i < this.rects.length; i++) {
            this.bounds.union(this.rects[i]);
        }
    }
}

/**
 * Utility functions for geometry
 */
export const VNGeometryUtils = {
    /**
     * Calculate distance between two points
     * @param {VNPoint} p1 
     * @param {VNPoint} p2 
     * @returns {number}
     */
    distance(p1, p2) {
        return p1.distanceTo(p2);
    },

    /**
     * Calculate angle between two points (in radians)
     * @param {VNPoint} p1 
     * @param {VNPoint} p2 
     * @returns {number}
     */
    angle(p1, p2) {
        return Math.atan2(p2.y - p1.y, p2.x - p1.x);
    },

    /**
     * Check if two rectangles intersect
     * @param {VNRect} r1 
     * @param {VNRect} r2 
     * @returns {boolean}
     */
    rectsIntersect(r1, r2) {
        return r1.touches(r2);
    },

    /**
     * Calculate intersection area
     * @param {VNRect} r1 
     * @param {VNRect} r2 
     * @returns {number}
     */
    intersectionArea(r1, r2) {
        const intersection = r1.getIntersection(r2);
        if (intersection.isEmpty()) {
            return 0;
        }
        return intersection.width * intersection.height;
    },

    /**
     * Clamp point to rectangle bounds
     * @param {VNPoint} point 
     * @param {VNRect} bounds 
     * @returns {VNPoint}
     */
    clampPoint(point, bounds) {
        return new VNPoint(
            Math.max(bounds.left, Math.min(bounds.right - 1, point.x)),
            Math.max(bounds.top, Math.min(bounds.bottom - 1, point.y))
        );
    },

    /**
     * Lerp between two points
     * @param {VNPoint} p1 
     * @param {VNPoint} p2 
     * @param {number} t - 0 to 1
     * @returns {VNPoint}
     */
    lerp(p1, p2, t) {
        return new VNPoint(
            p1.x + (p2.x - p1.x) * t,
            p1.y + (p2.y - p1.y) * t
        );
    },

    /**
     * Convert degrees to radians
     * @param {number} degrees 
     * @returns {number}
     */
    degToRad(degrees) {
        return degrees * Math.PI / 180;
    },

    /**
     * Convert radians to degrees
     * @param {number} radians 
     * @returns {number}
     */
    radToDeg(radians) {
        return radians * 180 / Math.PI;
    }
};

export default {
    VNPoint,
    VNSize,
    VNRect,
    VNRegion,
    VNGeometryUtils
};
