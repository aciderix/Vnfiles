/**
 * VNHistory - History and navigation classes
 * 
 * Port of TVNHistData, THistQueue<TVNHistData> from europeo.exe
 * Manages scene navigation history for back/forward functionality
 * 
 * Original classes:
 * - THistQueue<TVNHistData> - Template queue for history
 * - TVNHistData - History data structure (scene + state)
 */

import { VNStreamable } from './VNObject.js';

/**
 * TVNHistData - History data structure
 * Stores scene state for back/forward navigation
 */
export class VNHistData extends VNStreamable {
    constructor(options = {}) {
        super();
        
        // Scene identification
        this.sceneIndex = options.sceneIndex ?? -1;
        this.sceneName = options.sceneName || '';
        
        // Navigation state
        this.commandIndex = options.commandIndex ?? 0;
        this.timestamp = options.timestamp || Date.now();
        
        // Variable snapshot (for state restoration)
        this.variableSnapshot = options.variableSnapshot || {};
        
        // Media state
        this.mediaState = options.mediaState || {
            bgm: null,
            bgmPosition: 0,
            sounds: []
        };
        
        // Display state
        this.displayState = options.displayState || {
            objects: [],
            hotspots: [],
            dialogVisible: false
        };
        
        // Scroll/zoom position
        this.viewportState = options.viewportState || {
            scrollX: 0,
            scrollY: 0,
            zoomLevel: 1
        };
    }

    /**
     * Create from current engine state
     */
    static fromEngineState(engine, sceneIndex) {
        const histData = new VNHistData({
            sceneIndex: sceneIndex,
            sceneName: engine.currentScene?.name || '',
            commandIndex: engine.commandIndex || 0,
            timestamp: Date.now()
        });
        
        // Snapshot variables
        if (engine.variables) {
            histData.variableSnapshot = engine.variables.getAll 
                ? { ...engine.variables.getAll() }
                : {};
        }
        
        // Snapshot media state
        if (engine.audio) {
            histData.mediaState = {
                bgm: engine.audio.currentBgm,
                bgmPosition: engine.audio.bgmPosition || 0,
                sounds: []
            };
        }
        
        return histData;
    }

    /**
     * Restore state to engine
     */
    restoreToEngine(engine) {
        // Restore variables
        if (engine.variables && this.variableSnapshot) {
            for (const [name, value] of Object.entries(this.variableSnapshot)) {
                engine.variables.set(name, value);
            }
        }
        
        // Restore media state
        if (engine.audio && this.mediaState.bgm) {
            engine.audio.playBgm(this.mediaState.bgm, {
                startTime: this.mediaState.bgmPosition
            });
        }
    }

    /**
     * Serialize for save
     */
    toJSON() {
        return {
            sceneIndex: this.sceneIndex,
            sceneName: this.sceneName,
            commandIndex: this.commandIndex,
            timestamp: this.timestamp,
            variableSnapshot: this.variableSnapshot,
            mediaState: this.mediaState,
            displayState: this.displayState,
            viewportState: this.viewportState
        };
    }

    /**
     * Deserialize from save
     */
    static fromJSON(data) {
        return new VNHistData(data);
    }
}

/**
 * THistQueue - History queue (template class port)
 * Circular buffer for navigation history
 */
export class VNHistQueue extends VNStreamable {
    constructor(maxSize = 50) {
        super();
        
        this._maxSize = maxSize;
        this._items = [];
        this._currentIndex = -1;
    }

    /**
     * Get current size
     */
    get size() {
        return this._items.length;
    }

    /**
     * Get max size
     */
    get maxSize() {
        return this._maxSize;
    }

    /**
     * Check if empty
     */
    get isEmpty() {
        return this._items.length === 0;
    }

    /**
     * Get current index
     */
    get currentIndex() {
        return this._currentIndex;
    }

    /**
     * Can go back?
     */
    get canGoBack() {
        return this._currentIndex > 0;
    }

    /**
     * Can go forward?
     */
    get canGoForward() {
        return this._currentIndex < this._items.length - 1;
    }

    /**
     * Push new history entry
     * Clears forward history if not at end
     */
    push(item) {
        // Remove forward history
        if (this._currentIndex < this._items.length - 1) {
            this._items = this._items.slice(0, this._currentIndex + 1);
        }
        
        // Add new item
        this._items.push(item);
        
        // Enforce max size (remove from front)
        while (this._items.length > this._maxSize) {
            this._items.shift();
        }
        
        this._currentIndex = this._items.length - 1;
        return this._currentIndex;
    }

    /**
     * Go back in history
     */
    back() {
        if (!this.canGoBack) return null;
        this._currentIndex--;
        return this._items[this._currentIndex];
    }

    /**
     * Go forward in history
     */
    forward() {
        if (!this.canGoForward) return null;
        this._currentIndex++;
        return this._items[this._currentIndex];
    }

    /**
     * Get current item
     */
    current() {
        if (this._currentIndex < 0 || this._currentIndex >= this._items.length) {
            return null;
        }
        return this._items[this._currentIndex];
    }

    /**
     * Peek at previous item without moving
     */
    peekBack() {
        if (!this.canGoBack) return null;
        return this._items[this._currentIndex - 1];
    }

    /**
     * Peek at next item without moving
     */
    peekForward() {
        if (!this.canGoForward) return null;
        return this._items[this._currentIndex + 1];
    }

    /**
     * Get item at index
     */
    at(index) {
        if (index < 0 || index >= this._items.length) return null;
        return this._items[index];
    }

    /**
     * Get all items
     */
    getAll() {
        return [...this._items];
    }

    /**
     * Clear history
     */
    clear() {
        this._items = [];
        this._currentIndex = -1;
    }

    /**
     * Go to specific index
     */
    goTo(index) {
        if (index < 0 || index >= this._items.length) return null;
        this._currentIndex = index;
        return this._items[this._currentIndex];
    }

    /**
     * Serialize
     */
    toJSON() {
        return {
            maxSize: this._maxSize,
            items: this._items.map(item => item.toJSON ? item.toJSON() : item),
            currentIndex: this._currentIndex
        };
    }

    /**
     * Deserialize
     */
    static fromJSON(data, ItemClass = VNHistData) {
        const queue = new VNHistQueue(data.maxSize);
        queue._items = data.items.map(item => 
            ItemClass.fromJSON ? ItemClass.fromJSON(item) : item
        );
        queue._currentIndex = data.currentIndex;
        return queue;
    }
}

/**
 * VNNavigationManager - High-level navigation management
 * Combines history with scene navigation
 */
export class VNNavigationManager {
    constructor(engine) {
        this._engine = engine;
        this._history = new VNHistQueue(100);
        this._autoRecord = true;
    }

    /**
     * Get history queue
     */
    get history() {
        return this._history;
    }

    /**
     * Set auto-record mode
     */
    setAutoRecord(enabled) {
        this._autoRecord = enabled;
    }

    /**
     * Record current state
     */
    recordState(sceneIndex = null) {
        if (!this._engine) return;
        
        const index = sceneIndex ?? this._engine.currentSceneIndex;
        const histData = VNHistData.fromEngineState(this._engine, index);
        this._history.push(histData);
    }

    /**
     * Go to previous scene
     */
    async goBack() {
        if (!this._history.canGoBack) return false;
        
        const histData = this._history.back();
        if (histData) {
            await this._restoreState(histData);
            return true;
        }
        return false;
    }

    /**
     * Go to next scene (forward)
     */
    async goForward() {
        if (!this._history.canGoForward) return false;
        
        const histData = this._history.forward();
        if (histData) {
            await this._restoreState(histData);
            return true;
        }
        return false;
    }

    /**
     * Restore state from history data
     */
    async _restoreState(histData) {
        if (!this._engine || !histData) return;
        
        // Disable auto-record during restoration
        const wasAutoRecord = this._autoRecord;
        this._autoRecord = false;
        
        try {
            // Go to scene
            if (this._engine.goToScene) {
                await this._engine.goToScene(histData.sceneIndex);
            }
            
            // Restore state
            histData.restoreToEngine(this._engine);
            
            // Set command index
            if (this._engine.setCommandIndex) {
                this._engine.setCommandIndex(histData.commandIndex);
            }
        } finally {
            this._autoRecord = wasAutoRecord;
        }
    }

    /**
     * Called when scene changes (for auto-record)
     */
    onSceneChange(newSceneIndex) {
        if (this._autoRecord) {
            this.recordState(newSceneIndex);
        }
    }

    /**
     * Can go back?
     */
    canGoBack() {
        return this._history.canGoBack;
    }

    /**
     * Can go forward?
     */
    canGoForward() {
        return this._history.canGoForward;
    }

    /**
     * Clear history
     */
    clear() {
        this._history.clear();
    }

    /**
     * Get history list for display
     */
    getHistoryList() {
        return this._history.getAll().map((item, index) => ({
            index,
            sceneName: item.sceneName,
            sceneIndex: item.sceneIndex,
            timestamp: item.timestamp,
            isCurrent: index === this._history.currentIndex
        }));
    }

    /**
     * Serialize
     */
    toJSON() {
        return {
            history: this._history.toJSON(),
            autoRecord: this._autoRecord
        };
    }

    /**
     * Deserialize
     */
    static fromJSON(data, engine) {
        const manager = new VNNavigationManager(engine);
        manager._history = VNHistQueue.fromJSON(data.history, VNHistData);
        manager._autoRecord = data.autoRecord;
        return manager;
    }
}

export default {
    VNHistData,
    VNHistQueue,
    VNNavigationManager
};
