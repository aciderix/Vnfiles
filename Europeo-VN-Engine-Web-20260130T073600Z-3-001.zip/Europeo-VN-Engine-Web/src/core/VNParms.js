/**
 * VNParms - All parameter classes for VN commands
 * 
 * Port of all TVN*Parms classes from europeo.exe
 * These classes hold parameters for VN script commands
 */

import { VNStreamable } from './VNObject.js';

/**
 * Base parameter class
 */
export class VNBaseParms extends VNStreamable {
    constructor() {
        super();
        this.commandType = 0;
        this.lineNumber = 0;
    }

    serialize() {
        return {
            ...super.serialize(),
            commandType: this.commandType,
            lineNumber: this.lineNumber
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.commandType !== undefined) this.commandType = data.commandType;
        if (data.lineNumber !== undefined) this.lineNumber = data.lineNumber;
        return this;
    }
}

/**
 * TVNStringParms - String parameter
 * Port from europeo.exe (0x0040ee2e)
 */
export class VNStringParms extends VNBaseParms {
    constructor() {
        super();
        this.value = '';
    }

    serialize() {
        return { ...super.serialize(), value: this.value };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.value !== undefined) this.value = data.value;
        return this;
    }
}

/**
 * TVNFileNameParms - File name parameter
 * Port from europeo.exe (0x0040f2e2)
 */
export class VNFileNameParms extends VNBaseParms {
    constructor() {
        super();
        this.fileName = '';
        this.basePath = '';
        this.fullPath = '';
    }

    getFullPath() {
        if (this.fullPath) return this.fullPath;
        if (this.basePath && this.fileName) {
            return `${this.basePath}/${this.fileName}`;
        }
        return this.fileName;
    }

    serialize() {
        return {
            ...super.serialize(),
            fileName: this.fileName,
            basePath: this.basePath,
            fullPath: this.fullPath
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.fileName !== undefined) this.fileName = data.fileName;
        if (data.basePath !== undefined) this.basePath = data.basePath;
        if (data.fullPath !== undefined) this.fullPath = data.fullPath;
        return this;
    }
}

/**
 * TVNSceneParms - Scene parameters
 * Port from europeo.exe (0x004104ab - TVNSceneParms)
 */
export class VNSceneParms extends VNBaseParms {
    constructor() {
        super();
        this.sceneId = 0;
        this.sceneName = '';
        this.transition = 'none';
        this.transitionDuration = 500;
        this.backgroundColor = '#000000';
    }

    serialize() {
        return {
            ...super.serialize(),
            sceneId: this.sceneId,
            sceneName: this.sceneName,
            transition: this.transition,
            transitionDuration: this.transitionDuration,
            backgroundColor: this.backgroundColor
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNImageParms - Image display parameters
 * Port from europeo.exe (0x0040eee6)
 */
export class VNImageParms extends VNFileNameParms {
    constructor() {
        super();
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;
        this.transparent = false;
        this.transparentColor = '#FF00FF';
        this.opacity = 1.0;
        this.zOrder = 0;
    }

    serialize() {
        return {
            ...super.serialize(),
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            transparent: this.transparent,
            transparentColor: this.transparentColor,
            opacity: this.opacity,
            zOrder: this.zOrder
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNImgObjParms - Image object parameters
 * Port from europeo.exe (0x0040efa6)
 */
export class VNImgObjParms extends VNImageParms {
    constructor() {
        super();
        this.objectId = '';
        this.visible = true;
        this.enabled = true;
        this.clickable = false;
        this.onClickCommand = '';
    }

    serialize() {
        return {
            ...super.serialize(),
            objectId: this.objectId,
            visible: this.visible,
            enabled: this.enabled,
            clickable: this.clickable,
            onClickCommand: this.onClickCommand
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNImgSeqParms - Image sequence parameters
 * Port from europeo.exe (0x0040f0b6)
 */
export class VNImgSeqParms extends VNImageParms {
    constructor() {
        super();
        this.frameCount = 1;
        this.frameDelay = 100;
        this.loop = true;
        this.autoPlay = true;
        this.currentFrame = 0;
    }

    serialize() {
        return {
            ...super.serialize(),
            frameCount: this.frameCount,
            frameDelay: this.frameDelay,
            loop: this.loop,
            autoPlay: this.autoPlay
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNTextParms - Text display parameters
 * Port from europeo.exe (0x0040f346)
 */
export class VNTextParms extends VNBaseParms {
    constructor() {
        super();
        this.text = '';
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;
        this.align = 'left';
        this.valign = 'top';
        this.wrap = true;
        this.fontName = 'Arial';
        this.fontSize = 14;
        this.fontColor = '#FFFFFF';
        this.fontBold = false;
        this.fontItalic = false;
        this.fontUnderline = false;
        this.backgroundColor = 'transparent';
        this.borderColor = 'transparent';
        this.borderWidth = 0;
        this.padding = 5;
    }

    serialize() {
        return {
            ...super.serialize(),
            text: this.text,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            align: this.align,
            valign: this.valign,
            wrap: this.wrap,
            fontName: this.fontName,
            fontSize: this.fontSize,
            fontColor: this.fontColor,
            fontBold: this.fontBold,
            fontItalic: this.fontItalic,
            fontUnderline: this.fontUnderline,
            backgroundColor: this.backgroundColor,
            borderColor: this.borderColor,
            borderWidth: this.borderWidth,
            padding: this.padding
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNTextObjParms - Text object parameters
 * Port from europeo.exe (0x0040f006)
 */
export class VNTextObjParms extends VNTextParms {
    constructor() {
        super();
        this.objectId = '';
        this.visible = true;
        this.typewriterEffect = false;
        this.typewriterSpeed = 50;
    }

    serialize() {
        return {
            ...super.serialize(),
            objectId: this.objectId,
            visible: this.visible,
            typewriterEffect: this.typewriterEffect,
            typewriterSpeed: this.typewriterSpeed
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNFontParms - Font parameters
 * Port from europeo.exe (0x0040f39e)
 */
export class VNFontParms extends VNBaseParms {
    constructor() {
        super();
        this.fontName = 'Arial';
        this.fontSize = 14;
        this.fontWeight = 400;
        this.italic = false;
        this.underline = false;
        this.strikeout = false;
        this.color = '#000000';
        this.charSet = 0;
    }

    toCSSFont() {
        let style = this.italic ? 'italic ' : '';
        let weight = this.fontWeight;
        return `${style}${weight} ${this.fontSize}px "${this.fontName}"`;
    }

    serialize() {
        return {
            ...super.serialize(),
            fontName: this.fontName,
            fontSize: this.fontSize,
            fontWeight: this.fontWeight,
            italic: this.italic,
            underline: this.underline,
            strikeout: this.strikeout,
            color: this.color
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNHtmlParms - HTML text parameters
 * Port from europeo.exe (0x0040ee8e)
 */
export class VNHtmlParms extends VNBaseParms {
    constructor() {
        super();
        this.html = '';
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;
        this.scrollable = false;
        this.baseUrl = '';
    }

    serialize() {
        return {
            ...super.serialize(),
            html: this.html,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            scrollable: this.scrollable,
            baseUrl: this.baseUrl
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNDigitParms - Digital display parameters
 * Port from europeo.exe (0x0040f05e)
 */
export class VNDigitParms extends VNBaseParms {
    constructor() {
        super();
        this.value = 0;
        this.digits = 4;
        this.leadingZeros = false;
        this.x = 0;
        this.y = 0;
        this.digitWidth = 20;
        this.digitHeight = 30;
        this.digitImageFile = '';
    }

    getFormattedValue() {
        let str = String(Math.abs(Math.floor(this.value)));
        if (this.leadingZeros) {
            str = str.padStart(this.digits, '0');
        }
        return str.slice(-this.digits);
    }

    serialize() {
        return {
            ...super.serialize(),
            value: this.value,
            digits: this.digits,
            leadingZeros: this.leadingZeros,
            x: this.x,
            y: this.y,
            digitWidth: this.digitWidth,
            digitHeight: this.digitHeight,
            digitImageFile: this.digitImageFile
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNMidiParms - MIDI playback parameters
 * Port from europeo.exe (0x0040ec2c)
 */
export class VNMidiParms extends VNFileNameParms {
    constructor() {
        super();
        this.loop = false;
        this.volume = 100;
        this.autoStart = true;
    }

    serialize() {
        return {
            ...super.serialize(),
            loop: this.loop,
            volume: this.volume,
            autoStart: this.autoStart
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNCDAParms - CD Audio parameters
 * Port from europeo.exe (0x00410d5d)
 */
export class VNCDAParms extends VNBaseParms {
    constructor() {
        super();
        this.track = 1;
        this.startPosition = 0;
        this.endPosition = 0;
        this.loop = false;
    }

    serialize() {
        return {
            ...super.serialize(),
            track: this.track,
            startPosition: this.startPosition,
            endPosition: this.endPosition,
            loop: this.loop
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNExecParms - External execution parameters
 * Port from europeo.exe (0x0040f10e)
 */
export class VNExecParms extends VNBaseParms {
    constructor() {
        super();
        this.command = '';
        this.arguments = '';
        this.workingDirectory = '';
        this.waitForExit = false;
        this.showWindow = true;
        this.url = ''; // For web version
    }

    serialize() {
        return {
            ...super.serialize(),
            command: this.command,
            arguments: this.arguments,
            workingDirectory: this.workingDirectory,
            waitForExit: this.waitForExit,
            showWindow: this.showWindow,
            url: this.url
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNIfParms - Conditional parameters
 * Port from europeo.exe (0x0040f16e)
 */
export class VNIfParms extends VNBaseParms {
    constructor() {
        super();
        this.condition = '';
        this.leftOperand = '';
        this.operator = '==';
        this.rightOperand = '';
        this.thenCommand = '';
        this.elseCommand = '';
    }

    evaluate(variables) {
        let left = this.leftOperand;
        let right = this.rightOperand;
        
        // Resolve variable references
        if (variables) {
            if (left.startsWith('$')) {
                left = variables.get(left.substring(1));
            }
            if (right.startsWith('$')) {
                right = variables.get(right.substring(1));
            }
        }
        
        // Convert to numbers if possible
        const leftNum = parseFloat(left);
        const rightNum = parseFloat(right);
        const useNumbers = !isNaN(leftNum) && !isNaN(rightNum);
        
        if (useNumbers) {
            left = leftNum;
            right = rightNum;
        }
        
        switch (this.operator) {
            case '==':
            case '=':
                return left == right;
            case '!=':
            case '<>':
                return left != right;
            case '<':
                return left < right;
            case '<=':
                return left <= right;
            case '>':
                return left > right;
            case '>=':
                return left >= right;
            case 'contains':
                return String(left).includes(String(right));
            case 'startswith':
                return String(left).startsWith(String(right));
            case 'endswith':
                return String(left).endsWith(String(right));
            default:
                return false;
        }
    }

    serialize() {
        return {
            ...super.serialize(),
            condition: this.condition,
            leftOperand: this.leftOperand,
            operator: this.operator,
            rightOperand: this.rightOperand,
            thenCommand: this.thenCommand,
            elseCommand: this.elseCommand
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNSetVarParms - Variable set parameters
 * Port from europeo.exe (0x0040f1d2)
 */
export class VNSetVarParms extends VNBaseParms {
    constructor() {
        super();
        this.variableName = '';
        this.value = '';
        this.isExpression = false;
    }

    serialize() {
        return {
            ...super.serialize(),
            variableName: this.variableName,
            value: this.value,
            isExpression: this.isExpression
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNIncVarParms - Variable increment parameters
 * Port from europeo.exe (0x0040f232)
 */
export class VNIncVarParms extends VNBaseParms {
    constructor() {
        super();
        this.variableName = '';
        this.amount = 1;
    }

    serialize() {
        return {
            ...super.serialize(),
            variableName: this.variableName,
            amount: this.amount
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNDecVarParms - Variable decrement parameters
 * Port from europeo.exe (0x0040f28a)
 */
export class VNDecVarParms extends VNIncVarParms {
    constructor() {
        super();
        // Same as increment, just operation is different
    }
}

/**
 * TVNConditionParms - Condition parameters
 * Port from europeo.exe (0x00410d0a)
 */
export class VNConditionParms extends VNBaseParms {
    constructor() {
        super();
        this.conditions = [];
        this.logicalOperator = 'AND'; // 'AND' or 'OR'
    }

    addCondition(leftOperand, operator, rightOperand) {
        this.conditions.push({ leftOperand, operator, rightOperand });
    }

    evaluate(variables) {
        if (this.conditions.length === 0) return true;
        
        const results = this.conditions.map(cond => {
            const ifParms = new VNIfParms();
            ifParms.leftOperand = cond.leftOperand;
            ifParms.operator = cond.operator;
            ifParms.rightOperand = cond.rightOperand;
            return ifParms.evaluate(variables);
        });
        
        if (this.logicalOperator === 'AND') {
            return results.every(r => r);
        } else {
            return results.some(r => r);
        }
    }

    serialize() {
        return {
            ...super.serialize(),
            conditions: this.conditions,
            logicalOperator: this.logicalOperator
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.conditions) this.conditions = data.conditions;
        if (data.logicalOperator) this.logicalOperator = data.logicalOperator;
        return this;
    }
}

/**
 * TVNTimeParms - Time/delay parameters
 * Port from europeo.exe (0x00410a7c)
 */
export class VNTimeParms extends VNBaseParms {
    constructor() {
        super();
        this.delay = 0;
        this.unit = 'ms'; // 'ms', 's', 'm'
    }

    getMilliseconds() {
        switch (this.unit) {
            case 's':
                return this.delay * 1000;
            case 'm':
                return this.delay * 60000;
            default:
                return this.delay;
        }
    }

    serialize() {
        return {
            ...super.serialize(),
            delay: this.delay,
            unit: this.unit
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.delay !== undefined) this.delay = data.delay;
        if (data.unit !== undefined) this.unit = data.unit;
        return this;
    }
}

/**
 * TVNHotspotParms - Hotspot parameters
 * Port from europeo.exe (0x00410ad2)
 */
export class VNHotspotParms extends VNBaseParms {
    constructor() {
        super();
        this.id = '';
        this.name = '';
        this.x = 0;
        this.y = 0;
        this.width = 100;
        this.height = 100;
        this.shape = 'rect'; // 'rect', 'circle', 'poly'
        this.points = []; // For polygon
        this.cursor = 'pointer';
        this.tooltip = '';
        this.enabled = true;
        this.visible = true;
        this.onClick = '';
        this.onEnter = '';
        this.onLeave = '';
        this.highlightOnHover = false;
        this.highlightColor = 'rgba(255,255,0,0.3)';
    }

    containsPoint(px, py) {
        switch (this.shape) {
            case 'circle':
                const cx = this.x + this.width / 2;
                const cy = this.y + this.height / 2;
                const rx = this.width / 2;
                const ry = this.height / 2;
                return Math.pow((px - cx) / rx, 2) + Math.pow((py - cy) / ry, 2) <= 1;
                
            case 'poly':
                return this._pointInPolygon(px, py);
                
            case 'rect':
            default:
                return px >= this.x && px < this.x + this.width &&
                       py >= this.y && py < this.y + this.height;
        }
    }

    _pointInPolygon(px, py) {
        if (this.points.length < 3) return false;
        
        let inside = false;
        for (let i = 0, j = this.points.length - 1; i < this.points.length; j = i++) {
            const xi = this.points[i].x, yi = this.points[i].y;
            const xj = this.points[j].x, yj = this.points[j].y;
            
            if (((yi > py) !== (yj > py)) &&
                (px < (xj - xi) * (py - yi) / (yj - yi) + xi)) {
                inside = !inside;
            }
        }
        return inside;
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            name: this.name,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            shape: this.shape,
            points: this.points,
            cursor: this.cursor,
            tooltip: this.tooltip,
            enabled: this.enabled,
            visible: this.visible,
            onClick: this.onClick,
            onEnter: this.onEnter,
            onLeave: this.onLeave,
            highlightOnHover: this.highlightOnHover,
            highlightColor: this.highlightColor
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNRectParms - Rectangle parameters
 * Port from europeo.exe (0x00410dfc)
 */
export class VNRectParms extends VNBaseParms {
    constructor() {
        super();
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;
        this.fillColor = 'transparent';
        this.borderColor = '#000000';
        this.borderWidth = 1;
        this.borderRadius = 0;
        this.opacity = 1.0;
    }

    containsPoint(px, py) {
        return px >= this.x && px < this.x + this.width &&
               py >= this.y && py < this.y + this.height;
    }

    intersects(other) {
        return !(other.x > this.x + this.width ||
                 other.x + other.width < this.x ||
                 other.y > this.y + this.height ||
                 other.y + other.height < this.y);
    }

    serialize() {
        return {
            ...super.serialize(),
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            fillColor: this.fillColor,
            borderColor: this.borderColor,
            borderWidth: this.borderWidth,
            borderRadius: this.borderRadius,
            opacity: this.opacity
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNProjectParms - Project parameters
 * Port from europeo.exe (0x0040ec0e)
 */
export class VNProjectParms extends VNFileNameParms {
    constructor() {
        super();
        this.projectName = '';
        this.startScene = 0;
        this.returnToScene = -1;
    }

    serialize() {
        return {
            ...super.serialize(),
            projectName: this.projectName,
            startScene: this.startScene,
            returnToScene: this.returnToScene
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNCommandParms - Generic command parameters
 * Port from europeo.exe (0x0040fe88)
 */
export class VNCommandParms extends VNBaseParms {
    constructor() {
        super();
        this.command = '';
        this.args = [];
        this.namedArgs = {};
    }

    getArg(index, defaultValue = '') {
        return index < this.args.length ? this.args[index] : defaultValue;
    }

    getNamedArg(name, defaultValue = '') {
        return this.namedArgs.hasOwnProperty(name) ? this.namedArgs[name] : defaultValue;
    }

    serialize() {
        return {
            ...super.serialize(),
            command: this.command,
            args: this.args,
            namedArgs: this.namedArgs
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.command !== undefined) this.command = data.command;
        if (data.args !== undefined) this.args = data.args;
        if (data.namedArgs !== undefined) this.namedArgs = data.namedArgs;
        return this;
    }
}

// Export all classes
export default {
    VNBaseParms,
    VNStringParms,
    VNFileNameParms,
    VNSceneParms,
    VNImageParms,
    VNImgObjParms,
    VNImgSeqParms,
    VNTextParms,
    VNTextObjParms,
    VNFontParms,
    VNHtmlParms,
    VNDigitParms,
    VNMidiParms,
    VNCDAParms,
    VNExecParms,
    VNIfParms,
    VNSetVarParms,
    VNIncVarParms,
    VNDecVarParms,
    VNConditionParms,
    VNTimeParms,
    VNHotspotParms,
    VNRectParms,
    VNProjectParms,
    VNCommandParms
};
