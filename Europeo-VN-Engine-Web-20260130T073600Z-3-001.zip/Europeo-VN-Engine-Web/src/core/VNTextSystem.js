/**
 * VNTextSystem - Text Display and Object System
 * 
 * EXACT PORT from text handling functions
 * Classes: TVNTextParms, TVNTextObjParms, TVNTextObject, TVNHtmlText, TPageContext
 * 
 * @original_file text objects in europeo.exe
 * @original_address various
 */

/**
 * VNTextAlignment - Text alignment constants
 */
const VNTextAlignment = {
    LEFT: 0,
    CENTER: 1,
    RIGHT: 2,
    JUSTIFY: 3
};

/**
 * VNTextParms - Text display parameters
 * Port of TVNTextParms
 * @original_address 0x0040f346 (TVNTextParms)
 */
class VNTextParms {
    constructor() {
        this.text = '';               // Text content
        this.x = 0;                   // X position
        this.y = 0;                   // Y position
        this.width = 0;               // Width (0 = auto)
        this.height = 0;              // Height (0 = auto)
        this.fontName = 'Arial';      // Font family
        this.fontSize = 16;           // Font size in pixels
        this.fontWeight = 400;        // Font weight (400=normal, 700=bold)
        this.fontStyle = '';          // 'italic' or ''
        this.color = 0x000000;        // Text color (RGB)
        this.backgroundColor = null;  // Background color (null = transparent)
        this.alignment = VNTextAlignment.LEFT;
        this.lineHeight = 1.2;        // Line height multiplier
        this.wordWrap = true;         // Enable word wrapping
    }

    /**
     * Parse from command string
     * Format: playtext,text,x,y[,width,height][,font,size,color]
     * @original_address playtext command at 0x0043f881
     */
    static parse(args) {
        const parms = new VNTextParms();
        
        if (!args) return parms;
        
        const parts = args.split(',').map(s => s.trim());
        
        if (parts.length >= 1) parms.text = parts[0];
        if (parts.length >= 2) parms.x = parseInt(parts[1]) || 0;
        if (parts.length >= 3) parms.y = parseInt(parts[2]) || 0;
        if (parts.length >= 4) parms.width = parseInt(parts[3]) || 0;
        if (parts.length >= 5) parms.height = parseInt(parts[4]) || 0;
        if (parts.length >= 6) parms.fontName = parts[5];
        if (parts.length >= 7) parms.fontSize = parseInt(parts[6]) || 16;
        if (parts.length >= 8) parms.color = parseInt(parts[7], 16) || 0x000000;
        
        return parms;
    }
}

/**
 * VNTextObjParms - Text object parameters
 * Port of TVNTextObjParms
 * @original_address 0x0040efa6 (TVNTextObjParms)
 */
class VNTextObjParms extends VNTextParms {
    constructor() {
        super();
        this.name = '';               // Object name/ID
        this.visible = true;          // Visibility
        this.zOrder = 0;              // Z-order for layering
        this.fadeIn = 0;              // Fade in duration (ms)
        this.fadeOut = 0;             // Fade out duration (ms)
        this.typewriter = 0;          // Typewriter effect speed (ms per char)
        this.onClick = '';            // Click handler command
    }

    /**
     * Parse from command string
     * @original_address addtext command at 0x0043f893
     */
    static parse(args) {
        const parms = new VNTextObjParms();
        const base = VNTextParms.parse(args);
        Object.assign(parms, base);
        
        if (!args) return parms;
        
        const parts = args.split(',').map(s => s.trim());
        
        // Name is often first or after basic params
        if (parts.length >= 9) parms.name = parts[8];
        
        return parms;
    }
}

/**
 * VNPageContext - Page context for paginated text
 * Port of TPageContext
 * @original_address 0x00423ae7 (TArray<TPageContext>)
 */
class VNPageContext {
    constructor() {
        this.startIndex = 0;         // Start character index
        this.endIndex = 0;           // End character index
        this.lineCount = 0;          // Number of lines
        this.height = 0;             // Rendered height
    }
}

/**
 * VNTextObject - Rendered text object
 * Port of TVNTextObject
 * @original_address 0x0042a6b0 (TVNTextObject)
 */
class VNTextObject {
    // Object ID counter
    static _idCounter = 0;

    constructor(parms = null) {
        this.id = VNTextObject._idCounter++;
        this.name = parms?.name || `TEXT_${this.id}`;
        
        // Position and size
        this.x = parms?.x || 0;
        this.y = parms?.y || 0;
        this.width = parms?.width || 0;
        this.height = parms?.height || 0;
        
        // Text content
        this.text = parms?.text || '';
        this.displayedText = '';      // For typewriter effect
        
        // Style
        this.fontName = parms?.fontName || 'Arial';
        this.fontSize = parms?.fontSize || 16;
        this.fontWeight = parms?.fontWeight || 400;
        this.fontStyle = parms?.fontStyle || '';
        this.color = parms?.color || 0x000000;
        this.backgroundColor = parms?.backgroundColor || null;
        this.alignment = parms?.alignment || VNTextAlignment.LEFT;
        this.lineHeight = parms?.lineHeight || 1.2;
        this.wordWrap = parms?.wordWrap !== false;
        
        // State
        this.visible = parms?.visible !== false;
        this.zOrder = parms?.zOrder || 0;
        this.opacity = 1.0;
        
        // Effects
        this.fadeIn = parms?.fadeIn || 0;
        this.fadeOut = parms?.fadeOut || 0;
        this.typewriter = parms?.typewriter || 0;
        
        // Event handler
        this.onClick = parms?.onClick || null;
        
        // Animation state
        this._animating = false;
        this._animationStart = 0;
        this._typewriterIndex = 0;
        
        // Cached render data
        this._lines = [];
        this._dirty = true;
    }

    /**
     * Set text content
     */
    setText(text) {
        this.text = text;
        this._dirty = true;
        
        if (this.typewriter > 0) {
            this.displayedText = '';
            this._typewriterIndex = 0;
            this._animating = true;
            this._animationStart = performance.now();
        } else {
            this.displayedText = text;
        }
    }

    /**
     * Update animation
     */
    update(deltaTime) {
        if (!this._animating) return;
        
        const elapsed = performance.now() - this._animationStart;
        
        // Typewriter effect
        if (this.typewriter > 0) {
            const targetIndex = Math.floor(elapsed / this.typewriter);
            if (targetIndex > this._typewriterIndex) {
                this._typewriterIndex = Math.min(targetIndex, this.text.length);
                this.displayedText = this.text.substring(0, this._typewriterIndex);
                this._dirty = true;
                
                if (this._typewriterIndex >= this.text.length) {
                    this._animating = false;
                }
            }
        }
        
        // Fade effect
        if (this.fadeIn > 0 && elapsed < this.fadeIn) {
            this.opacity = elapsed / this.fadeIn;
        } else {
            this.opacity = 1.0;
        }
    }

    /**
     * Prepare text for rendering (line breaking)
     */
    _prepareLines(ctx) {
        if (!this._dirty) return;
        
        this._lines = [];
        const text = this.displayedText || this.text;
        
        if (!text) {
            this._dirty = false;
            return;
        }
        
        // Set font for measurement
        ctx.font = this._getFont();
        
        if (this.wordWrap && this.width > 0) {
            // Word wrap
            const words = text.split(/\s+/);
            let currentLine = '';
            
            for (const word of words) {
                const testLine = currentLine ? `${currentLine} ${word}` : word;
                const metrics = ctx.measureText(testLine);
                
                if (metrics.width > this.width && currentLine) {
                    this._lines.push(currentLine);
                    currentLine = word;
                } else {
                    currentLine = testLine;
                }
            }
            
            if (currentLine) {
                this._lines.push(currentLine);
            }
        } else {
            // Split by newlines only
            this._lines = text.split('\n');
        }
        
        this._dirty = false;
    }

    /**
     * Get CSS font string
     */
    _getFont() {
        let font = '';
        if (this.fontStyle) font += `${this.fontStyle} `;
        if (this.fontWeight !== 400) font += `${this.fontWeight} `;
        font += `${this.fontSize}px ${this.fontName}`;
        return font;
    }

    /**
     * Render text object
     */
    render(ctx) {
        if (!this.visible || this.opacity <= 0) return;
        
        this._prepareLines(ctx);
        
        ctx.save();
        
        // Set opacity
        ctx.globalAlpha = this.opacity;
        
        // Draw background if set
        if (this.backgroundColor !== null) {
            ctx.fillStyle = `#${this.backgroundColor.toString(16).padStart(6, '0')}`;
            const totalHeight = this._lines.length * this.fontSize * this.lineHeight;
            ctx.fillRect(this.x, this.y, this.width || 200, this.height || totalHeight);
        }
        
        // Set text style
        ctx.font = this._getFont();
        ctx.fillStyle = `#${this.color.toString(16).padStart(6, '0')}`;
        ctx.textBaseline = 'top';
        
        // Set alignment
        switch (this.alignment) {
            case VNTextAlignment.CENTER:
                ctx.textAlign = 'center';
                break;
            case VNTextAlignment.RIGHT:
                ctx.textAlign = 'right';
                break;
            default:
                ctx.textAlign = 'left';
        }
        
        // Draw lines
        const lineSpacing = this.fontSize * this.lineHeight;
        let y = this.y;
        let x = this.x;
        
        if (this.alignment === VNTextAlignment.CENTER && this.width > 0) {
            x = this.x + this.width / 2;
        } else if (this.alignment === VNTextAlignment.RIGHT && this.width > 0) {
            x = this.x + this.width;
        }
        
        for (const line of this._lines) {
            ctx.fillText(line, x, y);
            y += lineSpacing;
        }
        
        ctx.restore();
    }

    /**
     * Check if point is inside text bounds
     */
    containsPoint(px, py) {
        if (!this.visible) return false;
        
        const height = this.height || (this._lines.length * this.fontSize * this.lineHeight);
        const width = this.width || 200;
        
        return px >= this.x && px < this.x + width &&
               py >= this.y && py < this.y + height;
    }

    /**
     * Start fade out animation
     */
    fadeOutAndRemove(duration, callback) {
        this.fadeOut = duration;
        this._animating = true;
        this._animationStart = performance.now();
        
        // Set up fade out
        const startOpacity = this.opacity;
        const animate = () => {
            const elapsed = performance.now() - this._animationStart;
            const progress = Math.min(1, elapsed / duration);
            this.opacity = startOpacity * (1 - progress);
            
            if (progress >= 1) {
                this.visible = false;
                if (callback) callback(this);
            } else {
                requestAnimationFrame(animate);
            }
        };
        animate();
    }
}

/**
 * VNHtmlText - HTML formatted text renderer
 * Port of TVNHtmlText
 * @original_address 0x004236c2 (TVNHtmlText)
 */
class VNHtmlText extends VNTextObject {
    constructor(parms = null) {
        super(parms);
        
        // HTML content
        this.html = '';
        
        // Page management for pagination
        this.pages = [];              // Array of VNPageContext
        this.currentPage = 0;
        
        // Link data
        this.links = [];
    }

    /**
     * Set HTML content
     */
    setHtml(html) {
        this.html = html;
        this.text = this._stripHtml(html);
        this._dirty = true;
        this._parsePages();
    }

    /**
     * Strip HTML tags for plain text
     */
    _stripHtml(html) {
        return html.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ');
    }

    /**
     * Parse into pages
     */
    _parsePages() {
        this.pages = [];
        // Simplified pagination - one page for now
        const page = new VNPageContext();
        page.startIndex = 0;
        page.endIndex = this.text.length;
        this.pages.push(page);
    }

    /**
     * Go to next page
     */
    nextPage() {
        if (this.currentPage < this.pages.length - 1) {
            this.currentPage++;
            return true;
        }
        return false;
    }

    /**
     * Go to previous page
     */
    prevPage() {
        if (this.currentPage > 0) {
            this.currentPage--;
            return true;
        }
        return false;
    }

    /**
     * Get current page text
     */
    getCurrentPageText() {
        if (this.pages.length === 0) return this.text;
        const page = this.pages[this.currentPage];
        return this.text.substring(page.startIndex, page.endIndex);
    }
}

/**
 * VNTextManager - Text object management
 */
class VNTextManager {
    constructor(engine) {
        this.engine = engine;
        
        // Text objects by name
        this.objects = new Map();
        
        // Rendering order
        this.renderOrder = [];
    }

    /**
     * Create text object
     * @original_address addtext command handler
     */
    createTextObject(parms) {
        const obj = new VNTextObject(parms);
        this.objects.set(obj.name.toLowerCase(), obj);
        this._updateRenderOrder();
        return obj;
    }

    /**
     * Create from command string
     */
    createFromCommand(argsString) {
        const parms = VNTextObjParms.parse(argsString);
        return this.createTextObject(parms);
    }

    /**
     * Display text (simplified playtext)
     * @original_address playtext command handler
     */
    displayText(argsString, ctx) {
        const parms = VNTextParms.parse(argsString);
        
        // Create temporary text object
        const obj = new VNTextObject(parms);
        obj.setText(parms.text);
        obj.render(ctx);
        
        return obj;
    }

    /**
     * Get text object by name
     */
    getObject(name) {
        return this.objects.get(name.toLowerCase()) || null;
    }

    /**
     * Remove text object
     */
    removeObject(name) {
        const key = name.toLowerCase();
        if (this.objects.has(key)) {
            this.objects.delete(key);
            this._updateRenderOrder();
            return true;
        }
        return false;
    }

    /**
     * Clear all text objects
     */
    clearAll() {
        this.objects.clear();
        this.renderOrder = [];
    }

    /**
     * Update render order based on z-order
     */
    _updateRenderOrder() {
        this.renderOrder = Array.from(this.objects.values())
            .sort((a, b) => a.zOrder - b.zOrder);
    }

    /**
     * Update all text objects
     */
    update(deltaTime) {
        for (const obj of this.objects.values()) {
            obj.update(deltaTime);
        }
    }

    /**
     * Render all text objects
     */
    render(ctx) {
        for (const obj of this.renderOrder) {
            obj.render(ctx);
        }
    }

    /**
     * Get text object at point
     */
    getObjectAtPoint(x, y) {
        // Check in reverse render order (topmost first)
        for (let i = this.renderOrder.length - 1; i >= 0; i--) {
            const obj = this.renderOrder[i];
            if (obj.containsPoint(x, y)) {
                return obj;
            }
        }
        return null;
    }

    /**
     * Handle click
     */
    handleClick(x, y) {
        const obj = this.getObjectAtPoint(x, y);
        if (obj && obj.onClick) {
            if (typeof obj.onClick === 'function') {
                obj.onClick(obj);
            } else if (typeof obj.onClick === 'string') {
                return { command: obj.onClick, object: obj };
            }
        }
        return null;
    }
}

/**
 * VNTipText - Tooltip text display
 * @original_address tiptext command at 0x0043f79a
 */
class VNTipText {
    constructor(engine) {
        this.engine = engine;
        
        this.text = '';
        this.x = 0;
        this.y = 0;
        this.visible = false;
        this.timeout = null;
        
        // Style
        this.backgroundColor = 0xFFFFE1;  // Light yellow
        this.borderColor = 0x000000;
        this.textColor = 0x000000;
        this.fontSize = 12;
        this.fontName = 'Arial';
        this.padding = 4;
    }

    /**
     * Show tooltip
     */
    show(text, x, y, duration = 0) {
        this.text = text;
        this.x = x;
        this.y = y;
        this.visible = true;
        
        // Clear existing timeout
        if (this.timeout) {
            clearTimeout(this.timeout);
            this.timeout = null;
        }
        
        // Auto-hide after duration
        if (duration > 0) {
            this.timeout = setTimeout(() => {
                this.hide();
            }, duration);
        }
    }

    /**
     * Hide tooltip
     */
    hide() {
        this.visible = false;
        if (this.timeout) {
            clearTimeout(this.timeout);
            this.timeout = null;
        }
    }

    /**
     * Render tooltip
     */
    render(ctx) {
        if (!this.visible || !this.text) return;
        
        ctx.save();
        
        // Measure text
        ctx.font = `${this.fontSize}px ${this.fontName}`;
        const metrics = ctx.measureText(this.text);
        const width = metrics.width + this.padding * 2;
        const height = this.fontSize + this.padding * 2;
        
        // Position (avoid going off screen)
        let x = this.x;
        let y = this.y;
        
        if (this.engine && this.engine.canvas) {
            if (x + width > this.engine.canvas.width) {
                x = this.engine.canvas.width - width;
            }
            if (y + height > this.engine.canvas.height) {
                y = this.y - height - 5;
            }
        }
        
        // Draw background
        ctx.fillStyle = `#${this.backgroundColor.toString(16).padStart(6, '0')}`;
        ctx.fillRect(x, y, width, height);
        
        // Draw border
        ctx.strokeStyle = `#${this.borderColor.toString(16).padStart(6, '0')}`;
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, width, height);
        
        // Draw text
        ctx.fillStyle = `#${this.textColor.toString(16).padStart(6, '0')}`;
        ctx.textBaseline = 'top';
        ctx.fillText(this.text, x + this.padding, y + this.padding);
        
        ctx.restore();
    }
}

// Export all classes
export {
    VNTextAlignment,
    VNTextParms,
    VNTextObjParms,
    VNPageContext,
    VNTextObject,
    VNHtmlText,
    VNTextManager,
    VNTipText
};
