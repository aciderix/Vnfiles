/**
 * VNFileFormat - File format parsing classes
 * 
 * Port of TVNStreamable, file loading/saving from europeo.exe
 * Original sources: 
 * - TVNStreamable @ 0x00410ba2
 * - ipstream/opstream @ 0x00417bb2, 0x0042a65c
 * 
 * Handles .vnp (project), .vns (script), .sav (save) file formats
 */

/**
 * TStreamableBase - Base class for streamable objects
 * Port of TStreamableBase @ 0x0041c9d0
 */
export class TStreamableBase {
    constructor() {
        this._streamId = null;
    }
    
    /**
     * Get stream class identifier
     * @returns {string}
     */
    static getStreamId() {
        return 'TStreamableBase';
    }
    
    /**
     * Read from stream
     * @param {VNInputStream} stream
     */
    read(stream) {
        // Override in subclasses
    }
    
    /**
     * Write to stream
     * @param {VNOutputStream} stream
     */
    write(stream) {
        // Override in subclasses
    }
}

/**
 * VNInputStream - Input stream for reading binary data
 * Port of ipstream @ 0x00417bb2
 */
export class VNInputStream {
    /**
     * @param {ArrayBuffer} data
     */
    constructor(data) {
        this.data = data;
        this.view = new DataView(data);
        this.position = 0;
        this.littleEndian = true; // x86 is little-endian
    }
    
    /**
     * Create from base64 string
     * @param {string} base64
     * @returns {VNInputStream}
     */
    static fromBase64(base64) {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        return new VNInputStream(bytes.buffer);
    }
    
    /**
     * Check if at end of stream
     * @returns {boolean}
     */
    eof() {
        return this.position >= this.data.byteLength;
    }
    
    /**
     * Get remaining bytes
     * @returns {number}
     */
    remaining() {
        return this.data.byteLength - this.position;
    }
    
    /**
     * Read unsigned byte
     * @returns {number}
     */
    readUint8() {
        const value = this.view.getUint8(this.position);
        this.position += 1;
        return value;
    }
    
    /**
     * Read signed byte
     * @returns {number}
     */
    readInt8() {
        const value = this.view.getInt8(this.position);
        this.position += 1;
        return value;
    }
    
    /**
     * Read unsigned 16-bit integer
     * @returns {number}
     */
    readUint16() {
        const value = this.view.getUint16(this.position, this.littleEndian);
        this.position += 2;
        return value;
    }
    
    /**
     * Read signed 16-bit integer
     * @returns {number}
     */
    readInt16() {
        const value = this.view.getInt16(this.position, this.littleEndian);
        this.position += 2;
        return value;
    }
    
    /**
     * Read unsigned 32-bit integer
     * @returns {number}
     */
    readUint32() {
        const value = this.view.getUint32(this.position, this.littleEndian);
        this.position += 4;
        return value;
    }
    
    /**
     * Read signed 32-bit integer
     * @returns {number}
     */
    readInt32() {
        const value = this.view.getInt32(this.position, this.littleEndian);
        this.position += 4;
        return value;
    }
    
    /**
     * Read 32-bit float
     * @returns {number}
     */
    readFloat32() {
        const value = this.view.getFloat32(this.position, this.littleEndian);
        this.position += 4;
        return value;
    }
    
    /**
     * Read 64-bit float
     * @returns {number}
     */
    readFloat64() {
        const value = this.view.getFloat64(this.position, this.littleEndian);
        this.position += 8;
        return value;
    }
    
    /**
     * Read boolean
     * @returns {boolean}
     */
    readBool() {
        return this.readUint8() !== 0;
    }
    
    /**
     * Read null-terminated string
     * @returns {string}
     */
    readCString() {
        let result = '';
        while (this.position < this.data.byteLength) {
            const byte = this.view.getUint8(this.position);
            this.position++;
            if (byte === 0) break;
            result += String.fromCharCode(byte);
        }
        return result;
    }
    
    /**
     * Read length-prefixed string (Pascal style)
     * @returns {string}
     */
    readPString() {
        const length = this.readUint8();
        return this.readString(length);
    }
    
    /**
     * Read fixed-length string
     * @param {number} length
     * @returns {string}
     */
    readString(length) {
        let result = '';
        for (let i = 0; i < length && this.position < this.data.byteLength; i++) {
            const byte = this.view.getUint8(this.position);
            this.position++;
            if (byte !== 0) {
                result += String.fromCharCode(byte);
            }
        }
        return result;
    }
    
    /**
     * Read length-prefixed string (32-bit length)
     * @returns {string}
     */
    readLongString() {
        const length = this.readUint32();
        return this.readString(length);
    }
    
    /**
     * Read raw bytes
     * @param {number} length
     * @returns {Uint8Array}
     */
    readBytes(length) {
        const bytes = new Uint8Array(this.data, this.position, length);
        this.position += length;
        return bytes;
    }
    
    /**
     * Skip bytes
     * @param {number} count
     */
    skip(count) {
        this.position += count;
    }
    
    /**
     * Seek to position
     * @param {number} position
     */
    seek(position) {
        this.position = position;
    }
    
    /**
     * Get current position
     * @returns {number}
     */
    tell() {
        return this.position;
    }
}

/**
 * VNOutputStream - Output stream for writing binary data
 * Port of opstream @ 0x0042a65c
 */
export class VNOutputStream {
    constructor(initialSize = 1024) {
        this.buffer = new ArrayBuffer(initialSize);
        this.view = new DataView(this.buffer);
        this.position = 0;
        this.littleEndian = true;
    }
    
    /**
     * Ensure buffer has enough space
     * @param {number} needed
     */
    _ensureCapacity(needed) {
        const required = this.position + needed;
        if (required > this.buffer.byteLength) {
            const newSize = Math.max(this.buffer.byteLength * 2, required);
            const newBuffer = new ArrayBuffer(newSize);
            new Uint8Array(newBuffer).set(new Uint8Array(this.buffer));
            this.buffer = newBuffer;
            this.view = new DataView(this.buffer);
        }
    }
    
    /**
     * Write unsigned byte
     * @param {number} value
     */
    writeUint8(value) {
        this._ensureCapacity(1);
        this.view.setUint8(this.position, value);
        this.position += 1;
    }
    
    /**
     * Write signed byte
     * @param {number} value
     */
    writeInt8(value) {
        this._ensureCapacity(1);
        this.view.setInt8(this.position, value);
        this.position += 1;
    }
    
    /**
     * Write unsigned 16-bit integer
     * @param {number} value
     */
    writeUint16(value) {
        this._ensureCapacity(2);
        this.view.setUint16(this.position, value, this.littleEndian);
        this.position += 2;
    }
    
    /**
     * Write signed 16-bit integer
     * @param {number} value
     */
    writeInt16(value) {
        this._ensureCapacity(2);
        this.view.setInt16(this.position, value, this.littleEndian);
        this.position += 2;
    }
    
    /**
     * Write unsigned 32-bit integer
     * @param {number} value
     */
    writeUint32(value) {
        this._ensureCapacity(4);
        this.view.setUint32(this.position, value, this.littleEndian);
        this.position += 4;
    }
    
    /**
     * Write signed 32-bit integer
     * @param {number} value
     */
    writeInt32(value) {
        this._ensureCapacity(4);
        this.view.setInt32(this.position, value, this.littleEndian);
        this.position += 4;
    }
    
    /**
     * Write 32-bit float
     * @param {number} value
     */
    writeFloat32(value) {
        this._ensureCapacity(4);
        this.view.setFloat32(this.position, value, this.littleEndian);
        this.position += 4;
    }
    
    /**
     * Write 64-bit float
     * @param {number} value
     */
    writeFloat64(value) {
        this._ensureCapacity(8);
        this.view.setFloat64(this.position, value, this.littleEndian);
        this.position += 8;
    }
    
    /**
     * Write boolean
     * @param {boolean} value
     */
    writeBool(value) {
        this.writeUint8(value ? 1 : 0);
    }
    
    /**
     * Write null-terminated string
     * @param {string} str
     */
    writeCString(str) {
        for (let i = 0; i < str.length; i++) {
            this.writeUint8(str.charCodeAt(i));
        }
        this.writeUint8(0);
    }
    
    /**
     * Write length-prefixed string (Pascal style)
     * @param {string} str
     */
    writePString(str) {
        const length = Math.min(str.length, 255);
        this.writeUint8(length);
        for (let i = 0; i < length; i++) {
            this.writeUint8(str.charCodeAt(i));
        }
    }
    
    /**
     * Write fixed-length string
     * @param {string} str
     * @param {number} length
     */
    writeString(str, length) {
        for (let i = 0; i < length; i++) {
            this.writeUint8(i < str.length ? str.charCodeAt(i) : 0);
        }
    }
    
    /**
     * Write length-prefixed string (32-bit length)
     * @param {string} str
     */
    writeLongString(str) {
        this.writeUint32(str.length);
        for (let i = 0; i < str.length; i++) {
            this.writeUint8(str.charCodeAt(i));
        }
    }
    
    /**
     * Write raw bytes
     * @param {Uint8Array} bytes
     */
    writeBytes(bytes) {
        this._ensureCapacity(bytes.length);
        new Uint8Array(this.buffer, this.position).set(bytes);
        this.position += bytes.length;
    }
    
    /**
     * Get final buffer
     * @returns {ArrayBuffer}
     */
    getBuffer() {
        return this.buffer.slice(0, this.position);
    }
    
    /**
     * Get as Uint8Array
     * @returns {Uint8Array}
     */
    getBytes() {
        return new Uint8Array(this.getBuffer());
    }
    
    /**
     * Get as base64 string
     * @returns {string}
     */
    toBase64() {
        const bytes = this.getBytes();
        let binary = '';
        for (let i = 0; i < bytes.length; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
    }
}

/**
 * VNProjectFile - VN project file format (.vnp)
 * Port of project file parsing from europeo.exe
 */
export class VNProjectFile {
    constructor() {
        // File header
        this.signature = 'VNPF'; // VN Project File
        this.version = 0x0100; // 1.0
        
        // Project info
        this.projectName = '';
        this.author = '';
        this.description = '';
        this.startScene = 0;
        
        // Display settings
        this.width = 640;
        this.height = 480;
        this.colorDepth = 8;
        this.fullscreen = false;
        
        // Paths
        this.dataPath = '';
        this.imagePath = '';
        this.soundPath = '';
        this.videoPath = '';
        
        // Scenes
        this.scenes = [];
        
        // Variables
        this.variables = [];
        
        // Resources
        this.resources = [];
    }
    
    /**
     * Load from JSON data (web format)
     * @param {Object} json
     */
    loadFromJson(json) {
        if (json.projectInfo) {
            this.projectName = json.projectInfo.name || '';
            this.author = json.projectInfo.author || '';
            this.description = json.projectInfo.description || '';
        }
        
        if (json.displaySettings) {
            this.width = json.displaySettings.width || 640;
            this.height = json.displaySettings.height || 480;
            this.colorDepth = json.displaySettings.colorDepth || 32;
            this.fullscreen = json.displaySettings.fullscreen || false;
        }
        
        if (json.paths) {
            this.dataPath = json.paths.data || '';
            this.imagePath = json.paths.images || '';
            this.soundPath = json.paths.sounds || '';
            this.videoPath = json.paths.videos || '';
        }
        
        this.scenes = json.scenes || [];
        this.variables = json.variables || [];
        this.startScene = json.startScene || 0;
    }
    
    /**
     * Load from binary data (original format)
     * @param {ArrayBuffer} data
     */
    loadFromBinary(data) {
        const stream = new VNInputStream(data);
        
        // Read signature
        const sig = stream.readString(4);
        if (sig !== 'VNPF' && sig !== 'VN\x00\x00') {
            throw new Error('Invalid VN project file');
        }
        
        // Read version
        this.version = stream.readUint16();
        
        // Read project info
        this.projectName = stream.readPString();
        this.author = stream.readPString();
        this.description = stream.readLongString();
        
        // Read display settings
        this.width = stream.readUint16();
        this.height = stream.readUint16();
        this.colorDepth = stream.readUint8();
        this.fullscreen = stream.readBool();
        
        // Read paths
        this.dataPath = stream.readPString();
        this.imagePath = stream.readPString();
        this.soundPath = stream.readPString();
        this.videoPath = stream.readPString();
        
        // Read scene count and scenes
        const sceneCount = stream.readUint16();
        this.scenes = [];
        for (let i = 0; i < sceneCount; i++) {
            this.scenes.push(this._readScene(stream));
        }
        
        // Read variable count and variables
        const varCount = stream.readUint16();
        this.variables = [];
        for (let i = 0; i < varCount; i++) {
            this.variables.push(this._readVariable(stream));
        }
        
        this.startScene = stream.readUint16();
    }
    
    _readScene(stream) {
        return {
            id: stream.readUint16(),
            name: stream.readPString(),
            background: stream.readPString(),
            commands: this._readCommands(stream)
        };
    }
    
    _readCommands(stream) {
        const count = stream.readUint16();
        const commands = [];
        for (let i = 0; i < count; i++) {
            commands.push({
                type: stream.readUint8(),
                params: stream.readLongString()
            });
        }
        return commands;
    }
    
    _readVariable(stream) {
        return {
            name: stream.readPString(),
            type: stream.readUint8(),
            value: stream.readInt32()
        };
    }
    
    /**
     * Save to JSON
     * @returns {Object}
     */
    toJson() {
        return {
            signature: this.signature,
            version: this.version,
            projectInfo: {
                name: this.projectName,
                author: this.author,
                description: this.description
            },
            displaySettings: {
                width: this.width,
                height: this.height,
                colorDepth: this.colorDepth,
                fullscreen: this.fullscreen
            },
            paths: {
                data: this.dataPath,
                images: this.imagePath,
                sounds: this.soundPath,
                videos: this.videoPath
            },
            scenes: this.scenes,
            variables: this.variables,
            startScene: this.startScene
        };
    }
    
    /**
     * Save to binary format
     * @returns {ArrayBuffer}
     */
    toBinary() {
        const stream = new VNOutputStream();
        
        // Write signature
        stream.writeString('VNPF', 4);
        
        // Write version
        stream.writeUint16(this.version);
        
        // Write project info
        stream.writePString(this.projectName);
        stream.writePString(this.author);
        stream.writeLongString(this.description);
        
        // Write display settings
        stream.writeUint16(this.width);
        stream.writeUint16(this.height);
        stream.writeUint8(this.colorDepth);
        stream.writeBool(this.fullscreen);
        
        // Write paths
        stream.writePString(this.dataPath);
        stream.writePString(this.imagePath);
        stream.writePString(this.soundPath);
        stream.writePString(this.videoPath);
        
        // Write scenes
        stream.writeUint16(this.scenes.length);
        for (const scene of this.scenes) {
            this._writeScene(stream, scene);
        }
        
        // Write variables
        stream.writeUint16(this.variables.length);
        for (const variable of this.variables) {
            this._writeVariable(stream, variable);
        }
        
        stream.writeUint16(this.startScene);
        
        return stream.getBuffer();
    }
    
    _writeScene(stream, scene) {
        stream.writeUint16(scene.id || 0);
        stream.writePString(scene.name || '');
        stream.writePString(scene.background || '');
        
        const commands = scene.commands || [];
        stream.writeUint16(commands.length);
        for (const cmd of commands) {
            stream.writeUint8(cmd.type || 0);
            stream.writeLongString(cmd.params || '');
        }
    }
    
    _writeVariable(stream, variable) {
        stream.writePString(variable.name || '');
        stream.writeUint8(variable.type || 0);
        stream.writeInt32(variable.value || 0);
    }
}

/**
 * VNSaveFile - Save game file format (.sav)
 * Port of VNSAVFILE @ 0x0044939b
 */
export class VNSaveFile {
    constructor() {
        this.signature = 'VNSV'; // VN Save
        this.version = 0x0100;
        this.timestamp = 0;
        this.sceneName = '';
        this.sceneIndex = 0;
        this.commandIndex = 0;
        this.variables = {};
        this.flags = {};
        this.thumbnail = null;
    }
    
    /**
     * Load from JSON (localStorage format)
     * @param {Object} json
     */
    loadFromJson(json) {
        this.timestamp = json.timestamp || Date.now();
        this.sceneName = json.sceneName || '';
        this.sceneIndex = json.sceneIndex || 0;
        this.commandIndex = json.commandIndex || 0;
        this.variables = json.variables || {};
        this.flags = json.flags || {};
        this.thumbnail = json.thumbnail || null;
    }
    
    /**
     * Save to JSON
     * @returns {Object}
     */
    toJson() {
        return {
            signature: this.signature,
            version: this.version,
            timestamp: this.timestamp,
            sceneName: this.sceneName,
            sceneIndex: this.sceneIndex,
            commandIndex: this.commandIndex,
            variables: this.variables,
            flags: this.flags,
            thumbnail: this.thumbnail
        };
    }
    
    /**
     * Create thumbnail from canvas
     * @param {HTMLCanvasElement} canvas
     * @param {number} maxWidth
     * @param {number} maxHeight
     */
    createThumbnail(canvas, maxWidth = 160, maxHeight = 120) {
        const aspectRatio = canvas.width / canvas.height;
        let width = maxWidth;
        let height = maxWidth / aspectRatio;
        
        if (height > maxHeight) {
            height = maxHeight;
            width = maxHeight * aspectRatio;
        }
        
        const thumbCanvas = document.createElement('canvas');
        thumbCanvas.width = width;
        thumbCanvas.height = height;
        
        const ctx = thumbCanvas.getContext('2d');
        ctx.drawImage(canvas, 0, 0, width, height);
        
        this.thumbnail = thumbCanvas.toDataURL('image/jpeg', 0.7);
    }
    
    /**
     * Get formatted timestamp
     * @returns {string}
     */
    getFormattedTime() {
        const date = new Date(this.timestamp);
        return date.toLocaleString();
    }
}

/**
 * VNDatFile - Data file format (DATFILE)
 * Port of DATFILE @ 0x00447794
 */
export class VNDatFile {
    constructor() {
        this.signature = 'VNDF';
        this.version = 0x0100;
        this.entries = new Map();
    }
    
    /**
     * Add entry
     * @param {string} name
     * @param {ArrayBuffer} data
     */
    addEntry(name, data) {
        this.entries.set(name.toUpperCase(), data);
    }
    
    /**
     * Get entry
     * @param {string} name
     * @returns {ArrayBuffer|null}
     */
    getEntry(name) {
        return this.entries.get(name.toUpperCase()) || null;
    }
    
    /**
     * Check if entry exists
     * @param {string} name
     * @returns {boolean}
     */
    hasEntry(name) {
        return this.entries.has(name.toUpperCase());
    }
    
    /**
     * Get all entry names
     * @returns {string[]}
     */
    getEntryNames() {
        return Array.from(this.entries.keys());
    }
    
    /**
     * Load from binary
     * @param {ArrayBuffer} data
     */
    loadFromBinary(data) {
        const stream = new VNInputStream(data);
        
        // Read signature
        const sig = stream.readString(4);
        if (sig !== 'VNDF') {
            throw new Error('Invalid VN data file');
        }
        
        this.version = stream.readUint16();
        
        // Read entry count
        const count = stream.readUint32();
        
        // Read directory
        const directory = [];
        for (let i = 0; i < count; i++) {
            directory.push({
                name: stream.readPString(),
                offset: stream.readUint32(),
                size: stream.readUint32()
            });
        }
        
        // Read entries
        for (const entry of directory) {
            stream.seek(entry.offset);
            const entryData = stream.readBytes(entry.size);
            this.entries.set(entry.name, entryData.buffer);
        }
    }
    
    /**
     * Save to binary
     * @returns {ArrayBuffer}
     */
    toBinary() {
        const stream = new VNOutputStream();
        
        // Write signature
        stream.writeString('VNDF', 4);
        stream.writeUint16(this.version);
        
        // Write entry count
        stream.writeUint32(this.entries.size);
        
        // Calculate directory size
        let dirSize = 0;
        for (const name of this.entries.keys()) {
            dirSize += 1 + name.length + 8; // pstring + offset + size
        }
        
        // Calculate data offset
        let dataOffset = 4 + 2 + 4 + dirSize;
        
        // Write directory
        const entryOffsets = [];
        for (const [name, data] of this.entries) {
            stream.writePString(name);
            stream.writeUint32(dataOffset);
            stream.writeUint32(data.byteLength);
            entryOffsets.push({ name, offset: dataOffset, data });
            dataOffset += data.byteLength;
        }
        
        // Write data
        for (const entry of entryOffsets) {
            stream.writeBytes(new Uint8Array(entry.data));
        }
        
        return stream.getBuffer();
    }
}

export default VNProjectFile;
