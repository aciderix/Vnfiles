/**
 * VNResource - Resource management classes
 * 
 * Port of resource handling from vnresmod.dll and europeo.exe
 * Manages loading, caching, and unloading of game assets
 * 
 * Original systems:
 * - vnresmod.dll - Resource module (40KB, 565KB in later versions)
 * - Resource loading via FindResourceA, LoadResource, LockResource
 * - Image loading via DirectDraw surfaces
 */

import { VNStreamable } from './VNObject.js';
import { EventEmitter } from '../utils/EventEmitter.js';

/**
 * Resource types enum
 */
export const VNResourceType = {
    UNKNOWN: 0,
    IMAGE: 1,       // BMP, JPG, PNG, GIF
    AUDIO: 2,       // WAV, MP3, OGG
    VIDEO: 3,       // AVI, MP4, WebM
    MIDI: 4,        // MID, MIDI
    SCRIPT: 5,      // VN script files
    FONT: 6,        // TTF, OTF
    DATA: 7,        // JSON, XML, binary
    PALETTE: 8      // PAL files
};

/**
 * Resource state enum
 */
export const VNResourceState = {
    UNLOADED: 0,
    LOADING: 1,
    LOADED: 2,
    ERROR: 3,
    CACHED: 4
};

/**
 * VNResource - Base resource class
 */
export class VNResource extends VNStreamable {
    constructor(options = {}) {
        super();
        
        this.id = options.id || VNResource._generateId();
        this.name = options.name || '';
        this.path = options.path || '';
        this.type = options.type || VNResourceType.UNKNOWN;
        this.state = VNResourceState.UNLOADED;
        
        // Resource data
        this.data = null;
        this.size = 0;
        
        // Metadata
        this.mimeType = options.mimeType || '';
        this.lastAccessed = 0;
        this.loadTime = 0;
        this.refCount = 0;
        
        // Error info
        this.error = null;
        
        // Events
        this._events = new EventEmitter();
    }

    static _idCounter = 0;
    static _generateId() {
        return `res_${++VNResource._idCounter}`;
    }

    /**
     * Load resource
     */
    async load() {
        if (this.state === VNResourceState.LOADED || 
            this.state === VNResourceState.LOADING) {
            return this.data;
        }
        
        this.state = VNResourceState.LOADING;
        const startTime = performance.now();
        
        try {
            this.data = await this._doLoad();
            this.state = VNResourceState.LOADED;
            this.loadTime = performance.now() - startTime;
            this.lastAccessed = Date.now();
            this._events.emit('load', this);
            return this.data;
        } catch (err) {
            this.state = VNResourceState.ERROR;
            this.error = err;
            this._events.emit('error', err, this);
            throw err;
        }
    }

    /**
     * Internal load implementation (override in subclasses)
     */
    async _doLoad() {
        const response = await fetch(this.path);
        if (!response.ok) {
            throw new Error(`Failed to load resource: ${this.path}`);
        }
        
        this.mimeType = response.headers.get('content-type') || '';
        const blob = await response.blob();
        this.size = blob.size;
        
        return blob;
    }

    /**
     * Unload resource
     */
    unload() {
        if (this.state === VNResourceState.UNLOADED) return;
        
        this._doUnload();
        this.data = null;
        this.state = VNResourceState.UNLOADED;
        this._events.emit('unload', this);
    }

    /**
     * Internal unload implementation
     */
    _doUnload() {
        // Override in subclasses for specific cleanup
    }

    /**
     * Increment reference count
     */
    addRef() {
        this.refCount++;
        this.lastAccessed = Date.now();
        return this.refCount;
    }

    /**
     * Decrement reference count
     */
    release() {
        this.refCount = Math.max(0, this.refCount - 1);
        return this.refCount;
    }

    /**
     * Event subscription
     */
    on(event, handler) {
        this._events.on(event, handler);
        return this;
    }

    off(event, handler) {
        this._events.off(event, handler);
        return this;
    }
}

/**
 * VNImageResource - Image resource
 */
export class VNImageResource extends VNResource {
    constructor(options = {}) {
        super({ ...options, type: VNResourceType.IMAGE });
        
        this.width = 0;
        this.height = 0;
        this.image = null;
    }

    async _doLoad() {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            
            img.onload = () => {
                this.image = img;
                this.width = img.naturalWidth;
                this.height = img.naturalHeight;
                this.size = this.width * this.height * 4; // Approximate
                resolve(img);
            };
            
            img.onerror = () => {
                reject(new Error(`Failed to load image: ${this.path}`));
            };
            
            img.src = this.path;
        });
    }

    _doUnload() {
        if (this.image) {
            this.image.src = '';
            this.image = null;
        }
    }

    /**
     * Get as canvas
     */
    toCanvas() {
        if (!this.image) return null;
        
        const canvas = document.createElement('canvas');
        canvas.width = this.width;
        canvas.height = this.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(this.image, 0, 0);
        return canvas;
    }

    /**
     * Get image data
     */
    getImageData() {
        const canvas = this.toCanvas();
        if (!canvas) return null;
        
        const ctx = canvas.getContext('2d');
        return ctx.getImageData(0, 0, this.width, this.height);
    }
}

/**
 * VNAudioResource - Audio resource
 */
export class VNAudioResource extends VNResource {
    constructor(options = {}) {
        super({ ...options, type: VNResourceType.AUDIO });
        
        this.duration = 0;
        this.audioBuffer = null;
        this._audioContext = options.audioContext || null;
    }

    async _doLoad() {
        const response = await fetch(this.path);
        if (!response.ok) {
            throw new Error(`Failed to load audio: ${this.path}`);
        }
        
        const arrayBuffer = await response.arrayBuffer();
        this.size = arrayBuffer.byteLength;
        
        // Decode audio if context provided
        if (this._audioContext) {
            this.audioBuffer = await this._audioContext.decodeAudioData(arrayBuffer);
            this.duration = this.audioBuffer.duration;
        }
        
        return this.audioBuffer || arrayBuffer;
    }

    _doUnload() {
        this.audioBuffer = null;
    }

    /**
     * Create audio element
     */
    createAudioElement() {
        const audio = new Audio(this.path);
        audio.preload = 'auto';
        return audio;
    }
}

/**
 * VNVideoResource - Video resource
 */
export class VNVideoResource extends VNResource {
    constructor(options = {}) {
        super({ ...options, type: VNResourceType.VIDEO });
        
        this.width = 0;
        this.height = 0;
        this.duration = 0;
        this.video = null;
    }

    async _doLoad() {
        return new Promise((resolve, reject) => {
            const video = document.createElement('video');
            video.preload = 'metadata';
            video.crossOrigin = 'anonymous';
            
            video.onloadedmetadata = () => {
                this.video = video;
                this.width = video.videoWidth;
                this.height = video.videoHeight;
                this.duration = video.duration;
                resolve(video);
            };
            
            video.onerror = () => {
                reject(new Error(`Failed to load video: ${this.path}`));
            };
            
            video.src = this.path;
        });
    }

    _doUnload() {
        if (this.video) {
            this.video.src = '';
            this.video = null;
        }
    }
}

/**
 * VNResourceManager - Resource management system
 * Port of vnresmod.dll functionality
 */
export class VNResourceManager {
    constructor(options = {}) {
        this._resources = new Map();
        this._pathMap = new Map();
        
        // Cache settings
        this._maxCacheSize = options.maxCacheSize || 100 * 1024 * 1024; // 100MB
        this._currentCacheSize = 0;
        
        // Base path for resources
        this._basePath = options.basePath || '';
        
        // Audio context for audio resources
        this._audioContext = options.audioContext || null;
        
        // Events
        this._events = new EventEmitter();
        
        // Loading queue
        this._loadQueue = [];
        this._isLoading = false;
        this._maxConcurrent = options.maxConcurrent || 4;
        this._activeLoads = 0;
    }

    /**
     * Set base path
     */
    setBasePath(path) {
        this._basePath = path.endsWith('/') ? path : path + '/';
    }

    /**
     * Get full path
     */
    getFullPath(relativePath) {
        if (relativePath.startsWith('http://') || 
            relativePath.startsWith('https://') ||
            relativePath.startsWith('/')) {
            return relativePath;
        }
        return this._basePath + relativePath;
    }

    /**
     * Detect resource type from path
     */
    detectType(path) {
        const ext = path.split('.').pop().toLowerCase();
        
        const typeMap = {
            // Images
            'bmp': VNResourceType.IMAGE,
            'jpg': VNResourceType.IMAGE,
            'jpeg': VNResourceType.IMAGE,
            'png': VNResourceType.IMAGE,
            'gif': VNResourceType.IMAGE,
            'webp': VNResourceType.IMAGE,
            
            // Audio
            'wav': VNResourceType.AUDIO,
            'mp3': VNResourceType.AUDIO,
            'ogg': VNResourceType.AUDIO,
            'aac': VNResourceType.AUDIO,
            
            // Video
            'avi': VNResourceType.VIDEO,
            'mp4': VNResourceType.VIDEO,
            'webm': VNResourceType.VIDEO,
            'mkv': VNResourceType.VIDEO,
            
            // MIDI
            'mid': VNResourceType.MIDI,
            'midi': VNResourceType.MIDI,
            
            // Data
            'json': VNResourceType.DATA,
            'xml': VNResourceType.DATA,
            
            // Fonts
            'ttf': VNResourceType.FONT,
            'otf': VNResourceType.FONT,
            'woff': VNResourceType.FONT,
            'woff2': VNResourceType.FONT
        };
        
        return typeMap[ext] || VNResourceType.UNKNOWN;
    }

    /**
     * Create resource for type
     */
    _createResource(type, options) {
        switch (type) {
            case VNResourceType.IMAGE:
                return new VNImageResource(options);
            case VNResourceType.AUDIO:
                return new VNAudioResource({ 
                    ...options, 
                    audioContext: this._audioContext 
                });
            case VNResourceType.VIDEO:
                return new VNVideoResource(options);
            default:
                return new VNResource(options);
        }
    }

    /**
     * Get or create resource
     */
    getResource(path, options = {}) {
        const fullPath = this.getFullPath(path);
        
        // Check if already exists
        if (this._pathMap.has(fullPath)) {
            const id = this._pathMap.get(fullPath);
            return this._resources.get(id);
        }
        
        // Create new resource
        const type = options.type || this.detectType(path);
        const resource = this._createResource(type, {
            name: options.name || path,
            path: fullPath,
            ...options
        });
        
        this._resources.set(resource.id, resource);
        this._pathMap.set(fullPath, resource.id);
        
        return resource;
    }

    /**
     * Load resource
     */
    async load(path, options = {}) {
        const resource = this.getResource(path, options);
        resource.addRef();
        
        await resource.load();
        this._updateCacheSize();
        
        return resource;
    }

    /**
     * Load multiple resources
     */
    async loadAll(paths, options = {}) {
        const resources = paths.map(path => this.getResource(path, options));
        
        const results = await Promise.allSettled(
            resources.map(res => {
                res.addRef();
                return res.load();
            })
        );
        
        this._updateCacheSize();
        
        return resources.map((res, i) => ({
            resource: res,
            success: results[i].status === 'fulfilled',
            error: results[i].reason
        }));
    }

    /**
     * Preload resources
     */
    async preload(paths, onProgress) {
        const total = paths.length;
        let loaded = 0;
        
        for (const path of paths) {
            try {
                await this.load(path);
            } catch (err) {
                console.warn(`Failed to preload: ${path}`, err);
            }
            
            loaded++;
            if (onProgress) {
                onProgress(loaded, total, path);
            }
        }
    }

    /**
     * Unload resource
     */
    unload(pathOrId) {
        let resource;
        
        if (this._resources.has(pathOrId)) {
            resource = this._resources.get(pathOrId);
        } else {
            const fullPath = this.getFullPath(pathOrId);
            const id = this._pathMap.get(fullPath);
            resource = this._resources.get(id);
        }
        
        if (resource) {
            resource.release();
            if (resource.refCount === 0) {
                resource.unload();
            }
        }
    }

    /**
     * Force unload resource
     */
    forceUnload(pathOrId) {
        let resource, id;
        
        if (this._resources.has(pathOrId)) {
            id = pathOrId;
            resource = this._resources.get(id);
        } else {
            const fullPath = this.getFullPath(pathOrId);
            id = this._pathMap.get(fullPath);
            resource = this._resources.get(id);
        }
        
        if (resource) {
            resource.unload();
            this._resources.delete(id);
            this._pathMap.delete(resource.path);
            this._updateCacheSize();
        }
    }

    /**
     * Get resource by ID
     */
    getById(id) {
        return this._resources.get(id);
    }

    /**
     * Get resource by path
     */
    getByPath(path) {
        const fullPath = this.getFullPath(path);
        const id = this._pathMap.get(fullPath);
        return id ? this._resources.get(id) : null;
    }

    /**
     * Check if resource is loaded
     */
    isLoaded(path) {
        const resource = this.getByPath(path);
        return resource?.state === VNResourceState.LOADED;
    }

    /**
     * Update cache size calculation
     */
    _updateCacheSize() {
        this._currentCacheSize = 0;
        for (const resource of this._resources.values()) {
            if (resource.state === VNResourceState.LOADED) {
                this._currentCacheSize += resource.size;
            }
        }
    }

    /**
     * Cleanup unused resources
     */
    cleanup() {
        const toRemove = [];
        
        for (const [id, resource] of this._resources) {
            if (resource.refCount === 0 && 
                resource.state === VNResourceState.LOADED) {
                toRemove.push(id);
            }
        }
        
        for (const id of toRemove) {
            const resource = this._resources.get(id);
            resource.unload();
            this._resources.delete(id);
            this._pathMap.delete(resource.path);
        }
        
        this._updateCacheSize();
        return toRemove.length;
    }

    /**
     * Trim cache to max size
     */
    trimCache() {
        if (this._currentCacheSize <= this._maxCacheSize) return;
        
        // Sort by last accessed (oldest first)
        const sorted = [...this._resources.values()]
            .filter(r => r.refCount === 0 && r.state === VNResourceState.LOADED)
            .sort((a, b) => a.lastAccessed - b.lastAccessed);
        
        for (const resource of sorted) {
            if (this._currentCacheSize <= this._maxCacheSize) break;
            
            this._currentCacheSize -= resource.size;
            resource.unload();
            this._resources.delete(resource.id);
            this._pathMap.delete(resource.path);
        }
    }

    /**
     * Clear all resources
     */
    clear() {
        for (const resource of this._resources.values()) {
            resource.unload();
        }
        this._resources.clear();
        this._pathMap.clear();
        this._currentCacheSize = 0;
    }

    /**
     * Get cache statistics
     */
    getStats() {
        let loaded = 0, loading = 0, errors = 0;
        
        for (const resource of this._resources.values()) {
            switch (resource.state) {
                case VNResourceState.LOADED: loaded++; break;
                case VNResourceState.LOADING: loading++; break;
                case VNResourceState.ERROR: errors++; break;
            }
        }
        
        return {
            total: this._resources.size,
            loaded,
            loading,
            errors,
            cacheSize: this._currentCacheSize,
            maxCacheSize: this._maxCacheSize,
            cacheUsage: this._currentCacheSize / this._maxCacheSize
        };
    }

    /**
     * Event subscription
     */
    on(event, handler) {
        this._events.on(event, handler);
        return this;
    }

    off(event, handler) {
        this._events.off(event, handler);
        return this;
    }
}

export default {
    VNResourceType,
    VNResourceState,
    VNResource,
    VNImageResource,
    VNAudioResource,
    VNVideoResource,
    VNResourceManager
};
