/**
 * VNObject - Base object class for all VN Engine objects
 * 
 * Port of TVNObject from europeo.exe (0x00410c0d)
 * Base class providing common functionality for all VN objects
 */

/**
 * TVNStreamable - Serialization base class
 * Port of TVNStreamable from europeo.exe (0x00410ba2)
 */
export class VNStreamable {
    constructor() {
        this._streamVersion = 1;
        this._modified = false;
    }

    /**
     * Serialize object to JSON
     * Mirrors: TVNStreamable::Write @ 0x00414ca1
     */
    serialize() {
        return {
            _type: this.constructor.name,
            _version: this._streamVersion
        };
    }

    /**
     * Deserialize object from JSON
     * Mirrors: TVNStreamable::Read @ 0x00414b2a
     */
    deserialize(data) {
        if (data._version) {
            this._streamVersion = data._version;
        }
        return this;
    }

    /**
     * Mark object as modified
     */
    setModified(value = true) {
        this._modified = value;
    }

    /**
     * Check if object is modified
     */
    isModified() {
        return this._modified;
    }
}

/**
 * TVNObject - Base object class
 * Port of TVNObject from europeo.exe (0x00410c0d)
 * Size: 82 bytes in original
 */
export class VNObject extends VNStreamable {
    constructor() {
        super();
        
        // Object identification (offset 0x00)
        this.id = 0;
        this.name = '';
        
        // Position and size (offset 0x08)
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;
        
        // State flags (offset 0x18)
        this.visible = true;
        this.enabled = true;
        this.active = true;
        
        // Z-order (offset 0x1C)
        this.zOrder = 0;
        
        // Parent reference (offset 0x20)
        this.parent = null;
        
        // Custom data (offset 0x24)
        this.userData = null;
        
        // Creation timestamp
        this._createdAt = Date.now();
    }

    /**
     * Set object position
     * Mirrors: TVNObject::SetPosition @ fcn.00419750
     */
    setPosition(x, y) {
        this.x = x;
        this.y = y;
        this.setModified();
    }

    /**
     * Set object size
     * Mirrors: TVNObject::SetSize @ fcn.00419a6c
     */
    setSize(width, height) {
        this.width = width;
        this.height = height;
        this.setModified();
    }

    /**
     * Set object bounds (position + size)
     * Mirrors: TVNObject::SetBounds
     */
    setBounds(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.setModified();
    }

    /**
     * Get object bounds as rect
     */
    getBounds() {
        return {
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            right: this.x + this.width,
            bottom: this.y + this.height
        };
    }

    /**
     * Show the object
     * Mirrors: TVNObject::Show @ case 43 in command handler
     */
    show() {
        this.visible = true;
        this.setModified();
    }

    /**
     * Hide the object
     * Mirrors: TVNObject::Hide @ case 44 in command handler
     */
    hide() {
        this.visible = false;
        this.setModified();
    }

    /**
     * Enable the object
     */
    enable() {
        this.enabled = true;
        this.setModified();
    }

    /**
     * Disable the object
     */
    disable() {
        this.enabled = false;
        this.setModified();
    }

    /**
     * Check if point is inside object bounds
     * Mirrors: TVNObject::HitTest
     */
    hitTest(px, py) {
        return px >= this.x && px < this.x + this.width &&
               py >= this.y && py < this.y + this.height;
    }

    /**
     * Clone the object
     */
    clone() {
        const cloned = new this.constructor();
        Object.assign(cloned, this.serialize());
        cloned.deserialize(this.serialize());
        return cloned;
    }

    /**
     * Destroy the object
     * Mirrors: TVNObject::~TVNObject (destructor)
     */
    destroy() {
        this.parent = null;
        this.userData = null;
        this.active = false;
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            name: this.name,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            visible: this.visible,
            enabled: this.enabled,
            zOrder: this.zOrder
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.id !== undefined) this.id = data.id;
        if (data.name !== undefined) this.name = data.name;
        if (data.x !== undefined) this.x = data.x;
        if (data.y !== undefined) this.y = data.y;
        if (data.width !== undefined) this.width = data.width;
        if (data.height !== undefined) this.height = data.height;
        if (data.visible !== undefined) this.visible = data.visible;
        if (data.enabled !== undefined) this.enabled = data.enabled;
        if (data.zOrder !== undefined) this.zOrder = data.zOrder;
        return this;
    }
}

/**
 * TVNIndexDependant - Index dependency manager
 * Port of TVNIndexDependant from europeo.exe (0x004104ab)
 */
export class VNIndexDependant extends VNObject {
    constructor() {
        super();
        this.index = -1;
        this.dependsOn = null;
        this.dependencies = [];
    }

    /**
     * Set dependency index
     */
    setIndex(index) {
        this.index = index;
        this.setModified();
    }

    /**
     * Add a dependency
     */
    addDependency(obj) {
        if (!this.dependencies.includes(obj)) {
            this.dependencies.push(obj);
            this.setModified();
        }
    }

    /**
     * Remove a dependency
     */
    removeDependency(obj) {
        const idx = this.dependencies.indexOf(obj);
        if (idx !== -1) {
            this.dependencies.splice(idx, 1);
            this.setModified();
        }
    }

    /**
     * Check if this object depends on another
     */
    dependsOnObject(obj) {
        return this.dependencies.includes(obj);
    }

    serialize() {
        return {
            ...super.serialize(),
            index: this.index
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.index !== undefined) this.index = data.index;
        return this;
    }
}

export default VNObject;
