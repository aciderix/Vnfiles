/**
 * VNClipboard - Clipboard and Drag-Drop System
 * 
 * EXACT PORT from Windows clipboard and OLE drag-drop
 * 
 * Original functions from disassembly:
 * - wm_vndraplistdrop @ 0x0044e01d (custom drag-drop message)
 * - DragQueryFileA @ 0x004519cc
 * - DragFinish @ 0x004519de
 * - OLE32.dll @ 0x0045108b
 * 
 * Clipboard formats:
 * - CF_TEXT (1)
 * - CF_BITMAP (2)
 * - CF_DIB (8)
 * - CF_HDROP (15)
 */

/**
 * Clipboard format constants
 * Port of Windows clipboard formats
 */
export const CF = {
    TEXT: 1,
    BITMAP: 2,
    METAFILEPICT: 3,
    SYLK: 4,
    DIF: 5,
    TIFF: 6,
    OEMTEXT: 7,
    DIB: 8,
    PALETTE: 9,
    PENDATA: 10,
    RIFF: 11,
    WAVE: 12,
    UNICODETEXT: 13,
    ENHMETAFILE: 14,
    HDROP: 15,
    LOCALE: 16,
    DIBV5: 17
};

/**
 * VNClipboard - Clipboard management
 */
export class VNClipboard {
    constructor() {
        this.data = new Map();
        this.formatNames = new Map();
        this.ownerWindow = null;
        
        // Register standard format names
        this.formatNames.set(CF.TEXT, 'Text');
        this.formatNames.set(CF.BITMAP, 'Bitmap');
        this.formatNames.set(CF.DIB, 'DIB');
        this.formatNames.set(CF.HDROP, 'HDROP');
        this.formatNames.set(CF.UNICODETEXT, 'UnicodeText');
    }

    /**
     * Open clipboard
     * @param {*} owner 
     * @returns {boolean}
     */
    open(owner = null) {
        this.ownerWindow = owner;
        return true;
    }

    /**
     * Close clipboard
     * @returns {boolean}
     */
    close() {
        this.ownerWindow = null;
        return true;
    }

    /**
     * Empty clipboard
     * @returns {boolean}
     */
    empty() {
        this.data.clear();
        return true;
    }

    /**
     * Set clipboard data
     * @param {number} format 
     * @param {*} data 
     * @returns {boolean}
     */
    setData(format, data) {
        this.data.set(format, data);
        return true;
    }

    /**
     * Get clipboard data
     * @param {number} format 
     * @returns {*}
     */
    getData(format) {
        return this.data.get(format);
    }

    /**
     * Check if format available
     * @param {number} format 
     * @returns {boolean}
     */
    isFormatAvailable(format) {
        return this.data.has(format);
    }

    /**
     * Get available formats
     * @returns {number[]}
     */
    getFormats() {
        return Array.from(this.data.keys());
    }

    /**
     * Register clipboard format
     * @param {string} name 
     * @returns {number}
     */
    registerFormat(name) {
        // Find unused format ID
        let id = 0xC000;
        while (this.formatNames.has(id)) {
            id++;
        }
        this.formatNames.set(id, name);
        return id;
    }

    /**
     * Get format name
     * @param {number} format 
     * @returns {string}
     */
    getFormatName(format) {
        return this.formatNames.get(format) || `Format ${format}`;
    }

    /**
     * Set text
     * @param {string} text 
     */
    async setText(text) {
        this.setData(CF.TEXT, text);
        this.setData(CF.UNICODETEXT, text);
        
        // Try native clipboard
        try {
            await navigator.clipboard.writeText(text);
        } catch (e) {
            console.warn('Could not write to native clipboard:', e);
        }
    }

    /**
     * Get text
     * @returns {Promise<string>}
     */
    async getText() {
        // Try native clipboard first
        try {
            const text = await navigator.clipboard.readText();
            return text;
        } catch (e) {
            // Fall back to internal
            return this.getData(CF.TEXT) || this.getData(CF.UNICODETEXT) || '';
        }
    }

    /**
     * Check if has text
     * @returns {boolean}
     */
    hasText() {
        return this.isFormatAvailable(CF.TEXT) || this.isFormatAvailable(CF.UNICODETEXT);
    }

    /**
     * Set image
     * @param {HTMLImageElement|HTMLCanvasElement} image 
     */
    async setImage(image) {
        // Store internally
        this.setData(CF.BITMAP, image);
        
        // Try native clipboard
        try {
            let canvas;
            if (image instanceof HTMLCanvasElement) {
                canvas = image;
            } else {
                canvas = document.createElement('canvas');
                canvas.width = image.width;
                canvas.height = image.height;
                canvas.getContext('2d').drawImage(image, 0, 0);
            }
            
            const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
            await navigator.clipboard.write([
                new ClipboardItem({ 'image/png': blob })
            ]);
        } catch (e) {
            console.warn('Could not write image to native clipboard:', e);
        }
    }

    /**
     * Get image
     * @returns {Promise<HTMLImageElement|null>}
     */
    async getImage() {
        // Try native clipboard first
        try {
            const items = await navigator.clipboard.read();
            for (const item of items) {
                if (item.types.includes('image/png')) {
                    const blob = await item.getType('image/png');
                    const url = URL.createObjectURL(blob);
                    const img = new Image();
                    await new Promise((resolve, reject) => {
                        img.onload = resolve;
                        img.onerror = reject;
                        img.src = url;
                    });
                    URL.revokeObjectURL(url);
                    return img;
                }
            }
        } catch (e) {
            // Fall back to internal
        }
        
        return this.getData(CF.BITMAP) || null;
    }

    /**
     * Check if has image
     * @returns {boolean}
     */
    hasImage() {
        return this.isFormatAvailable(CF.BITMAP) || this.isFormatAvailable(CF.DIB);
    }
}

/**
 * Global clipboard instance
 */
export const clipboard = new VNClipboard();

/**
 * VNDropFiles - Dropped files handler
 * Port of HDROP handling
 */
export class VNDropFiles {
    constructor() {
        this.files = [];
        this.dropPoint = { x: 0, y: 0 };
    }

    /**
     * Query file count
     * @returns {number}
     */
    queryFileCount() {
        return this.files.length;
    }

    /**
     * Query file name
     * Port of DragQueryFileA @ 0x004519cc
     * @param {number} index 
     * @returns {string}
     */
    queryFile(index) {
        if (index >= 0 && index < this.files.length) {
            return this.files[index].name;
        }
        return '';
    }

    /**
     * Query drop point
     * @returns {{x: number, y: number}}
     */
    queryPoint() {
        return { ...this.dropPoint };
    }

    /**
     * Get file at index
     * @param {number} index 
     * @returns {File|null}
     */
    getFile(index) {
        return this.files[index] || null;
    }

    /**
     * Get all files
     * @returns {File[]}
     */
    getFiles() {
        return [...this.files];
    }

    /**
     * Finish drag operation
     * Port of DragFinish @ 0x004519de
     */
    finish() {
        this.files = [];
        this.dropPoint = { x: 0, y: 0 };
    }

    /**
     * Set from DataTransfer
     * @param {DataTransfer} dataTransfer 
     * @param {number} x 
     * @param {number} y 
     */
    setFromDataTransfer(dataTransfer, x = 0, y = 0) {
        this.files = Array.from(dataTransfer.files);
        this.dropPoint = { x, y };
    }
}

/**
 * VNDragDrop - Drag and Drop manager
 * Port of OLE drag-drop system
 */
export class VNDragDrop {
    constructor() {
        this.dropTargets = new Map();
        this.currentDrag = null;
        this.dropFiles = new VNDropFiles();
    }

    /**
     * Register drop target
     * @param {HTMLElement} element 
     * @param {Object} handlers 
     */
    registerDropTarget(element, handlers = {}) {
        const config = {
            element,
            onEnter: handlers.onEnter || (() => {}),
            onOver: handlers.onOver || (() => {}),
            onLeave: handlers.onLeave || (() => {}),
            onDrop: handlers.onDrop || (() => {}),
            acceptTypes: handlers.acceptTypes || ['*']
        };
        
        this.dropTargets.set(element, config);
        
        // Set up event listeners
        element.addEventListener('dragenter', (e) => this._handleDragEnter(e, config));
        element.addEventListener('dragover', (e) => this._handleDragOver(e, config));
        element.addEventListener('dragleave', (e) => this._handleDragLeave(e, config));
        element.addEventListener('drop', (e) => this._handleDrop(e, config));
    }

    /**
     * Unregister drop target
     * @param {HTMLElement} element 
     */
    unregisterDropTarget(element) {
        this.dropTargets.delete(element);
    }

    /**
     * Start drag operation
     * @param {*} data 
     * @param {string} type 
     */
    startDrag(data, type = 'text/plain') {
        this.currentDrag = { data, type };
    }

    /**
     * End drag operation
     */
    endDrag() {
        this.currentDrag = null;
    }

    /**
     * Handle drag enter
     * @private
     */
    _handleDragEnter(e, config) {
        e.preventDefault();
        e.stopPropagation();
        
        if (this._acceptsTypes(e.dataTransfer, config.acceptTypes)) {
            config.element.classList.add('vn-drag-over');
            config.onEnter(e);
        }
    }

    /**
     * Handle drag over
     * @private
     */
    _handleDragOver(e, config) {
        e.preventDefault();
        e.stopPropagation();
        
        if (this._acceptsTypes(e.dataTransfer, config.acceptTypes)) {
            e.dataTransfer.dropEffect = 'copy';
            config.onOver(e);
        } else {
            e.dataTransfer.dropEffect = 'none';
        }
    }

    /**
     * Handle drag leave
     * @private
     */
    _handleDragLeave(e, config) {
        e.preventDefault();
        e.stopPropagation();
        
        config.element.classList.remove('vn-drag-over');
        config.onLeave(e);
    }

    /**
     * Handle drop
     * @private
     */
    _handleDrop(e, config) {
        e.preventDefault();
        e.stopPropagation();
        
        config.element.classList.remove('vn-drag-over');
        
        // Set up drop files
        if (e.dataTransfer.files.length > 0) {
            this.dropFiles.setFromDataTransfer(e.dataTransfer, e.clientX, e.clientY);
        }
        
        config.onDrop(e, {
            files: e.dataTransfer.files,
            text: e.dataTransfer.getData('text/plain'),
            html: e.dataTransfer.getData('text/html'),
            dropFiles: this.dropFiles
        });
    }

    /**
     * Check if accepts types
     * @private
     */
    _acceptsTypes(dataTransfer, acceptTypes) {
        if (acceptTypes.includes('*')) {
            return true;
        }
        
        for (const type of dataTransfer.types) {
            if (acceptTypes.includes(type)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Make element draggable
     * @param {HTMLElement} element 
     * @param {*} data 
     * @param {Object} options 
     */
    makeDraggable(element, data, options = {}) {
        element.setAttribute('draggable', 'true');
        
        element.addEventListener('dragstart', (e) => {
            this.startDrag(data, options.type || 'text/plain');
            
            // Set drag data
            if (typeof data === 'string') {
                e.dataTransfer.setData('text/plain', data);
            } else if (typeof data === 'object') {
                e.dataTransfer.setData('application/json', JSON.stringify(data));
            }
            
            // Set drag image
            if (options.dragImage) {
                e.dataTransfer.setDragImage(options.dragImage, 0, 0);
            }
            
            // Set effect
            e.dataTransfer.effectAllowed = options.effect || 'copyMove';
            
            element.classList.add('vn-dragging');
            
            if (options.onStart) {
                options.onStart(e);
            }
        });
        
        element.addEventListener('dragend', (e) => {
            this.endDrag();
            element.classList.remove('vn-dragging');
            
            if (options.onEnd) {
                options.onEnd(e);
            }
        });
    }
}

/**
 * Global drag-drop manager
 */
export const dragDrop = new VNDragDrop();

/**
 * VN_WM_DROPFILES message handler
 * Port of wm_vndraplistdrop @ 0x0044e01d
 */
export class VNDropFilesMessage {
    /**
     * @param {VNDropFiles} dropFiles 
     */
    constructor(dropFiles) {
        this.message = 'WM_DROPFILES';
        this.wParam = dropFiles;
        this.lParam = 0;
    }

    /**
     * Get drop files handle
     * @returns {VNDropFiles}
     */
    getHDrop() {
        return this.wParam;
    }
}

export default {
    CF,
    VNClipboard,
    clipboard,
    VNDropFiles,
    VNDragDrop,
    dragDrop,
    VNDropFilesMessage
};
