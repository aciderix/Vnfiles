/**
 * VNPalette - Palette and color management classes
 * 
 * Port of TVNPaletteEntries, TDefaultPalette, TPalette from europeo.exe
 * Original source: palette.cpp @ 0x004442ef
 * 
 * Handles 256-color palette management for legacy VN projects
 */

/**
 * TColor - Color value class
 * Port of TColor from OWL framework
 * Original: @TColor @ 0x00451a78
 */
export class TColor {
    // Predefined colors (from @TColor::White, @TColor::Black, etc.)
    static White = new TColor(255, 255, 255);
    static Black = new TColor(0, 0, 0);
    static LtGray = new TColor(192, 192, 192);
    static LtBlue = new TColor(173, 216, 230);
    static Red = new TColor(255, 0, 0);
    static Green = new TColor(0, 255, 0);
    static Blue = new TColor(0, 0, 255);
    static Yellow = new TColor(255, 255, 0);
    static Cyan = new TColor(0, 255, 255);
    static Magenta = new TColor(255, 0, 255);
    
    /**
     * @param {number} r - Red component (0-255)
     * @param {number} g - Green component (0-255)
     * @param {number} b - Blue component (0-255)
     * @param {number} a - Alpha component (0-255)
     */
    constructor(r = 0, g = 0, b = 0, a = 255) {
        // Original stores as COLORREF (0x00BBGGRR)
        this.r = r & 0xFF;
        this.g = g & 0xFF;
        this.b = b & 0xFF;
        this.a = a & 0xFF;
    }
    
    /**
     * GetValue - Get COLORREF value
     * Port of @TColor@GetValue$xqv @ 0x00451a38
     * @returns {number} COLORREF value (0x00BBGGRR)
     */
    getValue() {
        return (this.b << 16) | (this.g << 8) | this.r;
    }
    
    /**
     * Create from COLORREF value
     * @param {number} colorref - COLORREF value (0x00BBGGRR)
     * @returns {TColor}
     */
    static fromColorRef(colorref) {
        return new TColor(
            colorref & 0xFF,
            (colorref >> 8) & 0xFF,
            (colorref >> 16) & 0xFF
        );
    }
    
    /**
     * Create from hex string
     * @param {string} hex - Hex color string (#RRGGBB or RRGGBB)
     * @returns {TColor}
     */
    static fromHex(hex) {
        const clean = hex.replace('#', '');
        const value = parseInt(clean, 16);
        return new TColor(
            (value >> 16) & 0xFF,
            (value >> 8) & 0xFF,
            value & 0xFF
        );
    }
    
    /**
     * Convert to hex string
     * @returns {string} Hex color string (#RRGGBB)
     */
    toHex() {
        const r = this.r.toString(16).padStart(2, '0');
        const g = this.g.toString(16).padStart(2, '0');
        const b = this.b.toString(16).padStart(2, '0');
        return `#${r}${g}${b}`;
    }
    
    /**
     * Convert to CSS rgba string
     * @returns {string}
     */
    toRgba() {
        return `rgba(${this.r}, ${this.g}, ${this.b}, ${this.a / 255})`;
    }
    
    /**
     * Convert to CSS rgb string
     * @returns {string}
     */
    toRgb() {
        return `rgb(${this.r}, ${this.g}, ${this.b})`;
    }
    
    /**
     * Clone color
     * @returns {TColor}
     */
    clone() {
        return new TColor(this.r, this.g, this.b, this.a);
    }
    
    /**
     * Check equality
     * @param {TColor} other
     * @returns {boolean}
     */
    equals(other) {
        return this.r === other.r && 
               this.g === other.g && 
               this.b === other.b && 
               this.a === other.a;
    }
}

/**
 * PaletteEntry - Single palette entry
 * Port of PALETTEENTRY structure
 */
export class PaletteEntry {
    constructor(r = 0, g = 0, b = 0, flags = 0) {
        this.peRed = r;
        this.peGreen = g;
        this.peBlue = b;
        this.peFlags = flags;
    }
    
    toColor() {
        return new TColor(this.peRed, this.peGreen, this.peBlue);
    }
    
    static fromColor(color) {
        return new PaletteEntry(color.r, color.g, color.b, 0);
    }
}

/**
 * TVNPaletteEntries - Palette entries array
 * Port of TVNPaletteEntries @ 0x0041d36b
 * Original source: palette.cpp
 */
export class VNPaletteEntries {
    /**
     * @param {number} count - Number of entries (default 256)
     */
    constructor(count = 256) {
        // Original: PALETTEENTRY entries[256]
        this.entries = new Array(count);
        this.count = count;
        
        // Initialize with default grayscale palette
        for (let i = 0; i < count; i++) {
            this.entries[i] = new PaletteEntry(i, i, i, 0);
        }
    }
    
    /**
     * Get palette entry
     * @param {number} index
     * @returns {PaletteEntry}
     */
    getEntry(index) {
        if (index < 0 || index >= this.count) {
            return null;
        }
        return this.entries[index];
    }
    
    /**
     * Set palette entry
     * @param {number} index
     * @param {PaletteEntry} entry
     */
    setEntry(index, entry) {
        if (index >= 0 && index < this.count) {
            this.entries[index] = entry;
        }
    }
    
    /**
     * Set multiple entries
     * Port of SetPaletteEntries @ 0x0045401a
     * @param {number} startIndex
     * @param {PaletteEntry[]} entries
     */
    setEntries(startIndex, entries) {
        for (let i = 0; i < entries.length && (startIndex + i) < this.count; i++) {
            this.entries[startIndex + i] = entries[i];
        }
    }
    
    /**
     * Get multiple entries
     * Port of GetPaletteEntries @ 0x004540b2
     * @param {number} startIndex
     * @param {number} count
     * @returns {PaletteEntry[]}
     */
    getEntries(startIndex, count) {
        const result = [];
        for (let i = 0; i < count && (startIndex + i) < this.count; i++) {
            result.push(this.entries[startIndex + i]);
        }
        return result;
    }
    
    /**
     * Load from array of RGB values
     * @param {number[][]} rgbArray - Array of [r, g, b] values
     */
    loadFromRgbArray(rgbArray) {
        for (let i = 0; i < rgbArray.length && i < this.count; i++) {
            const [r, g, b] = rgbArray[i];
            this.entries[i] = new PaletteEntry(r, g, b, 0);
        }
    }
    
    /**
     * Convert to array of colors
     * @returns {TColor[]}
     */
    toColorArray() {
        return this.entries.map(e => e.toColor());
    }
    
    /**
     * Find nearest color index
     * @param {TColor} color
     * @returns {number} Index of nearest matching color
     */
    findNearest(color) {
        let minDist = Infinity;
        let minIndex = 0;
        
        for (let i = 0; i < this.count; i++) {
            const entry = this.entries[i];
            const dr = color.r - entry.peRed;
            const dg = color.g - entry.peGreen;
            const db = color.b - entry.peBlue;
            const dist = dr * dr + dg * dg + db * db;
            
            if (dist < minDist) {
                minDist = dist;
                minIndex = i;
                if (dist === 0) break;
            }
        }
        
        return minIndex;
    }
}

/**
 * TDefaultPalette - Default system palette
 * Port of TDefaultPalette @ 0x0041d227
 */
export class TDefaultPalette extends VNPaletteEntries {
    constructor() {
        super(256);
        this._initializeDefaultPalette();
    }
    
    /**
     * Initialize with Windows default 256-color palette
     */
    _initializeDefaultPalette() {
        // Standard Windows 16-color palette (first 16 entries)
        const standardColors = [
            [0, 0, 0],       // Black
            [128, 0, 0],     // Dark Red
            [0, 128, 0],     // Dark Green
            [128, 128, 0],   // Dark Yellow
            [0, 0, 128],     // Dark Blue
            [128, 0, 128],   // Dark Magenta
            [0, 128, 128],   // Dark Cyan
            [192, 192, 192], // Light Gray
            [128, 128, 128], // Dark Gray
            [255, 0, 0],     // Red
            [0, 255, 0],     // Green
            [255, 255, 0],   // Yellow
            [0, 0, 255],     // Blue
            [255, 0, 255],   // Magenta
            [0, 255, 255],   // Cyan
            [255, 255, 255]  // White
        ];
        
        // Set first 16 colors
        for (let i = 0; i < 16; i++) {
            const [r, g, b] = standardColors[i];
            this.entries[i] = new PaletteEntry(r, g, b, 0);
        }
        
        // Fill middle with color cube (6x6x6 = 216 colors)
        let index = 16;
        for (let r = 0; r < 6; r++) {
            for (let g = 0; g < 6; g++) {
                for (let b = 0; b < 6; b++) {
                    if (index < 232) {
                        this.entries[index] = new PaletteEntry(
                            Math.round(r * 51),
                            Math.round(g * 51),
                            Math.round(b * 51),
                            0
                        );
                        index++;
                    }
                }
            }
        }
        
        // Fill remaining with grayscale ramp
        for (let i = 232; i < 256; i++) {
            const gray = Math.round((i - 232) * 10.625);
            this.entries[i] = new PaletteEntry(gray, gray, gray, 0);
        }
    }
}

/**
 * TPalette - Logical palette class
 * Port of TPalette from OWL framework @ 0x0041d433
 */
export class TPalette {
    /**
     * @param {VNPaletteEntries|PaletteEntry[]} entries
     */
    constructor(entries = null) {
        this.handle = null; // Original: HPALETTE
        this.entries = new VNPaletteEntries(256);
        this.version = 0x300; // Windows 3.0 palette
        
        if (entries instanceof VNPaletteEntries) {
            this.entries = entries;
        } else if (Array.isArray(entries)) {
            for (let i = 0; i < entries.length; i++) {
                this.entries.setEntry(i, entries[i]);
            }
        }
    }
    
    /**
     * Create halftone palette
     * Port of CreateHalftonePalette @ 0x00454100
     * @returns {TPalette}
     */
    static createHalftone() {
        const palette = new TPalette();
        
        // Create halftone palette (8x8x4 color cube)
        let index = 0;
        for (let r = 0; r < 8; r++) {
            for (let g = 0; g < 8; g++) {
                for (let b = 0; b < 4; b++) {
                    if (index < 256) {
                        palette.entries.setEntry(index, new PaletteEntry(
                            Math.round(r * 36.43),
                            Math.round(g * 36.43),
                            Math.round(b * 85),
                            0
                        ));
                        index++;
                    }
                }
            }
        }
        
        return palette;
    }
    
    /**
     * Realize palette
     * Port of RealizePalette @ 0x00454056
     * @param {CanvasRenderingContext2D} ctx
     * @returns {number} Number of entries realized
     */
    realize(ctx) {
        // In web context, palettes are not needed for true-color displays
        // This is a compatibility stub
        return this.entries.count;
    }
    
    /**
     * Get number of entries
     * @returns {number}
     */
    getCount() {
        return this.entries.count;
    }
    
    /**
     * Get color at index
     * @param {number} index
     * @returns {TColor}
     */
    getColor(index) {
        const entry = this.entries.getEntry(index);
        return entry ? entry.toColor() : null;
    }
    
    /**
     * Convert indexed color to RGB
     * @param {number} index
     * @returns {string} CSS color string
     */
    indexToRgb(index) {
        const color = this.getColor(index);
        return color ? color.toRgb() : '#000000';
    }
}

/**
 * VNPalette - VN Engine palette manager
 * Port of VNPALETTE @ 0x00444308
 */
export class VNPalette {
    constructor() {
        this.currentPalette = new TDefaultPalette();
        this.systemPalette = new TDefaultPalette();
        this.customPalette = null;
        this.isCustom = false;
    }
    
    /**
     * Load palette from file data
     * @param {ArrayBuffer} data - Palette file data
     */
    loadFromData(data) {
        const view = new DataView(data);
        const entries = new VNPaletteEntries(256);
        
        // Read 256 RGB triplets
        for (let i = 0; i < 256 && i * 3 < data.byteLength; i++) {
            const r = view.getUint8(i * 3);
            const g = view.getUint8(i * 3 + 1);
            const b = view.getUint8(i * 3 + 2);
            entries.setEntry(i, new PaletteEntry(r, g, b, 0));
        }
        
        this.customPalette = entries;
        this.currentPalette = entries;
        this.isCustom = true;
    }
    
    /**
     * Load palette from BMP file header
     * @param {ArrayBuffer} bmpData - BMP file data
     */
    loadFromBmp(bmpData) {
        const view = new DataView(bmpData);
        
        // Check BMP signature
        if (view.getUint16(0, true) !== 0x4D42) {
            console.error('Invalid BMP file');
            return;
        }
        
        // Get info header offset and bits per pixel
        const infoOffset = view.getUint32(10, true);
        const bitsPerPixel = view.getUint16(infoOffset + 14, true);
        
        // Only 8-bit BMPs have palettes
        if (bitsPerPixel !== 8) {
            return;
        }
        
        // Palette starts after info header (usually at offset 54)
        const paletteOffset = 14 + view.getUint32(infoOffset, true);
        const numColors = view.getUint32(infoOffset + 32, true) || 256;
        
        const entries = new VNPaletteEntries(256);
        
        // Read RGBQUAD entries (BGRA format)
        for (let i = 0; i < numColors && i < 256; i++) {
            const offset = paletteOffset + i * 4;
            const b = view.getUint8(offset);
            const g = view.getUint8(offset + 1);
            const r = view.getUint8(offset + 2);
            entries.setEntry(i, new PaletteEntry(r, g, b, 0));
        }
        
        this.customPalette = entries;
        this.currentPalette = entries;
        this.isCustom = true;
    }
    
    /**
     * Reset to system palette
     */
    reset() {
        this.currentPalette = this.systemPalette;
        this.customPalette = null;
        this.isCustom = false;
    }
    
    /**
     * Get current palette
     * @returns {VNPaletteEntries}
     */
    getPalette() {
        return this.currentPalette;
    }
    
    /**
     * Apply palette to indexed image data
     * @param {Uint8Array} indexedData - 8-bit indexed pixel data
     * @param {number} width
     * @param {number} height
     * @returns {ImageData}
     */
    applyToIndexedImage(indexedData, width, height) {
        const imageData = new ImageData(width, height);
        const data = imageData.data;
        
        for (let i = 0; i < indexedData.length; i++) {
            const colorIndex = indexedData[i];
            const entry = this.currentPalette.getEntry(colorIndex);
            
            const destIndex = i * 4;
            data[destIndex] = entry.peRed;
            data[destIndex + 1] = entry.peGreen;
            data[destIndex + 2] = entry.peBlue;
            data[destIndex + 3] = 255;
        }
        
        return imageData;
    }
}

// Singleton instance
export const vnPalette = new VNPalette();

export default VNPalette;
