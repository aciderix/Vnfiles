/**
 * VNSaveLoad - Save/Load system for VN Engine
 * 
 * Handles game state persistence using localStorage
 * Mirrors the load/save commands from the original engine
 */

class VNSaveLoad extends EventEmitter {
    constructor(engine, options = {}) {
        super();
        this.engine = engine;
        
        // Configuration
        this.storagePrefix = options.storagePrefix || 'vnengine_';
        this.maxSlots = options.maxSlots || 10;
        this.autoSaveSlot = options.autoSaveSlot || 0;
        this.screenshotEnabled = options.screenshotEnabled !== false;
    }

    /**
     * Get storage key for a save slot
     * @param {number} slot - Slot number
     * @returns {string}
     */
    _getStorageKey(slot) {
        const gameId = this.engine.config?.gameId || 'default';
        return `${this.storagePrefix}${gameId}_save_${slot}`;
    }

    /**
     * Get list storage key
     * @returns {string}
     */
    _getListKey() {
        const gameId = this.engine.config?.gameId || 'default';
        return `${this.storagePrefix}${gameId}_saves`;
    }

    /**
     * Save game to slot
     * @param {number} slot - Slot number
     * @param {string} title - Save title (optional)
     * @returns {Promise<boolean>}
     */
    async save(slot = 0, title = null) {
        try {
            const state = this._collectState();
            
            const saveData = {
                slot,
                title: title || `Save ${slot + 1}`,
                timestamp: Date.now(),
                date: new Date().toISOString(),
                version: this.engine.version || '1.0.0',
                state,
                preview: this._generatePreview()
            };
            
            // Capture screenshot if enabled
            if (this.screenshotEnabled) {
                try {
                    saveData.screenshot = await this._captureScreenshot();
                } catch (e) {
                    console.warn('Screenshot capture failed:', e);
                }
            }
            
            // Save to localStorage
            const key = this._getStorageKey(slot);
            localStorage.setItem(key, JSON.stringify(saveData));
            
            // Update save list
            this._updateSaveList(slot, saveData);
            
            this.emit(VNEvents.SAVE_COMPLETE, { slot, success: true });
            this.engine.emit(VNEvents.SAVE_COMPLETE, { slot, success: true });
            
            return true;
        } catch (error) {
            console.error('Save failed:', error);
            this.emit(VNEvents.SAVE_COMPLETE, { slot, success: false, error });
            return false;
        }
    }

    /**
     * Load game from slot
     * @param {number} slot - Slot number
     * @returns {Promise<boolean>}
     */
    async load(slot = 0) {
        try {
            const key = this._getStorageKey(slot);
            const data = localStorage.getItem(key);
            
            if (!data) {
                throw new Error(`No save data in slot ${slot}`);
            }
            
            const saveData = JSON.parse(data);
            
            // Restore state
            await this._restoreState(saveData.state);
            
            this.emit(VNEvents.LOAD_COMPLETE, { slot, success: true });
            this.engine.emit(VNEvents.LOAD_COMPLETE, { slot, success: true });
            
            return true;
        } catch (error) {
            console.error('Load failed:', error);
            this.emit(VNEvents.LOAD_COMPLETE, { slot, success: false, error });
            return false;
        }
    }

    /**
     * Auto-save
     * @returns {Promise<boolean>}
     */
    async autoSave() {
        return this.save(this.autoSaveSlot, 'Auto Save');
    }

    /**
     * Delete save from slot
     * @param {number} slot - Slot number
     * @returns {boolean}
     */
    delete(slot) {
        try {
            const key = this._getStorageKey(slot);
            localStorage.removeItem(key);
            
            // Update save list
            this._removeSaveFromList(slot);
            
            return true;
        } catch (error) {
            console.error('Delete save failed:', error);
            return false;
        }
    }

    /**
     * Get save data for a slot
     * @param {number} slot - Slot number
     * @returns {Object|null}
     */
    getSaveData(slot) {
        try {
            const key = this._getStorageKey(slot);
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('Get save data failed:', error);
            return null;
        }
    }

    /**
     * Get all saves
     * @returns {Object[]}
     */
    getAllSaves() {
        const saves = [];
        
        for (let slot = 0; slot < this.maxSlots; slot++) {
            const saveData = this.getSaveData(slot);
            if (saveData) {
                saves.push({
                    slot,
                    ...saveData,
                    state: undefined // Don't include full state in list
                });
            } else {
                saves.push({
                    slot,
                    empty: true
                });
            }
        }
        
        return saves;
    }

    /**
     * Check if slot has save data
     * @param {number} slot - Slot number
     * @returns {boolean}
     */
    hasSave(slot) {
        const key = this._getStorageKey(slot);
        return localStorage.getItem(key) !== null;
    }

    /**
     * Collect current game state
     * @returns {Object}
     */
    _collectState() {
        return {
            // Scene state
            scene: {
                name: this.engine.currentScene?.name,
                index: this.engine.currentSceneIndex
            },
            
            // Variables
            variables: this.engine.variables?.getAll() || {},
            
            // Audio state
            audio: this.engine.audio?.getState() || null,
            
            // Video state (if playing)
            video: this.engine.video?.getState() || null,
            
            // Dialog state
            dialog: this.engine.dialog?.getState() || null,
            
            // Current scene objects
            sceneState: this.engine.currentScene?.getState() || null
        };
    }

    /**
     * Restore game state
     * @param {Object} state - Saved state
     */
    async _restoreState(state) {
        if (!state) return;
        
        // Clear current state
        this.engine.clearCurrentScene();
        
        // Restore variables
        if (state.variables) {
            this.engine.variables.loadAll(state.variables);
        }
        
        // Load scene
        if (state.scene) {
            await this.engine.loadSceneByIndex(state.scene.index);
        }
        
        // Restore scene objects
        if (state.sceneState && this.engine.currentScene) {
            await this.engine.currentScene.restoreState(state.sceneState);
        }
        
        // Restore audio
        if (state.audio) {
            await this.engine.audio?.restoreState(state.audio);
        }
        
        // Restore video
        if (state.video) {
            await this.engine.video?.restoreState(state.video);
        }
        
        // Restore dialog
        if (state.dialog) {
            this.engine.dialog?.restoreState(state.dialog);
        }
    }

    /**
     * Generate text preview
     * @returns {string}
     */
    _generatePreview() {
        const sceneName = this.engine.currentScene?.name || 'Unknown Scene';
        const dialogText = this.engine.dialog?.getCurrentText() || '';
        
        let preview = `Scene: ${sceneName}`;
        if (dialogText) {
            preview += ` - "${dialogText.substring(0, 50)}${dialogText.length > 50 ? '...' : ''}"`;
        }
        
        return preview;
    }

    /**
     * Capture screenshot of current viewport
     * @returns {Promise<string>} Base64 data URL
     */
    async _captureScreenshot() {
        const viewport = document.getElementById('vn-viewport');
        if (!viewport) return null;
        
        // Use html2canvas if available, otherwise return null
        if (typeof html2canvas === 'function') {
            const canvas = await html2canvas(viewport, {
                scale: 0.25, // Small thumbnail
                logging: false
            });
            return canvas.toDataURL('image/jpeg', 0.6);
        }
        
        return null;
    }

    /**
     * Update save list metadata
     * @param {number} slot - Slot number
     * @param {Object} saveData - Save data
     */
    _updateSaveList(slot, saveData) {
        const listKey = this._getListKey();
        let list = {};
        
        try {
            const stored = localStorage.getItem(listKey);
            if (stored) {
                list = JSON.parse(stored);
            }
        } catch (e) {}
        
        list[slot] = {
            title: saveData.title,
            timestamp: saveData.timestamp,
            date: saveData.date,
            preview: saveData.preview
        };
        
        localStorage.setItem(listKey, JSON.stringify(list));
    }

    /**
     * Remove save from list
     * @param {number} slot - Slot number
     */
    _removeSaveFromList(slot) {
        const listKey = this._getListKey();
        
        try {
            const stored = localStorage.getItem(listKey);
            if (stored) {
                const list = JSON.parse(stored);
                delete list[slot];
                localStorage.setItem(listKey, JSON.stringify(list));
            }
        } catch (e) {}
    }

    /**
     * Export save to JSON string
     * @param {number} slot - Slot number
     * @returns {string|null}
     */
    exportSave(slot) {
        const saveData = this.getSaveData(slot);
        if (!saveData) return null;
        
        return JSON.stringify(saveData, null, 2);
    }

    /**
     * Import save from JSON string
     * @param {number} slot - Target slot
     * @param {string} jsonString - JSON save data
     * @returns {boolean}
     */
    importSave(slot, jsonString) {
        try {
            const saveData = JSON.parse(jsonString);
            saveData.slot = slot;
            
            const key = this._getStorageKey(slot);
            localStorage.setItem(key, JSON.stringify(saveData));
            
            this._updateSaveList(slot, saveData);
            
            return true;
        } catch (error) {
            console.error('Import save failed:', error);
            return false;
        }
    }

    /**
     * Clear all saves
     * @returns {boolean}
     */
    clearAllSaves() {
        try {
            for (let slot = 0; slot < this.maxSlots; slot++) {
                this.delete(slot);
            }
            
            localStorage.removeItem(this._getListKey());
            
            return true;
        } catch (error) {
            console.error('Clear saves failed:', error);
            return false;
        }
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNSaveLoad };
}
