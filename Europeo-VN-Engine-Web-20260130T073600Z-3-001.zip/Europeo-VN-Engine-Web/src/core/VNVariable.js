/**
 * VNVariable - Exact port of TVNVariable from vndllapi.dll
 * 
 * Original structure (0x108 bytes = 264 bytes):
 * - Offset 0x000: char name[256]  - Variable name (uppercase)
 * - Offset 0x100: int32 value     - Variable value
 * - Offset 0x104: TVNVariable* next - Next variable in linked list
 * 
 * Ported from: sym.vndllapi.dll_VNDLLVarAddModify @ 0x004014dd
 *              sym.vndllapi.dll_VNDLLVarFind @ 0x00401499
 */

class VNVariable {
    constructor() {
        // Linked list head pointer (mirrors the global var list in original)
        this._head = null;
        // Variable count for debugging
        this._count = 0;
    }

    /**
     * VNDLLVarFind - Find variable by name
     * Original: 0x00401499 (68 bytes)
     * 
     * Assembly logic:
     *   mov esi, [arg_ch]     ; name parameter
     *   mov edi, [arg_8h]     ; list head pointer
     *   test esi, esi
     *   je return_null
     *   cmp byte [esi], 0
     *   je return_null
     *   mov ebx, [edi]        ; current = head
     * loop:
     *   test ebx, ebx
     *   je return_null
     *   push esi
     *   push ebx
     *   call stricmp          ; case-insensitive compare
     *   test eax, eax
     *   je found
     *   mov ebx, [ebx + 0x104] ; current = current->next
     *   jmp loop
     * found:
     *   mov eax, [ebx + 0x100] ; return value
     */
    find(name) {
        if (!name || name.length === 0) {
            return null;
        }
        
        const upperName = name.toUpperCase();
        let current = this._head;
        
        while (current !== null) {
            if (current.name === upperName) {
                return current;
            }
            current = current.next;
        }
        
        return null;
    }

    /**
     * VNDLLVarAddModify - Add or modify variable
     * Original: 0x004014dd (213 bytes)
     * 
     * Assembly logic:
     *   ; Check if name is valid
     *   test esi, esi
     *   je return_null
     *   cmp byte [esi], 0
     *   je return_null
     *   
     *   ; Search for existing variable
     *   xor edx, edx
     *   mov [var_4h], edx     ; prev = null
     *   mov ebx, [edi]        ; current = head
     *   test ebx, ebx
     *   je create_first
     *   
     * search_loop:
     *   mov [var_4h], ebx     ; prev = current
     *   push esi
     *   push ebx
     *   call stricmp
     *   test eax, eax
     *   je found_modify
     *   mov ebx, [ebx + 0x104] ; current = current->next
     *   test ebx, ebx
     *   jne search_loop
     *   
     * found_modify:
     *   test ebx, ebx
     *   je create_new
     *   mov eax, [arg_10h]    ; value
     *   mov [ebx + 0x100], eax ; current->value = value
     *   mov eax, ebx
     *   jmp return
     *   
     * create_new:
     *   push 0x108            ; sizeof(TVNVariable)
     *   call __bnew_qui       ; allocate
     *   mov ebx, eax
     *   push esi
     *   push ebx
     *   call strcpy           ; copy name
     *   push ebx
     *   call strupr           ; uppercase
     *   mov eax, [arg_10h]
     *   mov [ebx + 0x100], eax ; value
     *   xor edx, edx
     *   mov [ebx + 0x104], edx ; next = null
     *   mov ecx, [var_4h]     ; prev
     *   mov [ecx + 0x104], ebx ; prev->next = new
     *   
     * create_first:
     *   ; Same as create_new but sets head
     *   push 0x108
     *   call __bnew_qui
     *   mov [edi], eax        ; head = new
     *   ; ... rest same as create_new
     */
    set(name, value) {
        if (!name || name.length === 0) {
            return null;
        }
        
        const upperName = name.toUpperCase();
        let prev = null;
        let current = this._head;
        
        // Search for existing variable
        while (current !== null) {
            if (current.name === upperName) {
                // Found - modify value
                current.value = value;
                return current;
            }
            prev = current;
            current = current.next;
        }
        
        // Create new variable node
        const newVar = {
            name: upperName,
            value: value,
            next: null
        };
        
        if (prev === null) {
            // First variable - set as head
            this._head = newVar;
        } else {
            // Append to list
            prev.next = newVar;
        }
        
        this._count++;
        return newVar;
    }

    /**
     * Get variable value
     * Returns 0 if not found (matches original behavior)
     */
    get(name) {
        const varNode = this.find(name);
        return varNode ? varNode.value : 0;
    }

    /**
     * inc_var command handler (case 23)
     * Original: adds value to existing variable
     */
    increment(name, amount = 1) {
        const current = this.get(name);
        return this.set(name, current + amount);
    }

    /**
     * dec_var command handler (case 24)
     * Original: subtracts value from existing variable
     */
    decrement(name, amount = 1) {
        const current = this.get(name);
        return this.set(name, current - amount);
    }

    /**
     * Check if variable exists
     */
    exists(name) {
        return this.find(name) !== null;
    }

    /**
     * Delete variable from list
     */
    delete(name) {
        if (!name || name.length === 0) {
            return false;
        }
        
        const upperName = name.toUpperCase();
        let prev = null;
        let current = this._head;
        
        while (current !== null) {
            if (current.name === upperName) {
                if (prev === null) {
                    this._head = current.next;
                } else {
                    prev.next = current.next;
                }
                this._count--;
                return true;
            }
            prev = current;
            current = current.next;
        }
        
        return false;
    }

    /**
     * Get all variables as object (for save/load)
     */
    getAll() {
        const result = {};
        let current = this._head;
        
        while (current !== null) {
            result[current.name] = current.value;
            current = current.next;
        }
        
        return result;
    }

    /**
     * Load variables from object (for save/load)
     */
    loadAll(data) {
        // Clear existing
        this._head = null;
        this._count = 0;
        
        // Load all
        for (const [name, value] of Object.entries(data)) {
            this.set(name, value);
        }
    }

    /**
     * Clear all variables
     */
    clear() {
        this._head = null;
        this._count = 0;
    }

    /**
     * Evaluate expression with variables
     * Handles: =, !=, >, <, >=, <=, RANDOM
     * 
     * Original operators from 0x0043f8f0:
     * "=", "!=", ">", "<", ">=", "<=", "RANDOM"
     */
    evaluate(expression) {
        // Handle RANDOM
        if (expression.toUpperCase().includes('RANDOM')) {
            const match = expression.match(/RANDOM\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)/i);
            if (match) {
                const min = parseInt(match[1], 10);
                const max = parseInt(match[2], 10);
                return Math.floor(Math.random() * (max - min + 1)) + min;
            }
            // RANDOM without args returns 0-99
            return Math.floor(Math.random() * 100);
        }
        
        // Handle comparison operators
        const operators = ['!=', '>=', '<=', '=', '>', '<'];
        
        for (const op of operators) {
            const parts = expression.split(op);
            if (parts.length === 2) {
                const left = this._resolveValue(parts[0].trim());
                const right = this._resolveValue(parts[1].trim());
                
                switch (op) {
                    case '=':
                    case '==':
                        return left === right ? 1 : 0;
                    case '!=':
                        return left !== right ? 1 : 0;
                    case '>':
                        return left > right ? 1 : 0;
                    case '<':
                        return left < right ? 1 : 0;
                    case '>=':
                        return left >= right ? 1 : 0;
                    case '<=':
                        return left <= right ? 1 : 0;
                }
            }
        }
        
        // Return resolved value
        return this._resolveValue(expression.trim());
    }

    /**
     * Resolve a value - either literal number or variable name
     */
    _resolveValue(value) {
        // Check if it's a number
        const num = parseInt(value, 10);
        if (!isNaN(num)) {
            return num;
        }
        
        // Check for hex
        if (value.startsWith('#') || value.startsWith('0x')) {
            const hex = value.replace('#', '').replace('0x', '');
            return parseInt(hex, 16);
        }
        
        // It's a variable name
        return this.get(value);
    }

    /**
     * Parse set_var command
     * Format: set_var name=value or set_var name value
     */
    parseSetVar(args) {
        // Handle name=value format
        if (args.includes('=')) {
            const [name, value] = args.split('=').map(s => s.trim());
            return this.set(name, this._resolveValue(value));
        }
        
        // Handle name value format
        const parts = args.split(/\s+/);
        if (parts.length >= 2) {
            return this.set(parts[0], this._resolveValue(parts[1]));
        }
        
        return null;
    }
}

// Export singleton instance (mirrors global var list in original)
const vnVariables = new VNVariable();

export { VNVariable, vnVariables };
export default VNVariable;
