/**
 * VNTimer - Timer management classes
 * 
 * Port of TVNTimer, TVNTimerRes, TVNTimerBasedFx, TVNTimerProperties
 * from europeo.exe
 */

import { VNStreamable } from './VNObject.js';

/**
 * TVNTimerProperties - Timer configuration
 * Port from europeo.exe
 */
export class VNTimerProperties extends VNStreamable {
    constructor() {
        super();
        this.interval = 100;       // Milliseconds
        this.enabled = false;
        this.autoStart = false;
        this.repeat = true;
        this.maxIterations = 0;    // 0 = infinite
        this.priority = 0;
    }

    serialize() {
        return {
            ...super.serialize(),
            interval: this.interval,
            enabled: this.enabled,
            autoStart: this.autoStart,
            repeat: this.repeat,
            maxIterations: this.maxIterations,
            priority: this.priority
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNTimerRes - Timer resource management
 * Port from europeo.exe (timer resource handling)
 * Mirrors Windows multimedia timer functionality
 */
export class VNTimerRes extends VNStreamable {
    constructor() {
        super();
        this.id = 0;
        this.resolution = 1;       // Minimum resolution in ms
        this.active = false;
        this._handle = null;
    }

    /**
     * Begin time period (like timeBeginPeriod)
     */
    begin(resolution = 1) {
        this.resolution = resolution;
        this.active = true;
    }

    /**
     * End time period (like timeEndPeriod)
     */
    end() {
        this.active = false;
    }

    /**
     * Get current time in milliseconds
     */
    getTime() {
        return performance.now();
    }
}

/**
 * TVNTimer - Main timer class
 * Port from europeo.exe (timer management in fcn.004099dc and related)
 * Wraps JavaScript timing functions
 */
export class VNTimer extends VNStreamable {
    constructor(properties = null) {
        super();
        
        this.id = VNTimer._nextId++;
        this.name = '';
        this.properties = properties || new VNTimerProperties();
        
        // Internal state
        this._timerId = null;
        this._startTime = 0;
        this._elapsedTime = 0;
        this._pausedTime = 0;
        this._iterations = 0;
        this._running = false;
        this._paused = false;
        
        // Callbacks
        this._onTick = null;
        this._onComplete = null;
        this._onStart = null;
        this._onStop = null;
        
        // Bound method for requestAnimationFrame
        this._tick = this._tick.bind(this);
        this._intervalTick = this._intervalTick.bind(this);
    }

    static _nextId = 1;

    /**
     * Set tick callback
     */
    onTick(callback) {
        this._onTick = callback;
        return this;
    }

    /**
     * Set completion callback
     */
    onComplete(callback) {
        this._onComplete = callback;
        return this;
    }

    /**
     * Set start callback
     */
    onStart(callback) {
        this._onStart = callback;
        return this;
    }

    /**
     * Set stop callback
     */
    onStop(callback) {
        this._onStop = callback;
        return this;
    }

    /**
     * Start the timer
     * Mirrors: TVNTimer::Start
     */
    start() {
        if (this._running) return this;
        
        this._running = true;
        this._paused = false;
        this._startTime = performance.now();
        this._iterations = 0;
        this.properties.enabled = true;
        
        if (this._onStart) {
            this._onStart(this);
        }
        
        // Use setInterval for regular intervals
        if (this.properties.interval > 0) {
            this._timerId = setInterval(this._intervalTick, this.properties.interval);
        } else {
            // Use requestAnimationFrame for smooth animation
            this._timerId = requestAnimationFrame(this._tick);
        }
        
        return this;
    }

    /**
     * Stop the timer
     * Mirrors: TVNTimer::Stop
     */
    stop() {
        if (!this._running) return this;
        
        this._running = false;
        this._paused = false;
        this.properties.enabled = false;
        
        if (this._timerId !== null) {
            if (this.properties.interval > 0) {
                clearInterval(this._timerId);
            } else {
                cancelAnimationFrame(this._timerId);
            }
            this._timerId = null;
        }
        
        if (this._onStop) {
            this._onStop(this);
        }
        
        return this;
    }

    /**
     * Pause the timer
     */
    pause() {
        if (!this._running || this._paused) return this;
        
        this._paused = true;
        this._pausedTime = performance.now();
        
        if (this._timerId !== null) {
            if (this.properties.interval > 0) {
                clearInterval(this._timerId);
            } else {
                cancelAnimationFrame(this._timerId);
            }
            this._timerId = null;
        }
        
        return this;
    }

    /**
     * Resume the timer
     */
    resume() {
        if (!this._running || !this._paused) return this;
        
        this._paused = false;
        const pauseDuration = performance.now() - this._pausedTime;
        this._startTime += pauseDuration;
        
        if (this.properties.interval > 0) {
            this._timerId = setInterval(this._intervalTick, this.properties.interval);
        } else {
            this._timerId = requestAnimationFrame(this._tick);
        }
        
        return this;
    }

    /**
     * Reset the timer
     */
    reset() {
        this.stop();
        this._elapsedTime = 0;
        this._iterations = 0;
        return this;
    }

    /**
     * Restart the timer
     */
    restart() {
        this.reset();
        return this.start();
    }

    /**
     * Check if timer is running
     */
    isRunning() {
        return this._running && !this._paused;
    }

    /**
     * Check if timer is paused
     */
    isPaused() {
        return this._paused;
    }

    /**
     * Get elapsed time in milliseconds
     */
    getElapsedTime() {
        if (this._running) {
            if (this._paused) {
                return this._pausedTime - this._startTime;
            }
            return performance.now() - this._startTime;
        }
        return this._elapsedTime;
    }

    /**
     * Get iteration count
     */
    getIterations() {
        return this._iterations;
    }

    /**
     * Internal tick for requestAnimationFrame
     */
    _tick(timestamp) {
        if (!this._running || this._paused) return;
        
        this._elapsedTime = timestamp - this._startTime;
        this._iterations++;
        
        if (this._onTick) {
            this._onTick(this._elapsedTime, this);
        }
        
        // Check max iterations
        if (this.properties.maxIterations > 0 && 
            this._iterations >= this.properties.maxIterations) {
            this.stop();
            if (this._onComplete) {
                this._onComplete(this);
            }
            return;
        }
        
        // Continue if repeat is enabled
        if (this.properties.repeat) {
            this._timerId = requestAnimationFrame(this._tick);
        } else {
            this.stop();
            if (this._onComplete) {
                this._onComplete(this);
            }
        }
    }

    /**
     * Internal tick for setInterval
     */
    _intervalTick() {
        if (!this._running || this._paused) return;
        
        this._elapsedTime = performance.now() - this._startTime;
        this._iterations++;
        
        if (this._onTick) {
            this._onTick(this._elapsedTime, this);
        }
        
        // Check max iterations
        if (this.properties.maxIterations > 0 && 
            this._iterations >= this.properties.maxIterations) {
            this.stop();
            if (this._onComplete) {
                this._onComplete(this);
            }
        } else if (!this.properties.repeat) {
            this.stop();
            if (this._onComplete) {
                this._onComplete(this);
            }
        }
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            name: this.name,
            properties: this.properties.serialize()
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.id !== undefined) this.id = data.id;
        if (data.name !== undefined) this.name = data.name;
        if (data.properties) this.properties.deserialize(data.properties);
        return this;
    }
}

/**
 * TVNTimerBasedFx - Base class for timer-based effects
 * Port from europeo.exe (effect system base)
 */
export class VNTimerBasedFx extends VNStreamable {
    constructor() {
        super();
        
        this.id = VNTimerBasedFx._nextId++;
        this.name = '';
        this.duration = 1000;      // Effect duration in ms
        this.easing = 'linear';    // Easing function
        this.loop = false;
        this.autoReverse = false;
        this.delay = 0;
        
        // State
        this._timer = null;
        this._startValue = 0;
        this._endValue = 1;
        this._currentValue = 0;
        this._progress = 0;
        this._running = false;
        this._reversed = false;
        
        // Callbacks
        this._onUpdate = null;
        this._onComplete = null;
    }

    static _nextId = 1;

    /**
     * Easing functions
     */
    static easings = {
        linear: t => t,
        easeInQuad: t => t * t,
        easeOutQuad: t => t * (2 - t),
        easeInOutQuad: t => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
        easeInCubic: t => t * t * t,
        easeOutCubic: t => (--t) * t * t + 1,
        easeInOutCubic: t => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
        easeInSine: t => 1 - Math.cos(t * Math.PI / 2),
        easeOutSine: t => Math.sin(t * Math.PI / 2),
        easeInOutSine: t => -(Math.cos(Math.PI * t) - 1) / 2,
        easeInExpo: t => t === 0 ? 0 : Math.pow(2, 10 * t - 10),
        easeOutExpo: t => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),
        easeInOutExpo: t => {
            if (t === 0) return 0;
            if (t === 1) return 1;
            if (t < 0.5) return Math.pow(2, 20 * t - 10) / 2;
            return (2 - Math.pow(2, -20 * t + 10)) / 2;
        },
        easeInElastic: t => {
            if (t === 0) return 0;
            if (t === 1) return 1;
            return -Math.pow(2, 10 * t - 10) * Math.sin((t * 10 - 10.75) * ((2 * Math.PI) / 3));
        },
        easeOutElastic: t => {
            if (t === 0) return 0;
            if (t === 1) return 1;
            return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * ((2 * Math.PI) / 3)) + 1;
        },
        easeOutBounce: t => {
            const n1 = 7.5625, d1 = 2.75;
            if (t < 1 / d1) return n1 * t * t;
            if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
            if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
            return n1 * (t -= 2.625 / d1) * t + 0.984375;
        }
    };

    /**
     * Set update callback
     */
    onUpdate(callback) {
        this._onUpdate = callback;
        return this;
    }

    /**
     * Set completion callback
     */
    onComplete(callback) {
        this._onComplete = callback;
        return this;
    }

    /**
     * Set value range
     */
    setRange(start, end) {
        this._startValue = start;
        this._endValue = end;
        return this;
    }

    /**
     * Start the effect
     */
    start() {
        if (this._running) return this;
        
        this._running = true;
        this._progress = 0;
        this._currentValue = this._startValue;
        this._reversed = false;
        
        // Create timer
        this._timer = new VNTimer();
        this._timer.properties.interval = 0; // Use RAF
        this._timer.properties.repeat = true;
        
        const startTime = performance.now() + this.delay;
        
        this._timer.onTick((elapsed) => {
            const actualElapsed = performance.now() - startTime;
            if (actualElapsed < 0) return; // Still in delay
            
            this._progress = Math.min(actualElapsed / this.duration, 1);
            
            // Apply easing
            const easingFn = VNTimerBasedFx.easings[this.easing] || VNTimerBasedFx.easings.linear;
            let easedProgress = easingFn(this._progress);
            
            // Handle reverse
            if (this._reversed) {
                easedProgress = 1 - easedProgress;
            }
            
            // Calculate current value
            this._currentValue = this._startValue + (this._endValue - this._startValue) * easedProgress;
            
            // Call update
            if (this._onUpdate) {
                this._onUpdate(this._currentValue, this._progress, this);
            }
            
            // Check completion
            if (this._progress >= 1) {
                if (this.autoReverse && !this._reversed) {
                    this._reversed = true;
                    this._progress = 0;
                } else if (this.loop) {
                    this._progress = 0;
                    this._reversed = false;
                } else {
                    this.stop();
                    if (this._onComplete) {
                        this._onComplete(this);
                    }
                }
            }
        });
        
        this._timer.start();
        return this;
    }

    /**
     * Stop the effect
     */
    stop() {
        if (this._timer) {
            this._timer.stop();
            this._timer = null;
        }
        this._running = false;
        return this;
    }

    /**
     * Pause the effect
     */
    pause() {
        if (this._timer) {
            this._timer.pause();
        }
        return this;
    }

    /**
     * Resume the effect
     */
    resume() {
        if (this._timer) {
            this._timer.resume();
        }
        return this;
    }

    /**
     * Check if running
     */
    isRunning() {
        return this._running;
    }

    /**
     * Get current value
     */
    getValue() {
        return this._currentValue;
    }

    /**
     * Get progress (0-1)
     */
    getProgress() {
        return this._progress;
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            name: this.name,
            duration: this.duration,
            easing: this.easing,
            loop: this.loop,
            autoReverse: this.autoReverse,
            delay: this.delay,
            startValue: this._startValue,
            endValue: this._endValue
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (key === 'startValue') this._startValue = data[key];
            else if (key === 'endValue') this._endValue = data[key];
            else if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * Delay helper function
 * Mirrors: pause command implementation
 */
export function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Timer manager for multiple timers
 */
export class VNTimerManager {
    constructor() {
        this.timers = new Map();
    }

    /**
     * Create and register a timer
     */
    create(name, interval = 100) {
        const timer = new VNTimer();
        timer.name = name;
        timer.properties.interval = interval;
        this.timers.set(name, timer);
        return timer;
    }

    /**
     * Get timer by name
     */
    get(name) {
        return this.timers.get(name);
    }

    /**
     * Remove timer
     */
    remove(name) {
        const timer = this.timers.get(name);
        if (timer) {
            timer.stop();
            this.timers.delete(name);
        }
    }

    /**
     * Stop all timers
     */
    stopAll() {
        this.timers.forEach(timer => timer.stop());
    }

    /**
     * Pause all timers
     */
    pauseAll() {
        this.timers.forEach(timer => timer.pause());
    }

    /**
     * Resume all timers
     */
    resumeAll() {
        this.timers.forEach(timer => timer.resume());
    }

    /**
     * Clear all timers
     */
    clear() {
        this.stopAll();
        this.timers.clear();
    }
}

export default {
    VNTimerProperties,
    VNTimerRes,
    VNTimer,
    VNTimerBasedFx,
    VNTimerManager,
    delay
};
