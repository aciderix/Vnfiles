/**
 * VNCommand - Command and event handling classes
 * 
 * Port of TVNCommand, TVNCommandArray, TVNEventCommand, TVNEventCommandArray
 * from europeo.exe
 */

import { VNStreamable } from './VNObject.js';

/**
 * Command types enumeration
 * Mirrors command IDs from the switch table at 0x40ba69
 */
export const VNCommandType = {
    QUIT: 0,
    ABOUT: 1,
    PREFS: 2,
    PREV: 3,
    NEXT: 4,
    ZOOM: 5,
    SCENE: 6,
    HOTSPOT: 7,
    TIPTEXT: 8,
    PLAYAVI: 9,
    PLAYBMP: 10,
    PLAYWAV: 11,
    PLAYMID: 12,
    PLAYHTML: 13,
    ZOOMIN: 14,
    ZOOMOUT: 15,
    PAUSE: 16,
    EXEC: 17,
    EXPLORE: 18,
    PLAYCDA: 19,
    PLAYSEQ: 20,
    IF: 21,
    SET_VAR: 22,
    INC_VAR: 23,
    DEC_VAR: 24,
    INVALIDATE: 25,
    DEFCURSOR: 26,
    ADDBMP: 27,
    DELBMP: 28,
    SHOWBMP: 29,
    HIDEBMP: 30,
    RUNPRJ: 31,
    UPDATE: 32,
    RUNDLL: 33,
    MSGBOX: 34,
    PLAYCMD: 35,
    CLOSEWAV: 36,
    CLOSEDLL: 37,
    PLAYTEXT: 38,
    FONT: 39,
    REM: 40,
    ADDTEXT: 41,
    DELOBJ: 42,
    SHOWOBJ: 43,
    HIDEOBJ: 44,
    LOAD: 45,
    SAVE: 46,
    CLOSEAVI: 47,
    CLOSEMID: 48
};

/**
 * Command type names
 */
export const VNCommandNames = {
    [VNCommandType.QUIT]: 'quit',
    [VNCommandType.ABOUT]: 'about',
    [VNCommandType.PREFS]: 'prefs',
    [VNCommandType.PREV]: 'prev',
    [VNCommandType.NEXT]: 'next',
    [VNCommandType.ZOOM]: 'zoom',
    [VNCommandType.SCENE]: 'scene',
    [VNCommandType.HOTSPOT]: 'hotspot',
    [VNCommandType.TIPTEXT]: 'tiptext',
    [VNCommandType.PLAYAVI]: 'playavi',
    [VNCommandType.PLAYBMP]: 'playbmp',
    [VNCommandType.PLAYWAV]: 'playwav',
    [VNCommandType.PLAYMID]: 'playmid',
    [VNCommandType.PLAYHTML]: 'playhtml',
    [VNCommandType.ZOOMIN]: 'zoomin',
    [VNCommandType.ZOOMOUT]: 'zoomout',
    [VNCommandType.PAUSE]: 'pause',
    [VNCommandType.EXEC]: 'exec',
    [VNCommandType.EXPLORE]: 'explore',
    [VNCommandType.PLAYCDA]: 'playcda',
    [VNCommandType.PLAYSEQ]: 'playseq',
    [VNCommandType.IF]: 'if',
    [VNCommandType.SET_VAR]: 'set_var',
    [VNCommandType.INC_VAR]: 'inc_var',
    [VNCommandType.DEC_VAR]: 'dec_var',
    [VNCommandType.INVALIDATE]: 'invalidate',
    [VNCommandType.DEFCURSOR]: 'defcursor',
    [VNCommandType.ADDBMP]: 'addbmp',
    [VNCommandType.DELBMP]: 'delbmp',
    [VNCommandType.SHOWBMP]: 'showbmp',
    [VNCommandType.HIDEBMP]: 'hidebmp',
    [VNCommandType.RUNPRJ]: 'runprj',
    [VNCommandType.UPDATE]: 'update',
    [VNCommandType.RUNDLL]: 'rundll',
    [VNCommandType.MSGBOX]: 'msgbox',
    [VNCommandType.PLAYCMD]: 'playcmd',
    [VNCommandType.CLOSEWAV]: 'closewav',
    [VNCommandType.CLOSEDLL]: 'closedll',
    [VNCommandType.PLAYTEXT]: 'playtext',
    [VNCommandType.FONT]: 'font',
    [VNCommandType.REM]: 'rem',
    [VNCommandType.ADDTEXT]: 'addtext',
    [VNCommandType.DELOBJ]: 'delobj',
    [VNCommandType.SHOWOBJ]: 'showobj',
    [VNCommandType.HIDEOBJ]: 'hideobj',
    [VNCommandType.LOAD]: 'load',
    [VNCommandType.SAVE]: 'save',
    [VNCommandType.CLOSEAVI]: 'closeavi',
    [VNCommandType.CLOSEMID]: 'closemid'
};

/**
 * Reverse lookup - name to type
 */
export const VNCommandNameToType = {};
Object.entries(VNCommandNames).forEach(([type, name]) => {
    VNCommandNameToType[name] = parseInt(type);
});

/**
 * TVNCommand - Single command
 * Port from europeo.exe (TVNCommand at 0x0040ed49)
 */
export class VNCommand extends VNStreamable {
    constructor(type = 0, params = null) {
        super();
        
        this.id = VNCommand._nextId++;
        this.type = type;
        this.name = VNCommandNames[type] || 'unknown';
        this.params = params;
        this.enabled = true;
        this.executed = false;
        this.result = null;
        this.error = null;
        
        // Execution context
        this.lineNumber = 0;
        this.sourceFile = '';
        
        // Conditional execution
        this.condition = null;
        
        // Timing
        this.delay = 0;
        this.async = false;
    }

    static _nextId = 1;

    /**
     * Create command from name
     */
    static fromName(name, params = null) {
        const type = VNCommandNameToType[name.toLowerCase()];
        if (type === undefined) {
            throw new Error(`Unknown command: ${name}`);
        }
        return new VNCommand(type, params);
    }

    /**
     * Create command from string (e.g., "scene 1" or "playwav sound.wav")
     */
    static parse(commandStr) {
        const parts = commandStr.trim().split(/\s+/);
        if (parts.length === 0) return null;
        
        const name = parts[0].toLowerCase();
        const args = parts.slice(1);
        
        const type = VNCommandNameToType[name];
        if (type === undefined) {
            throw new Error(`Unknown command: ${name}`);
        }
        
        return new VNCommand(type, { args });
    }

    /**
     * Set condition for execution
     */
    setCondition(condition) {
        this.condition = condition;
        return this;
    }

    /**
     * Check if condition is met
     */
    checkCondition(variables) {
        if (!this.condition) return true;
        
        if (typeof this.condition === 'function') {
            return this.condition(variables);
        }
        
        if (typeof this.condition === 'object' && this.condition.evaluate) {
            return this.condition.evaluate(variables);
        }
        
        return true;
    }

    /**
     * Clone command
     */
    clone() {
        const cloned = new VNCommand(this.type, { ...this.params });
        cloned.enabled = this.enabled;
        cloned.delay = this.delay;
        cloned.async = this.async;
        cloned.condition = this.condition;
        return cloned;
    }

    /**
     * Get command name
     */
    getName() {
        return this.name;
    }

    /**
     * Get command type
     */
    getType() {
        return this.type;
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            type: this.type,
            name: this.name,
            params: this.params,
            enabled: this.enabled,
            delay: this.delay,
            async: this.async,
            lineNumber: this.lineNumber,
            sourceFile: this.sourceFile
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNCommandArray - Array of commands
 * Port from europeo.exe (TVNCommandArray at 0x0040fdeb)
 */
export class VNCommandArray extends VNStreamable {
    constructor() {
        super();
        this.commands = [];
    }

    /**
     * Add command
     */
    add(command) {
        if (command instanceof VNCommand) {
            this.commands.push(command);
        } else if (typeof command === 'string') {
            this.commands.push(VNCommand.parse(command));
        }
        return this;
    }

    /**
     * Add multiple commands
     */
    addAll(commands) {
        commands.forEach(cmd => this.add(cmd));
        return this;
    }

    /**
     * Remove command by index
     */
    remove(index) {
        if (index >= 0 && index < this.commands.length) {
            return this.commands.splice(index, 1)[0];
        }
        return null;
    }

    /**
     * Remove command by ID
     */
    removeById(id) {
        const index = this.commands.findIndex(c => c.id === id);
        return this.remove(index);
    }

    /**
     * Get command at index
     */
    get(index) {
        return this.commands[index] || null;
    }

    /**
     * Get command by ID
     */
    getById(id) {
        return this.commands.find(c => c.id === id) || null;
    }

    /**
     * Get all commands
     */
    getAll() {
        return [...this.commands];
    }

    /**
     * Get commands by type
     */
    getByType(type) {
        return this.commands.filter(c => c.type === type);
    }

    /**
     * Get count
     */
    count() {
        return this.commands.length;
    }

    /**
     * Clear all commands
     */
    clear() {
        this.commands = [];
        return this;
    }

    /**
     * Insert command at index
     */
    insert(index, command) {
        if (command instanceof VNCommand) {
            this.commands.splice(index, 0, command);
        }
        return this;
    }

    /**
     * Iterate over commands
     */
    forEach(callback) {
        this.commands.forEach(callback);
    }

    /**
     * Map commands
     */
    map(callback) {
        return this.commands.map(callback);
    }

    /**
     * Filter commands
     */
    filter(callback) {
        return this.commands.filter(callback);
    }

    serialize() {
        return {
            ...super.serialize(),
            commands: this.commands.map(c => c.serialize())
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.commands) {
            this.commands = data.commands.map(cmdData => {
                const cmd = new VNCommand();
                cmd.deserialize(cmdData);
                return cmd;
            });
        }
        return this;
    }
}

/**
 * Event types
 */
export const VNEventType = {
    CLICK: 'click',
    ENTER: 'enter',
    LEAVE: 'leave',
    SCENE_ENTER: 'scene_enter',
    SCENE_LEAVE: 'scene_leave',
    TIMER: 'timer',
    KEY: 'key',
    LOAD: 'load',
    UNLOAD: 'unload',
    CUSTOM: 'custom'
};

/**
 * TVNEventCommand - Event-triggered command
 * Port from europeo.exe (TVNEventCommand at 0x0040f6de)
 */
export class VNEventCommand extends VNStreamable {
    constructor(eventType = VNEventType.CLICK) {
        super();
        
        this.id = VNEventCommand._nextId++;
        this.eventType = eventType;
        this.targetId = '';      // ID of the target object (hotspot, etc.)
        this.commands = new VNCommandArray();
        this.enabled = true;
        this.once = false;       // Execute only once
        this.fired = false;      // Has been fired (for once events)
        
        // Event parameters
        this.keyCode = 0;        // For key events
        this.modifiers = [];     // ctrl, alt, shift
    }

    static _nextId = 1;

    /**
     * Add command to execute on event
     */
    addCommand(command) {
        this.commands.add(command);
        return this;
    }

    /**
     * Add multiple commands
     */
    addCommands(commands) {
        commands.forEach(cmd => this.addCommand(cmd));
        return this;
    }

    /**
     * Set target
     */
    setTarget(targetId) {
        this.targetId = targetId;
        return this;
    }

    /**
     * Check if event should fire
     */
    shouldFire(event) {
        if (!this.enabled) return false;
        if (this.once && this.fired) return false;
        
        // Check event type match
        if (event.type !== this.eventType) return false;
        
        // Check target match
        if (this.targetId && event.targetId !== this.targetId) return false;
        
        // Check key code for key events
        if (this.eventType === VNEventType.KEY) {
            if (this.keyCode && event.keyCode !== this.keyCode) return false;
        }
        
        return true;
    }

    /**
     * Mark as fired
     */
    markFired() {
        this.fired = true;
    }

    /**
     * Reset fired state
     */
    reset() {
        this.fired = false;
    }

    /**
     * Get commands
     */
    getCommands() {
        return this.commands.getAll();
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            eventType: this.eventType,
            targetId: this.targetId,
            commands: this.commands.serialize(),
            enabled: this.enabled,
            once: this.once,
            keyCode: this.keyCode,
            modifiers: this.modifiers
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (key === 'commands' && data.commands) {
                this.commands.deserialize(data.commands);
            } else if (this.hasOwnProperty(key)) {
                this[key] = data[key];
            }
        });
        return this;
    }
}

/**
 * TVNEventCommandArray - Array of event commands
 * Port from europeo.exe (TVNEventCommandArray at 0x0040fd62)
 */
export class VNEventCommandArray extends VNStreamable {
    constructor() {
        super();
        this.events = [];
    }

    /**
     * Add event handler
     */
    add(eventCommand) {
        if (eventCommand instanceof VNEventCommand) {
            this.events.push(eventCommand);
        }
        return this;
    }

    /**
     * Remove event by ID
     */
    removeById(id) {
        const index = this.events.findIndex(e => e.id === id);
        if (index !== -1) {
            return this.events.splice(index, 1)[0];
        }
        return null;
    }

    /**
     * Get event by ID
     */
    getById(id) {
        return this.events.find(e => e.id === id) || null;
    }

    /**
     * Get events for target
     */
    getForTarget(targetId) {
        return this.events.filter(e => e.targetId === targetId);
    }

    /**
     * Get events by type
     */
    getByType(eventType) {
        return this.events.filter(e => e.eventType === eventType);
    }

    /**
     * Find matching events for an event
     */
    findMatching(event) {
        return this.events.filter(e => e.shouldFire(event));
    }

    /**
     * Get all events
     */
    getAll() {
        return [...this.events];
    }

    /**
     * Get count
     */
    count() {
        return this.events.length;
    }

    /**
     * Clear all events
     */
    clear() {
        this.events = [];
        return this;
    }

    /**
     * Reset all fired states
     */
    resetAll() {
        this.events.forEach(e => e.reset());
    }

    serialize() {
        return {
            ...super.serialize(),
            events: this.events.map(e => e.serialize())
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.events) {
            this.events = data.events.map(evtData => {
                const evt = new VNEventCommand();
                evt.deserialize(evtData);
                return evt;
            });
        }
        return this;
    }
}

/**
 * Command queue for execution
 */
export class VNCommandQueue {
    constructor() {
        this.queue = [];
        this.executing = false;
        this.paused = false;
        this.currentCommand = null;
        
        // Callbacks
        this._onExecute = null;
        this._onComplete = null;
        this._onError = null;
    }

    /**
     * Enqueue command
     */
    enqueue(command) {
        if (command instanceof VNCommand) {
            this.queue.push(command);
        } else if (command instanceof VNCommandArray) {
            this.queue.push(...command.getAll());
        }
        return this;
    }

    /**
     * Enqueue at front
     */
    enqueueFront(command) {
        if (command instanceof VNCommand) {
            this.queue.unshift(command);
        }
        return this;
    }

    /**
     * Dequeue next command
     */
    dequeue() {
        return this.queue.shift() || null;
    }

    /**
     * Peek at next command without removing
     */
    peek() {
        return this.queue[0] || null;
    }

    /**
     * Clear queue
     */
    clear() {
        this.queue = [];
        return this;
    }

    /**
     * Get queue length
     */
    length() {
        return this.queue.length;
    }

    /**
     * Check if empty
     */
    isEmpty() {
        return this.queue.length === 0;
    }

    /**
     * Pause execution
     */
    pause() {
        this.paused = true;
    }

    /**
     * Resume execution
     */
    resume() {
        this.paused = false;
    }

    /**
     * Set execute callback
     */
    onExecute(callback) {
        this._onExecute = callback;
        return this;
    }

    /**
     * Set complete callback
     */
    onComplete(callback) {
        this._onComplete = callback;
        return this;
    }

    /**
     * Set error callback
     */
    onError(callback) {
        this._onError = callback;
        return this;
    }

    /**
     * Execute next command
     */
    async executeNext() {
        if (this.paused || this.isEmpty()) {
            return null;
        }
        
        this.currentCommand = this.dequeue();
        if (!this.currentCommand) {
            return null;
        }
        
        try {
            if (this._onExecute) {
                await this._onExecute(this.currentCommand);
            }
            this.currentCommand.executed = true;
            return this.currentCommand;
        } catch (error) {
            this.currentCommand.error = error;
            if (this._onError) {
                this._onError(error, this.currentCommand);
            }
            throw error;
        }
    }

    /**
     * Execute all commands
     */
    async executeAll() {
        this.executing = true;
        
        while (!this.isEmpty() && !this.paused) {
            await this.executeNext();
        }
        
        this.executing = false;
        
        if (this._onComplete) {
            this._onComplete();
        }
    }
}

export default {
    VNCommandType,
    VNCommandNames,
    VNCommandNameToType,
    VNCommand,
    VNCommandArray,
    VNEventType,
    VNEventCommand,
    VNEventCommandArray,
    VNCommandQueue
};
