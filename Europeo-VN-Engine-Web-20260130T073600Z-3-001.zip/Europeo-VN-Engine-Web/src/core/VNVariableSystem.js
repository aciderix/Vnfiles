/**
 * VNVariableSystem - Variable and Flow Control System
 * 
 * EXACT PORT from variable handling functions
 * Classes: TVNVariable, TVNVariableArray, TVNIfParms, TVNSetVarParms
 * 
 * @original_file variable.cpp (implied from strings)
 * @original_address various
 */

/**
 * VNVariableType - Variable type enumeration
 */
const VNVariableType = {
    UNDEFINED: 0,
    STRING: 1,
    INTEGER: 2,
    FLOAT: 3,
    BOOLEAN: 4,
    ARRAY: 5
};

/**
 * VNVariable - Single variable storage
 * Port of TVNVariable
 * @original_address 0x00406861 (TVNVariable)
 */
class VNVariable {
    constructor(name = '', value = null, type = VNVariableType.UNDEFINED) {
        this.name = name;
        this._value = value;
        this._type = type;
        
        // Auto-detect type if not specified
        if (type === VNVariableType.UNDEFINED && value !== null) {
            this._type = this._detectType(value);
        }
    }

    /**
     * Detect value type
     */
    _detectType(value) {
        if (value === null || value === undefined) {
            return VNVariableType.UNDEFINED;
        }
        if (typeof value === 'string') {
            return VNVariableType.STRING;
        }
        if (typeof value === 'number') {
            return Number.isInteger(value) ? VNVariableType.INTEGER : VNVariableType.FLOAT;
        }
        if (typeof value === 'boolean') {
            return VNVariableType.BOOLEAN;
        }
        if (Array.isArray(value)) {
            return VNVariableType.ARRAY;
        }
        return VNVariableType.STRING;
    }

    /**
     * Get value
     */
    get value() {
        return this._value;
    }

    /**
     * Set value
     */
    set value(val) {
        this._value = val;
        this._type = this._detectType(val);
    }

    /**
     * Get type
     */
    get type() {
        return this._type;
    }

    /**
     * Get as string
     */
    asString() {
        if (this._value === null || this._value === undefined) {
            return '';
        }
        return String(this._value);
    }

    /**
     * Get as integer
     */
    asInteger() {
        if (typeof this._value === 'number') {
            return Math.floor(this._value);
        }
        return parseInt(this._value) || 0;
    }

    /**
     * Get as float
     */
    asFloat() {
        if (typeof this._value === 'number') {
            return this._value;
        }
        return parseFloat(this._value) || 0.0;
    }

    /**
     * Get as boolean
     */
    asBoolean() {
        if (typeof this._value === 'boolean') {
            return this._value;
        }
        if (typeof this._value === 'number') {
            return this._value !== 0;
        }
        if (typeof this._value === 'string') {
            const lower = this._value.toLowerCase();
            return lower === 'true' || lower === '1' || lower === 'yes';
        }
        return !!this._value;
    }

    /**
     * Clone variable
     */
    clone() {
        return new VNVariable(this.name, this._value, this._type);
    }
}

/**
 * VNVariableArray - Variable collection
 * Port of TVNVariableArray / TMIArrayAsVector<TVNVariable>
 * @original_address 0x00406db9 (TVNVariableArray)
 */
class VNVariableArray {
    constructor() {
        // Variables by name (case-insensitive)
        this._variables = new Map();
    }

    /**
     * Get variable count
     */
    get length() {
        return this._variables.size;
    }

    /**
     * Get variable by name
     */
    get(name) {
        return this._variables.get(name.toLowerCase()) || null;
    }

    /**
     * Set variable
     */
    set(name, value) {
        const key = name.toLowerCase();
        let variable = this._variables.get(key);
        
        if (variable) {
            variable.value = value;
        } else {
            variable = new VNVariable(name, value);
            this._variables.set(key, variable);
        }
        
        return variable;
    }

    /**
     * Check if variable exists
     */
    exists(name) {
        return this._variables.has(name.toLowerCase());
    }

    /**
     * Delete variable
     */
    delete(name) {
        return this._variables.delete(name.toLowerCase());
    }

    /**
     * Clear all variables
     */
    clear() {
        this._variables.clear();
    }

    /**
     * Get all variable names
     */
    getNames() {
        return Array.from(this._variables.keys());
    }

    /**
     * Get all variables
     */
    getAll() {
        return Array.from(this._variables.values());
    }

    /**
     * Iterate over variables
     */
    forEach(callback) {
        this._variables.forEach((variable, name) => {
            callback(variable, name);
        });
    }

    /**
     * Get iterator
     */
    [Symbol.iterator]() {
        return this._variables.values();
    }

    /**
     * Serialize to object
     */
    toObject() {
        const obj = {};
        this._variables.forEach((variable, name) => {
            obj[name] = variable.value;
        });
        return obj;
    }

    /**
     * Load from object
     */
    fromObject(obj) {
        this.clear();
        for (const [name, value] of Object.entries(obj)) {
            this.set(name, value);
        }
    }
}

/**
 * VNSetVarParms - Set variable command parameters
 * Port of TVNSetVarParms
 * @original_address 0x0040f1d2 (TVNSetVarParms)
 */
class VNSetVarParms {
    constructor() {
        this.name = '';           // Variable name
        this.value = '';          // Value to set
        this.operation = '=';     // Operation (=, +=, -=, *=, /=)
    }

    /**
     * Parse from command string
     * Format: set_var,name,value or set_var,name,op,value
     * @original_address set_var command at 0x0043f800
     */
    static parse(args) {
        const parms = new VNSetVarParms();
        
        if (!args) return parms;
        
        const parts = args.split(',').map(s => s.trim());
        
        if (parts.length >= 2) {
            parms.name = parts[0];
            
            // Check for operation
            if (parts.length >= 3 && ['=', '+=', '-=', '*=', '/=', '%='].includes(parts[1])) {
                parms.operation = parts[1];
                parms.value = parts[2];
            } else {
                parms.value = parts[1];
            }
        }
        
        return parms;
    }
}

/**
 * VNIfParms - If command parameters
 * Port of TVNIfParms
 * @original_address 0x0040f16e (TVNIfParms)
 */
class VNIfParms {
    constructor() {
        this.left = '';           // Left operand
        this.operator = '==';     // Comparison operator
        this.right = '';          // Right operand
        this.thenCommand = '';    // Command if true
        this.elseCommand = '';    // Command if false (optional)
    }

    /**
     * Parse from command string
     * Format: if,left,op,right,then[,else]
     * Or: if,condition then command else command
     * @original_address %s then %s else %s at 0x0043fa09
     */
    static parse(args) {
        const parms = new VNIfParms();
        
        if (!args) return parms;
        
        // Try format with "then" and "else" keywords
        const thenMatch = args.match(/^(.+?)\s+then\s+(.+?)(?:\s+else\s+(.+))?$/i);
        if (thenMatch) {
            const condition = thenMatch[1].trim();
            parms.thenCommand = thenMatch[2].trim();
            parms.elseCommand = thenMatch[3] ? thenMatch[3].trim() : '';
            
            // Parse condition
            const condMatch = condition.match(/^(.+?)\s*(==|!=|<>|<=|>=|<|>|=)\s*(.+)$/);
            if (condMatch) {
                parms.left = condMatch[1].trim();
                parms.operator = condMatch[2] === '=' ? '==' : 
                                condMatch[2] === '<>' ? '!=' : condMatch[2];
                parms.right = condMatch[3].trim();
            } else {
                // Simple boolean check
                parms.left = condition;
                parms.operator = '!=';
                parms.right = '0';
            }
        } else {
            // Try comma-separated format
            const parts = args.split(',').map(s => s.trim());
            
            if (parts.length >= 4) {
                parms.left = parts[0];
                parms.operator = parts[1];
                parms.right = parts[2];
                parms.thenCommand = parts[3];
                if (parts.length >= 5) {
                    parms.elseCommand = parts[4];
                }
            }
        }
        
        return parms;
    }
}

/**
 * VNVariableManager - Complete variable management system
 * Handles variables, expressions, and flow control
 */
class VNVariableManager {
    constructor(engine) {
        this.engine = engine;
        
        // Variable scopes
        this.globalVariables = new VNVariableArray();   // Global scope
        this.localVariables = new VNVariableArray();    // Local/scene scope
        this.systemVariables = new VNVariableArray();   // System variables (read-only)
        
        // Initialize system variables
        this._initSystemVariables();
        
        // Label storage for goto
        this.labels = new Map();
    }

    /**
     * Initialize system variables
     */
    _initSystemVariables() {
        this.systemVariables.set('_VERSION', '1.0');
        this.systemVariables.set('_DATE', new Date().toLocaleDateString());
        this.systemVariables.set('_TIME', new Date().toLocaleTimeString());
        this.systemVariables.set('_RANDOM', Math.random());
        this.systemVariables.set('_TRUE', 1);
        this.systemVariables.set('_FALSE', 0);
    }

    /**
     * Update dynamic system variables
     */
    _updateSystemVariables() {
        this.systemVariables.set('_TIME', new Date().toLocaleTimeString());
        this.systemVariables.set('_RANDOM', Math.random());
        
        if (this.engine) {
            this.systemVariables.set('_SCENE', this.engine.currentSceneName || '');
            this.systemVariables.set('_MOUSE_X', this.engine.mouseX || 0);
            this.systemVariables.set('_MOUSE_Y', this.engine.mouseY || 0);
        }
    }

    /**
     * Get variable value by name
     * Searches: local -> global -> system
     */
    get(name) {
        // Check local first
        let variable = this.localVariables.get(name);
        if (variable) return variable.value;
        
        // Check global
        variable = this.globalVariables.get(name);
        if (variable) return variable.value;
        
        // Check system (with update)
        this._updateSystemVariables();
        variable = this.systemVariables.get(name);
        if (variable) return variable.value;
        
        return null;
    }

    /**
     * Set variable value
     * @param name Variable name
     * @param value Value to set
     * @param global If true, set in global scope
     */
    set(name, value, global = false) {
        const scope = global ? this.globalVariables : this.localVariables;
        return scope.set(name, value);
    }

    /**
     * Execute set_var command
     * @original_address set_var command handler
     */
    executeSetVar(argsString) {
        const parms = VNSetVarParms.parse(argsString);
        
        if (!parms.name) {
            console.warn('VNVariableManager: No variable name specified');
            return false;
        }

        // Evaluate value (may contain variable references)
        let newValue = this.evaluateExpression(parms.value);
        
        // Apply operation
        if (parms.operation !== '=') {
            const currentValue = this.get(parms.name) || 0;
            const numCurrent = parseFloat(currentValue) || 0;
            const numNew = parseFloat(newValue) || 0;
            
            switch (parms.operation) {
                case '+=':
                    if (typeof currentValue === 'string' && isNaN(numCurrent)) {
                        newValue = currentValue + String(newValue);
                    } else {
                        newValue = numCurrent + numNew;
                    }
                    break;
                case '-=':
                    newValue = numCurrent - numNew;
                    break;
                case '*=':
                    newValue = numCurrent * numNew;
                    break;
                case '/=':
                    newValue = numNew !== 0 ? numCurrent / numNew : 0;
                    break;
                case '%=':
                    newValue = numNew !== 0 ? numCurrent % numNew : 0;
                    break;
            }
        }

        this.set(parms.name, newValue);
        return true;
    }

    /**
     * Execute if command
     * @original_address if command handler
     */
    executeIf(argsString) {
        const parms = VNIfParms.parse(argsString);
        
        // Evaluate operands
        const leftValue = this.evaluateExpression(parms.left);
        const rightValue = this.evaluateExpression(parms.right);
        
        // Compare values
        const result = this._compare(leftValue, parms.operator, rightValue);
        
        // Return command to execute
        if (result) {
            return parms.thenCommand;
        } else if (parms.elseCommand) {
            return parms.elseCommand;
        }
        
        return null;
    }

    /**
     * Compare two values
     */
    _compare(left, operator, right) {
        // Try numeric comparison
        const numLeft = parseFloat(left);
        const numRight = parseFloat(right);
        const isNumeric = !isNaN(numLeft) && !isNaN(numRight);
        
        switch (operator) {
            case '==':
            case '=':
                return isNumeric ? numLeft === numRight : String(left) === String(right);
            case '!=':
            case '<>':
                return isNumeric ? numLeft !== numRight : String(left) !== String(right);
            case '<':
                return isNumeric ? numLeft < numRight : String(left) < String(right);
            case '>':
                return isNumeric ? numLeft > numRight : String(left) > String(right);
            case '<=':
                return isNumeric ? numLeft <= numRight : String(left) <= String(right);
            case '>=':
                return isNumeric ? numLeft >= numRight : String(left) >= String(right);
            default:
                return false;
        }
    }

    /**
     * Evaluate expression (replace variable references)
     */
    evaluateExpression(expr) {
        if (expr === null || expr === undefined) return '';
        
        let str = String(expr);
        
        // Replace ${varname} or %varname% patterns
        str = str.replace(/\$\{([^}]+)\}/g, (match, name) => {
            const value = this.get(name);
            return value !== null ? String(value) : '';
        });
        
        str = str.replace(/%([^%]+)%/g, (match, name) => {
            const value = this.get(name);
            return value !== null ? String(value) : '';
        });
        
        // If it's a simple variable reference (starts with $)
        if (str.startsWith('$')) {
            const value = this.get(str.substring(1));
            if (value !== null) return value;
        }
        
        // Check if it's a registered variable name
        const directValue = this.get(str);
        if (directValue !== null) return directValue;
        
        // Try to evaluate as math expression
        if (/^[\d\s+\-*/%().]+$/.test(str)) {
            try {
                return eval(str);
            } catch (e) {
                // Not a valid expression
            }
        }
        
        return str;
    }

    /**
     * Register a label for goto
     */
    registerLabel(name, index) {
        this.labels.set(name.toLowerCase(), index);
    }

    /**
     * Get label index
     */
    getLabelIndex(name) {
        return this.labels.get(name.toLowerCase()) || -1;
    }

    /**
     * Clear local variables (called on scene change)
     */
    clearLocal() {
        this.localVariables.clear();
    }

    /**
     * Clear all non-system variables
     */
    clearAll() {
        this.globalVariables.clear();
        this.localVariables.clear();
        this.labels.clear();
    }

    /**
     * Serialize state for save
     */
    serialize() {
        return {
            global: this.globalVariables.toObject(),
            local: this.localVariables.toObject()
        };
    }

    /**
     * Deserialize state from save
     */
    deserialize(data) {
        if (data.global) {
            this.globalVariables.fromObject(data.global);
        }
        if (data.local) {
            this.localVariables.fromObject(data.local);
        }
    }
}

/**
 * VNFlowControl - Flow control (if/else/goto/label) system
 */
class VNFlowControl {
    constructor(variableManager) {
        this.variables = variableManager;
        
        // Stack for nested if/else
        this.conditionStack = [];
        
        // Current execution state
        this.skipUntilEndIf = false;
        this.skipLevel = 0;
    }

    /**
     * Process if command
     */
    processIf(condition) {
        const result = this._evaluateCondition(condition);
        
        this.conditionStack.push({
            result: result,
            executed: result,
            inElse: false
        });
        
        return result;
    }

    /**
     * Process else command
     */
    processElse() {
        if (this.conditionStack.length === 0) {
            console.warn('VNFlowControl: else without if');
            return true;
        }
        
        const current = this.conditionStack[this.conditionStack.length - 1];
        current.inElse = true;
        
        // Execute else block if if-block wasn't executed
        return !current.executed;
    }

    /**
     * Process endif command
     */
    processEndIf() {
        if (this.conditionStack.length === 0) {
            console.warn('VNFlowControl: endif without if');
            return;
        }
        
        this.conditionStack.pop();
    }

    /**
     * Check if currently in skip mode
     */
    shouldSkip() {
        for (const state of this.conditionStack) {
            if (state.inElse) {
                if (state.executed) return true;
            } else {
                if (!state.result) return true;
            }
        }
        return false;
    }

    /**
     * Evaluate condition string
     */
    _evaluateCondition(condition) {
        // Parse condition
        const match = condition.match(/^(.+?)\s*(==|!=|<>|<=|>=|<|>|=)\s*(.+)$/);
        
        if (match) {
            const left = this.variables.evaluateExpression(match[1].trim());
            const op = match[2] === '=' ? '==' : match[2] === '<>' ? '!=' : match[2];
            const right = this.variables.evaluateExpression(match[3].trim());
            
            return this.variables._compare(left, op, right);
        }
        
        // Simple truthy check
        const value = this.variables.evaluateExpression(condition);
        return !!value && value !== '0' && value !== 'false';
    }

    /**
     * Reset flow control state
     */
    reset() {
        this.conditionStack = [];
        this.skipUntilEndIf = false;
        this.skipLevel = 0;
    }
}

// Export all classes
export {
    VNVariableType,
    VNVariable,
    VNVariableArray,
    VNSetVarParms,
    VNIfParms,
    VNVariableManager,
    VNFlowControl
};
