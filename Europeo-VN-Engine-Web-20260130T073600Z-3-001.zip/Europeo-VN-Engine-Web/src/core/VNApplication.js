/**
 * VNApplication - Main application class
 * 
 * Port of TVNApplication from europeo.exe
 * Entry point: 0x00401000
 * Main window creation: fcn.0040768d
 */

import { VNStreamable } from './VNObject.js';

/**
 * TVNVersion - Version information
 * Port from europeo.exe (version strings at 0x0043e000 region)
 */
export class VNVersion {
    constructor() {
        // Original version: Europeo VN Engine 1.0
        this.major = 1;
        this.minor = 0;
        this.build = 0;
        this.revision = 0;
        this.name = 'Europeo VN Engine';
        this.webPort = true;
        this.webVersion = '2.0.0';
    }

    toString() {
        return `${this.name} v${this.major}.${this.minor}.${this.build}`;
    }

    toWebString() {
        return `${this.name} Web Port v${this.webVersion}`;
    }

    /**
     * Compare versions
     */
    compare(other) {
        if (this.major !== other.major) return this.major - other.major;
        if (this.minor !== other.minor) return this.minor - other.minor;
        if (this.build !== other.build) return this.build - other.build;
        return this.revision - other.revision;
    }

    /**
     * Check if version is compatible
     */
    isCompatible(minMajor, minMinor = 0) {
        return this.major > minMajor || 
               (this.major === minMajor && this.minor >= minMinor);
    }
}

/**
 * TVNApplicationInfo - Application metadata
 * Port from europeo.exe (0x00410513 region)
 */
export class VNApplicationInfo extends VNStreamable {
    constructor() {
        super();
        this.title = '';
        this.author = '';
        this.copyright = '';
        this.description = '';
        this.website = '';
        this.email = '';
        this.createdDate = null;
        this.modifiedDate = null;
        this.version = new VNVersion();
    }

    serialize() {
        return {
            ...super.serialize(),
            title: this.title,
            author: this.author,
            copyright: this.copyright,
            description: this.description,
            website: this.website,
            email: this.email,
            createdDate: this.createdDate?.toISOString(),
            modifiedDate: this.modifiedDate?.toISOString()
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.title) this.title = data.title;
        if (data.author) this.author = data.author;
        if (data.copyright) this.copyright = data.copyright;
        if (data.description) this.description = data.description;
        if (data.website) this.website = data.website;
        if (data.email) this.email = data.email;
        if (data.createdDate) this.createdDate = new Date(data.createdDate);
        if (data.modifiedDate) this.modifiedDate = new Date(data.modifiedDate);
        return this;
    }
}

/**
 * TVNProjectInfo - Project information
 * Port from europeo.exe (TVNProjectInfo at multiple addresses)
 */
export class VNProjectInfo extends VNStreamable {
    constructor() {
        super();
        
        // Project identification
        this.id = '';
        this.name = '';
        this.fileName = '';
        this.basePath = '';
        
        // Project settings
        this.width = 800;
        this.height = 600;
        this.colorDepth = 32;
        this.fullscreen = false;
        
        // Audio settings
        this.musicVolume = 100;
        this.soundVolume = 100;
        this.voiceVolume = 100;
        
        // Display settings
        this.showToolbar = true;
        this.showStatusbar = false;
        this.allowResize = false;
        
        // Navigation settings
        this.startScene = 0;
        this.autoAdvance = false;
        this.autoAdvanceDelay = 5000;
        
        // Protection settings
        this.protected = false;
        this.password = '';
        
        // Metadata
        this.info = new VNApplicationInfo();
    }

    /**
     * Get full path for a resource
     */
    getResourcePath(relativePath) {
        if (!relativePath) return '';
        if (relativePath.startsWith('http://') || relativePath.startsWith('https://')) {
            return relativePath;
        }
        return this.basePath ? `${this.basePath}/${relativePath}` : relativePath;
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            name: this.name,
            fileName: this.fileName,
            basePath: this.basePath,
            width: this.width,
            height: this.height,
            colorDepth: this.colorDepth,
            fullscreen: this.fullscreen,
            musicVolume: this.musicVolume,
            soundVolume: this.soundVolume,
            voiceVolume: this.voiceVolume,
            showToolbar: this.showToolbar,
            showStatusbar: this.showStatusbar,
            allowResize: this.allowResize,
            startScene: this.startScene,
            autoAdvance: this.autoAdvance,
            autoAdvanceDelay: this.autoAdvanceDelay,
            info: this.info.serialize()
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (key === 'info' && data.info) {
                this.info.deserialize(data.info);
            } else if (this.hasOwnProperty(key) && key !== '_type' && key !== '_version') {
                this[key] = data[key];
            }
        });
        return this;
    }
}

/**
 * TVNDisplayMode - Display mode settings
 * Port from europeo.exe (display handling in fcn.004200cf)
 */
export class VNDisplayMode {
    constructor() {
        this.width = 800;
        this.height = 600;
        this.colorDepth = 32;
        this.refreshRate = 60;
        this.fullscreen = false;
        this.aspectRatio = 4/3;
        this.scalingMode = 'fit'; // 'fit', 'fill', 'stretch', 'none'
    }

    /**
     * Calculate scaled dimensions maintaining aspect ratio
     */
    getScaledDimensions(containerWidth, containerHeight) {
        const containerRatio = containerWidth / containerHeight;
        const contentRatio = this.width / this.height;
        
        let scaledWidth, scaledHeight;
        
        switch (this.scalingMode) {
            case 'fill':
                if (containerRatio > contentRatio) {
                    scaledWidth = containerWidth;
                    scaledHeight = containerWidth / contentRatio;
                } else {
                    scaledHeight = containerHeight;
                    scaledWidth = containerHeight * contentRatio;
                }
                break;
                
            case 'stretch':
                scaledWidth = containerWidth;
                scaledHeight = containerHeight;
                break;
                
            case 'none':
                scaledWidth = this.width;
                scaledHeight = this.height;
                break;
                
            case 'fit':
            default:
                if (containerRatio > contentRatio) {
                    scaledHeight = containerHeight;
                    scaledWidth = containerHeight * contentRatio;
                } else {
                    scaledWidth = containerWidth;
                    scaledHeight = containerWidth / contentRatio;
                }
                break;
        }
        
        return {
            width: Math.round(scaledWidth),
            height: Math.round(scaledHeight),
            x: Math.round((containerWidth - scaledWidth) / 2),
            y: Math.round((containerHeight - scaledHeight) / 2),
            scale: scaledWidth / this.width
        };
    }

    /**
     * Check if display mode is valid
     */
    isValid() {
        return this.width > 0 && this.height > 0 && 
               this.colorDepth >= 8 && this.refreshRate > 0;
    }
}

/**
 * TVNPaletteEntries - Palette handling for 8-bit graphics
 * Port from europeo.exe (palette management)
 */
export class VNPaletteEntries {
    constructor(size = 256) {
        this.size = size;
        this.entries = new Array(size).fill(null).map(() => ({
            r: 0, g: 0, b: 0, a: 255
        }));
    }

    /**
     * Set palette entry
     */
    setEntry(index, r, g, b, a = 255) {
        if (index >= 0 && index < this.size) {
            this.entries[index] = { r, g, b, a };
        }
    }

    /**
     * Get palette entry
     */
    getEntry(index) {
        if (index >= 0 && index < this.size) {
            return { ...this.entries[index] };
        }
        return { r: 0, g: 0, b: 0, a: 255 };
    }

    /**
     * Load palette from array of colors
     */
    loadFromArray(colors) {
        colors.forEach((color, index) => {
            if (index < this.size) {
                if (typeof color === 'number') {
                    // 32-bit ARGB
                    this.entries[index] = {
                        a: (color >> 24) & 0xFF,
                        r: (color >> 16) & 0xFF,
                        g: (color >> 8) & 0xFF,
                        b: color & 0xFF
                    };
                } else if (typeof color === 'object') {
                    this.entries[index] = { ...color };
                }
            }
        });
    }

    /**
     * Generate grayscale palette
     */
    generateGrayscale() {
        for (let i = 0; i < this.size; i++) {
            const value = Math.round((i / (this.size - 1)) * 255);
            this.entries[i] = { r: value, g: value, b: value, a: 255 };
        }
    }

    /**
     * Convert palette to CSS colors array
     */
    toCSSColors() {
        return this.entries.map(e => 
            `rgba(${e.r}, ${e.g}, ${e.b}, ${e.a / 255})`
        );
    }
}

/**
 * TVNHistData - History data for navigation
 * Port from europeo.exe (TVNHistData at 0x00413fbc region)
 */
export class VNHistData extends VNStreamable {
    constructor() {
        super();
        this.sceneIndex = 0;
        this.timestamp = Date.now();
        this.variables = {};
        this.mediaState = {};
    }

    /**
     * Capture current state
     */
    capture(engine) {
        this.sceneIndex = engine.currentSceneIndex || 0;
        this.timestamp = Date.now();
        this.variables = engine.variables ? engine.variables.exportAll() : {};
        // Capture media state if needed
        return this;
    }

    /**
     * Restore state to engine
     */
    restore(engine) {
        if (engine.variables) {
            engine.variables.importAll(this.variables);
        }
        if (typeof engine.gotoScene === 'function') {
            engine.gotoScene(this.sceneIndex);
        }
        return this;
    }

    serialize() {
        return {
            ...super.serialize(),
            sceneIndex: this.sceneIndex,
            timestamp: this.timestamp,
            variables: this.variables
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.sceneIndex !== undefined) this.sceneIndex = data.sceneIndex;
        if (data.timestamp !== undefined) this.timestamp = data.timestamp;
        if (data.variables) this.variables = { ...data.variables };
        return this;
    }
}

/**
 * TVNProtectData - Protection/DRM data
 * Port from europeo.exe (TVNProtectData)
 */
export class VNProtectData extends VNStreamable {
    constructor() {
        super();
        this.enabled = false;
        this.passwordHash = '';
        this.expirationDate = null;
        this.maxRuns = 0;
        this.currentRuns = 0;
        this.registrationRequired = false;
        this.registrationKey = '';
    }

    /**
     * Check if protection is active
     */
    isProtected() {
        return this.enabled;
    }

    /**
     * Verify password
     */
    verifyPassword(password) {
        if (!this.enabled) return true;
        // Simple hash comparison (original used basic hashing)
        const hash = this._hashPassword(password);
        return hash === this.passwordHash;
    }

    /**
     * Check if expired
     */
    isExpired() {
        if (!this.expirationDate) return false;
        return Date.now() > this.expirationDate;
    }

    /**
     * Check if max runs exceeded
     */
    isMaxRunsExceeded() {
        if (this.maxRuns <= 0) return false;
        return this.currentRuns >= this.maxRuns;
    }

    /**
     * Increment run counter
     */
    incrementRuns() {
        this.currentRuns++;
    }

    /**
     * Set password
     */
    setPassword(password) {
        this.passwordHash = this._hashPassword(password);
        this.enabled = true;
    }

    /**
     * Simple password hash (matches original's basic hashing)
     */
    _hashPassword(password) {
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return hash.toString(16);
    }

    serialize() {
        return {
            ...super.serialize(),
            enabled: this.enabled,
            passwordHash: this.passwordHash,
            expirationDate: this.expirationDate,
            maxRuns: this.maxRuns,
            currentRuns: this.currentRuns
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key) && key !== '_type' && key !== '_version') {
                this[key] = data[key];
            }
        });
        return this;
    }
}

/**
 * TVNPluginData - Plugin/extension data
 * Port from europeo.exe (TVNPluginData)
 */
export class VNPluginData extends VNStreamable {
    constructor() {
        super();
        this.id = '';
        this.name = '';
        this.version = '';
        this.author = '';
        this.description = '';
        this.enabled = true;
        this.settings = {};
        this.exports = {};
    }

    /**
     * Call exported function
     */
    callExport(name, ...args) {
        if (typeof this.exports[name] === 'function') {
            return this.exports[name](...args);
        }
        return undefined;
    }

    /**
     * Register export
     */
    registerExport(name, fn) {
        this.exports[name] = fn;
    }

    /**
     * Get setting
     */
    getSetting(key, defaultValue = null) {
        return this.settings.hasOwnProperty(key) ? this.settings[key] : defaultValue;
    }

    /**
     * Set setting
     */
    setSetting(key, value) {
        this.settings[key] = value;
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            name: this.name,
            version: this.version,
            author: this.author,
            description: this.description,
            enabled: this.enabled,
            settings: this.settings
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key) && key !== '_type' && key !== '_version' && key !== 'exports') {
                this[key] = data[key];
            }
        });
        return this;
    }
}

/**
 * Main Application class
 */
export class VNApplication extends VNStreamable {
    constructor() {
        super();
        
        this.version = new VNVersion();
        this.info = new VNApplicationInfo();
        this.projectInfo = new VNProjectInfo();
        this.displayMode = new VNDisplayMode();
        this.palette = new VNPaletteEntries();
        this.protection = new VNProtectData();
        this.plugins = [];
        this.history = [];
        this.maxHistory = 100;
        
        // State
        this.initialized = false;
        this.running = false;
        this.paused = false;
        
        // References
        this.engine = null;
        this.container = null;
    }

    /**
     * Initialize application
     * Mirrors: TVNApplication::InitInstance @ fcn.0040768d
     */
    initialize(container, options = {}) {
        this.container = container;
        
        // Apply options
        if (options.width) this.displayMode.width = options.width;
        if (options.height) this.displayMode.height = options.height;
        if (options.fullscreen !== undefined) this.displayMode.fullscreen = options.fullscreen;
        
        this.initialized = true;
        return this;
    }

    /**
     * Run application
     * Mirrors: TVNApplication::Run
     */
    run() {
        if (!this.initialized) {
            throw new Error('Application not initialized');
        }
        this.running = true;
        this.paused = false;
        return this;
    }

    /**
     * Pause application
     */
    pause() {
        this.paused = true;
        return this;
    }

    /**
     * Resume application
     */
    resume() {
        this.paused = false;
        return this;
    }

    /**
     * Stop application
     */
    stop() {
        this.running = false;
        this.paused = false;
        return this;
    }

    /**
     * Add history entry
     */
    addHistory(histData) {
        this.history.push(histData);
        while (this.history.length > this.maxHistory) {
            this.history.shift();
        }
    }

    /**
     * Go back in history
     */
    goBack() {
        if (this.history.length > 1) {
            this.history.pop(); // Remove current
            const previous = this.history[this.history.length - 1];
            if (previous && this.engine) {
                previous.restore(this.engine);
            }
            return previous;
        }
        return null;
    }

    /**
     * Clear history
     */
    clearHistory() {
        this.history = [];
    }

    /**
     * Register plugin
     */
    registerPlugin(plugin) {
        if (plugin instanceof VNPluginData) {
            this.plugins.push(plugin);
        }
    }

    /**
     * Get plugin by ID
     */
    getPlugin(id) {
        return this.plugins.find(p => p.id === id);
    }

    serialize() {
        return {
            ...super.serialize(),
            projectInfo: this.projectInfo.serialize(),
            displayMode: {
                width: this.displayMode.width,
                height: this.displayMode.height,
                colorDepth: this.displayMode.colorDepth,
                fullscreen: this.displayMode.fullscreen,
                scalingMode: this.displayMode.scalingMode
            }
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.projectInfo) this.projectInfo.deserialize(data.projectInfo);
        if (data.displayMode) Object.assign(this.displayMode, data.displayMode);
        return this;
    }
}

export default VNApplication;
