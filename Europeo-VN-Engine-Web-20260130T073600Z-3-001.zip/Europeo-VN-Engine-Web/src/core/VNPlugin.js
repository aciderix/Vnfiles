/**
 * VNPlugin - Plugin System
 * 
 * EXACT PORT from europeo.exe plugin system
 * 
 * Original classes from disassembly:
 * - TVNPluginData @ detected in RTTI
 * - TVNIndexDependant @ detected in RTTI
 * - TVNStreamable @ detected in RTTI
 */

/**
 * Plugin state
 */
export const VNPluginState = {
    UNLOADED: 0,
    LOADING: 1,
    LOADED: 2,
    ACTIVE: 3,
    ERROR: 4
};

/**
 * VNPluginData - Plugin data container
 * Port of TVNPluginData
 */
export class VNPluginData {
    constructor() {
        this.id = '';
        this.name = '';
        this.version = '1.0';
        this.author = '';
        this.description = '';
        this.state = VNPluginState.UNLOADED;
        this.data = {};
        this.exports = {};
        this.dependencies = [];
    }

    /**
     * Set plugin info
     * @param {Object} info 
     */
    setInfo(info) {
        if (info.id) this.id = info.id;
        if (info.name) this.name = info.name;
        if (info.version) this.version = info.version;
        if (info.author) this.author = info.author;
        if (info.description) this.description = info.description;
        if (info.dependencies) this.dependencies = info.dependencies;
    }

    /**
     * Get data value
     * @param {string} key 
     * @param {*} defaultValue 
     * @returns {*}
     */
    get(key, defaultValue = null) {
        return key in this.data ? this.data[key] : defaultValue;
    }

    /**
     * Set data value
     * @param {string} key 
     * @param {*} value 
     */
    set(key, value) {
        this.data[key] = value;
    }

    /**
     * Export function
     * @param {string} name 
     * @param {Function} fn 
     */
    export(name, fn) {
        this.exports[name] = fn;
    }

    /**
     * Get export
     * @param {string} name 
     * @returns {Function|null}
     */
    getExport(name) {
        return this.exports[name] || null;
    }

    /**
     * Serialize plugin data
     * @returns {Object}
     */
    serialize() {
        return {
            id: this.id,
            name: this.name,
            version: this.version,
            author: this.author,
            description: this.description,
            data: JSON.parse(JSON.stringify(this.data))
        };
    }

    /**
     * Deserialize plugin data
     * @param {Object} obj 
     */
    deserialize(obj) {
        if (obj.id) this.id = obj.id;
        if (obj.name) this.name = obj.name;
        if (obj.version) this.version = obj.version;
        if (obj.author) this.author = obj.author;
        if (obj.description) this.description = obj.description;
        if (obj.data) this.data = JSON.parse(JSON.stringify(obj.data));
    }
}

/**
 * VNPluginManager - Plugin management
 */
export class VNPluginManager {
    constructor() {
        this.plugins = new Map();
        this.loadOrder = [];
    }

    /**
     * Register plugin
     * @param {VNPluginData} plugin 
     */
    register(plugin) {
        this.plugins.set(plugin.id, plugin);
        plugin.state = VNPluginState.LOADED;
    }

    /**
     * Unregister plugin
     * @param {string} id 
     */
    unregister(id) {
        this.plugins.delete(id);
    }

    /**
     * Get plugin
     * @param {string} id 
     * @returns {VNPluginData|null}
     */
    get(id) {
        return this.plugins.get(id) || null;
    }

    /**
     * Get all plugins
     * @returns {VNPluginData[]}
     */
    getAll() {
        return Array.from(this.plugins.values());
    }

    /**
     * Check if plugin exists
     * @param {string} id 
     * @returns {boolean}
     */
    has(id) {
        return this.plugins.has(id);
    }

    /**
     * Activate plugin
     * @param {string} id 
     * @returns {boolean}
     */
    activate(id) {
        const plugin = this.plugins.get(id);
        if (!plugin) return false;
        
        // Check dependencies
        for (const dep of plugin.dependencies) {
            const depPlugin = this.plugins.get(dep);
            if (!depPlugin || depPlugin.state !== VNPluginState.ACTIVE) {
                console.warn(`Plugin ${id} depends on ${dep} which is not active`);
                return false;
            }
        }
        
        plugin.state = VNPluginState.ACTIVE;
        return true;
    }

    /**
     * Deactivate plugin
     * @param {string} id 
     */
    deactivate(id) {
        const plugin = this.plugins.get(id);
        if (plugin) {
            plugin.state = VNPluginState.LOADED;
        }
    }

    /**
     * Call plugin export
     * @param {string} pluginId 
     * @param {string} exportName 
     * @param {...*} args 
     * @returns {*}
     */
    call(pluginId, exportName, ...args) {
        const plugin = this.plugins.get(pluginId);
        if (!plugin) return null;
        
        const fn = plugin.getExport(exportName);
        if (typeof fn === 'function') {
            return fn.apply(null, args);
        }
        
        return null;
    }
}

/**
 * VNIndexDependant - Index-dependent object
 * Port of TVNIndexDependant
 * Used for objects that depend on scene/resource indices
 */
export class VNIndexDependant {
    constructor() {
        this.index = -1;
        this.parentIndex = -1;
        this.childIndices = [];
        this.dependencies = [];
        this.valid = false;
    }

    /**
     * Set index
     * @param {number} index 
     */
    setIndex(index) {
        this.index = index;
        this._validateIndex();
    }

    /**
     * Get index
     * @returns {number}
     */
    getIndex() {
        return this.index;
    }

    /**
     * Set parent index
     * @param {number} index 
     */
    setParentIndex(index) {
        this.parentIndex = index;
    }

    /**
     * Add child index
     * @param {number} index 
     */
    addChildIndex(index) {
        if (!this.childIndices.includes(index)) {
            this.childIndices.push(index);
        }
    }

    /**
     * Remove child index
     * @param {number} index 
     */
    removeChildIndex(index) {
        const pos = this.childIndices.indexOf(index);
        if (pos !== -1) {
            this.childIndices.splice(pos, 1);
        }
    }

    /**
     * Add dependency
     * @param {number} index 
     */
    addDependency(index) {
        if (!this.dependencies.includes(index)) {
            this.dependencies.push(index);
        }
    }

    /**
     * Remove dependency
     * @param {number} index 
     */
    removeDependency(index) {
        const pos = this.dependencies.indexOf(index);
        if (pos !== -1) {
            this.dependencies.splice(pos, 1);
        }
    }

    /**
     * Check if depends on index
     * @param {number} index 
     * @returns {boolean}
     */
    dependsOn(index) {
        return this.dependencies.includes(index);
    }

    /**
     * Validate index
     * @private
     */
    _validateIndex() {
        this.valid = this.index >= 0;
    }

    /**
     * Check if valid
     * @returns {boolean}
     */
    isValid() {
        return this.valid && this.index >= 0;
    }

    /**
     * Update indices after deletion
     * @param {number} deletedIndex 
     */
    updateAfterDeletion(deletedIndex) {
        // Update own index
        if (this.index > deletedIndex) {
            this.index--;
        } else if (this.index === deletedIndex) {
            this.index = -1;
            this.valid = false;
        }
        
        // Update parent index
        if (this.parentIndex > deletedIndex) {
            this.parentIndex--;
        } else if (this.parentIndex === deletedIndex) {
            this.parentIndex = -1;
        }
        
        // Update child indices
        this.childIndices = this.childIndices
            .filter(idx => idx !== deletedIndex)
            .map(idx => idx > deletedIndex ? idx - 1 : idx);
        
        // Update dependencies
        this.dependencies = this.dependencies
            .filter(idx => idx !== deletedIndex)
            .map(idx => idx > deletedIndex ? idx - 1 : idx);
    }

    /**
     * Update indices after insertion
     * @param {number} insertedIndex 
     */
    updateAfterInsertion(insertedIndex) {
        // Update own index
        if (this.index >= insertedIndex) {
            this.index++;
        }
        
        // Update parent index
        if (this.parentIndex >= insertedIndex) {
            this.parentIndex++;
        }
        
        // Update child indices
        this.childIndices = this.childIndices
            .map(idx => idx >= insertedIndex ? idx + 1 : idx);
        
        // Update dependencies
        this.dependencies = this.dependencies
            .map(idx => idx >= insertedIndex ? idx + 1 : idx);
    }
}

/**
 * VNStreamable - Streamable object base
 * Port of TVNStreamable
 */
export class VNStreamable {
    constructor() {
        this.streamVersion = 1;
        this.streamId = Math.random().toString(36).substr(2, 9);
    }

    /**
     * Read from stream
     * @param {Object} stream - Stream reader
     */
    read(stream) {
        if (stream.readInt) {
            this.streamVersion = stream.readInt();
        }
    }

    /**
     * Write to stream
     * @param {Object} stream - Stream writer
     */
    write(stream) {
        if (stream.writeInt) {
            stream.writeInt(this.streamVersion);
        }
    }

    /**
     * Get class name for streaming
     * @returns {string}
     */
    getClassName() {
        return this.constructor.name;
    }

    /**
     * Create from stream
     * @param {Object} stream 
     * @returns {VNStreamable}
     */
    static createFromStream(stream) {
        const obj = new this();
        obj.read(stream);
        return obj;
    }
}

/**
 * Global plugin manager instance
 */
export const pluginManager = new VNPluginManager();

export default {
    VNPluginState,
    VNPluginData,
    VNPluginManager,
    VNIndexDependant,
    VNStreamable,
    pluginManager
};
