/**
 * VNProtect - Protection and DRM classes
 * 
 * Port of TVNProtectData from europeo.exe
 * The original engine had basic copy protection:
 * - Project file integrity checking
 * - Registration validation
 * - Expiration dates
 * 
 * Web implementation provides similar functionality
 * but focuses on content protection rather than DRM
 */

import { VNStreamable } from './VNObject.js';

/**
 * Protection flags
 */
export const VNProtectFlags = {
    NONE: 0x00,
    REGISTERED: 0x01,
    TRIAL: 0x02,
    EXPIRED: 0x04,
    DEMO: 0x08,
    FULL: 0x10,
    EDUCATIONAL: 0x20
};

/**
 * TVNProtectData - Protection data structure
 * Stores registration and protection state
 */
export class VNProtectData extends VNStreamable {
    constructor(options = {}) {
        super();
        
        // Registration info
        this.registeredName = options.registeredName || '';
        this.registrationKey = options.registrationKey || '';
        this.registrationDate = options.registrationDate || null;
        
        // Protection flags
        this.flags = options.flags || VNProtectFlags.NONE;
        
        // Trial info
        this.trialStartDate = options.trialStartDate || null;
        this.trialDays = options.trialDays || 30;
        this.trialExpired = false;
        
        // Version limits
        this.allowedVersion = options.allowedVersion || '*';
        this.minVersion = options.minVersion || '0.0.0';
        this.maxVersion = options.maxVersion || '999.999.999';
        
        // Feature flags
        this.features = options.features || {
            saveEnabled: true,
            loadEnabled: true,
            skipEnabled: true,
            galleryEnabled: false,
            extrasEnabled: false
        };
        
        // Integrity
        this.checksum = options.checksum || null;
        this.projectId = options.projectId || null;
    }

    /**
     * Check if registered
     */
    isRegistered() {
        return (this.flags & VNProtectFlags.REGISTERED) !== 0;
    }

    /**
     * Check if trial
     */
    isTrial() {
        return (this.flags & VNProtectFlags.TRIAL) !== 0;
    }

    /**
     * Check if demo mode
     */
    isDemo() {
        return (this.flags & VNProtectFlags.DEMO) !== 0;
    }

    /**
     * Check if trial expired
     */
    isTrialExpired() {
        if (!this.isTrial() || !this.trialStartDate) return false;
        
        const startDate = new Date(this.trialStartDate);
        const expiryDate = new Date(startDate);
        expiryDate.setDate(expiryDate.getDate() + this.trialDays);
        
        return new Date() > expiryDate;
    }

    /**
     * Get remaining trial days
     */
    getRemainingTrialDays() {
        if (!this.isTrial() || !this.trialStartDate) return 0;
        
        const startDate = new Date(this.trialStartDate);
        const expiryDate = new Date(startDate);
        expiryDate.setDate(expiryDate.getDate() + this.trialDays);
        
        const remaining = Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24));
        return Math.max(0, remaining);
    }

    /**
     * Start trial
     */
    startTrial(days = 30) {
        this.trialStartDate = new Date().toISOString();
        this.trialDays = days;
        this.flags |= VNProtectFlags.TRIAL;
    }

    /**
     * Register with key
     */
    register(name, key) {
        // Validate key (simplified)
        if (!this._validateKey(name, key)) {
            return false;
        }
        
        this.registeredName = name;
        this.registrationKey = key;
        this.registrationDate = new Date().toISOString();
        this.flags = VNProtectFlags.REGISTERED | VNProtectFlags.FULL;
        
        return true;
    }

    /**
     * Validate registration key
     */
    _validateKey(name, key) {
        // Simple validation - in real implementation would use proper algorithm
        if (!name || !key) return false;
        if (key.length < 16) return false;
        
        // Check key format (XXXX-XXXX-XXXX-XXXX)
        const keyPattern = /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
        if (!keyPattern.test(key)) return false;
        
        // Generate expected checksum from name
        const nameHash = this._hashString(name.toUpperCase());
        const keyChecksum = parseInt(key.replace(/-/g, '').slice(-4), 16);
        
        return (nameHash & 0xFFFF) === keyChecksum;
    }

    /**
     * Simple string hash
     */
    _hashString(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return Math.abs(hash);
    }

    /**
     * Check feature availability
     */
    isFeatureEnabled(feature) {
        return this.features[feature] === true;
    }

    /**
     * Enable feature
     */
    enableFeature(feature) {
        this.features[feature] = true;
    }

    /**
     * Disable feature
     */
    disableFeature(feature) {
        this.features[feature] = false;
    }

    /**
     * Verify version
     */
    isVersionAllowed(version) {
        if (this.allowedVersion === '*') return true;
        
        const v = this._parseVersion(version);
        const min = this._parseVersion(this.minVersion);
        const max = this._parseVersion(this.maxVersion);
        
        return this._compareVersions(v, min) >= 0 && 
               this._compareVersions(v, max) <= 0;
    }

    /**
     * Parse version string
     */
    _parseVersion(str) {
        const parts = str.split('.').map(p => parseInt(p) || 0);
        return {
            major: parts[0] || 0,
            minor: parts[1] || 0,
            patch: parts[2] || 0
        };
    }

    /**
     * Compare versions
     */
    _compareVersions(a, b) {
        if (a.major !== b.major) return a.major - b.major;
        if (a.minor !== b.minor) return a.minor - b.minor;
        return a.patch - b.patch;
    }

    /**
     * Calculate checksum for data
     */
    static calculateChecksum(data) {
        let checksum = 0;
        const str = JSON.stringify(data);
        
        for (let i = 0; i < str.length; i++) {
            checksum = ((checksum << 5) - checksum) + str.charCodeAt(i);
            checksum = checksum & checksum;
        }
        
        return checksum.toString(16);
    }

    /**
     * Verify data integrity
     */
    verifyIntegrity(data) {
        if (!this.checksum) return true;
        
        const calculated = VNProtectData.calculateChecksum(data);
        return calculated === this.checksum;
    }

    /**
     * Serialize
     */
    toJSON() {
        return {
            registeredName: this.registeredName,
            registrationKey: this.registrationKey,
            registrationDate: this.registrationDate,
            flags: this.flags,
            trialStartDate: this.trialStartDate,
            trialDays: this.trialDays,
            allowedVersion: this.allowedVersion,
            minVersion: this.minVersion,
            maxVersion: this.maxVersion,
            features: { ...this.features },
            checksum: this.checksum,
            projectId: this.projectId
        };
    }

    /**
     * Deserialize
     */
    static fromJSON(data) {
        return new VNProtectData(data);
    }
}

/**
 * VNPluginData - Plugin/DLL data
 * Port of TVNPluginData from europeo.exe
 * Manages loaded plugins/extensions
 */
export class VNPluginData extends VNStreamable {
    constructor(options = {}) {
        super();
        
        this.name = options.name || '';
        this.version = options.version || '1.0.0';
        this.author = options.author || '';
        this.description = options.description || '';
        
        // Plugin path (original was DLL path)
        this.path = options.path || '';
        
        // Entry points (function names)
        this.entryPoints = options.entryPoints || {
            init: 'PluginInit',
            execute: 'PluginExecute',
            cleanup: 'PluginCleanup'
        };
        
        // State
        this.loaded = false;
        this.instance = null;
        
        // Capabilities
        this.capabilities = options.capabilities || [];
        
        // Dependencies
        this.dependencies = options.dependencies || [];
    }

    /**
     * Load plugin (web: load JS module)
     */
    async load() {
        if (this.loaded) return true;
        
        try {
            // Dynamic import
            const module = await import(this.path);
            this.instance = module;
            
            // Call init if exists
            if (module[this.entryPoints.init]) {
                await module[this.entryPoints.init]();
            }
            
            this.loaded = true;
            return true;
        } catch (err) {
            console.error(`Failed to load plugin: ${this.name}`, err);
            return false;
        }
    }

    /**
     * Execute plugin function
     */
    async execute(functionName, ...args) {
        if (!this.loaded || !this.instance) {
            throw new Error('Plugin not loaded');
        }
        
        const fn = this.instance[functionName];
        if (typeof fn !== 'function') {
            throw new Error(`Plugin function not found: ${functionName}`);
        }
        
        return await fn(...args);
    }

    /**
     * Unload plugin
     */
    async unload() {
        if (!this.loaded) return;
        
        // Call cleanup if exists
        if (this.instance && this.instance[this.entryPoints.cleanup]) {
            await this.instance[this.entryPoints.cleanup]();
        }
        
        this.instance = null;
        this.loaded = false;
    }

    /**
     * Check if has capability
     */
    hasCapability(cap) {
        return this.capabilities.includes(cap);
    }

    /**
     * Serialize
     */
    toJSON() {
        return {
            name: this.name,
            version: this.version,
            author: this.author,
            description: this.description,
            path: this.path,
            entryPoints: { ...this.entryPoints },
            capabilities: [...this.capabilities],
            dependencies: [...this.dependencies]
        };
    }

    /**
     * Deserialize
     */
    static fromJSON(data) {
        return new VNPluginData(data);
    }
}

/**
 * VNPluginManager - Plugin management
 */
export class VNPluginManager {
    constructor() {
        this._plugins = new Map();
    }

    /**
     * Register plugin
     */
    register(plugin) {
        this._plugins.set(plugin.name, plugin);
    }

    /**
     * Get plugin
     */
    get(name) {
        return this._plugins.get(name);
    }

    /**
     * Load plugin
     */
    async load(name) {
        const plugin = this._plugins.get(name);
        if (!plugin) {
            throw new Error(`Plugin not found: ${name}`);
        }
        return await plugin.load();
    }

    /**
     * Load all plugins
     */
    async loadAll() {
        const results = [];
        for (const plugin of this._plugins.values()) {
            try {
                await plugin.load();
                results.push({ name: plugin.name, success: true });
            } catch (err) {
                results.push({ name: plugin.name, success: false, error: err });
            }
        }
        return results;
    }

    /**
     * Unload plugin
     */
    async unload(name) {
        const plugin = this._plugins.get(name);
        if (plugin) {
            await plugin.unload();
        }
    }

    /**
     * Unload all plugins
     */
    async unloadAll() {
        for (const plugin of this._plugins.values()) {
            await plugin.unload();
        }
    }

    /**
     * Get all plugins
     */
    getAll() {
        return [...this._plugins.values()];
    }

    /**
     * Get plugins with capability
     */
    getWithCapability(capability) {
        return this.getAll().filter(p => p.hasCapability(capability));
    }
}

export default {
    VNProtectFlags,
    VNProtectData,
    VNPluginData,
    VNPluginManager
};
