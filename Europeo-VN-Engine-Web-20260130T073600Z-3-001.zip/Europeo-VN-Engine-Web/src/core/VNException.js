/**
 * VNException - Exception and Error Handling System
 * 
 * EXACT PORT from Borland C++ exception system
 * 
 * Original functions from disassembly:
 * - xerror @ 0x00403d2b
 * - @xerror@MakeString$qpxct1t1ul @ 0x004515ec
 * - @_ThrowExceptionLDTC$qpvt1t1t1uiuiuipuct1 @ 0x00451462
 * - @_ReThrowException$quipuc @ 0x004513bc
 * - __ExceptionHandler @ 0x004513d8
 * - @_CatchCleanup$qv @ 0x00451540
 * - Exception @ 0x0044e04f
 */

/**
 * Base exception class
 * Port of Borland Exception class
 */
export class VNException extends Error {
    /**
     * @param {string} message 
     * @param {number} errorCode 
     */
    constructor(message = '', errorCode = 0) {
        super(message);
        this.name = 'VNException';
        this.errorCode = errorCode;
        this.timestamp = Date.now();
        
        // Capture stack trace
        if (Error.captureStackTrace) {
            Error.captureStackTrace(this, this.constructor);
        }
    }

    /**
     * Make string (xerror::MakeString)
     * Port of @xerror@MakeString$qpxct1t1ul @ 0x004515ec
     * @returns {string}
     */
    makeString() {
        return `${this.name}: ${this.message} (Error code: ${this.errorCode})`;
    }

    /**
     * Get error code
     * @returns {number}
     */
    getErrorCode() {
        return this.errorCode;
    }

    /**
     * Clone exception
     * @returns {VNException}
     */
    clone() {
        const ex = new VNException(this.message, this.errorCode);
        ex.stack = this.stack;
        return ex;
    }
}

/**
 * Runtime exception
 */
export class VNRuntimeException extends VNException {
    constructor(message = 'Runtime error', errorCode = 1) {
        super(message, errorCode);
        this.name = 'VNRuntimeException';
    }
}

/**
 * Out of memory exception
 */
export class VNOutOfMemoryException extends VNException {
    constructor(message = 'Out of memory') {
        super(message, 2);
        this.name = 'VNOutOfMemoryException';
    }
}

/**
 * Invalid parameter exception
 */
export class VNInvalidParameterException extends VNException {
    /**
     * @param {string} paramName 
     */
    constructor(paramName = '') {
        super(paramName ? `Invalid parameter: ${paramName}` : 'Invalid parameter', 3);
        this.name = 'VNInvalidParameterException';
        this.paramName = paramName;
    }
}

/**
 * File not found exception
 */
export class VNFileNotFoundException extends VNException {
    /**
     * @param {string} filename 
     */
    constructor(filename = '') {
        super(filename ? `File not found: ${filename}` : 'File not found', 4);
        this.name = 'VNFileNotFoundException';
        this.filename = filename;
    }
}

/**
 * File IO exception
 */
export class VNFileIOException extends VNException {
    /**
     * @param {string} message 
     * @param {string} filename 
     */
    constructor(message = 'File I/O error', filename = '') {
        super(filename ? `${message}: ${filename}` : message, 5);
        this.name = 'VNFileIOException';
        this.filename = filename;
    }
}

/**
 * Resource exception
 */
export class VNResourceException extends VNException {
    /**
     * @param {string} resourceName 
     */
    constructor(resourceName = '') {
        super(resourceName ? `Resource error: ${resourceName}` : 'Resource error', 6);
        this.name = 'VNResourceException';
        this.resourceName = resourceName;
    }
}

/**
 * Registry exception
 * Port of "Registry failure on key: %s, ErrorCode = %lX" @ 0x0044e8b6
 */
export class VNRegistryException extends VNException {
    /**
     * @param {string} key 
     * @param {number} errorCode 
     */
    constructor(key = '', errorCode = 0) {
        const msg = key 
            ? `Registry failure on key: ${key}, ErrorCode = ${errorCode.toString(16).toUpperCase()}`
            : `Registry failure on unknown key: ErrorCode = ${errorCode.toString(16).toUpperCase()}`;
        super(msg, 7);
        this.name = 'VNRegistryException';
        this.registryKey = key;
        this.windowsErrorCode = errorCode;
    }
}

/**
 * Script exception
 */
export class VNScriptException extends VNException {
    /**
     * @param {string} message 
     * @param {number} line 
     * @param {string} script 
     */
    constructor(message = 'Script error', line = 0, script = '') {
        super(line > 0 ? `${message} at line ${line}` : message, 8);
        this.name = 'VNScriptException';
        this.line = line;
        this.script = script;
    }
}

/**
 * Command exception
 */
export class VNCommandException extends VNException {
    /**
     * @param {string} command 
     * @param {string} message 
     */
    constructor(command = '', message = 'Command error') {
        super(command ? `${message}: ${command}` : message, 9);
        this.name = 'VNCommandException';
        this.command = command;
    }
}

/**
 * Media exception
 */
export class VNMediaException extends VNException {
    /**
     * @param {string} message 
     * @param {string} mediaFile 
     */
    constructor(message = 'Media error', mediaFile = '') {
        super(mediaFile ? `${message}: ${mediaFile}` : message, 10);
        this.name = 'VNMediaException';
        this.mediaFile = mediaFile;
    }
}

/**
 * Graphics exception
 */
export class VNGraphicsException extends VNException {
    constructor(message = 'Graphics error') {
        super(message, 11);
        this.name = 'VNGraphicsException';
    }
}

/**
 * Handle exception (HINSTANCE_ERROR)
 * Port of "Handle > HINSTANCE(HINSTANCE_ERROR)" @ various addresses
 */
export class VNHandleException extends VNException {
    /**
     * @param {string} handleType 
     */
    constructor(handleType = 'HINSTANCE') {
        super(`Handle > ${handleType}(${handleType}_ERROR)`, 12);
        this.name = 'VNHandleException';
        this.handleType = handleType;
    }
}

/**
 * Printing exception
 * Port of "'%s' not printed. %s." @ 0x004d8378
 */
export class VNPrintException extends VNException {
    /**
     * @param {string} document 
     * @param {string} reason 
     */
    constructor(document = '', reason = '') {
        const msg = document 
            ? `'${document}' not printed. ${reason || 'Unknown error'}.`
            : 'Printing error';
        super(msg, 13);
        this.name = 'VNPrintException';
        this.document = document;
        this.reason = reason;
    }
}

/**
 * Print cancelled exception
 * Port of "Printing canceled!Printing aborted in Print Manager" @ 0x004d83e6
 */
export class VNPrintCancelledException extends VNException {
    /**
     * @param {boolean} abortedByManager 
     */
    constructor(abortedByManager = false) {
        const msg = abortedByManager 
            ? 'Printing aborted in Print Manager'
            : 'Printing canceled!';
        super(msg, 14);
        this.name = 'VNPrintCancelledException';
        this.abortedByManager = abortedByManager;
    }
}

/**
 * Exception handler
 * Port of __ExceptionHandler @ 0x004513d8
 */
export class VNExceptionHandler {
    constructor() {
        this.handlers = [];
        this.lastException = null;
        this.exceptionLog = [];
        this.maxLogSize = 100;
    }

    /**
     * Register handler
     * @param {Function} handler - (exception) => boolean (return true if handled)
     */
    registerHandler(handler) {
        this.handlers.push(handler);
    }

    /**
     * Unregister handler
     * @param {Function} handler 
     */
    unregisterHandler(handler) {
        const index = this.handlers.indexOf(handler);
        if (index !== -1) {
            this.handlers.splice(index, 1);
        }
    }

    /**
     * Handle exception
     * @param {Error} exception 
     * @returns {boolean} - True if handled
     */
    handle(exception) {
        this.lastException = exception;
        this._logException(exception);
        
        for (const handler of this.handlers) {
            try {
                if (handler(exception)) {
                    return true;
                }
            } catch (e) {
                console.error('Exception in exception handler:', e);
            }
        }
        
        return false;
    }

    /**
     * Throw exception
     * Port of @_ThrowExceptionLDTC$qpvt1t1t1uiuiuipuct1 @ 0x00451462
     * @param {Error} exception 
     */
    throw(exception) {
        if (!this.handle(exception)) {
            throw exception;
        }
    }

    /**
     * Rethrow last exception
     * Port of @_ReThrowException$quipuc @ 0x004513bc
     */
    rethrow() {
        if (this.lastException) {
            throw this.lastException;
        }
    }

    /**
     * Get last exception
     * @returns {Error|null}
     */
    getLastException() {
        return this.lastException;
    }

    /**
     * Get exception log
     * @returns {Array}
     */
    getLog() {
        return [...this.exceptionLog];
    }

    /**
     * Clear exception log
     */
    clearLog() {
        this.exceptionLog = [];
        this.lastException = null;
    }

    /**
     * Log exception
     * @private
     */
    _logException(exception) {
        this.exceptionLog.push({
            timestamp: Date.now(),
            name: exception.name || 'Error',
            message: exception.message,
            stack: exception.stack,
            errorCode: exception.errorCode
        });
        
        // Trim log
        if (this.exceptionLog.length > this.maxLogSize) {
            this.exceptionLog.shift();
        }
    }
}

/**
 * Global exception handler
 */
export const exceptionHandler = new VNExceptionHandler();

/**
 * Try-catch wrapper
 * @param {Function} fn 
 * @param {Function} errorHandler 
 * @returns {*}
 */
export function vnTry(fn, errorHandler = null) {
    try {
        return fn();
    } catch (e) {
        if (!exceptionHandler.handle(e)) {
            if (errorHandler) {
                return errorHandler(e);
            }
            throw e;
        }
    }
}

/**
 * Async try-catch wrapper
 * @param {Function} fn 
 * @param {Function} errorHandler 
 * @returns {Promise<*>}
 */
export async function vnTryAsync(fn, errorHandler = null) {
    try {
        return await fn();
    } catch (e) {
        if (!exceptionHandler.handle(e)) {
            if (errorHandler) {
                return errorHandler(e);
            }
            throw e;
        }
    }
}

export default {
    VNException,
    VNRuntimeException,
    VNOutOfMemoryException,
    VNInvalidParameterException,
    VNFileNotFoundException,
    VNFileIOException,
    VNResourceException,
    VNRegistryException,
    VNScriptException,
    VNCommandException,
    VNMediaException,
    VNGraphicsException,
    VNHandleException,
    VNPrintException,
    VNPrintCancelledException,
    VNExceptionHandler,
    exceptionHandler,
    vnTry,
    vnTryAsync
};
