/**
 * VNRegistry - Registry and configuration storage
 * 
 * Port of Windows Registry access from europeo.exe
 * Uses localStorage/IndexedDB for web persistence
 * 
 * Original functions (from disassembly):
 * - RegOpenKeyExA, RegCreateKeyExA
 * - RegQueryValueExA, RegSetValueExA
 * - RegEnumKeyA, RegEnumValueA
 * - RegDeleteKeyA, RegCloseKey
 * 
 * Registry paths used:
 * - HKEY_CURRENT_USER\Software\Europeo
 * - HKEY_LOCAL_MACHINE\Software\Europeo
 */

import { VNStreamable } from './VNObject.js';

/**
 * Registry root keys (simulated)
 */
export const VNRegRoot = {
    HKEY_CURRENT_USER: 'HKCU',
    HKEY_LOCAL_MACHINE: 'HKLM',
    HKEY_CLASSES_ROOT: 'HKCR'
};

/**
 * Registry value types
 */
export const VNRegType = {
    REG_SZ: 1,          // String
    REG_EXPAND_SZ: 2,   // Expandable string
    REG_BINARY: 3,      // Binary data
    REG_DWORD: 4,       // 32-bit number
    REG_MULTI_SZ: 7     // Multiple strings
};

/**
 * VNRegistryKey - Registry key class
 */
export class VNRegistryKey extends VNStreamable {
    constructor(root, path) {
        super();
        
        this.root = root;
        this.path = path;
        this.fullPath = `${root}\\${path}`;
        this._values = new Map();
        this._subkeys = new Map();
    }

    /**
     * Set value
     */
    setValue(name, value, type = VNRegType.REG_SZ) {
        this._values.set(name, { value, type });
    }

    /**
     * Get value
     */
    getValue(name, defaultValue = null) {
        const entry = this._values.get(name);
        return entry ? entry.value : defaultValue;
    }

    /**
     * Delete value
     */
    deleteValue(name) {
        return this._values.delete(name);
    }

    /**
     * Get all values
     */
    getValues() {
        return new Map(this._values);
    }

    /**
     * Get value names
     */
    getValueNames() {
        return [...this._values.keys()];
    }

    /**
     * Add subkey
     */
    addSubkey(name, key) {
        this._subkeys.set(name, key);
    }

    /**
     * Get subkey
     */
    getSubkey(name) {
        return this._subkeys.get(name);
    }

    /**
     * Get subkey names
     */
    getSubkeyNames() {
        return [...this._subkeys.keys()];
    }

    /**
     * Serialize
     */
    toJSON() {
        const values = {};
        for (const [name, entry] of this._values) {
            values[name] = entry;
        }
        
        const subkeys = {};
        for (const [name, key] of this._subkeys) {
            subkeys[name] = key.toJSON();
        }
        
        return {
            root: this.root,
            path: this.path,
            values,
            subkeys
        };
    }

    /**
     * Deserialize
     */
    static fromJSON(data) {
        const key = new VNRegistryKey(data.root, data.path);
        
        for (const [name, entry] of Object.entries(data.values)) {
            key._values.set(name, entry);
        }
        
        for (const [name, subkeyData] of Object.entries(data.subkeys)) {
            key._subkeys.set(name, VNRegistryKey.fromJSON(subkeyData));
        }
        
        return key;
    }
}

/**
 * VNRegistry - Windows Registry emulation
 */
export class VNRegistry {
    constructor(options = {}) {
        this._storageKey = options.storageKey || 'vn_registry';
        this._keys = new Map();
        this._modified = false;
        
        // Load from storage
        this._load();
    }

    /**
     * Load from localStorage
     */
    _load() {
        try {
            const data = localStorage.getItem(this._storageKey);
            if (data) {
                const parsed = JSON.parse(data);
                for (const [path, keyData] of Object.entries(parsed)) {
                    this._keys.set(path, VNRegistryKey.fromJSON(keyData));
                }
            }
        } catch (err) {
            console.warn('Failed to load registry:', err);
        }
    }

    /**
     * Save to localStorage
     */
    _save() {
        try {
            const data = {};
            for (const [path, key] of this._keys) {
                data[path] = key.toJSON();
            }
            localStorage.setItem(this._storageKey, JSON.stringify(data));
            this._modified = false;
        } catch (err) {
            console.warn('Failed to save registry:', err);
        }
    }

    /**
     * Open or create key
     * @param {string} root - Root key (HKCU, HKLM)
     * @param {string} path - Key path
     * @param {boolean} create - Create if not exists
     */
    openKey(root, path, create = false) {
        const fullPath = `${root}\\${path}`;
        
        if (this._keys.has(fullPath)) {
            return this._keys.get(fullPath);
        }
        
        if (create) {
            const key = new VNRegistryKey(root, path);
            this._keys.set(fullPath, key);
            this._modified = true;
            return key;
        }
        
        return null;
    }

    /**
     * Create key
     */
    createKey(root, path) {
        return this.openKey(root, path, true);
    }

    /**
     * Delete key
     */
    deleteKey(root, path) {
        const fullPath = `${root}\\${path}`;
        const deleted = this._keys.delete(fullPath);
        if (deleted) {
            this._modified = true;
        }
        return deleted;
    }

    /**
     * Set value
     */
    setValue(root, path, name, value, type = VNRegType.REG_SZ) {
        const key = this.openKey(root, path, true);
        key.setValue(name, value, type);
        this._modified = true;
        this._save();
    }

    /**
     * Get value
     */
    getValue(root, path, name, defaultValue = null) {
        const key = this.openKey(root, path);
        if (!key) return defaultValue;
        return key.getValue(name, defaultValue);
    }

    /**
     * Delete value
     */
    deleteValue(root, path, name) {
        const key = this.openKey(root, path);
        if (key) {
            const deleted = key.deleteValue(name);
            if (deleted) {
                this._modified = true;
                this._save();
            }
            return deleted;
        }
        return false;
    }

    /**
     * Enumerate keys
     */
    enumKeys(root, path) {
        const key = this.openKey(root, path);
        return key ? key.getSubkeyNames() : [];
    }

    /**
     * Enumerate values
     */
    enumValues(root, path) {
        const key = this.openKey(root, path);
        return key ? key.getValueNames() : [];
    }

    /**
     * Flush changes
     */
    flush() {
        if (this._modified) {
            this._save();
        }
    }

    /**
     * Clear all
     */
    clear() {
        this._keys.clear();
        localStorage.removeItem(this._storageKey);
        this._modified = false;
    }

    // ============================================
    // High-level convenience methods for VN Engine
    // ============================================

    /**
     * Get engine settings
     */
    getEngineSetting(name, defaultValue = null) {
        return this.getValue(
            VNRegRoot.HKEY_CURRENT_USER,
            'Software\\Europeo\\Engine',
            name,
            defaultValue
        );
    }

    /**
     * Set engine setting
     */
    setEngineSetting(name, value) {
        this.setValue(
            VNRegRoot.HKEY_CURRENT_USER,
            'Software\\Europeo\\Engine',
            name,
            value
        );
    }

    /**
     * Get project setting
     */
    getProjectSetting(projectName, name, defaultValue = null) {
        return this.getValue(
            VNRegRoot.HKEY_CURRENT_USER,
            `Software\\Europeo\\Projects\\${projectName}`,
            name,
            defaultValue
        );
    }

    /**
     * Set project setting
     */
    setProjectSetting(projectName, name, value) {
        this.setValue(
            VNRegRoot.HKEY_CURRENT_USER,
            `Software\\Europeo\\Projects\\${projectName}`,
            name,
            value
        );
    }

    /**
     * Get recent projects
     */
    getRecentProjects() {
        const json = this.getEngineSetting('RecentProjects', '[]');
        try {
            return JSON.parse(json);
        } catch {
            return [];
        }
    }

    /**
     * Add recent project
     */
    addRecentProject(path, name) {
        const recent = this.getRecentProjects();
        
        // Remove if exists
        const index = recent.findIndex(p => p.path === path);
        if (index !== -1) {
            recent.splice(index, 1);
        }
        
        // Add to front
        recent.unshift({ path, name, timestamp: Date.now() });
        
        // Limit to 10
        while (recent.length > 10) {
            recent.pop();
        }
        
        this.setEngineSetting('RecentProjects', JSON.stringify(recent));
    }

    /**
     * Get window position
     */
    getWindowPosition() {
        return {
            x: parseInt(this.getEngineSetting('WindowX', '0')) || 0,
            y: parseInt(this.getEngineSetting('WindowY', '0')) || 0,
            width: parseInt(this.getEngineSetting('WindowWidth', '800')) || 800,
            height: parseInt(this.getEngineSetting('WindowHeight', '600')) || 600,
            maximized: this.getEngineSetting('WindowMaximized', 'false') === 'true'
        };
    }

    /**
     * Save window position
     */
    saveWindowPosition(x, y, width, height, maximized) {
        this.setEngineSetting('WindowX', String(x));
        this.setEngineSetting('WindowY', String(y));
        this.setEngineSetting('WindowWidth', String(width));
        this.setEngineSetting('WindowHeight', String(height));
        this.setEngineSetting('WindowMaximized', String(maximized));
    }

    /**
     * Get audio settings
     */
    getAudioSettings() {
        return {
            musicVolume: parseInt(this.getEngineSetting('MusicVolume', '100')) || 100,
            soundVolume: parseInt(this.getEngineSetting('SoundVolume', '100')) || 100,
            voiceVolume: parseInt(this.getEngineSetting('VoiceVolume', '100')) || 100,
            muted: this.getEngineSetting('Muted', 'false') === 'true'
        };
    }

    /**
     * Save audio settings
     */
    saveAudioSettings(settings) {
        if (settings.musicVolume !== undefined) {
            this.setEngineSetting('MusicVolume', String(settings.musicVolume));
        }
        if (settings.soundVolume !== undefined) {
            this.setEngineSetting('SoundVolume', String(settings.soundVolume));
        }
        if (settings.voiceVolume !== undefined) {
            this.setEngineSetting('VoiceVolume', String(settings.voiceVolume));
        }
        if (settings.muted !== undefined) {
            this.setEngineSetting('Muted', String(settings.muted));
        }
    }

    /**
     * Get text settings
     */
    getTextSettings() {
        return {
            textSpeed: parseInt(this.getEngineSetting('TextSpeed', '50')) || 50,
            autoAdvance: this.getEngineSetting('AutoAdvance', 'false') === 'true',
            autoAdvanceDelay: parseInt(this.getEngineSetting('AutoAdvanceDelay', '3000')) || 3000,
            skipRead: this.getEngineSetting('SkipRead', 'true') === 'true'
        };
    }

    /**
     * Save text settings
     */
    saveTextSettings(settings) {
        if (settings.textSpeed !== undefined) {
            this.setEngineSetting('TextSpeed', String(settings.textSpeed));
        }
        if (settings.autoAdvance !== undefined) {
            this.setEngineSetting('AutoAdvance', String(settings.autoAdvance));
        }
        if (settings.autoAdvanceDelay !== undefined) {
            this.setEngineSetting('AutoAdvanceDelay', String(settings.autoAdvanceDelay));
        }
        if (settings.skipRead !== undefined) {
            this.setEngineSetting('SkipRead', String(settings.skipRead));
        }
    }
}

/**
 * Global registry instance
 */
export const vnRegistry = new VNRegistry();

export default {
    VNRegRoot,
    VNRegType,
    VNRegistryKey,
    VNRegistry,
    vnRegistry
};
