/**
 * VNHtml - HTML text and anchor link classes
 * 
 * Port of TVNHtmlText, TVNAnchLink, TPageContext from europeo.exe
 * Handles rich text rendering with clickable links
 * 
 * Original classes:
 * - TVNHtmlText - HTML-like text renderer
 * - TVNAnchLink - Anchor/hyperlink handling
 * - TPageContext - Page rendering context
 * - TMArrayAsVector<TVNAnchLink> - Anchor collection
 */

import { VNStreamable } from './VNObject.js';

/**
 * TVNAnchLink - Anchor link class
 * Represents a clickable hyperlink in HTML text
 */
export class VNAnchLink extends VNStreamable {
    constructor(options = {}) {
        super();
        
        // Link text and target
        this.text = options.text || '';
        this.href = options.href || '';
        this.target = options.target || '_self';
        this.title = options.title || '';
        
        // Visual bounds
        this.x = options.x ?? 0;
        this.y = options.y ?? 0;
        this.width = options.width ?? 0;
        this.height = options.height ?? 0;
        
        // Multiple rects for wrapped text
        this.rects = options.rects || [];
        
        // Style
        this.color = options.color || '#0066cc';
        this.hoverColor = options.hoverColor || '#0088ff';
        this.visitedColor = options.visitedColor || '#6633cc';
        this.underline = options.underline !== false;
        
        // State
        this.visited = false;
        this.hover = false;
        
        // Command to execute (VN engine specific)
        this.command = options.command || null;
        this.sceneTarget = options.sceneTarget ?? -1;
    }

    /**
     * Check if point is within link bounds
     */
    containsPoint(x, y) {
        // Check main rect
        if (x >= this.x && x <= this.x + this.width &&
            y >= this.y && y <= this.y + this.height) {
            return true;
        }
        
        // Check additional rects (for wrapped text)
        for (const rect of this.rects) {
            if (x >= rect.x && x <= rect.x + rect.width &&
                y >= rect.y && y <= rect.y + rect.height) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Add rect for wrapped text
     */
    addRect(x, y, width, height) {
        this.rects.push({ x, y, width, height });
    }

    /**
     * Get current color based on state
     */
    getCurrentColor() {
        if (this.hover) return this.hoverColor;
        if (this.visited) return this.visitedColor;
        return this.color;
    }

    /**
     * Execute link action
     */
    execute(engine) {
        this.visited = true;
        
        // Execute VN command
        if (this.command && engine) {
            engine.executeCommand(this.command);
            return;
        }
        
        // Go to scene
        if (this.sceneTarget >= 0 && engine) {
            engine.goToScene(this.sceneTarget);
            return;
        }
        
        // External link
        if (this.href) {
            if (this.target === '_blank') {
                window.open(this.href, '_blank');
            } else {
                window.location.href = this.href;
            }
        }
    }

    /**
     * Serialize
     */
    toJSON() {
        return {
            text: this.text,
            href: this.href,
            target: this.target,
            title: this.title,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            rects: this.rects,
            command: this.command,
            sceneTarget: this.sceneTarget,
            visited: this.visited
        };
    }

    static fromJSON(data) {
        return new VNAnchLink(data);
    }
}

/**
 * TVNAnchLinkArray - Collection of anchor links
 */
export class VNAnchLinkArray {
    constructor() {
        this._links = [];
    }

    get length() {
        return this._links.length;
    }

    /**
     * Add link
     */
    add(link) {
        this._links.push(link);
        return this._links.length - 1;
    }

    /**
     * Get link at index
     */
    get(index) {
        return this._links[index];
    }

    /**
     * Remove link
     */
    remove(index) {
        if (index >= 0 && index < this._links.length) {
            this._links.splice(index, 1);
        }
    }

    /**
     * Clear all links
     */
    clear() {
        this._links = [];
    }

    /**
     * Find link at point
     */
    findAtPoint(x, y) {
        for (const link of this._links) {
            if (link.containsPoint(x, y)) {
                return link;
            }
        }
        return null;
    }

    /**
     * Iterate links
     */
    forEach(callback) {
        this._links.forEach(callback);
    }

    /**
     * Get all links
     */
    getAll() {
        return [...this._links];
    }
}

/**
 * TPageContext - Page rendering context
 * Manages text layout and rendering state
 */
export class VNPageContext extends VNStreamable {
    constructor(options = {}) {
        super();
        
        // Rendering area
        this.x = options.x ?? 0;
        this.y = options.y ?? 0;
        this.width = options.width ?? 800;
        this.height = options.height ?? 600;
        
        // Current position
        this.cursorX = this.x;
        this.cursorY = this.y;
        
        // Line metrics
        this.lineHeight = options.lineHeight ?? 20;
        this.lineSpacing = options.lineSpacing ?? 1.2;
        this.paragraphSpacing = options.paragraphSpacing ?? 10;
        
        // Margins
        this.marginLeft = options.marginLeft ?? 10;
        this.marginRight = options.marginRight ?? 10;
        this.marginTop = options.marginTop ?? 10;
        this.marginBottom = options.marginBottom ?? 10;
        
        // Text style stack
        this._styleStack = [{
            fontFamily: options.fontFamily || 'Arial, sans-serif',
            fontSize: options.fontSize || 14,
            fontWeight: 'normal',
            fontStyle: 'normal',
            color: options.color || '#ffffff',
            backgroundColor: 'transparent',
            textDecoration: 'none',
            textAlign: options.textAlign || 'left'
        }];
        
        // Anchor links
        this.anchors = new VNAnchLinkArray();
        
        // Rendered elements
        this._elements = [];
        
        // Current link (during parsing)
        this._currentLink = null;
    }

    /**
     * Get current style
     */
    get currentStyle() {
        return this._styleStack[this._styleStack.length - 1];
    }

    /**
     * Push style
     */
    pushStyle(style) {
        this._styleStack.push({
            ...this.currentStyle,
            ...style
        });
    }

    /**
     * Pop style
     */
    popStyle() {
        if (this._styleStack.length > 1) {
            this._styleStack.pop();
        }
    }

    /**
     * Move to new line
     */
    newLine() {
        this.cursorX = this.x + this.marginLeft;
        this.cursorY += this.lineHeight * this.lineSpacing;
    }

    /**
     * Move to new paragraph
     */
    newParagraph() {
        this.cursorX = this.x + this.marginLeft;
        this.cursorY += this.lineHeight * this.lineSpacing + this.paragraphSpacing;
    }

    /**
     * Get available width
     */
    getAvailableWidth() {
        return this.width - this.marginLeft - this.marginRight;
    }

    /**
     * Get remaining width on current line
     */
    getRemainingWidth() {
        return (this.x + this.width - this.marginRight) - this.cursorX;
    }

    /**
     * Check if at end of page
     */
    isAtEndOfPage() {
        return this.cursorY + this.lineHeight > this.y + this.height - this.marginBottom;
    }

    /**
     * Reset to start
     */
    reset() {
        this.cursorX = this.x + this.marginLeft;
        this.cursorY = this.y + this.marginTop;
        this._elements = [];
        this.anchors.clear();
        this._styleStack = [this._styleStack[0]];
    }

    /**
     * Add text element
     */
    addElement(element) {
        this._elements.push(element);
    }

    /**
     * Get all elements
     */
    getElements() {
        return this._elements;
    }

    /**
     * Begin link
     */
    beginLink(href, options = {}) {
        this._currentLink = new VNAnchLink({
            href,
            x: this.cursorX,
            y: this.cursorY,
            ...options
        });
    }

    /**
     * End link
     */
    endLink() {
        if (this._currentLink) {
            this._currentLink.width = this.cursorX - this._currentLink.x;
            this._currentLink.height = this.lineHeight;
            this.anchors.add(this._currentLink);
            this._currentLink = null;
        }
    }
}

/**
 * TVNHtmlText - HTML-like text renderer
 * Parses and renders text with basic HTML tags
 */
export class VNHtmlText extends VNStreamable {
    constructor(options = {}) {
        super();
        
        this.text = options.text || '';
        this.x = options.x ?? 0;
        this.y = options.y ?? 0;
        this.width = options.width ?? 400;
        this.height = options.height ?? 300;
        
        // Page context for rendering
        this.context = new VNPageContext({
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            ...options
        });
        
        // Parsed result
        this._parsed = null;
        this._dirty = true;
    }

    /**
     * Set text
     */
    setText(text) {
        this.text = text;
        this._dirty = true;
    }

    /**
     * Parse HTML text
     */
    parse() {
        if (!this._dirty && this._parsed) {
            return this._parsed;
        }
        
        this.context.reset();
        this._parsed = [];
        
        // Simple HTML parser
        const tagRegex = /<\/?([a-zA-Z][a-zA-Z0-9]*)\s*([^>]*)>/g;
        let lastIndex = 0;
        let match;
        
        while ((match = tagRegex.exec(this.text)) !== null) {
            // Text before tag
            if (match.index > lastIndex) {
                const textContent = this.text.slice(lastIndex, match.index);
                this._addText(textContent);
            }
            
            const isClosing = match[0].startsWith('</');
            const tagName = match[1].toLowerCase();
            const attrs = this._parseAttributes(match[2]);
            
            this._handleTag(tagName, attrs, isClosing);
            
            lastIndex = tagRegex.lastIndex;
        }
        
        // Remaining text
        if (lastIndex < this.text.length) {
            this._addText(this.text.slice(lastIndex));
        }
        
        // End any open link
        this.context.endLink();
        
        this._dirty = false;
        return this._parsed;
    }

    /**
     * Parse tag attributes
     */
    _parseAttributes(attrString) {
        const attrs = {};
        const attrRegex = /([a-zA-Z-]+)\s*=\s*["']([^"']*)["']/g;
        let match;
        
        while ((match = attrRegex.exec(attrString)) !== null) {
            attrs[match[1].toLowerCase()] = match[2];
        }
        
        return attrs;
    }

    /**
     * Handle HTML tag
     */
    _handleTag(tagName, attrs, isClosing) {
        switch (tagName) {
            case 'b':
            case 'strong':
                if (isClosing) {
                    this.context.popStyle();
                } else {
                    this.context.pushStyle({ fontWeight: 'bold' });
                }
                break;
                
            case 'i':
            case 'em':
                if (isClosing) {
                    this.context.popStyle();
                } else {
                    this.context.pushStyle({ fontStyle: 'italic' });
                }
                break;
                
            case 'u':
                if (isClosing) {
                    this.context.popStyle();
                } else {
                    this.context.pushStyle({ textDecoration: 'underline' });
                }
                break;
                
            case 'font':
                if (isClosing) {
                    this.context.popStyle();
                } else {
                    const style = {};
                    if (attrs.face) style.fontFamily = attrs.face;
                    if (attrs.size) style.fontSize = parseInt(attrs.size) * 4;
                    if (attrs.color) style.color = attrs.color;
                    this.context.pushStyle(style);
                }
                break;
                
            case 'a':
                if (isClosing) {
                    this.context.endLink();
                    this.context.popStyle();
                } else {
                    this.context.pushStyle({ 
                        color: '#0066cc',
                        textDecoration: 'underline'
                    });
                    this.context.beginLink(attrs.href || '', {
                        target: attrs.target,
                        title: attrs.title,
                        command: attrs['data-command'],
                        sceneTarget: attrs['data-scene'] ? parseInt(attrs['data-scene']) : -1
                    });
                }
                break;
                
            case 'br':
                this.context.newLine();
                break;
                
            case 'p':
                if (isClosing) {
                    this.context.newParagraph();
                } else if (attrs.align) {
                    this.context.pushStyle({ textAlign: attrs.align });
                }
                break;
                
            case 'div':
                if (isClosing) {
                    this.context.newLine();
                    this.context.popStyle();
                } else {
                    const style = {};
                    if (attrs.align) style.textAlign = attrs.align;
                    this.context.pushStyle(style);
                }
                break;
                
            case 'center':
                if (isClosing) {
                    this.context.popStyle();
                } else {
                    this.context.pushStyle({ textAlign: 'center' });
                }
                break;
                
            case 'span':
                if (isClosing) {
                    this.context.popStyle();
                } else {
                    const style = {};
                    if (attrs.style) {
                        // Parse inline style
                        const styleRules = attrs.style.split(';');
                        for (const rule of styleRules) {
                            const [prop, value] = rule.split(':').map(s => s.trim());
                            if (prop === 'color') style.color = value;
                            if (prop === 'font-size') style.fontSize = parseInt(value);
                            if (prop === 'font-family') style.fontFamily = value;
                            if (prop === 'font-weight') style.fontWeight = value;
                            if (prop === 'font-style') style.fontStyle = value;
                        }
                    }
                    this.context.pushStyle(style);
                }
                break;
                
            case 'img':
                this._addImage(attrs);
                break;
                
            case 'hr':
                this._addHorizontalRule();
                break;
        }
    }

    /**
     * Add text content
     */
    _addText(text) {
        // Decode HTML entities
        text = this._decodeEntities(text);
        
        const style = this.context.currentStyle;
        
        this._parsed.push({
            type: 'text',
            text: text,
            x: this.context.cursorX,
            y: this.context.cursorY,
            style: { ...style }
        });
        
        this.context.addElement({
            type: 'text',
            text: text,
            x: this.context.cursorX,
            y: this.context.cursorY,
            style: { ...style }
        });
        
        // Update cursor (simplified - doesn't handle word wrap)
        // In real implementation, would measure text width
        this.context.cursorX += text.length * (style.fontSize * 0.6);
    }

    /**
     * Add image
     */
    _addImage(attrs) {
        const element = {
            type: 'image',
            src: attrs.src,
            alt: attrs.alt || '',
            x: this.context.cursorX,
            y: this.context.cursorY,
            width: attrs.width ? parseInt(attrs.width) : 100,
            height: attrs.height ? parseInt(attrs.height) : 100
        };
        
        this._parsed.push(element);
        this.context.addElement(element);
        
        // Move cursor past image
        this.context.cursorX += element.width;
    }

    /**
     * Add horizontal rule
     */
    _addHorizontalRule() {
        this.context.newLine();
        
        const element = {
            type: 'hr',
            x: this.context.x + this.context.marginLeft,
            y: this.context.cursorY,
            width: this.context.getAvailableWidth()
        };
        
        this._parsed.push(element);
        this.context.addElement(element);
        
        this.context.newLine();
    }

    /**
     * Decode HTML entities
     */
    _decodeEntities(text) {
        const entities = {
            '&lt;': '<',
            '&gt;': '>',
            '&amp;': '&',
            '&quot;': '"',
            '&apos;': "'",
            '&nbsp;': ' ',
            '&copy;': '©',
            '&reg;': '®',
            '&trade;': '™'
        };
        
        return text.replace(/&[a-z]+;/gi, match => entities[match] || match);
    }

    /**
     * Render to canvas
     */
    render(ctx) {
        const elements = this.parse();
        
        for (const element of elements) {
            switch (element.type) {
                case 'text':
                    this._renderText(ctx, element);
                    break;
                case 'image':
                    this._renderImage(ctx, element);
                    break;
                case 'hr':
                    this._renderHr(ctx, element);
                    break;
            }
        }
        
        // Render link underlines for hover state
        this.context.anchors.forEach(link => {
            if (link.hover) {
                ctx.strokeStyle = link.hoverColor;
                ctx.beginPath();
                ctx.moveTo(link.x, link.y + link.height - 2);
                ctx.lineTo(link.x + link.width, link.y + link.height - 2);
                ctx.stroke();
            }
        });
    }

    /**
     * Render text element
     */
    _renderText(ctx, element) {
        const style = element.style;
        
        ctx.font = `${style.fontStyle} ${style.fontWeight} ${style.fontSize}px ${style.fontFamily}`;
        ctx.fillStyle = style.color;
        ctx.textBaseline = 'top';
        
        ctx.fillText(element.text, element.x, element.y);
        
        if (style.textDecoration === 'underline') {
            ctx.strokeStyle = style.color;
            ctx.beginPath();
            const textWidth = ctx.measureText(element.text).width;
            ctx.moveTo(element.x, element.y + style.fontSize);
            ctx.lineTo(element.x + textWidth, element.y + style.fontSize);
            ctx.stroke();
        }
    }

    /**
     * Render image element
     */
    _renderImage(ctx, element) {
        // Would load and draw image
        // Placeholder rectangle for now
        ctx.strokeStyle = '#666';
        ctx.strokeRect(element.x, element.y, element.width, element.height);
    }

    /**
     * Render horizontal rule
     */
    _renderHr(ctx, element) {
        ctx.strokeStyle = '#666';
        ctx.beginPath();
        ctx.moveTo(element.x, element.y);
        ctx.lineTo(element.x + element.width, element.y);
        ctx.stroke();
    }

    /**
     * Handle mouse move (for link hover)
     */
    onMouseMove(x, y) {
        let needsRedraw = false;
        
        this.context.anchors.forEach(link => {
            const wasHover = link.hover;
            link.hover = link.containsPoint(x, y);
            if (wasHover !== link.hover) {
                needsRedraw = true;
            }
        });
        
        return needsRedraw;
    }

    /**
     * Handle click (for link activation)
     */
    onClick(x, y, engine) {
        const link = this.context.anchors.findAtPoint(x, y);
        if (link) {
            link.execute(engine);
            return true;
        }
        return false;
    }

    /**
     * Get cursor for position
     */
    getCursor(x, y) {
        const link = this.context.anchors.findAtPoint(x, y);
        return link ? 'pointer' : 'default';
    }
}

export default {
    VNAnchLink,
    VNAnchLinkArray,
    VNPageContext,
    VNHtmlText
};
