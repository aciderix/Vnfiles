/**
 * VNSysInfo - System information and utility classes
 * 
 * Port of system information functions from europeo.exe
 * Original source: sysinfo.cpp @ 0x004477dd
 * 
 * Provides system capabilities detection for VN engine
 */

/**
 * VNDisplayInfo - Display information
 */
export class VNDisplayInfo {
    constructor() {
        this.width = 0;
        this.height = 0;
        this.colorDepth = 0;
        this.refreshRate = 0;
        this.deviceName = '';
        
        this._detect();
    }
    
    _detect() {
        // Detect screen parameters
        this.width = window.screen.width;
        this.height = window.screen.height;
        this.colorDepth = window.screen.colorDepth;
        this.refreshRate = 60; // Default, can't reliably detect in web
        this.deviceName = 'WebCanvas';
        
        // Detect available width/height (excluding taskbar)
        this.availableWidth = window.screen.availWidth;
        this.availableHeight = window.screen.availHeight;
        
        // Detect pixel ratio for HiDPI displays
        this.pixelRatio = window.devicePixelRatio || 1;
    }
    
    /**
     * Check if resolution is supported
     * @param {number} width
     * @param {number} height
     * @returns {boolean}
     */
    supportsResolution(width, height) {
        return this.width >= width && this.height >= height;
    }
    
    /**
     * Get recommended resolution for VN
     * @returns {{width: number, height: number}}
     */
    getRecommendedResolution() {
        // Standard VN resolutions
        const resolutions = [
            { width: 800, height: 600 },
            { width: 640, height: 480 },
            { width: 1024, height: 768 },
            { width: 1280, height: 720 }
        ];
        
        for (const res of resolutions) {
            if (this.supportsResolution(res.width, res.height)) {
                return res;
            }
        }
        
        return { width: 640, height: 480 };
    }
}

/**
 * VNMemoryInfo - Memory information
 * Port of memory detection from original engine
 */
export class VNMemoryInfo {
    constructor() {
        this.totalMemory = 0;
        this.availableMemory = 0;
        
        this._detect();
    }
    
    _detect() {
        // Use performance.memory if available (Chrome only)
        if (performance.memory) {
            this.totalMemory = performance.memory.jsHeapSizeLimit;
            this.availableMemory = performance.memory.jsHeapSizeLimit - performance.memory.usedJSHeapSize;
        } else {
            // Estimate based on typical browser limits
            this.totalMemory = 512 * 1024 * 1024; // 512MB
            this.availableMemory = 256 * 1024 * 1024; // 256MB
        }
    }
    
    /**
     * Get memory usage percentage
     * @returns {number}
     */
    getUsagePercent() {
        if (performance.memory) {
            return (performance.memory.usedJSHeapSize / performance.memory.jsHeapSizeLimit) * 100;
        }
        return 50; // Unknown
    }
    
    /**
     * Check if sufficient memory for operation
     * @param {number} requiredBytes
     * @returns {boolean}
     */
    hasMemory(requiredBytes) {
        return this.availableMemory >= requiredBytes;
    }
}

/**
 * VNAudioInfo - Audio capabilities information
 */
export class VNAudioInfo {
    constructor() {
        this.supported = false;
        this.formats = [];
        this.channels = 0;
        this.sampleRate = 0;
        
        this._detect();
    }
    
    _detect() {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                this.supported = true;
                const ctx = new AudioContext();
                this.channels = ctx.destination.maxChannelCount;
                this.sampleRate = ctx.sampleRate;
                ctx.close();
            }
            
            // Detect supported audio formats
            const audio = document.createElement('audio');
            const formats = {
                'wav': 'audio/wav',
                'mp3': 'audio/mpeg',
                'ogg': 'audio/ogg',
                'aac': 'audio/aac',
                'mid': 'audio/midi',
                'webm': 'audio/webm'
            };
            
            for (const [ext, mime] of Object.entries(formats)) {
                if (audio.canPlayType(mime)) {
                    this.formats.push(ext);
                }
            }
        } catch (e) {
            this.supported = false;
        }
    }
    
    /**
     * Check if audio format is supported
     * @param {string} format
     * @returns {boolean}
     */
    supportsFormat(format) {
        return this.formats.includes(format.toLowerCase());
    }
}

/**
 * VNVideoInfo - Video capabilities information
 */
export class VNVideoInfo {
    constructor() {
        this.supported = false;
        this.formats = [];
        this.maxResolution = { width: 0, height: 0 };
        
        this._detect();
    }
    
    _detect() {
        const video = document.createElement('video');
        this.supported = !!video.canPlayType;
        
        if (this.supported) {
            // Detect supported video formats
            const formats = {
                'avi': 'video/x-msvideo',
                'mp4': 'video/mp4',
                'webm': 'video/webm',
                'ogg': 'video/ogg',
                'mov': 'video/quicktime',
                'mkv': 'video/x-matroska'
            };
            
            for (const [ext, mime] of Object.entries(formats)) {
                if (video.canPlayType(mime)) {
                    this.formats.push(ext);
                }
            }
            
            // Assume modern browsers can handle HD
            this.maxResolution = { width: 1920, height: 1080 };
        }
    }
    
    /**
     * Check if video format is supported
     * @param {string} format
     * @returns {boolean}
     */
    supportsFormat(format) {
        return this.formats.includes(format.toLowerCase());
    }
}

/**
 * VNDirectDrawInfo - DirectDraw emulation capabilities
 * Port of DirectDraw detection from original engine
 */
export class VNDirectDrawInfo {
    constructor() {
        this.enabled = false;
        this.hardwareAccelerated = false;
        this.videoMemory = 0;
        
        this._detect();
    }
    
    _detect() {
        // Check for WebGL (hardware acceleration)
        try {
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            
            if (gl) {
                this.enabled = true;
                this.hardwareAccelerated = true;
                
                // Estimate video memory
                const ext = gl.getExtension('WEBGL_debug_renderer_info');
                if (ext) {
                    const renderer = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL);
                    // Try to estimate VRAM from renderer string
                    this.videoMemory = this._estimateVRAM(renderer);
                } else {
                    this.videoMemory = 128 * 1024 * 1024; // 128MB default
                }
            }
        } catch (e) {
            this.enabled = false;
        }
    }
    
    _estimateVRAM(renderer) {
        // Rough estimation based on GPU type
        if (/GTX|RTX|Radeon RX/i.test(renderer)) {
            return 4 * 1024 * 1024 * 1024; // 4GB
        } else if (/Intel|HD Graphics/i.test(renderer)) {
            return 512 * 1024 * 1024; // 512MB
        }
        return 256 * 1024 * 1024; // 256MB default
    }
}

/**
 * VNMCIInfo - MCI (Media Control Interface) emulation capabilities
 */
export class VNMCIInfo {
    constructor() {
        this.waveAudio = false;
        this.midiAudio = false;
        this.cdAudio = false;
        this.aviVideo = false;
        this.sequencer = false;
        
        this._detect();
    }
    
    _detect() {
        // Web Audio API for wave/audio
        this.waveAudio = !!(window.AudioContext || window.webkitAudioContext);
        
        // MIDI support via Web MIDI API
        this.midiAudio = !!navigator.requestMIDIAccess;
        
        // CD Audio not supported in web
        this.cdAudio = false;
        
        // Video support
        const video = document.createElement('video');
        this.aviVideo = !!video.canPlayType;
        
        // MIDI sequencer
        this.sequencer = this.midiAudio;
    }
    
    /**
     * Get MCI device list
     * @returns {string[]}
     */
    getDevices() {
        const devices = [];
        if (this.waveAudio) devices.push('waveaudio');
        if (this.midiAudio) devices.push('sequencer');
        if (this.aviVideo) devices.push('avivideo');
        if (this.cdAudio) devices.push('cdaudio');
        return devices;
    }
}

/**
 * VNSysInfo - Complete system information
 * Main class combining all system info
 */
export class VNSysInfo {
    constructor() {
        this.display = new VNDisplayInfo();
        this.memory = new VNMemoryInfo();
        this.audio = new VNAudioInfo();
        this.video = new VNVideoInfo();
        this.directDraw = new VNDirectDrawInfo();
        this.mci = new VNMCIInfo();
        
        // Operating system info
        this.osName = this._detectOS();
        this.browserName = this._detectBrowser();
        this.isMobile = this._detectMobile();
        
        // VN Engine specific capabilities
        this.capabilities = this._detectCapabilities();
    }
    
    _detectOS() {
        const ua = navigator.userAgent;
        if (ua.includes('Windows')) return 'Windows';
        if (ua.includes('Mac')) return 'MacOS';
        if (ua.includes('Linux')) return 'Linux';
        if (ua.includes('Android')) return 'Android';
        if (ua.includes('iOS') || ua.includes('iPhone') || ua.includes('iPad')) return 'iOS';
        return 'Unknown';
    }
    
    _detectBrowser() {
        const ua = navigator.userAgent;
        if (ua.includes('Chrome')) return 'Chrome';
        if (ua.includes('Firefox')) return 'Firefox';
        if (ua.includes('Safari')) return 'Safari';
        if (ua.includes('Edge')) return 'Edge';
        if (ua.includes('Opera')) return 'Opera';
        return 'Unknown';
    }
    
    _detectMobile() {
        return /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }
    
    _detectCapabilities() {
        return {
            canvas2d: !!document.createElement('canvas').getContext,
            webgl: this.directDraw.enabled,
            webAudio: this.audio.supported,
            webMidi: this.mci.midiAudio,
            fullscreen: !!(document.fullscreenEnabled || document.webkitFullscreenEnabled),
            localStorage: !!window.localStorage,
            sessionStorage: !!window.sessionStorage,
            indexedDB: !!window.indexedDB,
            workers: !!window.Worker,
            touch: 'ontouchstart' in window,
            gamepad: !!navigator.getGamepads
        };
    }
    
    /**
     * Check if VN engine requirements are met
     * @returns {{met: boolean, missing: string[]}}
     */
    checkRequirements() {
        const missing = [];
        
        if (!this.capabilities.canvas2d) {
            missing.push('Canvas 2D');
        }
        if (!this.audio.supported) {
            missing.push('Web Audio');
        }
        if (!this.video.supported) {
            missing.push('HTML5 Video');
        }
        if (!this.capabilities.localStorage) {
            missing.push('Local Storage');
        }
        
        return {
            met: missing.length === 0,
            missing: missing
        };
    }
    
    /**
     * Get summary string
     * @returns {string}
     */
    getSummary() {
        return `
System: ${this.osName} / ${this.browserName}
Display: ${this.display.width}x${this.display.height} @ ${this.display.colorDepth}bit
Memory: ${Math.round(this.memory.totalMemory / 1024 / 1024)}MB
Audio: ${this.audio.supported ? 'Yes' : 'No'} (${this.audio.formats.join(', ')})
Video: ${this.video.supported ? 'Yes' : 'No'} (${this.video.formats.join(', ')})
DirectDraw: ${this.directDraw.enabled ? 'Emulated via WebGL' : 'No'}
Mobile: ${this.isMobile ? 'Yes' : 'No'}
        `.trim();
    }
}

// Singleton instance
let _sysInfo = null;

/**
 * Get system info singleton
 * @returns {VNSysInfo}
 */
export function getSysInfo() {
    if (!_sysInfo) {
        _sysInfo = new VNSysInfo();
    }
    return _sysInfo;
}

/**
 * Tool functions - Utility functions from toolsfct.cpp
 * Port of toolsfct.cpp @ 0x0043a8c3
 */
export class VNToolsFunctions {
    /**
     * Clamp value between min and max
     * @param {number} value
     * @param {number} min
     * @param {number} max
     * @returns {number}
     */
    static clamp(value, min, max) {
        return Math.max(min, Math.min(max, value));
    }
    
    /**
     * Linear interpolation
     * @param {number} a
     * @param {number} b
     * @param {number} t
     * @returns {number}
     */
    static lerp(a, b, t) {
        return a + (b - a) * t;
    }
    
    /**
     * Check if point is inside rectangle
     * @param {number} x
     * @param {number} y
     * @param {Object} rect - {x, y, width, height}
     * @returns {boolean}
     */
    static pointInRect(x, y, rect) {
        return x >= rect.x && x < rect.x + rect.width &&
               y >= rect.y && y < rect.y + rect.height;
    }
    
    /**
     * Check if rectangles intersect
     * @param {Object} r1
     * @param {Object} r2
     * @returns {boolean}
     */
    static rectsIntersect(r1, r2) {
        return r1.x < r2.x + r2.width &&
               r1.x + r1.width > r2.x &&
               r1.y < r2.y + r2.height &&
               r1.y + r1.height > r2.y;
    }
    
    /**
     * Get intersection of two rectangles
     * @param {Object} r1
     * @param {Object} r2
     * @returns {Object|null}
     */
    static rectIntersection(r1, r2) {
        const x = Math.max(r1.x, r2.x);
        const y = Math.max(r1.y, r2.y);
        const width = Math.min(r1.x + r1.width, r2.x + r2.width) - x;
        const height = Math.min(r1.y + r1.height, r2.y + r2.height) - y;
        
        if (width <= 0 || height <= 0) {
            return null;
        }
        
        return { x, y, width, height };
    }
    
    /**
     * Scale rectangle to fit inside another
     * @param {Object} inner
     * @param {Object} outer
     * @param {boolean} maintainAspect
     * @returns {Object}
     */
    static fitRect(inner, outer, maintainAspect = true) {
        if (!maintainAspect) {
            return { ...outer };
        }
        
        const innerRatio = inner.width / inner.height;
        const outerRatio = outer.width / outer.height;
        
        let width, height;
        if (innerRatio > outerRatio) {
            width = outer.width;
            height = outer.width / innerRatio;
        } else {
            height = outer.height;
            width = outer.height * innerRatio;
        }
        
        return {
            x: outer.x + (outer.width - width) / 2,
            y: outer.y + (outer.height - height) / 2,
            width: width,
            height: height
        };
    }
    
    /**
     * Generate unique ID
     * @returns {string}
     */
    static generateId() {
        return 'vn_' + Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    
    /**
     * Deep clone object
     * @param {*} obj
     * @returns {*}
     */
    static deepClone(obj) {
        if (obj === null || typeof obj !== 'object') {
            return obj;
        }
        
        if (Array.isArray(obj)) {
            return obj.map(item => this.deepClone(item));
        }
        
        const clone = {};
        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                clone[key] = this.deepClone(obj[key]);
            }
        }
        return clone;
    }
    
    /**
     * Delay execution
     * @param {number} ms
     * @returns {Promise}
     */
    static delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    /**
     * Format time in MM:SS format
     * @param {number} seconds
     * @returns {string}
     */
    static formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
}

export default VNSysInfo;
