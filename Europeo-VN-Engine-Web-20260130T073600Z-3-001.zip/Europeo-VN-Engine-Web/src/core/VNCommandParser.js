/**
 * VNCommandParser - Exact port of command handler from europeo.exe
 * 
 * Original function: fcn.0040b990 @ 0x0040b990 (7328 bytes)
 * Switch table at: 0x40ba69 (49 cases)
 * 
 * Command table extracted from: 0x0043f760
 * 
 * Each case corresponds to a specific VN command:
 * Case 0:  quit         Case 25: invalidate
 * Case 1:  about        Case 26: defcursor
 * Case 2:  prefs        Case 27: addbmp
 * Case 3:  prev         Case 28: delbmp
 * Case 4:  next         Case 29: showbmp
 * Case 5:  zoom         Case 30: hidebmp
 * Case 6:  scene        Case 31: runprj
 * Case 7:  hotspot      Case 32: update
 * Case 8:  tiptext      Case 33: rundll
 * Case 9:  playavi      Case 34: msgbox
 * Case 10: playbmp      Case 35: playcmd
 * Case 11: playwav      Case 36: closewav
 * Case 12: playmid      Case 37: closedll
 * Case 13: playhtml     Case 38: playtext
 * Case 14: zoomin       Case 39: font
 * Case 15: zoomout      Case 40: rem
 * Case 16: pause        Case 41: addtext
 * Case 17: exec         Case 42: delobj
 * Case 18: explore      Case 43: showobj
 * Case 19: playcda      Case 44: hideobj
 * Case 20: playseq      Case 45: load
 * Case 21: if           Case 46: save
 * Case 22: set_var      Case 47: closeavi
 * Case 23: inc_var      Case 48: closemid
 * Case 24: dec_var
 */

import { vnVariables } from './VNVariable.js';

/**
 * Command IDs (from switch table analysis)
 */
const CMD = {
    QUIT: 0,
    ABOUT: 1,
    PREFS: 2,
    PREV: 3,
    NEXT: 4,
    ZOOM: 5,
    SCENE: 6,
    HOTSPOT: 7,
    TIPTEXT: 8,
    PLAYAVI: 9,
    PLAYBMP: 10,
    PLAYWAV: 11,
    PLAYMID: 12,
    PLAYHTML: 13,
    ZOOMIN: 14,
    ZOOMOUT: 15,
    PAUSE: 16,
    EXEC: 17,
    EXPLORE: 18,
    PLAYCDA: 19,
    PLAYSEQ: 20,
    IF: 21,
    SET_VAR: 22,
    INC_VAR: 23,
    DEC_VAR: 24,
    INVALIDATE: 25,
    DEFCURSOR: 26,
    ADDBMP: 27,
    DELBMP: 28,
    SHOWBMP: 29,
    HIDEBMP: 30,
    RUNPRJ: 31,
    UPDATE: 32,
    RUNDLL: 33,
    MSGBOX: 34,
    PLAYCMD: 35,
    CLOSEWAV: 36,
    CLOSEDLL: 37,
    PLAYTEXT: 38,
    FONT: 39,
    REM: 40,
    ADDTEXT: 41,
    DELOBJ: 42,
    SHOWOBJ: 43,
    HIDEOBJ: 44,
    LOAD: 45,
    SAVE: 46,
    CLOSEAVI: 47,
    CLOSEMID: 48
};

/**
 * Command name to ID mapping (from 0x0043f760)
 */
const COMMAND_MAP = {
    'quit': CMD.QUIT,
    'about': CMD.ABOUT,
    'prefs': CMD.PREFS,
    'prev': CMD.PREV,
    'next': CMD.NEXT,
    'zoom': CMD.ZOOM,
    'scene': CMD.SCENE,
    'hotspot': CMD.HOTSPOT,
    'tiptext': CMD.TIPTEXT,
    'playavi': CMD.PLAYAVI,
    'playbmp': CMD.PLAYBMP,
    'playwav': CMD.PLAYWAV,
    'playmid': CMD.PLAYMID,
    'playhtml': CMD.PLAYHTML,
    'zoomin': CMD.ZOOMIN,
    'zoomout': CMD.ZOOMOUT,
    'pause': CMD.PAUSE,
    'exec': CMD.EXEC,
    'explore': CMD.EXPLORE,
    'playcda': CMD.PLAYCDA,
    'playseq': CMD.PLAYSEQ,
    'if': CMD.IF,
    'set_var': CMD.SET_VAR,
    'inc_var': CMD.INC_VAR,
    'dec_var': CMD.DEC_VAR,
    'invalidate': CMD.INVALIDATE,
    'defcursor': CMD.DEFCURSOR,
    'addbmp': CMD.ADDBMP,
    'delbmp': CMD.DELBMP,
    'showbmp': CMD.SHOWBMP,
    'hidebmp': CMD.HIDEBMP,
    'runprj': CMD.RUNPRJ,
    'update': CMD.UPDATE,
    'rundll': CMD.RUNDLL,
    'msgbox': CMD.MSGBOX,
    'playcmd': CMD.PLAYCMD,
    'closewav': CMD.CLOSEWAV,
    'closedll': CMD.CLOSEDLL,
    'playtext': CMD.PLAYTEXT,
    'font': CMD.FONT,
    'rem': CMD.REM,
    'addtext': CMD.ADDTEXT,
    'delobj': CMD.DELOBJ,
    'showobj': CMD.SHOWOBJ,
    'hideobj': CMD.HIDEOBJ,
    'load': CMD.LOAD,
    'save': CMD.SAVE,
    'closeavi': CMD.CLOSEAVI,
    'closemid': CMD.CLOSEMID
};

/**
 * Window message constants (from analysis)
 * WM_COMMAND = 0x111 (273)
 */
const WM_COMMAND = 0x111;
const WM_VN_COMMAND = 'wm_vncommand';

class VNCommandParser {
    constructor(engine) {
        this.engine = engine;
        this._ifStack = [];  // Stack for nested if statements
        this._callStack = []; // Stack for gosub/return
        this._running = false;
        this._paused = false;
    }

    /**
     * Parse command string and return command structure
     * 
     * Original format strings from 0x0043f910:
     * "%li", "%u", "%i %i %i %i", "\"%s\" %u", etc.
     */
    parse(commandLine) {
        if (!commandLine || commandLine.trim().length === 0) {
            return null;
        }
        
        const line = commandLine.trim();
        
        // Skip comments (rem command)
        if (line.toLowerCase().startsWith('rem ') || line.startsWith('//') || line.startsWith('#')) {
            return { cmd: CMD.REM, args: line };
        }
        
        // Parse command and arguments
        const match = line.match(/^(\w+)\s*(.*)?$/);
        if (!match) {
            return null;
        }
        
        const cmdName = match[1].toLowerCase();
        const argsStr = match[2] || '';
        
        const cmdId = COMMAND_MAP[cmdName];
        if (cmdId === undefined) {
            console.warn(`Unknown command: ${cmdName}`);
            return null;
        }
        
        return {
            cmd: cmdId,
            name: cmdName,
            args: this._parseArgs(argsStr),
            raw: argsStr
        };
    }

    /**
     * Parse arguments string
     * Handles quoted strings, numbers, and key=value pairs
     */
    _parseArgs(argsStr) {
        const args = [];
        const params = {};
        
        if (!argsStr || argsStr.length === 0) {
            return { list: args, params };
        }
        
        // Regex to match quoted strings, numbers, or words
        const regex = /\"([^\"]*)\"|(\S+)/g;
        let match;
        
        while ((match = regex.exec(argsStr)) !== null) {
            const value = match[1] !== undefined ? match[1] : match[2];
            
            // Check for key=value
            if (value.includes('=')) {
                const [key, val] = value.split('=');
                params[key.toLowerCase()] = this._parseValue(val);
            } else {
                args.push(this._parseValue(value));
            }
        }
        
        return { list: args, params };
    }

    /**
     * Parse a single value - number, hex, or string
     */
    _parseValue(value) {
        if (value === undefined || value === null) {
            return value;
        }
        
        // Check for hex color (#RRGGBB)
        if (value.startsWith('#')) {
            return parseInt(value.substring(1), 16);
        }
        
        // Check for number
        const num = parseFloat(value);
        if (!isNaN(num) && value.match(/^-?\d+\.?\d*$/)) {
            return num;
        }
        
        return value;
    }

    /**
     * Execute command - Main switch statement
     * Port of fcn.0040b990 (49 cases)
     * 
     * Original assembly structure:
     *   mov edi, [arg_ch]     ; window handle
     *   mov esi, [arg_8h]     ; command structure
     *   mov eax, [esi + 8]    ; command ID
     *   cmp eax, 0x30         ; max case (48)
     *   ja default
     *   jmp [eax*4 + 0x40ba69] ; switch table
     */
    async execute(command) {
        if (!command) {
            return false;
        }
        
        const { cmd, args, raw } = command;
        
        // Main switch statement (mirrors original assembly)
        switch (cmd) {
            // Case 0: quit
            // Original: PostMessageA(hwnd, WM_COMMAND, 0xa4, 0)
            case CMD.QUIT:
                return this._cmdQuit();
            
            // Case 1: about
            // Original: PostMessageA(hwnd, WM_COMMAND, 0x4e29, 0)
            case CMD.ABOUT:
                return this._cmdAbout();
            
            // Case 2: prefs
            // Original: PostMessageA(hwnd, WM_COMMAND, 0x9d, 0)
            case CMD.PREFS:
                return this._cmdPrefs();
            
            // Case 3: prev
            // Original: PostMessageA(hwnd, WM_COMMAND, 0x9f, 0)
            case CMD.PREV:
                return this._cmdPrev();
            
            // Case 4: next
            // Original: PostMessageA(hwnd, WM_COMMAND, 0xa0, 0)
            case CMD.NEXT:
                return this._cmdNext();
            
            // Case 5: zoom
            case CMD.ZOOM:
                return this._cmdZoom(args);
            
            // Case 6: scene
            // Original: Complex scene loading at 0x40bd2b
            case CMD.SCENE:
                return this._cmdScene(args, raw);
            
            // Case 7: hotspot
            case CMD.HOTSPOT:
                return this._cmdHotspot(args, raw);
            
            // Case 8: tiptext
            case CMD.TIPTEXT:
                return this._cmdTiptext(args, raw);
            
            // Case 9: playavi
            case CMD.PLAYAVI:
                return this._cmdPlayavi(args, raw);
            
            // Case 10: playbmp
            case CMD.PLAYBMP:
                return this._cmdPlaybmp(args, raw);
            
            // Case 11: playwav
            case CMD.PLAYWAV:
                return this._cmdPlaywav(args, raw);
            
            // Case 12: playmid
            case CMD.PLAYMID:
                return this._cmdPlaymid(args, raw);
            
            // Case 13: playhtml
            case CMD.PLAYHTML:
                return this._cmdPlayhtml(args, raw);
            
            // Case 14: zoomin
            case CMD.ZOOMIN:
                return this._cmdZoomin(args);
            
            // Case 15: zoomout
            case CMD.ZOOMOUT:
                return this._cmdZoomout(args);
            
            // Case 16: pause
            // Original: calls Sleep(ms)
            case CMD.PAUSE:
                return this._cmdPause(args);
            
            // Case 17: exec
            // Original: ShellExecuteA
            case CMD.EXEC:
                return this._cmdExec(args, raw);
            
            // Case 18: explore
            case CMD.EXPLORE:
                return this._cmdExplore(args, raw);
            
            // Case 19: playcda
            case CMD.PLAYCDA:
                return this._cmdPlaycda(args, raw);
            
            // Case 20: playseq
            case CMD.PLAYSEQ:
                return this._cmdPlayseq(args, raw);
            
            // Case 21: if
            case CMD.IF:
                return this._cmdIf(args, raw);
            
            // Case 22: set_var
            case CMD.SET_VAR:
                return this._cmdSetVar(args, raw);
            
            // Case 23: inc_var
            case CMD.INC_VAR:
                return this._cmdIncVar(args, raw);
            
            // Case 24: dec_var
            case CMD.DEC_VAR:
                return this._cmdDecVar(args, raw);
            
            // Case 25: invalidate
            // Original: InvalidateRect(hwnd, NULL, TRUE)
            case CMD.INVALIDATE:
                return this._cmdInvalidate();
            
            // Case 26: defcursor
            case CMD.DEFCURSOR:
                return this._cmdDefcursor(args, raw);
            
            // Case 27: addbmp
            case CMD.ADDBMP:
                return this._cmdAddbmp(args, raw);
            
            // Case 28: delbmp
            case CMD.DELBMP:
                return this._cmdDelbmp(args, raw);
            
            // Case 29: showbmp
            case CMD.SHOWBMP:
                return this._cmdShowbmp(args, raw);
            
            // Case 30: hidebmp
            case CMD.HIDEBMP:
                return this._cmdHidebmp(args, raw);
            
            // Case 31: runprj
            case CMD.RUNPRJ:
                return this._cmdRunprj(args, raw);
            
            // Case 32: update
            case CMD.UPDATE:
                return this._cmdUpdate();
            
            // Case 33: rundll
            case CMD.RUNDLL:
                return this._cmdRundll(args, raw);
            
            // Case 34: msgbox
            // Original: MessageBoxExA
            case CMD.MSGBOX:
                return this._cmdMsgbox(args, raw);
            
            // Case 35: playcmd
            case CMD.PLAYCMD:
                return this._cmdPlaycmd(args, raw);
            
            // Case 36: closewav
            case CMD.CLOSEWAV:
                return this._cmdClosewav();
            
            // Case 37: closedll
            case CMD.CLOSEDLL:
                return this._cmdClosedll();
            
            // Case 38: playtext
            case CMD.PLAYTEXT:
                return this._cmdPlaytext(args, raw);
            
            // Case 39: font
            case CMD.FONT:
                return this._cmdFont(args, raw);
            
            // Case 40: rem (comment - no action)
            case CMD.REM:
                return true;
            
            // Case 41: addtext
            case CMD.ADDTEXT:
                return this._cmdAddtext(args, raw);
            
            // Case 42: delobj
            case CMD.DELOBJ:
                return this._cmdDelobj(args, raw);
            
            // Case 43: showobj
            case CMD.SHOWOBJ:
                return this._cmdShowobj(args, raw);
            
            // Case 44: hideobj
            case CMD.HIDEOBJ:
                return this._cmdHideobj(args, raw);
            
            // Case 45: load
            case CMD.LOAD:
                return this._cmdLoad(args, raw);
            
            // Case 46: save
            case CMD.SAVE:
                return this._cmdSave(args, raw);
            
            // Case 47: closeavi
            case CMD.CLOSEAVI:
                return this._cmdCloseavi();
            
            // Case 48: closemid
            case CMD.CLOSEMID:
                return this._cmdClosemid();
            
            default:
                console.warn(`Unhandled command: ${cmd}`);
                return false;
        }
    }

    /**
     * Execute a script (array of commands)
     */
    async executeScript(script) {
        if (!script || !Array.isArray(script)) {
            return;
        }
        
        this._running = true;
        
        for (let i = 0; i < script.length && this._running; i++) {
            if (this._paused) {
                await this._waitForResume();
            }
            
            const line = script[i];
            const command = this.parse(line);
            
            if (command) {
                await this.execute(command);
            }
        }
        
        this._running = false;
    }

    /**
     * Wait for resume from pause
     */
    async _waitForResume() {
        return new Promise(resolve => {
            const check = () => {
                if (!this._paused) {
                    resolve();
                } else {
                    setTimeout(check, 100);
                }
            };
            check();
        });
    }

    // ========== Command Implementations ==========

    // Case 0: quit
    _cmdQuit() {
        if (this.engine.onQuit) {
            this.engine.onQuit();
        }
        return true;
    }

    // Case 1: about
    _cmdAbout() {
        if (this.engine.onAbout) {
            this.engine.onAbout();
        }
        return true;
    }

    // Case 2: prefs
    _cmdPrefs() {
        if (this.engine.onPrefs) {
            this.engine.onPrefs();
        }
        return true;
    }

    // Case 3: prev
    _cmdPrev() {
        return this.engine.prevScene();
    }

    // Case 4: next
    _cmdNext() {
        return this.engine.nextScene();
    }

    // Case 5: zoom
    _cmdZoom(args) {
        return this.engine.toggleZoom();
    }

    // Case 6: scene
    // Original at 0x40bd2b checks for +/- prefix for relative navigation
    async _cmdScene(args, raw) {
        const { list } = args;
        
        if (list.length === 0) {
            return false;
        }
        
        const sceneArg = String(list[0]);
        
        // Check for relative scene navigation (+n or -n)
        if (sceneArg.startsWith('+') || sceneArg.startsWith('-')) {
            const offset = parseInt(sceneArg, 10);
            return this.engine.loadSceneRelative(offset);
        }
        
        // Load scene by name or index
        if (typeof list[0] === 'number') {
            return this.engine.loadSceneByIndex(list[0]);
        }
        
        return this.engine.loadScene(list[0]);
    }

    // Case 7: hotspot
    // Format: hotspot id x y w h [cursor] [onclick] [onfocus]
    _cmdHotspot(args, raw) {
        const { list, params } = args;
        
        if (list.length < 5) {
            return false;
        }
        
        const hotspot = {
            id: list[0],
            x: list[1],
            y: list[2],
            width: list[3],
            height: list[4],
            cursor: params.cursor || list[5],
            onclick: params.onclick || list[6],
            onfocus: params.onfocus || list[7]
        };
        
        return this.engine.addHotspot(hotspot);
    }

    // Case 8: tiptext
    _cmdTiptext(args, raw) {
        const { list } = args;
        if (list.length >= 2) {
            return this.engine.setTiptext(list[0], list[1]);
        }
        return false;
    }

    // Case 9: playavi
    async _cmdPlayavi(args, raw) {
        const { list, params } = args;
        if (list.length === 0) return false;
        
        const options = {
            loop: params.loop !== undefined,
            x: params.x,
            y: params.y,
            width: params.width || params.w,
            height: params.height || params.h
        };
        
        return this.engine.playVideo(list[0], options);
    }

    // Case 10: playbmp
    async _cmdPlaybmp(args, raw) {
        const { list, params } = args;
        if (list.length === 0) return false;
        
        return this.engine.setBackground(list[0], params);
    }

    // Case 11: playwav
    async _cmdPlaywav(args, raw) {
        const { list, params } = args;
        if (list.length === 0) return false;
        
        const options = {
            loop: params.loop !== undefined
        };
        
        return this.engine.playSound(list[0], options);
    }

    // Case 12: playmid
    async _cmdPlaymid(args, raw) {
        const { list, params } = args;
        if (list.length === 0) return false;
        
        const options = {
            loop: params.loop !== undefined || true // MIDI usually loops
        };
        
        return this.engine.playMusic(list[0], options);
    }

    // Case 13: playhtml
    _cmdPlayhtml(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        return this.engine.showHtml(list[0]);
    }

    // Case 14: zoomin
    _cmdZoomin(args) {
        return this.engine.zoomIn();
    }

    // Case 15: zoomout
    _cmdZoomout(args) {
        return this.engine.zoomOut();
    }

    // Case 16: pause
    // Original: Sleep(ms)
    async _cmdPause(args) {
        const { list } = args;
        const ms = list[0] || 1000;
        
        await new Promise(resolve => setTimeout(resolve, ms));
        return true;
    }

    // Case 17: exec
    // Original: ShellExecuteA(NULL, "open", path, args, NULL, SW_SHOW)
    _cmdExec(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        // In web context, we can't execute arbitrary programs
        // But we can open URLs
        if (list[0].startsWith('http')) {
            window.open(list[0], '_blank');
            return true;
        }
        
        console.warn('exec command not supported in web context:', list[0]);
        return false;
    }

    // Case 18: explore
    _cmdExplore(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        window.open(list[0], '_blank');
        return true;
    }

    // Case 19: playcda
    // CD Audio - not applicable in web context
    _cmdPlaycda(args, raw) {
        console.warn('playcda not supported in web context');
        return false;
    }

    // Case 20: playseq
    async _cmdPlayseq(args, raw) {
        const { list } = args;
        for (const item of list) {
            await this.engine.playSequenceItem(item);
        }
        return true;
    }

    // Case 21: if
    // Format: if condition then command [else command]
    async _cmdIf(args, raw) {
        // Parse: if var=value then cmd1 [else cmd2]
        const thenMatch = raw.match(/(.+?)\s+then\s+(.+?)(?:\s+else\s+(.+))?$/i);
        
        if (!thenMatch) {
            return false;
        }
        
        const condition = thenMatch[1].trim();
        const thenCmd = thenMatch[2].trim();
        const elseCmd = thenMatch[3] ? thenMatch[3].trim() : null;
        
        // Evaluate condition
        const result = vnVariables.evaluate(condition);
        
        if (result) {
            const cmd = this.parse(thenCmd);
            if (cmd) {
                await this.execute(cmd);
            }
        } else if (elseCmd) {
            const cmd = this.parse(elseCmd);
            if (cmd) {
                await this.execute(cmd);
            }
        }
        
        return true;
    }

    // Case 22: set_var
    _cmdSetVar(args, raw) {
        return vnVariables.parseSetVar(raw) !== null;
    }

    // Case 23: inc_var
    _cmdIncVar(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        const amount = list[1] !== undefined ? list[1] : 1;
        vnVariables.increment(list[0], amount);
        return true;
    }

    // Case 24: dec_var
    _cmdDecVar(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        const amount = list[1] !== undefined ? list[1] : 1;
        vnVariables.decrement(list[0], amount);
        return true;
    }

    // Case 25: invalidate
    // Original: InvalidateRect(hwnd, NULL, TRUE)
    _cmdInvalidate() {
        return this.engine.invalidate();
    }

    // Case 26: defcursor
    _cmdDefcursor(args, raw) {
        const { list } = args;
        return this.engine.setDefaultCursor(list[0]);
    }

    // Case 27: addbmp
    // Format: addbmp "name" "file" x y [w h] [layer]
    async _cmdAddbmp(args, raw) {
        const { list, params } = args;
        
        if (list.length < 4) return false;
        
        const obj = {
            name: list[0],
            file: list[1],
            x: list[2],
            y: list[3],
            width: params.width || list[4],
            height: params.height || list[5],
            layer: params.layer || list[6] || 0
        };
        
        return this.engine.addImageObject(obj);
    }

    // Case 28: delbmp
    _cmdDelbmp(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        return this.engine.removeImageObject(list[0]);
    }

    // Case 29: showbmp
    _cmdShowbmp(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        return this.engine.showObject(list[0]);
    }

    // Case 30: hidebmp
    _cmdHidebmp(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        return this.engine.hideObject(list[0]);
    }

    // Case 31: runprj
    _cmdRunprj(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        return this.engine.loadProject(list[0]);
    }

    // Case 32: update
    _cmdUpdate() {
        return this.engine.update();
    }

    // Case 33: rundll
    // Not directly portable to web
    _cmdRundll(args, raw) {
        console.warn('rundll not supported in web context');
        return false;
    }

    // Case 34: msgbox
    // Original: MessageBoxExA(hwnd, text, title, flags, langId)
    _cmdMsgbox(args, raw) {
        const { list } = args;
        const text = list[0] || '';
        const title = list[1] || 'Message';
        
        alert(text);
        return true;
    }

    // Case 35: playcmd
    async _cmdPlaycmd(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        const cmd = this.parse(list[0]);
        if (cmd) {
            return this.execute(cmd);
        }
        return false;
    }

    // Case 36: closewav
    _cmdClosewav() {
        return this.engine.stopSound();
    }

    // Case 37: closedll
    _cmdClosedll() {
        // Not applicable in web
        return true;
    }

    // Case 38: playtext
    // Format: playtext "text" [name]
    _cmdPlaytext(args, raw) {
        const { list, params } = args;
        if (list.length === 0) return false;
        
        const text = list[0];
        const name = list[1] || params.name;
        
        return this.engine.showDialog(text, name);
    }

    // Case 39: font
    // Format: font "name" size [bold] [italic]
    _cmdFont(args, raw) {
        const { list, params } = args;
        
        const font = {
            name: list[0] || 'Arial',
            size: list[1] || 14,
            bold: params.bold !== undefined || list[2] === 'bold',
            italic: params.italic !== undefined || list[3] === 'italic'
        };
        
        return this.engine.setFont(font);
    }

    // Case 41: addtext
    // Format: addtext "name" "text" x y [color] [font]
    _cmdAddtext(args, raw) {
        const { list, params } = args;
        
        if (list.length < 4) return false;
        
        const obj = {
            name: list[0],
            text: list[1],
            x: list[2],
            y: list[3],
            color: params.color || list[4],
            font: params.font || list[5]
        };
        
        return this.engine.addTextObject(obj);
    }

    // Case 42: delobj
    _cmdDelobj(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        return this.engine.removeObject(list[0]);
    }

    // Case 43: showobj
    _cmdShowobj(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        return this.engine.showObject(list[0]);
    }

    // Case 44: hideobj
    _cmdHideobj(args, raw) {
        const { list } = args;
        if (list.length === 0) return false;
        
        return this.engine.hideObject(list[0]);
    }

    // Case 45: load
    async _cmdLoad(args, raw) {
        const { list } = args;
        const slot = list[0] !== undefined ? list[0] : 0;
        
        return this.engine.loadGame(slot);
    }

    // Case 46: save
    async _cmdSave(args, raw) {
        const { list } = args;
        const slot = list[0] !== undefined ? list[0] : 0;
        
        return this.engine.saveGame(slot);
    }

    // Case 47: closeavi
    _cmdCloseavi() {
        return this.engine.stopVideo();
    }

    // Case 48: closemid
    _cmdClosemid() {
        return this.engine.stopMusic();
    }
}

export { VNCommandParser, CMD, COMMAND_MAP };
export default VNCommandParser;
