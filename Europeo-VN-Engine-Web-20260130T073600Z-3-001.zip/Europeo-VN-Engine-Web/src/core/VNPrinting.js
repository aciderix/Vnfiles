/**
 * VNPrinting - Printing and Page Context System
 * 
 * EXACT PORT from Windows printing system
 * 
 * Original classes from disassembly:
 * - TPageContext @ multiple addresses
 * - TArray<TPageContext> @ 0x00423ae7
 * - TArrayAsVector<TPageContext> @ 0x00423d67
 * 
 * Functions:
 * - Page %u @ 0x0044c7fa
 * - '%s' not printed. %s. @ 0x004d8378
 * - Printing canceled! @ 0x004d83e6
 */

/**
 * Page units
 */
export const VNPageUnits = {
    INCHES: 'inches',
    CM: 'cm',
    MM: 'mm',
    POINTS: 'points',
    PIXELS: 'pixels'
};

/**
 * Page orientation
 */
export const VNOrientation = {
    PORTRAIT: 1,
    LANDSCAPE: 2
};

/**
 * Paper sizes
 */
export const VNPaperSize = {
    LETTER: { width: 8.5, height: 11, name: 'Letter' },
    LEGAL: { width: 8.5, height: 14, name: 'Legal' },
    A4: { width: 8.27, height: 11.69, name: 'A4' },
    A3: { width: 11.69, height: 16.54, name: 'A3' },
    A5: { width: 5.83, height: 8.27, name: 'A5' }
};

/**
 * VNPageContext - Page printing context
 * Port of TPageContext class
 */
export class VNPageContext {
    constructor() {
        this.pageNumber = 1;
        this.totalPages = 1;
        this.paperSize = VNPaperSize.LETTER;
        this.orientation = VNOrientation.PORTRAIT;
        this.margins = {
            top: 1,    // inches
            bottom: 1,
            left: 1,
            right: 1
        };
        this.dpi = 96;
        this.canvas = null;
        this.ctx = null;
    }

    /**
     * Get page width in inches
     * @returns {number}
     */
    getPageWidth() {
        if (this.orientation === VNOrientation.LANDSCAPE) {
            return this.paperSize.height;
        }
        return this.paperSize.width;
    }

    /**
     * Get page height in inches
     * @returns {number}
     */
    getPageHeight() {
        if (this.orientation === VNOrientation.LANDSCAPE) {
            return this.paperSize.width;
        }
        return this.paperSize.height;
    }

    /**
     * Get printable width in inches
     * @returns {number}
     */
    getPrintableWidth() {
        return this.getPageWidth() - this.margins.left - this.margins.right;
    }

    /**
     * Get printable height in inches
     * @returns {number}
     */
    getPrintableHeight() {
        return this.getPageHeight() - this.margins.top - this.margins.bottom;
    }

    /**
     * Get width in pixels
     * @returns {number}
     */
    getPixelWidth() {
        return Math.round(this.getPageWidth() * this.dpi);
    }

    /**
     * Get height in pixels
     * @returns {number}
     */
    getPixelHeight() {
        return Math.round(this.getPageHeight() * this.dpi);
    }

    /**
     * Create canvas for page
     * @returns {HTMLCanvasElement}
     */
    createCanvas() {
        this.canvas = document.createElement('canvas');
        this.canvas.width = this.getPixelWidth();
        this.canvas.height = this.getPixelHeight();
        this.ctx = this.canvas.getContext('2d');
        
        // Set white background
        this.ctx.fillStyle = 'white';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        return this.canvas;
    }

    /**
     * Get context with margins applied
     * @returns {CanvasRenderingContext2D}
     */
    getContext() {
        if (!this.ctx) {
            this.createCanvas();
        }
        
        // Translate to printable area
        this.ctx.save();
        this.ctx.translate(
            this.margins.left * this.dpi,
            this.margins.top * this.dpi
        );
        
        return this.ctx;
    }

    /**
     * Restore context
     */
    restoreContext() {
        if (this.ctx) {
            this.ctx.restore();
        }
    }

    /**
     * Get page string
     * Port of "Page %u" @ 0x0044c7fa
     * @returns {string}
     */
    getPageString() {
        return `Page ${this.pageNumber}`;
    }

    /**
     * Get page info string
     * @returns {string}
     */
    getInfoString() {
        return `${this.getPageString()} of ${this.totalPages}`;
    }
}

/**
 * VNPrintJob - Print job manager
 */
export class VNPrintJob {
    constructor() {
        this.documentName = 'Untitled';
        this.pages = [];
        this.currentPage = null;
        this.canceled = false;
        this.aborted = false;
        this.status = 'idle';
        this.onProgress = null;
        this.onComplete = null;
        this.onError = null;
    }

    /**
     * Start print job
     * @param {string} documentName 
     */
    startDoc(documentName) {
        this.documentName = documentName;
        this.pages = [];
        this.canceled = false;
        this.aborted = false;
        this.status = 'printing';
    }

    /**
     * Start new page
     * @returns {VNPageContext}
     */
    startPage() {
        const page = new VNPageContext();
        page.pageNumber = this.pages.length + 1;
        this.currentPage = page;
        this.pages.push(page);
        return page;
    }

    /**
     * End current page
     */
    endPage() {
        if (this.currentPage) {
            this.currentPage.restoreContext();
        }
        this.currentPage = null;
        
        if (this.onProgress) {
            this.onProgress(this.pages.length, this.pages.length);
        }
    }

    /**
     * End print job
     */
    endDoc() {
        // Update total pages
        for (const page of this.pages) {
            page.totalPages = this.pages.length;
        }
        
        this.status = 'complete';
        
        if (this.onComplete) {
            this.onComplete(this);
        }
    }

    /**
     * Abort print job
     */
    abortDoc() {
        this.aborted = true;
        this.status = 'aborted';
        
        if (this.onError) {
            this.onError(new VNPrintCancelledException(true));
        }
    }

    /**
     * Cancel print job
     */
    cancel() {
        this.canceled = true;
        this.status = 'canceled';
        
        if (this.onError) {
            this.onError(new VNPrintCancelledException(false));
        }
    }

    /**
     * Get page count
     * @returns {number}
     */
    getPageCount() {
        return this.pages.length;
    }

    /**
     * Get page at index
     * @param {number} index 
     * @returns {VNPageContext|null}
     */
    getPage(index) {
        return this.pages[index] || null;
    }
}

/**
 * VNPrintCancelledException (imported from VNException)
 */
export class VNPrintCancelledException extends Error {
    constructor(abortedByManager = false) {
        const msg = abortedByManager 
            ? 'Printing aborted in Print Manager'
            : 'Printing canceled!';
        super(msg);
        this.name = 'VNPrintCancelledException';
        this.abortedByManager = abortedByManager;
    }
}

/**
 * VNPrinter - Printer interface
 */
export class VNPrinter {
    constructor() {
        this.name = 'Default Printer';
        this.available = true;
        this.paperSize = VNPaperSize.LETTER;
        this.orientation = VNOrientation.PORTRAIT;
        this.copies = 1;
        this.collate = true;
    }

    /**
     * Check if printing is available
     * @returns {boolean}
     */
    static isAvailable() {
        return typeof window !== 'undefined' && 'print' in window;
    }

    /**
     * Print document using browser print dialog
     * @param {VNPrintJob} job 
     */
    async print(job) {
        if (job.pages.length === 0) {
            throw new Error("'${job.documentName}' not printed. No pages.");
        }
        
        // Create print container
        const container = document.createElement('div');
        container.className = 'vn-print-container';
        container.style.cssText = `
            position: fixed;
            left: -9999px;
            top: 0;
        `;
        
        // Add pages
        for (const page of job.pages) {
            if (page.canvas) {
                const pageDiv = document.createElement('div');
                pageDiv.className = 'vn-print-page';
                pageDiv.style.cssText = `
                    page-break-after: always;
                `;
                
                const img = document.createElement('img');
                img.src = page.canvas.toDataURL('image/png');
                img.style.width = '100%';
                pageDiv.appendChild(img);
                container.appendChild(pageDiv);
            }
        }
        
        document.body.appendChild(container);
        
        // Print
        try {
            window.print();
        } finally {
            document.body.removeChild(container);
        }
    }

    /**
     * Export to PDF (via canvas to blob)
     * @param {VNPrintJob} job 
     * @returns {Promise<Blob[]>}
     */
    async exportToPng(job) {
        const blobs = [];
        
        for (const page of job.pages) {
            if (page.canvas) {
                const blob = await new Promise(resolve => 
                    page.canvas.toBlob(resolve, 'image/png')
                );
                blobs.push(blob);
            }
        }
        
        return blobs;
    }
}

/**
 * VNPrintPreview - Print preview dialog
 */
export class VNPrintPreview {
    constructor() {
        this.job = null;
        this.currentPage = 0;
        this.zoom = 1;
        this.element = null;
    }

    /**
     * Show preview
     * @param {VNPrintJob} job 
     */
    show(job) {
        this.job = job;
        this.currentPage = 0;
        this._createUI();
        this._renderPage();
    }

    /**
     * Hide preview
     */
    hide() {
        if (this.element && this.element.parentNode) {
            this.element.parentNode.removeChild(this.element);
        }
        this.element = null;
    }

    /**
     * Create preview UI
     * @private
     */
    _createUI() {
        this.element = document.createElement('div');
        this.element.className = 'vn-print-preview';
        this.element.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 10000;
            display: flex;
            flex-direction: column;
        `;
        
        // Toolbar
        const toolbar = document.createElement('div');
        toolbar.style.cssText = `
            background: #333;
            padding: 10px;
            display: flex;
            gap: 10px;
            align-items: center;
            color: white;
        `;
        
        const prevBtn = this._createButton('◀ Prev', () => this._prevPage());
        const nextBtn = this._createButton('Next ▶', () => this._nextPage());
        const printBtn = this._createButton('🖨 Print', () => this._print());
        const closeBtn = this._createButton('✕ Close', () => this.hide());
        
        this.pageInfo = document.createElement('span');
        this.pageInfo.style.marginLeft = 'auto';
        
        toolbar.appendChild(prevBtn);
        toolbar.appendChild(nextBtn);
        toolbar.appendChild(printBtn);
        toolbar.appendChild(this.pageInfo);
        toolbar.appendChild(closeBtn);
        
        // Canvas container
        this.canvasContainer = document.createElement('div');
        this.canvasContainer.style.cssText = `
            flex: 1;
            overflow: auto;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 20px;
        `;
        
        this.element.appendChild(toolbar);
        this.element.appendChild(this.canvasContainer);
        document.body.appendChild(this.element);
    }

    /**
     * Create button
     * @private
     */
    _createButton(text, onClick) {
        const btn = document.createElement('button');
        btn.textContent = text;
        btn.style.cssText = `
            padding: 8px 16px;
            cursor: pointer;
        `;
        btn.addEventListener('click', onClick);
        return btn;
    }

    /**
     * Render current page
     * @private
     */
    _renderPage() {
        if (!this.job || !this.canvasContainer) return;
        
        this.canvasContainer.innerHTML = '';
        
        const page = this.job.getPage(this.currentPage);
        if (page && page.canvas) {
            const canvas = document.createElement('canvas');
            canvas.width = page.canvas.width;
            canvas.height = page.canvas.height;
            canvas.style.cssText = `
                background: white;
                box-shadow: 0 4px 20px rgba(0,0,0,0.5);
                max-width: 100%;
                height: auto;
            `;
            
            const ctx = canvas.getContext('2d');
            ctx.drawImage(page.canvas, 0, 0);
            
            this.canvasContainer.appendChild(canvas);
        }
        
        this.pageInfo.textContent = `Page ${this.currentPage + 1} of ${this.job.getPageCount()}`;
    }

    /**
     * Go to previous page
     * @private
     */
    _prevPage() {
        if (this.currentPage > 0) {
            this.currentPage--;
            this._renderPage();
        }
    }

    /**
     * Go to next page
     * @private
     */
    _nextPage() {
        if (this.job && this.currentPage < this.job.getPageCount() - 1) {
            this.currentPage++;
            this._renderPage();
        }
    }

    /**
     * Print
     * @private
     */
    _print() {
        if (this.job) {
            const printer = new VNPrinter();
            printer.print(this.job);
        }
    }
}

export default {
    VNPageUnits,
    VNOrientation,
    VNPaperSize,
    VNPageContext,
    VNPrintJob,
    VNPrintCancelledException,
    VNPrinter,
    VNPrintPreview
};
