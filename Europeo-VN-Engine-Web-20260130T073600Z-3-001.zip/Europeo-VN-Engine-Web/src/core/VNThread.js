/**
 * VNThread - Threading and Synchronization System
 * 
 * EXACT PORT from OWL threading classes
 * 
 * Original classes from disassembly:
 * - TThread @ 0x00436f04
 * - TMsgThread @ 0x00436b63
 * - TMutex @ 0x00436fde
 * - TSemaphore @ 0x00436fde
 * - TMsgThread::TAppMutex @ 0x00436f34
 * 
 * Key functions:
 * - @TThread@$bdtr$qv @ 0x00451bb4 (destructor)
 * - @TThread@Terminate$qv @ 0x00451bb4 (terminate)
 * - @TMsgThread@PumpWaitingMessages$qv @ 0x00451a38
 * - Sleep @ 0x004518c8
 */

/**
 * Thread status
 */
export const VNThreadStatus = {
    CREATED: 0,
    RUNNING: 1,
    SUSPENDED: 2,
    TERMINATED: 3,
    FINISHED: 4
};

/**
 * VNThread - Thread emulation using Web Workers or async
 * Port of TThread @ 0x00436f04
 */
export class VNThread {
    /**
     * @param {Function} entryPoint - Thread entry function
     */
    constructor(entryPoint = null) {
        this.entryPoint = entryPoint;
        this.status = VNThreadStatus.CREATED;
        this.exitCode = 0;
        this.handle = null;
        this.worker = null;
        this.terminated = false;
        
        // Events
        this.onStart = null;
        this.onComplete = null;
        this.onError = null;
    }

    /**
     * Start thread
     * @returns {Promise<void>}
     */
    async start() {
        if (this.status !== VNThreadStatus.CREATED) {
            throw new Error('Thread already started');
        }
        
        this.status = VNThreadStatus.RUNNING;
        this.terminated = false;
        
        if (this.onStart) {
            this.onStart();
        }
        
        try {
            if (this.entryPoint) {
                this.exitCode = await this.run();
            }
            this.status = VNThreadStatus.FINISHED;
            
            if (this.onComplete) {
                this.onComplete(this.exitCode);
            }
        } catch (e) {
            this.status = VNThreadStatus.TERMINATED;
            
            if (this.onError) {
                this.onError(e);
            }
        }
    }

    /**
     * Run thread (override in subclass)
     * @returns {Promise<number>}
     */
    async run() {
        if (this.entryPoint) {
            return await this.entryPoint();
        }
        return 0;
    }

    /**
     * Terminate thread
     * Port of @TThread@Terminate$qv @ 0x00451bb4
     */
    terminate() {
        this.terminated = true;
        this.status = VNThreadStatus.TERMINATED;
    }

    /**
     * Check if terminated
     * @returns {boolean}
     */
    shouldTerminate() {
        return this.terminated;
    }

    /**
     * Suspend thread (not really possible in JS)
     */
    suspend() {
        this.status = VNThreadStatus.SUSPENDED;
    }

    /**
     * Resume thread
     */
    resume() {
        if (this.status === VNThreadStatus.SUSPENDED) {
            this.status = VNThreadStatus.RUNNING;
        }
    }

    /**
     * Wait for thread to complete
     * @param {number} timeout - Timeout in ms (-1 for infinite)
     * @returns {Promise<number>}
     */
    async waitFor(timeout = -1) {
        const startTime = Date.now();
        
        while (this.status === VNThreadStatus.RUNNING || 
               this.status === VNThreadStatus.SUSPENDED) {
            await VNThread.sleep(10);
            
            if (timeout > 0 && (Date.now() - startTime) > timeout) {
                return -1; // Timeout
            }
        }
        
        return this.exitCode;
    }

    /**
     * Get thread status
     * @returns {number}
     */
    getStatus() {
        return this.status;
    }

    /**
     * Get exit code
     * @returns {number}
     */
    getExitCode() {
        return this.exitCode;
    }

    /**
     * Sleep for duration
     * Port of Sleep @ 0x004518c8
     * @param {number} ms 
     * @returns {Promise<void>}
     */
    static sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

/**
 * VNMsgThread - Message-pumping thread
 * Port of TMsgThread @ 0x00436b63
 */
export class VNMsgThread extends VNThread {
    constructor() {
        super();
        this.messageQueue = [];
        this.mutex = new VNMutex();
        this.processing = false;
    }

    /**
     * Post message to thread
     * @param {*} message 
     */
    postMessage(message) {
        this.mutex.lock();
        this.messageQueue.push(message);
        this.mutex.unlock();
    }

    /**
     * Pump waiting messages
     * Port of @TMsgThread@PumpWaitingMessages$qv @ 0x00451a38
     * @returns {number} - Number of messages processed
     */
    pumpWaitingMessages() {
        let count = 0;
        this.processing = true;
        
        this.mutex.lock();
        const messages = [...this.messageQueue];
        this.messageQueue = [];
        this.mutex.unlock();
        
        for (const msg of messages) {
            this.processMessage(msg);
            count++;
        }
        
        this.processing = false;
        return count;
    }

    /**
     * Process single message (override)
     * @param {*} message 
     */
    processMessage(message) {
        // Override in subclass
    }

    /**
     * Run message loop
     * @returns {Promise<number>}
     */
    async run() {
        while (!this.shouldTerminate()) {
            this.pumpWaitingMessages();
            await VNThread.sleep(10);
        }
        return 0;
    }

    /**
     * Check if processing messages
     * @returns {boolean}
     */
    isProcessing() {
        return this.processing;
    }
}

/**
 * VNMutex - Mutual exclusion lock
 * Port of TMutex @ 0x00436fde
 */
export class VNMutex {
    constructor() {
        this.locked = false;
        this.owner = null;
        this.waitQueue = [];
    }

    /**
     * Lock mutex
     * @returns {Promise<void>}
     */
    async lock() {
        while (this.locked) {
            await new Promise(resolve => {
                this.waitQueue.push(resolve);
            });
        }
        this.locked = true;
    }

    /**
     * Try to lock without waiting
     * @returns {boolean}
     */
    tryLock() {
        if (this.locked) {
            return false;
        }
        this.locked = true;
        return true;
    }

    /**
     * Unlock mutex
     */
    unlock() {
        this.locked = false;
        
        if (this.waitQueue.length > 0) {
            const next = this.waitQueue.shift();
            next();
        }
    }

    /**
     * Check if locked
     * @returns {boolean}
     */
    isLocked() {
        return this.locked;
    }
}

/**
 * VNCriticalSection - Critical section lock
 */
export class VNCriticalSection {
    constructor() {
        this.mutex = new VNMutex();
        this.recursionCount = 0;
        this.owner = null;
    }

    /**
     * Enter critical section
     */
    async enter() {
        const currentId = this._getCurrentId();
        
        if (this.owner === currentId) {
            this.recursionCount++;
            return;
        }
        
        await this.mutex.lock();
        this.owner = currentId;
        this.recursionCount = 1;
    }

    /**
     * Try enter without waiting
     * @returns {boolean}
     */
    tryEnter() {
        const currentId = this._getCurrentId();
        
        if (this.owner === currentId) {
            this.recursionCount++;
            return true;
        }
        
        if (this.mutex.tryLock()) {
            this.owner = currentId;
            this.recursionCount = 1;
            return true;
        }
        
        return false;
    }

    /**
     * Leave critical section
     */
    leave() {
        this.recursionCount--;
        
        if (this.recursionCount <= 0) {
            this.owner = null;
            this.recursionCount = 0;
            this.mutex.unlock();
        }
    }

    /**
     * Get current execution context ID
     * @private
     */
    _getCurrentId() {
        // In JS, we don't have real thread IDs
        return 'main';
    }
}

/**
 * VNSemaphore - Counting semaphore
 * Port of TSemaphore @ 0x00436fde
 */
export class VNSemaphore {
    /**
     * @param {number} initialCount 
     * @param {number} maxCount 
     */
    constructor(initialCount = 0, maxCount = Infinity) {
        this.count = initialCount;
        this.maxCount = maxCount;
        this.waitQueue = [];
    }

    /**
     * Wait (acquire)
     * @param {number} timeout - Timeout in ms (-1 for infinite)
     * @returns {Promise<boolean>}
     */
    async wait(timeout = -1) {
        if (this.count > 0) {
            this.count--;
            return true;
        }
        
        return new Promise((resolve, reject) => {
            let timeoutId = null;
            
            const waiter = {
                resolve: () => {
                    if (timeoutId) clearTimeout(timeoutId);
                    this.count--;
                    resolve(true);
                },
                reject: () => {
                    resolve(false);
                }
            };
            
            this.waitQueue.push(waiter);
            
            if (timeout > 0) {
                timeoutId = setTimeout(() => {
                    const index = this.waitQueue.indexOf(waiter);
                    if (index !== -1) {
                        this.waitQueue.splice(index, 1);
                        resolve(false);
                    }
                }, timeout);
            }
        });
    }

    /**
     * Signal (release)
     * @param {number} count 
     * @returns {number} - Previous count
     */
    signal(count = 1) {
        const prevCount = this.count;
        
        for (let i = 0; i < count; i++) {
            if (this.count < this.maxCount) {
                this.count++;
                
                if (this.waitQueue.length > 0) {
                    const waiter = this.waitQueue.shift();
                    waiter.resolve();
                }
            }
        }
        
        return prevCount;
    }

    /**
     * Get current count
     * @returns {number}
     */
    getCount() {
        return this.count;
    }
}

/**
 * VNEvent - Event synchronization primitive
 */
export class VNEvent {
    /**
     * @param {boolean} manualReset 
     * @param {boolean} initialState 
     */
    constructor(manualReset = false, initialState = false) {
        this.manualReset = manualReset;
        this.signaled = initialState;
        this.waitQueue = [];
    }

    /**
     * Set event (signal)
     */
    set() {
        this.signaled = true;
        
        if (this.manualReset) {
            // Wake all waiters
            for (const waiter of this.waitQueue) {
                waiter();
            }
            this.waitQueue = [];
        } else {
            // Wake one waiter
            if (this.waitQueue.length > 0) {
                const waiter = this.waitQueue.shift();
                waiter();
                this.signaled = false;
            }
        }
    }

    /**
     * Reset event
     */
    reset() {
        this.signaled = false;
    }

    /**
     * Wait for event
     * @param {number} timeout 
     * @returns {Promise<boolean>}
     */
    async wait(timeout = -1) {
        if (this.signaled) {
            if (!this.manualReset) {
                this.signaled = false;
            }
            return true;
        }
        
        return new Promise((resolve) => {
            let timeoutId = null;
            
            const waiter = () => {
                if (timeoutId) clearTimeout(timeoutId);
                resolve(true);
            };
            
            this.waitQueue.push(waiter);
            
            if (timeout > 0) {
                timeoutId = setTimeout(() => {
                    const index = this.waitQueue.indexOf(waiter);
                    if (index !== -1) {
                        this.waitQueue.splice(index, 1);
                        resolve(false);
                    }
                }, timeout);
            }
        });
    }

    /**
     * Pulse event (set then immediately reset)
     */
    pulse() {
        this.set();
        if (this.manualReset) {
            this.reset();
        }
    }
}

/**
 * VNAppMutex - Application-wide mutex
 * Port of TMsgThread::TAppMutex @ 0x00436f34
 */
export class VNAppMutex extends VNMutex {
    constructor(name = 'AppMutex') {
        super();
        this.name = name;
    }
}

/**
 * Helper: Run function in async "thread"
 * @param {Function} fn 
 * @returns {VNThread}
 */
export function runInThread(fn) {
    const thread = new VNThread(fn);
    thread.start();
    return thread;
}

/**
 * Helper: Run function with lock
 * @param {VNMutex} mutex 
 * @param {Function} fn 
 * @returns {Promise<*>}
 */
export async function withLock(mutex, fn) {
    await mutex.lock();
    try {
        return await fn();
    } finally {
        mutex.unlock();
    }
}

export default {
    VNThreadStatus,
    VNThread,
    VNMsgThread,
    VNMutex,
    VNCriticalSection,
    VNSemaphore,
    VNEvent,
    VNAppMutex,
    runInThread,
    withLock
};
