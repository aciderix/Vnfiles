/**
 * VNStream - Borland Persistent Stream Emulation
 * 
 * EXACT PORT from bds52t.dll streaming system
 * Based on Borland C++ OWL TStreamable classes
 * 
 * Original functions (from disassembly):
 * - ipstream_readBytes_qpvui @ 0x00439192
 * - ipstream_readWord_qv @ 0x00439186
 * - ipstream_readWord32_qv @ 0x00439180
 * - ipstream_readVersion_qv @ 0x0043918c
 * - opstream_writeBytes_qpxvui @ 0x00439174
 * - opstream_writeWord32_qul @ 0x00439150
 * - TStreamableBase__bdtr_qv @ 0x004390cc
 * - TPReadObjects__bctr_qv @ 0x0043908a
 */

/**
 * VNStreamableBase - Base class for all streamable objects
 * Port of TStreamableBase
 */
export class VNStreamableBase {
    constructor() {
        // 0x004390cc - TStreamableBase destructor
        this._streamVersion = 1;
        this._className = 'VNStreamableBase';
    }

    /**
     * Read object from stream
     * @param {VNInputStream} stream 
     */
    read(stream) {
        // Override in subclasses
        throw new Error('read() must be implemented');
    }

    /**
     * Write object to stream
     * @param {VNOutputStream} stream 
     */
    write(stream) {
        // Override in subclasses
        throw new Error('write() must be implemented');
    }

    /**
     * Get stream version
     */
    getVersion() {
        return this._streamVersion;
    }

    /**
     * Get class name for RTTI
     */
    getClassName() {
        return this._className;
    }
}

/**
 * VNInputStream - Input persistence stream
 * Port of ipstream from bds52t.dll
 * 
 * Handles reading VN project files (.vnp, .vns, .vnr)
 */
export class VNInputStream {
    /**
     * @param {ArrayBuffer} buffer - Binary data buffer
     */
    constructor(buffer) {
        // 0x00438e7a - ifstream constructor
        this.buffer = buffer;
        this.view = new DataView(buffer);
        this.position = 0;
        this.littleEndian = true; // x86 is little-endian
        
        // Object registry for TPReadObjects
        // 0x0043908a - TPReadObjects constructor
        this.objectRegistry = new Map();
        this.nextObjectId = 1;
    }

    /**
     * Read raw bytes
     * Port of ipstream_readBytes_qpvui @ 0x00439192
     * @param {number} count - Number of bytes to read
     * @returns {Uint8Array}
     */
    readBytes(count) {
        // Original ASM:
        // mov ecx, [esp+4]     ; count
        // mov eax, [this+position]
        // lea edx, [eax+ecx]   ; new position
        // mov [this+position], edx
        // ret
        
        if (this.position + count > this.buffer.byteLength) {
            throw new Error(`Stream read overflow: pos=${this.position}, count=${count}, len=${this.buffer.byteLength}`);
        }
        
        const bytes = new Uint8Array(this.buffer, this.position, count);
        this.position += count;
        return bytes;
    }

    /**
     * Read 8-bit unsigned integer
     * @returns {number}
     */
    readByte() {
        const value = this.view.getUint8(this.position);
        this.position += 1;
        return value;
    }

    /**
     * Read 8-bit signed integer
     * @returns {number}
     */
    readInt8() {
        const value = this.view.getInt8(this.position);
        this.position += 1;
        return value;
    }

    /**
     * Read 16-bit word
     * Port of ipstream_readWord_qv @ 0x00439186
     * @returns {number}
     */
    readWord() {
        // Original ASM:
        // mov eax, [this+position]
        // movzx eax, word [buffer+eax]
        // add [this+position], 2
        // ret
        
        const value = this.view.getUint16(this.position, this.littleEndian);
        this.position += 2;
        return value;
    }

    /**
     * Read 16-bit signed integer
     * @returns {number}
     */
    readInt16() {
        const value = this.view.getInt16(this.position, this.littleEndian);
        this.position += 2;
        return value;
    }

    /**
     * Read 32-bit word (DWORD)
     * Port of ipstream_readWord32_qv @ 0x00439180
     * @returns {number}
     */
    readWord32() {
        // Original ASM:
        // mov eax, [this+position]
        // mov eax, [buffer+eax]
        // add [this+position], 4
        // ret
        
        const value = this.view.getUint32(this.position, this.littleEndian);
        this.position += 4;
        return value;
    }

    /**
     * Read 32-bit signed integer
     * @returns {number}
     */
    readInt32() {
        const value = this.view.getInt32(this.position, this.littleEndian);
        this.position += 4;
        return value;
    }

    /**
     * Read stream version
     * Port of ipstream_readVersion_qv @ 0x0043918c
     * @returns {number}
     */
    readVersion() {
        // Version is stored as 16-bit word
        return this.readWord();
    }

    /**
     * Read null-terminated string
     * @returns {string}
     */
    readString() {
        let str = '';
        let byte;
        while ((byte = this.readByte()) !== 0) {
            str += String.fromCharCode(byte);
        }
        return str;
    }

    /**
     * Read length-prefixed string (Pascal style)
     * @returns {string}
     */
    readPString() {
        const length = this.readByte();
        const bytes = this.readBytes(length);
        return new TextDecoder('windows-1252').decode(bytes);
    }

    /**
     * Read length-prefixed string with 16-bit length
     * @returns {string}
     */
    readLString() {
        const length = this.readWord();
        const bytes = this.readBytes(length);
        return new TextDecoder('windows-1252').decode(bytes);
    }

    /**
     * Read length-prefixed string with 32-bit length
     * @returns {string}
     */
    readLLString() {
        const length = this.readWord32();
        const bytes = this.readBytes(length);
        return new TextDecoder('windows-1252').decode(bytes);
    }

    /**
     * Read boolean
     * @returns {boolean}
     */
    readBool() {
        return this.readByte() !== 0;
    }

    /**
     * Read float (32-bit)
     * @returns {number}
     */
    readFloat() {
        const value = this.view.getFloat32(this.position, this.littleEndian);
        this.position += 4;
        return value;
    }

    /**
     * Read double (64-bit)
     * @returns {number}
     */
    readDouble() {
        const value = this.view.getFloat64(this.position, this.littleEndian);
        this.position += 8;
        return value;
    }

    /**
     * Read TRect structure
     * Port of _brsh_qr8ipstreamr5TRect @ 0x0043913e
     * @returns {{left: number, top: number, right: number, bottom: number}}
     */
    readRect() {
        // TRect is 4 x 32-bit integers
        // struct TRect { int left, top, right, bottom; }
        return {
            left: this.readInt32(),
            top: this.readInt32(),
            right: this.readInt32(),
            bottom: this.readInt32()
        };
    }

    /**
     * Read TPoint structure
     * @returns {{x: number, y: number}}
     */
    readPoint() {
        return {
            x: this.readInt32(),
            y: this.readInt32()
        };
    }

    /**
     * Read TSize structure
     * @returns {{cx: number, cy: number}}
     */
    readSize() {
        return {
            cx: this.readInt32(),
            cy: this.readInt32()
        };
    }

    /**
     * Read color (COLORREF - 32-bit)
     * @returns {number}
     */
    readColor() {
        return this.readWord32();
    }

    /**
     * Read object reference
     * Used by TPReadObjects system
     * @param {Function} factory - Factory function to create object
     * @returns {VNStreamableBase}
     */
    readObject(factory) {
        const marker = this.readByte();
        
        if (marker === 0x00) {
            // Null reference
            return null;
        } else if (marker === 0xFF) {
            // New object
            const obj = factory();
            const id = this.nextObjectId++;
            this.objectRegistry.set(id, obj);
            obj.read(this);
            return obj;
        } else {
            // Reference to existing object
            const id = (marker << 8) | this.readByte();
            return this.objectRegistry.get(id) || null;
        }
    }

    /**
     * Read array of objects
     * @param {Function} factory 
     * @returns {Array}
     */
    readObjectArray(factory) {
        const count = this.readWord32();
        const array = [];
        for (let i = 0; i < count; i++) {
            array.push(this.readObject(factory));
        }
        return array;
    }

    /**
     * Read array of integers
     * @returns {Int32Array}
     */
    readIntArray() {
        const count = this.readWord32();
        const array = new Int32Array(count);
        for (let i = 0; i < count; i++) {
            array[i] = this.readInt32();
        }
        return array;
    }

    /**
     * Read array of strings
     * @returns {string[]}
     */
    readStringArray() {
        const count = this.readWord32();
        const array = [];
        for (let i = 0; i < count; i++) {
            array.push(this.readLString());
        }
        return array;
    }

    /**
     * Seek to position
     * @param {number} position 
     */
    seek(position) {
        this.position = position;
    }

    /**
     * Skip bytes
     * @param {number} count 
     */
    skip(count) {
        this.position += count;
    }

    /**
     * Check if at end of stream
     * @returns {boolean}
     */
    eof() {
        return this.position >= this.buffer.byteLength;
    }

    /**
     * Get remaining bytes
     * @returns {number}
     */
    remaining() {
        return this.buffer.byteLength - this.position;
    }

    /**
     * Get current position
     * @returns {number}
     */
    tell() {
        return this.position;
    }
}

/**
 * VNOutputStream - Output persistence stream
 * Port of opstream from bds52t.dll
 */
export class VNOutputStream {
    constructor() {
        // 0x0043916e - pstream destructor
        this.chunks = [];
        this.littleEndian = true;
        
        // Object registry for writing references
        this.objectRegistry = new Map();
        this.nextObjectId = 1;
    }

    /**
     * Write raw bytes
     * Port of opstream_writeBytes_qpxvui @ 0x00439174
     * @param {Uint8Array} bytes 
     */
    writeBytes(bytes) {
        this.chunks.push(new Uint8Array(bytes));
    }

    /**
     * Write 8-bit unsigned integer
     * @param {number} value 
     */
    writeByte(value) {
        this.chunks.push(new Uint8Array([value & 0xFF]));
    }

    /**
     * Write 8-bit signed integer
     * @param {number} value 
     */
    writeInt8(value) {
        const buffer = new ArrayBuffer(1);
        new DataView(buffer).setInt8(0, value);
        this.chunks.push(new Uint8Array(buffer));
    }

    /**
     * Write 16-bit word
     * @param {number} value 
     */
    writeWord(value) {
        const buffer = new ArrayBuffer(2);
        new DataView(buffer).setUint16(0, value, this.littleEndian);
        this.chunks.push(new Uint8Array(buffer));
    }

    /**
     * Write 16-bit signed integer
     * @param {number} value 
     */
    writeInt16(value) {
        const buffer = new ArrayBuffer(2);
        new DataView(buffer).setInt16(0, value, this.littleEndian);
        this.chunks.push(new Uint8Array(buffer));
    }

    /**
     * Write 32-bit word
     * Port of opstream_writeWord32_qul @ 0x00439150
     * @param {number} value 
     */
    writeWord32(value) {
        const buffer = new ArrayBuffer(4);
        new DataView(buffer).setUint32(0, value, this.littleEndian);
        this.chunks.push(new Uint8Array(buffer));
    }

    /**
     * Write 32-bit signed integer
     * @param {number} value 
     */
    writeInt32(value) {
        const buffer = new ArrayBuffer(4);
        new DataView(buffer).setInt32(0, value, this.littleEndian);
        this.chunks.push(new Uint8Array(buffer));
    }

    /**
     * Write stream version
     * @param {number} version 
     */
    writeVersion(version) {
        this.writeWord(version);
    }

    /**
     * Write null-terminated string
     * @param {string} str 
     */
    writeString(str) {
        const encoder = new TextEncoder();
        this.writeBytes(encoder.encode(str));
        this.writeByte(0);
    }

    /**
     * Write length-prefixed string (Pascal style)
     * @param {string} str 
     */
    writePString(str) {
        const bytes = new TextEncoder().encode(str);
        this.writeByte(Math.min(bytes.length, 255));
        this.writeBytes(bytes.slice(0, 255));
    }

    /**
     * Write length-prefixed string with 16-bit length
     * @param {string} str 
     */
    writeLString(str) {
        const bytes = new TextEncoder().encode(str);
        this.writeWord(bytes.length);
        this.writeBytes(bytes);
    }

    /**
     * Write length-prefixed string with 32-bit length
     * @param {string} str 
     */
    writeLLString(str) {
        const bytes = new TextEncoder().encode(str);
        this.writeWord32(bytes.length);
        this.writeBytes(bytes);
    }

    /**
     * Write boolean
     * @param {boolean} value 
     */
    writeBool(value) {
        this.writeByte(value ? 1 : 0);
    }

    /**
     * Write float (32-bit)
     * @param {number} value 
     */
    writeFloat(value) {
        const buffer = new ArrayBuffer(4);
        new DataView(buffer).setFloat32(0, value, this.littleEndian);
        this.chunks.push(new Uint8Array(buffer));
    }

    /**
     * Write double (64-bit)
     * @param {number} value 
     */
    writeDouble(value) {
        const buffer = new ArrayBuffer(8);
        new DataView(buffer).setFloat64(0, value, this.littleEndian);
        this.chunks.push(new Uint8Array(buffer));
    }

    /**
     * Write TRect structure
     * @param {{left: number, top: number, right: number, bottom: number}} rect 
     */
    writeRect(rect) {
        this.writeInt32(rect.left);
        this.writeInt32(rect.top);
        this.writeInt32(rect.right);
        this.writeInt32(rect.bottom);
    }

    /**
     * Write TPoint structure
     * @param {{x: number, y: number}} point 
     */
    writePoint(point) {
        this.writeInt32(point.x);
        this.writeInt32(point.y);
    }

    /**
     * Write TSize structure
     * @param {{cx: number, cy: number}} size 
     */
    writeSize(size) {
        this.writeInt32(size.cx);
        this.writeInt32(size.cy);
    }

    /**
     * Write color (COLORREF)
     * @param {number} color 
     */
    writeColor(color) {
        this.writeWord32(color);
    }

    /**
     * Write object with reference tracking
     * @param {VNStreamableBase} obj 
     */
    writeObject(obj) {
        if (obj === null) {
            this.writeByte(0x00);
            return;
        }
        
        const existingId = this.objectRegistry.get(obj);
        if (existingId !== undefined) {
            // Reference to existing object
            this.writeByte((existingId >> 8) & 0xFF);
            this.writeByte(existingId & 0xFF);
        } else {
            // New object
            this.writeByte(0xFF);
            const id = this.nextObjectId++;
            this.objectRegistry.set(obj, id);
            obj.write(this);
        }
    }

    /**
     * Write array of objects
     * @param {VNStreamableBase[]} array 
     */
    writeObjectArray(array) {
        this.writeWord32(array.length);
        for (const obj of array) {
            this.writeObject(obj);
        }
    }

    /**
     * Write array of integers
     * @param {number[]|Int32Array} array 
     */
    writeIntArray(array) {
        this.writeWord32(array.length);
        for (const value of array) {
            this.writeInt32(value);
        }
    }

    /**
     * Write array of strings
     * @param {string[]} array 
     */
    writeStringArray(array) {
        this.writeWord32(array.length);
        for (const str of array) {
            this.writeLString(str);
        }
    }

    /**
     * Get total size
     * @returns {number}
     */
    size() {
        return this.chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    }

    /**
     * Get final buffer
     * @returns {ArrayBuffer}
     */
    toBuffer() {
        const totalSize = this.size();
        const result = new Uint8Array(totalSize);
        let offset = 0;
        
        for (const chunk of this.chunks) {
            result.set(chunk, offset);
            offset += chunk.length;
        }
        
        return result.buffer;
    }

    /**
     * Get as Blob
     * @param {string} mimeType 
     * @returns {Blob}
     */
    toBlob(mimeType = 'application/octet-stream') {
        return new Blob(this.chunks, { type: mimeType });
    }
}

/**
 * VNFileStream - File-based stream for reading VN project files
 */
export class VNFileStream extends VNInputStream {
    /**
     * Create stream from File object
     * @param {File} file 
     * @returns {Promise<VNFileStream>}
     */
    static async fromFile(file) {
        const buffer = await file.arrayBuffer();
        return new VNFileStream(buffer, file.name);
    }

    /**
     * Create stream from URL
     * @param {string} url 
     * @returns {Promise<VNFileStream>}
     */
    static async fromUrl(url) {
        const response = await fetch(url);
        const buffer = await response.arrayBuffer();
        const name = url.split('/').pop() || 'unknown';
        return new VNFileStream(buffer, name);
    }

    constructor(buffer, filename = '') {
        super(buffer);
        this.filename = filename;
        this.extension = filename.split('.').pop()?.toLowerCase() || '';
    }

    /**
     * Get file type from extension
     * @returns {string}
     */
    getFileType() {
        switch (this.extension) {
            case 'vnp': return 'project';
            case 'vns': return 'scene';
            case 'vnr': return 'resource';
            case 'dat': return 'data';
            default: return 'unknown';
        }
    }
}

/**
 * VNProjectReader - Reads VN project files (.vnp)
 * 
 * Based on strings found in binary:
 * - "TVNProjectInfo"
 * - "TVNProjectParms"
 * - "TVNApplicationInfo"
 */
export class VNProjectReader {
    constructor() {
        this.version = 0;
        this.project = null;
    }

    /**
     * Read project file
     * @param {VNInputStream} stream 
     * @returns {Object}
     */
    read(stream) {
        // Read file header
        const magic = stream.readWord32();
        
        // Check for VNP magic (based on file format analysis)
        // Common patterns: 'VNP\0' or version number
        
        this.version = stream.readVersion();
        
        this.project = {
            version: this.version,
            info: this.readProjectInfo(stream),
            parms: this.readProjectParms(stream),
            scenes: this.readSceneArray(stream),
            variables: this.readVariableArray(stream),
            resources: this.readResourceArray(stream)
        };
        
        return this.project;
    }

    /**
     * Read TVNProjectInfo
     */
    readProjectInfo(stream) {
        return {
            title: stream.readLString(),
            author: stream.readLString(),
            description: stream.readLString(),
            version: stream.readLString(),
            copyright: stream.readLString(),
            createdDate: stream.readWord32(),
            modifiedDate: stream.readWord32()
        };
    }

    /**
     * Read TVNProjectParms
     */
    readProjectParms(stream) {
        return {
            width: stream.readWord(),
            height: stream.readWord(),
            colorDepth: stream.readWord(),
            fullscreen: stream.readBool(),
            showToolbar: stream.readBool(),
            showMenu: stream.readBool(),
            allowResize: stream.readBool(),
            startScene: stream.readLString(),
            backgroundColor: stream.readColor()
        };
    }

    /**
     * Read scene array
     */
    readSceneArray(stream) {
        const count = stream.readWord32();
        const scenes = [];
        
        for (let i = 0; i < count; i++) {
            scenes.push(this.readScene(stream));
        }
        
        return scenes;
    }

    /**
     * Read single scene
     */
    readScene(stream) {
        return {
            name: stream.readLString(),
            background: stream.readLString(),
            music: stream.readLString(),
            rect: stream.readRect(),
            hotspots: this.readHotspotArray(stream),
            commands: this.readCommandArray(stream),
            textObjects: this.readTextObjectArray(stream),
            imageObjects: this.readImageObjectArray(stream)
        };
    }

    /**
     * Read hotspot array
     */
    readHotspotArray(stream) {
        const count = stream.readWord32();
        const hotspots = [];
        
        for (let i = 0; i < count; i++) {
            hotspots.push({
                name: stream.readLString(),
                rect: stream.readRect(),
                cursor: stream.readWord(),
                action: stream.readLString(),
                tooltip: stream.readLString(),
                visible: stream.readBool(),
                enabled: stream.readBool()
            });
        }
        
        return hotspots;
    }

    /**
     * Read command array
     */
    readCommandArray(stream) {
        const count = stream.readWord32();
        const commands = [];
        
        for (let i = 0; i < count; i++) {
            commands.push({
                type: stream.readWord(),
                params: stream.readStringArray()
            });
        }
        
        return commands;
    }

    /**
     * Read text object array
     */
    readTextObjectArray(stream) {
        const count = stream.readWord32();
        const objects = [];
        
        for (let i = 0; i < count; i++) {
            objects.push({
                name: stream.readLString(),
                text: stream.readLString(),
                rect: stream.readRect(),
                fontName: stream.readLString(),
                fontSize: stream.readWord(),
                fontStyle: stream.readWord(),
                color: stream.readColor(),
                backgroundColor: stream.readColor(),
                alignment: stream.readWord(),
                visible: stream.readBool()
            });
        }
        
        return objects;
    }

    /**
     * Read image object array
     */
    readImageObjectArray(stream) {
        const count = stream.readWord32();
        const objects = [];
        
        for (let i = 0; i < count; i++) {
            objects.push({
                name: stream.readLString(),
                filename: stream.readLString(),
                rect: stream.readRect(),
                transparent: stream.readBool(),
                transparentColor: stream.readColor(),
                visible: stream.readBool()
            });
        }
        
        return objects;
    }

    /**
     * Read variable array
     */
    readVariableArray(stream) {
        const count = stream.readWord32();
        const variables = [];
        
        for (let i = 0; i < count; i++) {
            variables.push({
                name: stream.readLString(),
                value: stream.readInt32(),
                type: stream.readWord()
            });
        }
        
        return variables;
    }

    /**
     * Read resource array
     */
    readResourceArray(stream) {
        const count = stream.readWord32();
        const resources = [];
        
        for (let i = 0; i < count; i++) {
            resources.push({
                name: stream.readLString(),
                type: stream.readWord(),
                filename: stream.readLString(),
                embedded: stream.readBool(),
                data: stream.readBool() ? stream.readBytes(stream.readWord32()) : null
            });
        }
        
        return resources;
    }
}

/**
 * VNProjectWriter - Writes VN project files (.vnp)
 */
export class VNProjectWriter {
    constructor() {
        this.version = 1;
    }

    /**
     * Write project to stream
     * @param {Object} project 
     * @returns {ArrayBuffer}
     */
    write(project) {
        const stream = new VNOutputStream();
        
        // Write magic header
        stream.writeWord32(0x00504E56); // 'VNP\0'
        
        // Write version
        stream.writeVersion(this.version);
        
        // Write project data
        this.writeProjectInfo(stream, project.info);
        this.writeProjectParms(stream, project.parms);
        this.writeSceneArray(stream, project.scenes);
        this.writeVariableArray(stream, project.variables);
        this.writeResourceArray(stream, project.resources);
        
        return stream.toBuffer();
    }

    writeProjectInfo(stream, info) {
        stream.writeLString(info.title || '');
        stream.writeLString(info.author || '');
        stream.writeLString(info.description || '');
        stream.writeLString(info.version || '1.0');
        stream.writeLString(info.copyright || '');
        stream.writeWord32(info.createdDate || Date.now());
        stream.writeWord32(info.modifiedDate || Date.now());
    }

    writeProjectParms(stream, parms) {
        stream.writeWord(parms.width || 640);
        stream.writeWord(parms.height || 480);
        stream.writeWord(parms.colorDepth || 24);
        stream.writeBool(parms.fullscreen || false);
        stream.writeBool(parms.showToolbar !== false);
        stream.writeBool(parms.showMenu !== false);
        stream.writeBool(parms.allowResize || false);
        stream.writeLString(parms.startScene || '');
        stream.writeColor(parms.backgroundColor || 0x000000);
    }

    writeSceneArray(stream, scenes) {
        stream.writeWord32(scenes?.length || 0);
        for (const scene of (scenes || [])) {
            this.writeScene(stream, scene);
        }
    }

    writeScene(stream, scene) {
        stream.writeLString(scene.name || '');
        stream.writeLString(scene.background || '');
        stream.writeLString(scene.music || '');
        stream.writeRect(scene.rect || { left: 0, top: 0, right: 640, bottom: 480 });
        this.writeHotspotArray(stream, scene.hotspots);
        this.writeCommandArray(stream, scene.commands);
        this.writeTextObjectArray(stream, scene.textObjects);
        this.writeImageObjectArray(stream, scene.imageObjects);
    }

    writeHotspotArray(stream, hotspots) {
        stream.writeWord32(hotspots?.length || 0);
        for (const hs of (hotspots || [])) {
            stream.writeLString(hs.name || '');
            stream.writeRect(hs.rect || { left: 0, top: 0, right: 0, bottom: 0 });
            stream.writeWord(hs.cursor || 0);
            stream.writeLString(hs.action || '');
            stream.writeLString(hs.tooltip || '');
            stream.writeBool(hs.visible !== false);
            stream.writeBool(hs.enabled !== false);
        }
    }

    writeCommandArray(stream, commands) {
        stream.writeWord32(commands?.length || 0);
        for (const cmd of (commands || [])) {
            stream.writeWord(cmd.type || 0);
            stream.writeStringArray(cmd.params || []);
        }
    }

    writeTextObjectArray(stream, objects) {
        stream.writeWord32(objects?.length || 0);
        for (const obj of (objects || [])) {
            stream.writeLString(obj.name || '');
            stream.writeLString(obj.text || '');
            stream.writeRect(obj.rect || { left: 0, top: 0, right: 0, bottom: 0 });
            stream.writeLString(obj.fontName || 'Arial');
            stream.writeWord(obj.fontSize || 12);
            stream.writeWord(obj.fontStyle || 0);
            stream.writeColor(obj.color || 0x000000);
            stream.writeColor(obj.backgroundColor || 0xFFFFFF);
            stream.writeWord(obj.alignment || 0);
            stream.writeBool(obj.visible !== false);
        }
    }

    writeImageObjectArray(stream, objects) {
        stream.writeWord32(objects?.length || 0);
        for (const obj of (objects || [])) {
            stream.writeLString(obj.name || '');
            stream.writeLString(obj.filename || '');
            stream.writeRect(obj.rect || { left: 0, top: 0, right: 0, bottom: 0 });
            stream.writeBool(obj.transparent || false);
            stream.writeColor(obj.transparentColor || 0xFF00FF);
            stream.writeBool(obj.visible !== false);
        }
    }

    writeVariableArray(stream, variables) {
        stream.writeWord32(variables?.length || 0);
        for (const v of (variables || [])) {
            stream.writeLString(v.name || '');
            stream.writeInt32(v.value || 0);
            stream.writeWord(v.type || 0);
        }
    }

    writeResourceArray(stream, resources) {
        stream.writeWord32(resources?.length || 0);
        for (const res of (resources || [])) {
            stream.writeLString(res.name || '');
            stream.writeWord(res.type || 0);
            stream.writeLString(res.filename || '');
            stream.writeBool(res.embedded || false);
            if (res.embedded && res.data) {
                stream.writeWord32(res.data.length);
                stream.writeBytes(res.data);
            }
        }
    }
}

export default {
    VNStreamableBase,
    VNInputStream,
    VNOutputStream,
    VNFileStream,
    VNProjectReader,
    VNProjectWriter
};
