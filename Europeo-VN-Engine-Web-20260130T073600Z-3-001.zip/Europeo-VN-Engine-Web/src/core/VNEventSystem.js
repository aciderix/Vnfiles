/**
 * VNEventSystem - Event and Command System
 * 
 * EXACT PORT from europeo.exe event handling
 * Based on TVNEventCommand, TVNEventCommandArray classes
 * 
 * Original classes from RTTI:
 * - TVNEventCommand @ 0x0040f6de
 * - TVNEventCommandArray @ 0x0040f67e
 * - TArrayAsVector<TVNEventCommand> @ 0x000108ed
 * - TMArrayAsVector<TVNEventCommand,TStandardAllocator> @ 0x00010c0a
 */

/**
 * Event types used by the VN engine
 * Mapped from Windows messages
 */
export const VNEventType = {
    // Mouse events
    MOUSE_MOVE: 'mousemove',        // WM_MOUSEMOVE
    MOUSE_DOWN: 'mousedown',        // WM_LBUTTONDOWN
    MOUSE_UP: 'mouseup',            // WM_LBUTTONUP
    MOUSE_CLICK: 'click',           // Click combo
    MOUSE_DBLCLICK: 'dblclick',     // WM_LBUTTONDBLCLK
    MOUSE_RDOWN: 'contextmenu',     // WM_RBUTTONDOWN
    MOUSE_RUP: 'rightup',           // WM_RBUTTONUP
    MOUSE_ENTER: 'mouseenter',      // WM_MOUSEENTER (synthetic)
    MOUSE_LEAVE: 'mouseleave',      // WM_MOUSELEAVE
    MOUSE_WHEEL: 'wheel',           // WM_MOUSEWHEEL

    // Keyboard events
    KEY_DOWN: 'keydown',            // WM_KEYDOWN
    KEY_UP: 'keyup',                // WM_KEYUP
    KEY_PRESS: 'keypress',          // WM_CHAR

    // Window events
    PAINT: 'paint',                 // WM_PAINT
    SIZE: 'size',                   // WM_SIZE
    MOVE: 'move',                   // WM_MOVE
    CLOSE: 'close',                 // WM_CLOSE
    DESTROY: 'destroy',             // WM_DESTROY
    ACTIVATE: 'activate',           // WM_ACTIVATE
    FOCUS: 'focus',                 // WM_SETFOCUS
    BLUR: 'blur',                   // WM_KILLFOCUS

    // Timer events
    TIMER: 'timer',                 // WM_TIMER

    // Command events (VN-specific)
    COMMAND: 'command',             // WM_COMMAND
    NOTIFY: 'notify',               // WM_NOTIFY

    // Media events
    MEDIA_END: 'mediaend',          // MCI_NOTIFY
    MEDIA_ERROR: 'mediaerror',

    // Scene events
    SCENE_LOAD: 'sceneload',
    SCENE_UNLOAD: 'sceneunload',
    SCENE_ENTER: 'sceneenter',
    SCENE_EXIT: 'sceneexit',

    // Hotspot events
    HOTSPOT_ENTER: 'hotspotenter',
    HOTSPOT_LEAVE: 'hotsportleave',
    HOTSPOT_CLICK: 'hotspotclick',

    // Engine events
    ENGINE_INIT: 'engineinit',
    ENGINE_READY: 'engineready',
    ENGINE_PAUSE: 'enginepause',
    ENGINE_RESUME: 'engineresume',
    ENGINE_STOP: 'enginestop',

    // Custom events
    CUSTOM: 'custom'
};

/**
 * VNEvent - Base event class
 */
export class VNEvent {
    /**
     * @param {string} type - Event type
     * @param {Object} data - Event data
     */
    constructor(type, data = {}) {
        this.type = type;
        this.data = data;
        this.timestamp = Date.now();
        this.target = null;
        this.currentTarget = null;
        this.bubbles = true;
        this.cancelable = true;
        this.defaultPrevented = false;
        this.propagationStopped = false;
        this.immediatePropagationStopped = false;
    }

    /**
     * Prevent default action
     */
    preventDefault() {
        if (this.cancelable) {
            this.defaultPrevented = true;
        }
    }

    /**
     * Stop propagation
     */
    stopPropagation() {
        this.propagationStopped = true;
    }

    /**
     * Stop immediate propagation
     */
    stopImmediatePropagation() {
        this.immediatePropagationStopped = true;
        this.propagationStopped = true;
    }
}

/**
 * VNMouseEvent - Mouse event
 */
export class VNMouseEvent extends VNEvent {
    /**
     * @param {string} type 
     * @param {Object} data 
     */
    constructor(type, data = {}) {
        super(type, data);
        this.x = data.x || 0;
        this.y = data.y || 0;
        this.clientX = data.clientX || this.x;
        this.clientY = data.clientY || this.y;
        this.screenX = data.screenX || this.x;
        this.screenY = data.screenY || this.y;
        this.button = data.button || 0;
        this.buttons = data.buttons || 0;
        this.ctrlKey = data.ctrlKey || false;
        this.shiftKey = data.shiftKey || false;
        this.altKey = data.altKey || false;
        this.metaKey = data.metaKey || false;
    }

    /**
     * Create from DOM MouseEvent
     * @param {MouseEvent} domEvent 
     * @param {string} type 
     * @returns {VNMouseEvent}
     */
    static fromDOM(domEvent, type = null) {
        return new VNMouseEvent(type || domEvent.type, {
            x: domEvent.offsetX,
            y: domEvent.offsetY,
            clientX: domEvent.clientX,
            clientY: domEvent.clientY,
            screenX: domEvent.screenX,
            screenY: domEvent.screenY,
            button: domEvent.button,
            buttons: domEvent.buttons,
            ctrlKey: domEvent.ctrlKey,
            shiftKey: domEvent.shiftKey,
            altKey: domEvent.altKey,
            metaKey: domEvent.metaKey
        });
    }
}

/**
 * VNKeyEvent - Keyboard event
 */
export class VNKeyEvent extends VNEvent {
    /**
     * @param {string} type 
     * @param {Object} data 
     */
    constructor(type, data = {}) {
        super(type, data);
        this.key = data.key || '';
        this.code = data.code || '';
        this.keyCode = data.keyCode || 0;
        this.charCode = data.charCode || 0;
        this.ctrlKey = data.ctrlKey || false;
        this.shiftKey = data.shiftKey || false;
        this.altKey = data.altKey || false;
        this.metaKey = data.metaKey || false;
        this.repeat = data.repeat || false;
    }

    /**
     * Create from DOM KeyboardEvent
     * @param {KeyboardEvent} domEvent 
     * @returns {VNKeyEvent}
     */
    static fromDOM(domEvent) {
        return new VNKeyEvent(domEvent.type, {
            key: domEvent.key,
            code: domEvent.code,
            keyCode: domEvent.keyCode,
            charCode: domEvent.charCode,
            ctrlKey: domEvent.ctrlKey,
            shiftKey: domEvent.shiftKey,
            altKey: domEvent.altKey,
            metaKey: domEvent.metaKey,
            repeat: domEvent.repeat
        });
    }
}

/**
 * VNTimerEvent - Timer event
 */
export class VNTimerEvent extends VNEvent {
    /**
     * @param {Object} data 
     */
    constructor(data = {}) {
        super(VNEventType.TIMER, data);
        this.timerId = data.timerId || 0;
        this.elapsed = data.elapsed || 0;
        this.interval = data.interval || 0;
    }
}

/**
 * VNCommandEvent - Command event (from menu, hotspot, etc.)
 */
export class VNCommandEvent extends VNEvent {
    /**
     * @param {Object} data 
     */
    constructor(data = {}) {
        super(VNEventType.COMMAND, data);
        this.commandId = data.commandId || 0;
        this.commandName = data.commandName || '';
        this.params = data.params || [];
    }
}

/**
 * VNEventCommand - Event-triggered command
 * Port of TVNEventCommand
 */
export class VNEventCommand {
    /**
     * @param {string} eventType - Event type to listen for
     * @param {string} command - Command to execute
     * @param {Array} params - Command parameters
     */
    constructor(eventType = '', command = '', params = []) {
        this.eventType = eventType;
        this.command = command;
        this.params = params;
        this.enabled = true;
        this.priority = 0;
        this.condition = null; // Optional condition expression
    }

    /**
     * Check if this event command matches an event
     * @param {VNEvent} event 
     * @returns {boolean}
     */
    matches(event) {
        return this.enabled && this.eventType === event.type;
    }

    /**
     * Execute command
     * @param {Object} engine - Engine reference
     * @param {VNEvent} event 
     */
    execute(engine, event) {
        if (engine && engine.executeCommand) {
            engine.executeCommand(this.command, this.params, event);
        }
    }

    /**
     * Clone this event command
     * @returns {VNEventCommand}
     */
    clone() {
        const ec = new VNEventCommand(this.eventType, this.command, [...this.params]);
        ec.enabled = this.enabled;
        ec.priority = this.priority;
        ec.condition = this.condition;
        return ec;
    }
}

/**
 * VNEventCommandArray - Array of event commands
 * Port of TVNEventCommandArray
 */
export class VNEventCommandArray {
    constructor() {
        this.items = [];
    }

    /**
     * Add event command
     * @param {VNEventCommand} eventCommand 
     */
    add(eventCommand) {
        this.items.push(eventCommand);
        // Sort by priority (higher first)
        this.items.sort((a, b) => b.priority - a.priority);
    }

    /**
     * Remove event command
     * @param {VNEventCommand} eventCommand 
     */
    remove(eventCommand) {
        const index = this.items.indexOf(eventCommand);
        if (index !== -1) {
            this.items.splice(index, 1);
        }
    }

    /**
     * Remove all event commands for a specific event type
     * @param {string} eventType 
     */
    removeByType(eventType) {
        this.items = this.items.filter(ec => ec.eventType !== eventType);
    }

    /**
     * Clear all event commands
     */
    clear() {
        this.items = [];
    }

    /**
     * Get matching event commands for an event
     * @param {VNEvent} event 
     * @returns {VNEventCommand[]}
     */
    getMatching(event) {
        return this.items.filter(ec => ec.matches(event));
    }

    /**
     * Process an event
     * @param {Object} engine 
     * @param {VNEvent} event 
     */
    process(engine, event) {
        const matching = this.getMatching(event);
        for (const ec of matching) {
            ec.execute(engine, event);
            if (event.immediatePropagationStopped) {
                break;
            }
        }
    }

    /**
     * Get count
     * @returns {number}
     */
    get count() {
        return this.items.length;
    }

    /**
     * Get by index
     * @param {number} index 
     * @returns {VNEventCommand}
     */
    get(index) {
        return this.items[index];
    }

    /**
     * Iterate over items
     * @param {Function} callback 
     */
    forEach(callback) {
        this.items.forEach(callback);
    }
}

/**
 * VNEventDispatcher - Central event dispatching system
 */
export class VNEventDispatcher {
    constructor() {
        this.listeners = new Map();
        this.eventCommands = new VNEventCommandArray();
        this.captureListeners = new Map();
    }

    /**
     * Add event listener
     * @param {string} type 
     * @param {Function} listener 
     * @param {Object} options 
     */
    addEventListener(type, listener, options = {}) {
        const listenerMap = options.capture ? this.captureListeners : this.listeners;
        
        if (!listenerMap.has(type)) {
            listenerMap.set(type, []);
        }
        
        const listeners = listenerMap.get(type);
        listeners.push({
            callback: listener,
            once: options.once || false,
            priority: options.priority || 0
        });
        
        // Sort by priority
        listeners.sort((a, b) => b.priority - a.priority);
    }

    /**
     * Remove event listener
     * @param {string} type 
     * @param {Function} listener 
     * @param {Object} options 
     */
    removeEventListener(type, listener, options = {}) {
        const listenerMap = options.capture ? this.captureListeners : this.listeners;
        
        if (!listenerMap.has(type)) {
            return;
        }
        
        const listeners = listenerMap.get(type);
        const index = listeners.findIndex(l => l.callback === listener);
        if (index !== -1) {
            listeners.splice(index, 1);
        }
    }

    /**
     * Dispatch event
     * @param {VNEvent} event 
     * @returns {boolean} - True if event was not cancelled
     */
    dispatchEvent(event) {
        // Capture phase
        if (this.captureListeners.has(event.type)) {
            this._invokeListeners(event, this.captureListeners.get(event.type));
            if (event.propagationStopped) {
                return !event.defaultPrevented;
            }
        }

        // Target phase / Bubble phase
        if (this.listeners.has(event.type)) {
            this._invokeListeners(event, this.listeners.get(event.type));
        }

        // Process event commands
        this.eventCommands.process(null, event);

        return !event.defaultPrevented;
    }

    /**
     * Invoke listeners
     * @param {VNEvent} event 
     * @param {Array} listeners 
     */
    _invokeListeners(event, listeners) {
        const toRemove = [];
        
        for (const listener of listeners) {
            try {
                listener.callback(event);
            } catch (error) {
                console.error('Error in event listener:', error);
            }
            
            if (listener.once) {
                toRemove.push(listener);
            }
            
            if (event.immediatePropagationStopped) {
                break;
            }
        }
        
        // Remove once listeners
        for (const listener of toRemove) {
            const index = listeners.indexOf(listener);
            if (index !== -1) {
                listeners.splice(index, 1);
            }
        }
    }

    /**
     * Add event command
     * @param {string} eventType 
     * @param {string} command 
     * @param {Array} params 
     * @returns {VNEventCommand}
     */
    addEventCommand(eventType, command, params = []) {
        const ec = new VNEventCommand(eventType, command, params);
        this.eventCommands.add(ec);
        return ec;
    }

    /**
     * Remove event command
     * @param {VNEventCommand} eventCommand 
     */
    removeEventCommand(eventCommand) {
        this.eventCommands.remove(eventCommand);
    }

    /**
     * Check if has listeners for type
     * @param {string} type 
     * @returns {boolean}
     */
    hasListeners(type) {
        return (this.listeners.has(type) && this.listeners.get(type).length > 0) ||
               (this.captureListeners.has(type) && this.captureListeners.get(type).length > 0);
    }

    /**
     * Clear all listeners
     */
    clear() {
        this.listeners.clear();
        this.captureListeners.clear();
        this.eventCommands.clear();
    }

    /**
     * Shorthand for addEventListener
     */
    on(type, listener, options) {
        this.addEventListener(type, listener, options);
        return this;
    }

    /**
     * Shorthand for removeEventListener
     */
    off(type, listener, options) {
        this.removeEventListener(type, listener, options);
        return this;
    }

    /**
     * Add one-time listener
     */
    once(type, listener) {
        this.addEventListener(type, listener, { once: true });
        return this;
    }

    /**
     * Emit event (alias for dispatchEvent with auto-creation)
     * @param {string} type 
     * @param {Object} data 
     * @returns {boolean}
     */
    emit(type, data = {}) {
        return this.dispatchEvent(new VNEvent(type, data));
    }
}

/**
 * VNInputManager - Handles input from DOM
 * Converts DOM events to VN events
 */
export class VNInputManager {
    /**
     * @param {HTMLElement} element - Target element
     * @param {VNEventDispatcher} dispatcher 
     */
    constructor(element, dispatcher) {
        this.element = element;
        this.dispatcher = dispatcher;
        this.enabled = true;
        this.mousePosition = { x: 0, y: 0 };
        this.keysDown = new Set();
        this.buttonsDown = new Set();
        
        this._boundHandlers = {};
        this._setupEventListeners();
    }

    /**
     * Setup DOM event listeners
     */
    _setupEventListeners() {
        // Mouse events
        this._addHandler('mousemove', this._onMouseMove.bind(this));
        this._addHandler('mousedown', this._onMouseDown.bind(this));
        this._addHandler('mouseup', this._onMouseUp.bind(this));
        this._addHandler('click', this._onClick.bind(this));
        this._addHandler('dblclick', this._onDblClick.bind(this));
        this._addHandler('contextmenu', this._onContextMenu.bind(this));
        this._addHandler('mouseenter', this._onMouseEnter.bind(this));
        this._addHandler('mouseleave', this._onMouseLeave.bind(this));
        this._addHandler('wheel', this._onWheel.bind(this));

        // Keyboard events (on document)
        this._addHandler('keydown', this._onKeyDown.bind(this), document);
        this._addHandler('keyup', this._onKeyUp.bind(this), document);
        this._addHandler('keypress', this._onKeyPress.bind(this), document);
    }

    /**
     * Add DOM event handler
     */
    _addHandler(type, handler, target = this.element) {
        this._boundHandlers[type] = { handler, target };
        target.addEventListener(type, handler);
    }

    /**
     * Mouse move handler
     */
    _onMouseMove(e) {
        if (!this.enabled) return;
        this.mousePosition = { x: e.offsetX, y: e.offsetY };
        this.dispatcher.dispatchEvent(VNMouseEvent.fromDOM(e, VNEventType.MOUSE_MOVE));
    }

    /**
     * Mouse down handler
     */
    _onMouseDown(e) {
        if (!this.enabled) return;
        this.buttonsDown.add(e.button);
        this.dispatcher.dispatchEvent(VNMouseEvent.fromDOM(e, VNEventType.MOUSE_DOWN));
    }

    /**
     * Mouse up handler
     */
    _onMouseUp(e) {
        if (!this.enabled) return;
        this.buttonsDown.delete(e.button);
        this.dispatcher.dispatchEvent(VNMouseEvent.fromDOM(e, VNEventType.MOUSE_UP));
    }

    /**
     * Click handler
     */
    _onClick(e) {
        if (!this.enabled) return;
        this.dispatcher.dispatchEvent(VNMouseEvent.fromDOM(e, VNEventType.MOUSE_CLICK));
    }

    /**
     * Double click handler
     */
    _onDblClick(e) {
        if (!this.enabled) return;
        this.dispatcher.dispatchEvent(VNMouseEvent.fromDOM(e, VNEventType.MOUSE_DBLCLICK));
    }

    /**
     * Context menu handler
     */
    _onContextMenu(e) {
        if (!this.enabled) return;
        e.preventDefault();
        this.dispatcher.dispatchEvent(VNMouseEvent.fromDOM(e, VNEventType.MOUSE_RDOWN));
    }

    /**
     * Mouse enter handler
     */
    _onMouseEnter(e) {
        if (!this.enabled) return;
        this.dispatcher.dispatchEvent(VNMouseEvent.fromDOM(e, VNEventType.MOUSE_ENTER));
    }

    /**
     * Mouse leave handler
     */
    _onMouseLeave(e) {
        if (!this.enabled) return;
        this.dispatcher.dispatchEvent(VNMouseEvent.fromDOM(e, VNEventType.MOUSE_LEAVE));
    }

    /**
     * Wheel handler
     */
    _onWheel(e) {
        if (!this.enabled) return;
        const event = VNMouseEvent.fromDOM(e, VNEventType.MOUSE_WHEEL);
        event.deltaX = e.deltaX;
        event.deltaY = e.deltaY;
        event.deltaZ = e.deltaZ;
        event.deltaMode = e.deltaMode;
        this.dispatcher.dispatchEvent(event);
    }

    /**
     * Key down handler
     */
    _onKeyDown(e) {
        if (!this.enabled) return;
        this.keysDown.add(e.code);
        this.dispatcher.dispatchEvent(VNKeyEvent.fromDOM(e));
    }

    /**
     * Key up handler
     */
    _onKeyUp(e) {
        if (!this.enabled) return;
        this.keysDown.delete(e.code);
        this.dispatcher.dispatchEvent(VNKeyEvent.fromDOM(e));
    }

    /**
     * Key press handler
     */
    _onKeyPress(e) {
        if (!this.enabled) return;
        this.dispatcher.dispatchEvent(VNKeyEvent.fromDOM(e));
    }

    /**
     * Check if key is down
     * @param {string} code 
     * @returns {boolean}
     */
    isKeyDown(code) {
        return this.keysDown.has(code);
    }

    /**
     * Check if mouse button is down
     * @param {number} button 
     * @returns {boolean}
     */
    isButtonDown(button) {
        return this.buttonsDown.has(button);
    }

    /**
     * Get mouse position
     * @returns {{x: number, y: number}}
     */
    getMousePosition() {
        return { ...this.mousePosition };
    }

    /**
     * Enable input
     */
    enable() {
        this.enabled = true;
    }

    /**
     * Disable input
     */
    disable() {
        this.enabled = false;
    }

    /**
     * Destroy and cleanup
     */
    destroy() {
        for (const [type, { handler, target }] of Object.entries(this._boundHandlers)) {
            target.removeEventListener(type, handler);
        }
        this._boundHandlers = {};
    }
}

export default {
    VNEventType,
    VNEvent,
    VNMouseEvent,
    VNKeyEvent,
    VNTimerEvent,
    VNCommandEvent,
    VNEventCommand,
    VNEventCommandArray,
    VNEventDispatcher,
    VNInputManager
};
