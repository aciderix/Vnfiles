/**
 * VNEffects - Visual effects classes
 * 
 * Port of TVNZoomFx, TVNScrollFx and related effect classes
 * from europeo.exe
 */

import { VNTimerBasedFx } from './VNTimer.js';

/**
 * TVNZoomFx - Zoom effect
 * Port from europeo.exe (zoom handling in command handler)
 * Commands: zoom, zoomin, zoomout (cases 5, 13, 14)
 */
export class VNZoomFx extends VNTimerBasedFx {
    constructor() {
        super();
        
        this.name = 'zoom';
        this.type = 'zoom'; // 'zoom', 'zoomin', 'zoomout'
        
        // Zoom parameters
        this.startScale = 1.0;
        this.endScale = 2.0;
        this.centerX = 0.5;        // Relative center (0-1)
        this.centerY = 0.5;
        this.absoluteCenter = false; // If true, centerX/Y are pixels
        
        // Target element
        this._target = null;
        this._originalTransform = '';
    }

    /**
     * Set target element
     */
    setTarget(element) {
        this._target = element;
        if (element) {
            this._originalTransform = element.style.transform || '';
        }
        return this;
    }

    /**
     * Configure as zoom in
     */
    configureZoomIn(scale = 2.0) {
        this.type = 'zoomin';
        this.startScale = 1.0;
        this.endScale = scale;
        this.setRange(this.startScale, this.endScale);
        return this;
    }

    /**
     * Configure as zoom out
     */
    configureZoomOut(scale = 0.5) {
        this.type = 'zoomout';
        this.startScale = 1.0;
        this.endScale = scale;
        this.setRange(this.startScale, this.endScale);
        return this;
    }

    /**
     * Configure custom zoom
     */
    configureZoom(startScale, endScale, centerX = 0.5, centerY = 0.5) {
        this.type = 'zoom';
        this.startScale = startScale;
        this.endScale = endScale;
        this.centerX = centerX;
        this.centerY = centerY;
        this.setRange(startScale, endScale);
        return this;
    }

    /**
     * Start zoom effect
     */
    start() {
        this.setRange(this.startScale, this.endScale);
        
        this.onUpdate((scale, progress, fx) => {
            if (this._target) {
                this._applyZoom(scale);
            }
        });
        
        return super.start();
    }

    /**
     * Apply zoom transform to target
     */
    _applyZoom(scale) {
        if (!this._target) return;
        
        let originX, originY;
        if (this.absoluteCenter) {
            originX = `${this.centerX}px`;
            originY = `${this.centerY}px`;
        } else {
            originX = `${this.centerX * 100}%`;
            originY = `${this.centerY * 100}%`;
        }
        
        this._target.style.transformOrigin = `${originX} ${originY}`;
        this._target.style.transform = `${this._originalTransform} scale(${scale})`;
    }

    /**
     * Reset to original state
     */
    reset() {
        if (this._target) {
            this._target.style.transform = this._originalTransform;
            this._target.style.transformOrigin = '';
        }
        return super.stop();
    }

    serialize() {
        return {
            ...super.serialize(),
            type: this.type,
            startScale: this.startScale,
            endScale: this.endScale,
            centerX: this.centerX,
            centerY: this.centerY,
            absoluteCenter: this.absoluteCenter
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * TVNScrollFx - Scroll/Pan effect
 * Port from europeo.exe (scroll handling)
 */
export class VNScrollFx extends VNTimerBasedFx {
    constructor() {
        super();
        
        this.name = 'scroll';
        this.direction = 'horizontal'; // 'horizontal', 'vertical', 'both'
        
        // Scroll parameters
        this.startX = 0;
        this.startY = 0;
        this.endX = 0;
        this.endY = 0;
        
        // Target element
        this._target = null;
        this._originalScroll = { x: 0, y: 0 };
    }

    /**
     * Set target element
     */
    setTarget(element) {
        this._target = element;
        if (element) {
            this._originalScroll = {
                x: element.scrollLeft || 0,
                y: element.scrollTop || 0
            };
        }
        return this;
    }

    /**
     * Configure horizontal scroll
     */
    configureHorizontal(startX, endX) {
        this.direction = 'horizontal';
        this.startX = startX;
        this.endX = endX;
        this.startY = 0;
        this.endY = 0;
        return this;
    }

    /**
     * Configure vertical scroll
     */
    configureVertical(startY, endY) {
        this.direction = 'vertical';
        this.startX = 0;
        this.endX = 0;
        this.startY = startY;
        this.endY = endY;
        return this;
    }

    /**
     * Configure free scroll (both directions)
     */
    configureFree(startX, startY, endX, endY) {
        this.direction = 'both';
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        return this;
    }

    /**
     * Start scroll effect
     */
    start() {
        this.setRange(0, 1);
        
        this.onUpdate((value, progress, fx) => {
            if (this._target) {
                this._applyScroll(progress);
            }
        });
        
        return super.start();
    }

    /**
     * Apply scroll position
     */
    _applyScroll(progress) {
        if (!this._target) return;
        
        const currentX = this.startX + (this.endX - this.startX) * progress;
        const currentY = this.startY + (this.endY - this.startY) * progress;
        
        if (this.direction === 'horizontal' || this.direction === 'both') {
            this._target.scrollLeft = currentX;
        }
        if (this.direction === 'vertical' || this.direction === 'both') {
            this._target.scrollTop = currentY;
        }
    }

    /**
     * Get current scroll position
     */
    getCurrentPosition() {
        const progress = this.getProgress();
        return {
            x: this.startX + (this.endX - this.startX) * progress,
            y: this.startY + (this.endY - this.startY) * progress
        };
    }

    serialize() {
        return {
            ...super.serialize(),
            direction: this.direction,
            startX: this.startX,
            startY: this.startY,
            endX: this.endX,
            endY: this.endY
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * VNFadeEffect - Fade in/out effect
 */
export class VNFadeEffect extends VNTimerBasedFx {
    constructor() {
        super();
        
        this.name = 'fade';
        this.type = 'in'; // 'in', 'out', 'crossfade'
        this.startOpacity = 0;
        this.endOpacity = 1;
        
        this._target = null;
    }

    setTarget(element) {
        this._target = element;
        return this;
    }

    configureFadeIn() {
        this.type = 'in';
        this.startOpacity = 0;
        this.endOpacity = 1;
        this.setRange(0, 1);
        return this;
    }

    configureFadeOut() {
        this.type = 'out';
        this.startOpacity = 1;
        this.endOpacity = 0;
        this.setRange(1, 0);
        return this;
    }

    start() {
        this.setRange(this.startOpacity, this.endOpacity);
        
        this.onUpdate((opacity, progress, fx) => {
            if (this._target) {
                this._target.style.opacity = opacity;
            }
        });
        
        return super.start();
    }

    serialize() {
        return {
            ...super.serialize(),
            type: this.type,
            startOpacity: this.startOpacity,
            endOpacity: this.endOpacity
        };
    }
}

/**
 * VNSlideEffect - Slide transition effect
 */
export class VNSlideEffect extends VNTimerBasedFx {
    constructor() {
        super();
        
        this.name = 'slide';
        this.direction = 'left'; // 'left', 'right', 'up', 'down'
        this.distance = 100; // pixels or percentage
        this.usePercentage = false;
        
        this._target = null;
        this._originalPosition = { x: 0, y: 0 };
    }

    setTarget(element) {
        this._target = element;
        if (element) {
            const rect = element.getBoundingClientRect();
            this._originalPosition = { x: rect.left, y: rect.top };
        }
        return this;
    }

    configureSlide(direction, distance = 100, usePercentage = false) {
        this.direction = direction;
        this.distance = distance;
        this.usePercentage = usePercentage;
        return this;
    }

    start() {
        this.setRange(0, 1);
        
        this.onUpdate((value, progress, fx) => {
            if (this._target) {
                this._applySlide(progress);
            }
        });
        
        return super.start();
    }

    _applySlide(progress) {
        if (!this._target) return;
        
        let dist = this.distance;
        if (this.usePercentage) {
            const rect = this._target.getBoundingClientRect();
            if (this.direction === 'left' || this.direction === 'right') {
                dist = rect.width * (this.distance / 100);
            } else {
                dist = rect.height * (this.distance / 100);
            }
        }
        
        const offset = dist * (1 - progress);
        let translateX = 0, translateY = 0;
        
        switch (this.direction) {
            case 'left':
                translateX = -offset;
                break;
            case 'right':
                translateX = offset;
                break;
            case 'up':
                translateY = -offset;
                break;
            case 'down':
                translateY = offset;
                break;
        }
        
        this._target.style.transform = `translate(${translateX}px, ${translateY}px)`;
    }

    serialize() {
        return {
            ...super.serialize(),
            direction: this.direction,
            distance: this.distance,
            usePercentage: this.usePercentage
        };
    }
}

/**
 * VNShakeEffect - Shake/vibrate effect
 */
export class VNShakeEffect extends VNTimerBasedFx {
    constructor() {
        super();
        
        this.name = 'shake';
        this.intensity = 10;    // Max displacement in pixels
        this.frequency = 20;    // Shakes per second
        
        this._target = null;
        this._originalTransform = '';
    }

    setTarget(element) {
        this._target = element;
        if (element) {
            this._originalTransform = element.style.transform || '';
        }
        return this;
    }

    configure(intensity = 10, frequency = 20) {
        this.intensity = intensity;
        this.frequency = frequency;
        return this;
    }

    start() {
        this.setRange(0, 1);
        
        this.onUpdate((value, progress, fx) => {
            if (this._target) {
                this._applyShake(progress);
            }
        });
        
        this.onComplete(() => {
            if (this._target) {
                this._target.style.transform = this._originalTransform;
            }
        });
        
        return super.start();
    }

    _applyShake(progress) {
        if (!this._target) return;
        
        const decay = 1 - progress; // Intensity decreases over time
        const phase = progress * this.duration * this.frequency / 1000 * Math.PI * 2;
        
        const offsetX = Math.sin(phase) * this.intensity * decay;
        const offsetY = Math.cos(phase * 1.5) * this.intensity * decay * 0.5;
        
        this._target.style.transform = `${this._originalTransform} translate(${offsetX}px, ${offsetY}px)`;
    }

    serialize() {
        return {
            ...super.serialize(),
            intensity: this.intensity,
            frequency: this.frequency
        };
    }
}

/**
 * VNTransitionEffect - Scene transition effects
 */
export class VNTransitionEffect extends VNTimerBasedFx {
    constructor() {
        super();
        
        this.name = 'transition';
        this.type = 'fade'; // 'fade', 'slide', 'wipe', 'dissolve', 'none'
        this.direction = 'left';
        
        this._outElement = null;
        this._inElement = null;
    }

    setElements(outElement, inElement) {
        this._outElement = outElement;
        this._inElement = inElement;
        return this;
    }

    configureTransition(type, direction = 'left') {
        this.type = type;
        this.direction = direction;
        return this;
    }

    start() {
        this.setRange(0, 1);
        
        // Initialize in element
        if (this._inElement) {
            this._inElement.style.opacity = '0';
            this._inElement.style.display = 'block';
        }
        
        this.onUpdate((value, progress, fx) => {
            this._applyTransition(progress);
        });
        
        this.onComplete(() => {
            if (this._outElement) {
                this._outElement.style.display = 'none';
            }
            if (this._inElement) {
                this._inElement.style.opacity = '1';
                this._inElement.style.transform = '';
            }
        });
        
        return super.start();
    }

    _applyTransition(progress) {
        switch (this.type) {
            case 'fade':
                this._applyFadeTransition(progress);
                break;
            case 'slide':
                this._applySlideTransition(progress);
                break;
            case 'wipe':
                this._applyWipeTransition(progress);
                break;
            case 'dissolve':
                this._applyDissolveTransition(progress);
                break;
            default:
                // Instant transition
                if (progress >= 0.5) {
                    if (this._outElement) this._outElement.style.opacity = '0';
                    if (this._inElement) this._inElement.style.opacity = '1';
                }
        }
    }

    _applyFadeTransition(progress) {
        if (this._outElement) {
            this._outElement.style.opacity = 1 - progress;
        }
        if (this._inElement) {
            this._inElement.style.opacity = progress;
        }
    }

    _applySlideTransition(progress) {
        const offset = (1 - progress) * 100;
        let inTransform = '', outTransform = '';
        
        switch (this.direction) {
            case 'left':
                inTransform = `translateX(${100 - offset}%)`;
                outTransform = `translateX(${-offset}%)`;
                break;
            case 'right':
                inTransform = `translateX(${-(100 - offset)}%)`;
                outTransform = `translateX(${offset}%)`;
                break;
            case 'up':
                inTransform = `translateY(${100 - offset}%)`;
                outTransform = `translateY(${-offset}%)`;
                break;
            case 'down':
                inTransform = `translateY(${-(100 - offset)}%)`;
                outTransform = `translateY(${offset}%)`;
                break;
        }
        
        if (this._outElement) {
            this._outElement.style.transform = outTransform;
        }
        if (this._inElement) {
            this._inElement.style.transform = inTransform;
            this._inElement.style.opacity = '1';
        }
    }

    _applyWipeTransition(progress) {
        if (this._inElement) {
            let clipPath = '';
            switch (this.direction) {
                case 'left':
                    clipPath = `inset(0 ${(1-progress)*100}% 0 0)`;
                    break;
                case 'right':
                    clipPath = `inset(0 0 0 ${(1-progress)*100}%)`;
                    break;
                case 'up':
                    clipPath = `inset(0 0 ${(1-progress)*100}% 0)`;
                    break;
                case 'down':
                    clipPath = `inset(${(1-progress)*100}% 0 0 0)`;
                    break;
            }
            this._inElement.style.clipPath = clipPath;
            this._inElement.style.opacity = '1';
        }
    }

    _applyDissolveTransition(progress) {
        // Pixelated dissolve effect using opacity and blur
        if (this._outElement) {
            this._outElement.style.opacity = 1 - progress;
            this._outElement.style.filter = `blur(${progress * 5}px)`;
        }
        if (this._inElement) {
            this._inElement.style.opacity = progress;
            this._inElement.style.filter = `blur(${(1-progress) * 5}px)`;
        }
    }

    serialize() {
        return {
            ...super.serialize(),
            type: this.type,
            direction: this.direction
        };
    }
}

/**
 * Effect factory
 */
export class VNEffectFactory {
    static create(type, options = {}) {
        let effect;
        
        switch (type) {
            case 'zoom':
            case 'zoomin':
            case 'zoomout':
                effect = new VNZoomFx();
                if (type === 'zoomin') effect.configureZoomIn(options.scale);
                else if (type === 'zoomout') effect.configureZoomOut(options.scale);
                break;
                
            case 'scroll':
            case 'pan':
                effect = new VNScrollFx();
                break;
                
            case 'fade':
            case 'fadein':
            case 'fadeout':
                effect = new VNFadeEffect();
                if (type === 'fadein') effect.configureFadeIn();
                else if (type === 'fadeout') effect.configureFadeOut();
                break;
                
            case 'slide':
                effect = new VNSlideEffect();
                if (options.direction) effect.configureSlide(options.direction, options.distance);
                break;
                
            case 'shake':
                effect = new VNShakeEffect();
                if (options.intensity) effect.configure(options.intensity, options.frequency);
                break;
                
            case 'transition':
                effect = new VNTransitionEffect();
                if (options.transitionType) effect.configureTransition(options.transitionType, options.direction);
                break;
                
            default:
                effect = new VNTimerBasedFx();
        }
        
        // Apply common options
        if (options.duration) effect.duration = options.duration;
        if (options.easing) effect.easing = options.easing;
        if (options.loop !== undefined) effect.loop = options.loop;
        if (options.delay) effect.delay = options.delay;
        
        return effect;
    }
}

export default {
    VNZoomFx,
    VNScrollFx,
    VNFadeEffect,
    VNSlideEffect,
    VNShakeEffect,
    VNTransitionEffect,
    VNEffectFactory
};
