/**
 * VNEngine - Main engine class
 * Port of TVNEngine / TVNApplication from europeo.exe
 * 
 * Original class hierarchy:
 * - TApplication (OWL) @ 0x0043948c
 * - TFrameWindow @ 0x0043942c
 * - TVNApplication (custom) - main window handling
 * 
 * Window message handling:
 * - TWindow_HandleMessage @ 0x004394f2
 * - WM_COMMAND (0x111) handlers
 * - wm_vncommand (custom message for VN commands)
 * 
 * Main command dispatcher: fcn.0040b990 (7328 bytes, 49 cases)
 */

import { VNVariable, vnVariables } from './VNVariable.js';
import { VNCommandParser, CMD } from './VNCommandParser.js';
import { VNScene, VNSceneArray, SCENE_FLAGS } from './VNScene.js';
import { VNAudio, VNVideo, VNTimer, MEDIA_STATE } from '../media/VNMedia.js';

/**
 * Engine state constants
 */
const ENGINE_STATE = {
    UNINITIALIZED: 0,
    INITIALIZING: 1,
    READY: 2,
    RUNNING: 3,
    PAUSED: 4,
    ERROR: 5
};

/**
 * Cursor types (from defcursor / cursor handling)
 */
const CURSOR_TYPE = {
    DEFAULT: 'default',
    POINTER: 'pointer',
    HAND: 'pointer',
    WAIT: 'wait',
    CROSSHAIR: 'crosshair',
    TEXT: 'text',
    MOVE: 'move',
    HELP: 'help',
    CUSTOM: 'url'
};

class VNEngine {
    /**
     * Constructor
     * Original: TVNApplication constructor via TApplication__bctr @ 0x0043948c
     */
    constructor(config = {}) {
        // Configuration (from INI file handling @ fcn.0040d6f4)
        this.config = {
            gameId: config.gameId || 'vnengine',
            basePath: config.basePath || '',
            width: config.width || 800,
            height: config.height || 600,
            debug: config.debug || false,
            ...config
        };
        
        // State
        this._state = ENGINE_STATE.UNINITIALIZED;
        
        // DOM elements
        this._container = null;
        this._canvas = null;
        this._ctx = null;
        this._uiLayer = null;
        this._dialogLayer = null;
        
        // Core systems
        this.variables = vnVariables;
        this.parser = new VNCommandParser(this);
        this.scenes = new VNSceneArray();
        this.audio = new VNAudio();
        this.video = new VNVideo();
        this.timer = new VNTimer();
        
        // Current state
        this._currentScene = null;
        this._background = null;
        this._backgroundImage = null;
        
        // Objects
        this._imageObjects = new Map();
        this._textObjects = new Map();
        this._hotspots = new Map();
        
        // UI state
        this._cursor = CURSOR_TYPE.DEFAULT;
        this._currentHotspot = null;
        this._tooltipElement = null;
        
        // Dialog state
        this._dialogElement = null;
        this._dialogText = '';
        this._dialogName = '';
        this._dialogVisible = false;
        this._textSpeed = 30; // ms per character
        this._autoAdvance = false;
        
        // Font settings
        this._font = {
            name: 'Arial',
            size: 16,
            bold: false,
            italic: false,
            color: '#ffffff'
        };
        
        // Zoom state
        this._zoomed = false;
        this._zoomLevel = 1;
        
        // Callbacks
        this.onQuit = null;
        this.onAbout = null;
        this.onPrefs = null;
        this.onSceneChange = null;
        
        // Project data
        this._project = null;
    }

    /**
     * Initialize engine
     * Original: TApplication_InitInstance @ 0x004394aa
     */
    async init(containerElement) {
        if (this._state !== ENGINE_STATE.UNINITIALIZED) {
            return false;
        }
        
        this._state = ENGINE_STATE.INITIALIZING;
        
        try {
            // Set up container
            if (typeof containerElement === 'string') {
                this._container = document.getElementById(containerElement);
            } else {
                this._container = containerElement;
            }
            
            if (!this._container) {
                throw new Error('Container element not found');
            }
            
            // Set container style
            this._container.style.position = 'relative';
            this._container.style.width = this.config.width + 'px';
            this._container.style.height = this.config.height + 'px';
            this._container.style.overflow = 'hidden';
            this._container.style.backgroundColor = '#000000';
            
            // Create canvas layer (for background and images)
            this._canvas = document.createElement('canvas');
            this._canvas.width = this.config.width;
            this._canvas.height = this.config.height;
            this._canvas.style.position = 'absolute';
            this._canvas.style.left = '0';
            this._canvas.style.top = '0';
            this._container.appendChild(this._canvas);
            this._ctx = this._canvas.getContext('2d');
            
            // Create UI layer (for hotspots and interactive elements)
            this._uiLayer = document.createElement('div');
            this._uiLayer.className = 'vn-ui-layer';
            this._uiLayer.style.position = 'absolute';
            this._uiLayer.style.left = '0';
            this._uiLayer.style.top = '0';
            this._uiLayer.style.width = '100%';
            this._uiLayer.style.height = '100%';
            this._uiLayer.style.pointerEvents = 'none';
            this._container.appendChild(this._uiLayer);
            
            // Create dialog layer
            this._dialogLayer = document.createElement('div');
            this._dialogLayer.className = 'vn-dialog-layer';
            this._dialogLayer.style.position = 'absolute';
            this._dialogLayer.style.left = '0';
            this._dialogLayer.style.bottom = '0';
            this._dialogLayer.style.width = '100%';
            this._dialogLayer.style.display = 'none';
            this._container.appendChild(this._dialogLayer);
            
            // Create tooltip element
            this._tooltipElement = document.createElement('div');
            this._tooltipElement.className = 'vn-tooltip';
            this._tooltipElement.style.position = 'absolute';
            this._tooltipElement.style.display = 'none';
            this._container.appendChild(this._tooltipElement);
            
            // Initialize audio
            await this.audio.init();
            
            // Initialize video
            this.video.init(this._container);
            
            // Set up event listeners
            this._setupEventListeners();
            
            this._state = ENGINE_STATE.READY;
            
            if (this.config.debug) {
                console.log('VNEngine initialized');
            }
            
            return true;
        } catch (error) {
            console.error('Failed to initialize engine:', error);
            this._state = ENGINE_STATE.ERROR;
            return false;
        }
    }

    /**
     * Set up event listeners
     * Original: Message map in TWindow @ 0x004394f2
     */
    _setupEventListeners() {
        // Mouse move - handle hotspot detection
        this._container.addEventListener('mousemove', (e) => {
            const rect = this._container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            this._handleMouseMove(x, y);
        });
        
        // Mouse click
        this._container.addEventListener('click', (e) => {
            const rect = this._container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            this._handleClick(x, y);
        });
        
        // Keyboard
        document.addEventListener('keydown', (e) => {
            this._handleKeyDown(e);
        });
    }

    /**
     * Handle mouse move
     * Original: WM_MOUSEMOVE handling, PtInRegion @ 0x004397ec
     */
    _handleMouseMove(x, y) {
        // Find hotspot at point
        let foundHotspot = null;
        
        for (const [id, hotspot] of this._hotspots) {
            if (x >= hotspot.x && x <= hotspot.x + hotspot.width &&
                y >= hotspot.y && y <= hotspot.y + hotspot.height) {
                foundHotspot = hotspot;
                break;
            }
        }
        
        // Handle hotspot change
        if (foundHotspot !== this._currentHotspot) {
            // Leave old hotspot
            if (this._currentHotspot && this._currentHotspot.onfocus) {
                // Fire onfocus leave event
            }
            
            this._currentHotspot = foundHotspot;
            
            // Enter new hotspot
            if (foundHotspot) {
                // Set cursor
                if (foundHotspot.cursor) {
                    this._container.style.cursor = foundHotspot.cursor;
                } else {
                    this._container.style.cursor = CURSOR_TYPE.POINTER;
                }
                
                // Show tooltip
                if (foundHotspot.tiptext) {
                    this._showTooltip(foundHotspot.tiptext, x, y);
                }
                
                // Fire onfocus event
                if (foundHotspot.onfocus) {
                    const cmd = this.parser.parse(foundHotspot.onfocus);
                    if (cmd) {
                        this.parser.execute(cmd);
                    }
                }
            } else {
                this._container.style.cursor = this._cursor;
                this._hideTooltip();
            }
        }
        
        // Update tooltip position
        if (foundHotspot && foundHotspot.tiptext) {
            this._updateTooltipPosition(x, y);
        }
    }

    /**
     * Handle click
     * Original: WM_LBUTTONDOWN / WM_LBUTTONUP handling
     */
    async _handleClick(x, y) {
        // Handle dialog click (advance text)
        if (this._dialogVisible) {
            this._advanceDialog();
            return;
        }
        
        // Handle hotspot click
        if (this._currentHotspot && this._currentHotspot.onclick) {
            const cmd = this.parser.parse(this._currentHotspot.onclick);
            if (cmd) {
                await this.parser.execute(cmd);
            }
        }
    }

    /**
     * Handle key down
     */
    _handleKeyDown(e) {
        switch (e.key) {
            case ' ':
            case 'Enter':
                if (this._dialogVisible) {
                    this._advanceDialog();
                    e.preventDefault();
                }
                break;
            case 'Escape':
                if (this._dialogVisible) {
                    this.hideDialog();
                    e.preventDefault();
                }
                break;
        }
    }

    /**
     * Load project file
     * Original: Project loading from INI/PRJ files
     */
    async loadProject(url) {
        try {
            const response = await fetch(this.config.basePath + '/' + url);
            this._project = await response.json();
            
            // Load scenes
            if (this._project.scenes) {
                for (const sceneData of this._project.scenes) {
                    this.scenes.add(sceneData);
                }
            }
            
            // Load initial variables
            if (this._project.variables) {
                this.variables.loadAll(this._project.variables);
            }
            
            // Load start scene
            const startScene = this._project.startScene || 0;
            await this.loadSceneByIndex(startScene);
            
            this._state = ENGINE_STATE.RUNNING;
            
            return true;
        } catch (error) {
            console.error('Failed to load project:', error);
            return false;
        }
    }

    /**
     * Load scene by index
     * Original: Scene loading at case 6 in fcn.0040b990
     */
    async loadSceneByIndex(index) {
        const scene = this.scenes.getByIndex(index);
        if (!scene) {
            console.error(`Scene not found at index ${index}`);
            return false;
        }
        
        return this._loadScene(scene, index);
    }

    /**
     * Load scene by name
     */
    async loadScene(name) {
        const scene = this.scenes.getByName(name);
        if (!scene) {
            console.error(`Scene not found: ${name}`);
            return false;
        }
        
        const index = this.scenes._scenes.indexOf(scene);
        return this._loadScene(scene, index);
    }

    /**
     * Load scene relative to current (+n or -n)
     * Original: Handles + and - prefix at 0x40bdb1
     */
    async loadSceneRelative(offset) {
        const newIndex = this.scenes.currentIndex + offset;
        return this.loadSceneByIndex(newIndex);
    }

    /**
     * Internal scene loading
     */
    async _loadScene(scene, index) {
        // Unload current scene
        if (this._currentScene) {
            await this._currentScene.unload(this);
        }
        
        // Clear objects
        this._imageObjects.clear();
        this._textObjects.clear();
        this._hotspots.clear();
        this._uiLayer.innerHTML = '';
        
        // Set new scene
        this._currentScene = scene;
        this.scenes.currentIndex = index;
        
        // Load scene
        await scene.load(this);
        await scene.activate(this);
        
        // Fire callback
        if (this.onSceneChange) {
            this.onSceneChange(scene, index);
        }
        
        // Render
        this.render();
        
        return true;
    }

    /**
     * Previous scene (case 3)
     */
    async prevScene() {
        if (this.scenes.currentIndex > 0) {
            return this.loadSceneByIndex(this.scenes.currentIndex - 1);
        }
        return false;
    }

    /**
     * Next scene (case 4)
     */
    async nextScene() {
        if (this.scenes.currentIndex < this.scenes.count - 1) {
            return this.loadSceneByIndex(this.scenes.currentIndex + 1);
        }
        return false;
    }

    /**
     * Load and set background image
     * Original: playbmp command (case 10)
     */
    async loadBackground(filename) {
        const url = this.config.basePath + '/images/' + filename;
        
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                this._backgroundImage = img;
                this._background = filename;
                this.render();
                resolve(true);
            };
            img.onerror = () => {
                console.error(`Failed to load background: ${filename}`);
                reject(new Error(`Failed to load background: ${filename}`));
            };
            img.src = url;
        });
    }

    /**
     * Set background (alias)
     */
    async setBackground(filename, params = {}) {
        return this.loadBackground(filename);
    }

    /**
     * Load music
     */
    async loadMusic(filename, options = {}) {
        const url = this.config.basePath + '/audio/' + filename;
        return this.audio.playMusic(url, options);
    }

    /**
     * Play music (case 12)
     */
    async playMusic(filename, options = {}) {
        return this.loadMusic(filename, options);
    }

    /**
     * Stop music (case 48)
     */
    stopMusic() {
        return this.audio.stopMusic();
    }

    /**
     * Play sound effect (case 11)
     */
    async playSound(filename, options = {}) {
        const url = this.config.basePath + '/audio/' + filename;
        return this.audio.playSound(url, options);
    }

    /**
     * Stop sound (case 36)
     */
    stopSound() {
        return this.audio.stopSound();
    }

    /**
     * Play video (case 9)
     */
    async playVideo(filename, options = {}) {
        const url = this.config.basePath + '/video/' + filename;
        return this.video.play(url, options);
    }

    /**
     * Stop video (case 47)
     */
    stopVideo() {
        return this.video.stop();
    }

    /**
     * Add hotspot (case 7)
     */
    addHotspot(hotspot) {
        this._hotspots.set(hotspot.id, hotspot);
        
        // Create visual element (for debugging)
        if (this.config.debug) {
            const elem = document.createElement('div');
            elem.className = 'vn-hotspot-debug';
            elem.style.position = 'absolute';
            elem.style.left = hotspot.x + 'px';
            elem.style.top = hotspot.y + 'px';
            elem.style.width = hotspot.width + 'px';
            elem.style.height = hotspot.height + 'px';
            elem.style.border = '1px solid rgba(255,0,0,0.5)';
            elem.style.pointerEvents = 'none';
            this._uiLayer.appendChild(elem);
        }
        
        return true;
    }

    /**
     * Remove hotspot
     */
    removeHotspot(id) {
        return this._hotspots.delete(id);
    }

    /**
     * Set tiptext (case 8)
     */
    setTiptext(id, text) {
        const hotspot = this._hotspots.get(id);
        if (hotspot) {
            hotspot.tiptext = text;
            return true;
        }
        return false;
    }

    /**
     * Show tooltip
     */
    _showTooltip(text, x, y) {
        this._tooltipElement.textContent = text;
        this._tooltipElement.style.display = 'block';
        this._updateTooltipPosition(x, y);
    }

    /**
     * Update tooltip position
     */
    _updateTooltipPosition(x, y) {
        this._tooltipElement.style.left = (x + 15) + 'px';
        this._tooltipElement.style.top = (y + 15) + 'px';
    }

    /**
     * Hide tooltip
     */
    _hideTooltip() {
        this._tooltipElement.style.display = 'none';
    }

    /**
     * Add image object (case 27)
     */
    async addImageObject(obj) {
        const url = this.config.basePath + '/images/' + obj.file;
        
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                const imageObj = {
                    ...obj,
                    image: img,
                    visible: obj.visible !== false,
                    layer: obj.layer || 0
                };
                this._imageObjects.set(obj.name, imageObj);
                this.render();
                resolve(true);
            };
            img.onerror = () => {
                console.error(`Failed to load image: ${obj.file}`);
                reject(new Error(`Failed to load image: ${obj.file}`));
            };
            img.src = url;
        });
    }

    /**
     * Remove image object (case 28)
     */
    removeImageObject(name) {
        const result = this._imageObjects.delete(name);
        if (result) {
            this.render();
        }
        return result;
    }

    /**
     * Add text object (case 41)
     */
    addTextObject(obj) {
        const textObj = {
            ...obj,
            visible: obj.visible !== false,
            color: obj.color || this._font.color,
            font: obj.font || `${this._font.size}px ${this._font.name}`
        };
        this._textObjects.set(obj.name, textObj);
        this.render();
        return true;
    }

    /**
     * Remove object (case 42 - delobj)
     */
    removeObject(name) {
        let removed = false;
        if (this._imageObjects.delete(name)) removed = true;
        if (this._textObjects.delete(name)) removed = true;
        if (removed) this.render();
        return removed;
    }

    /**
     * Show object (case 43)
     */
    showObject(name) {
        let obj = this._imageObjects.get(name);
        if (obj) {
            obj.visible = true;
            this.render();
            return true;
        }
        obj = this._textObjects.get(name);
        if (obj) {
            obj.visible = true;
            this.render();
            return true;
        }
        return false;
    }

    /**
     * Hide object (case 44)
     */
    hideObject(name) {
        let obj = this._imageObjects.get(name);
        if (obj) {
            obj.visible = false;
            this.render();
            return true;
        }
        obj = this._textObjects.get(name);
        if (obj) {
            obj.visible = false;
            this.render();
            return true;
        }
        return false;
    }

    /**
     * Show dialog (case 38 - playtext)
     */
    showDialog(text, name = '') {
        this._dialogText = text;
        this._dialogName = name;
        this._dialogVisible = true;
        
        // Create dialog HTML
        this._dialogLayer.innerHTML = `
            <div class="vn-dialog">
                ${name ? `<div class="vn-dialog-name">${name}</div>` : ''}
                <div class="vn-dialog-text">${text}</div>
            </div>
        `;
        this._dialogLayer.style.display = 'block';
        
        return true;
    }

    /**
     * Hide dialog
     */
    hideDialog() {
        this._dialogVisible = false;
        this._dialogLayer.style.display = 'none';
        return true;
    }

    /**
     * Advance dialog (click to continue)
     */
    _advanceDialog() {
        this.hideDialog();
    }

    /**
     * Set font (case 39)
     */
    setFont(font) {
        Object.assign(this._font, font);
        return true;
    }

    /**
     * Set default cursor (case 26)
     */
    setDefaultCursor(cursor) {
        this._cursor = cursor || CURSOR_TYPE.DEFAULT;
        this._container.style.cursor = this._cursor;
        return true;
    }

    /**
     * Invalidate/refresh display (case 25)
     * Original: InvalidateRect(hwnd, NULL, TRUE)
     */
    invalidate() {
        this.render();
        return true;
    }

    /**
     * Update display (case 32)
     */
    update() {
        this.render();
        return true;
    }

    /**
     * Zoom toggle (case 5)
     */
    toggleZoom() {
        this._zoomed = !this._zoomed;
        // Implement zoom logic
        return true;
    }

    /**
     * Zoom in (case 14)
     */
    zoomIn() {
        this._zoomLevel = Math.min(this._zoomLevel * 1.5, 4);
        this.render();
        return true;
    }

    /**
     * Zoom out (case 15)
     */
    zoomOut() {
        this._zoomLevel = Math.max(this._zoomLevel / 1.5, 1);
        this.render();
        return true;
    }

    /**
     * Show HTML content (case 13)
     */
    showHtml(content) {
        // Create overlay for HTML content
        const overlay = document.createElement('div');
        overlay.className = 'vn-html-overlay';
        overlay.innerHTML = content;
        overlay.style.position = 'absolute';
        overlay.style.left = '0';
        overlay.style.top = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = 'rgba(0,0,0,0.8)';
        overlay.style.color = '#ffffff';
        overlay.style.padding = '20px';
        overlay.style.boxSizing = 'border-box';
        overlay.style.overflow = 'auto';
        
        overlay.onclick = () => {
            overlay.remove();
        };
        
        this._container.appendChild(overlay);
        return true;
    }

    /**
     * Save game (case 46)
     */
    async saveGame(slot = 0) {
        const saveData = {
            version: 1,
            gameId: this.config.gameId,
            timestamp: Date.now(),
            sceneIndex: this.scenes.currentIndex,
            variables: this.variables.getAll()
        };
        
        const key = `${this.config.gameId}_save_${slot}`;
        localStorage.setItem(key, JSON.stringify(saveData));
        
        return true;
    }

    /**
     * Load game (case 45)
     */
    async loadGame(slot = 0) {
        const key = `${this.config.gameId}_save_${slot}`;
        const data = localStorage.getItem(key);
        
        if (!data) {
            return false;
        }
        
        try {
            const saveData = JSON.parse(data);
            
            // Restore variables
            this.variables.loadAll(saveData.variables);
            
            // Restore scene
            await this.loadSceneByIndex(saveData.sceneIndex);
            
            return true;
        } catch (error) {
            console.error('Failed to load game:', error);
            return false;
        }
    }

    /**
     * Render the scene
     * Original: TWindow_Paint @ 0x004394ce
     * Main rendering function @ fcn.004200cf (6624 bytes)
     */
    render() {
        // Clear canvas
        this._ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
        
        // Apply zoom
        this._ctx.save();
        if (this._zoomLevel !== 1) {
            this._ctx.scale(this._zoomLevel, this._zoomLevel);
        }
        
        // Draw background
        if (this._backgroundImage) {
            this._ctx.drawImage(
                this._backgroundImage,
                0, 0,
                this._canvas.width / this._zoomLevel,
                this._canvas.height / this._zoomLevel
            );
        }
        
        // Draw image objects (sorted by layer)
        const sortedImages = [...this._imageObjects.values()]
            .filter(obj => obj.visible)
            .sort((a, b) => (a.layer || 0) - (b.layer || 0));
        
        for (const obj of sortedImages) {
            const x = obj.x || 0;
            const y = obj.y || 0;
            const w = obj.width || obj.image.width;
            const h = obj.height || obj.image.height;
            
            this._ctx.drawImage(obj.image, x, y, w, h);
        }
        
        // Draw text objects
        for (const [name, obj] of this._textObjects) {
            if (!obj.visible) continue;
            
            this._ctx.font = obj.font;
            this._ctx.fillStyle = obj.color;
            this._ctx.fillText(obj.text, obj.x, obj.y);
        }
        
        this._ctx.restore();
    }

    /**
     * Get engine state
     */
    get state() {
        return this._state;
    }

    /**
     * Get current scene
     */
    get currentScene() {
        return this._currentScene;
    }

    /**
     * Destroy engine
     */
    destroy() {
        this.timer.killAll();
        this.audio.stopSound();
        this.audio.stopMusic();
        this.video.stop();
        
        if (this._container) {
            this._container.innerHTML = '';
        }
        
        this._state = ENGINE_STATE.UNINITIALIZED;
    }
}

export { VNEngine, ENGINE_STATE, CURSOR_TYPE };
export default VNEngine;
