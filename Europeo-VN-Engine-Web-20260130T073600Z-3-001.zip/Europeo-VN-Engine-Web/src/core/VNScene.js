/**
 * VNScene - Exact port of TVNScene from europeo.exe
 * 
 * Original class structure (0x52 = 82 bytes per scene item):
 * - Offset 0x00: char name[32]       - Scene identifier
 * - Offset 0x20: char background[32] - Background image filename
 * - Offset 0x40: char music[16]      - Music filename
 * - Offset 0x50: uint16 flags        - Scene flags
 * 
 * Scene array handling from:
 * - TIArrayAsVector<TVNScene> @ 0x004183bd
 * - Scene loading @ fcn.00417031
 * - Scene properties @ TVNSceneProperties @ 0x004180c3
 * 
 * Events from 0x0043f8d0:
 * - EV_ONFOCUS
 * - EV_ONCLICK
 * - EV_ONINIT
 * - EV_AFTERINIT
 */

/**
 * Scene flags (from binary analysis)
 */
const SCENE_FLAGS = {
    NONE: 0x00,
    PRELOAD: 0x01,
    LOOP_MUSIC: 0x02,
    AUTO_ADVANCE: 0x04,
    HIDE_CURSOR: 0x08,
    DISABLE_INPUT: 0x10
};

/**
 * Event types
 */
const SCENE_EVENTS = {
    ONINIT: 'oninit',
    AFTERINIT: 'afterinit',
    ONFOCUS: 'onfocus',
    ONCLICK: 'onclick',
    ONENTER: 'onenter',
    ONLEAVE: 'onleave'
};

class VNScene {
    /**
     * Constructor - mirrors TVNScene allocation
     * Original: __bnew_qui(0x52) @ various locations
     */
    constructor(data = {}) {
        // Core properties (matching struct offsets)
        this.name = data.name || '';           // 0x00: 32 bytes
        this.background = data.background || ''; // 0x20: 32 bytes
        this.music = data.music || '';          // 0x40: 16 bytes
        this.flags = data.flags || 0;           // 0x50: 2 bytes
        
        // Extended properties
        this.id = data.id || 0;
        this.title = data.title || '';
        
        // Hotspots array (TVNHotspot linked list in original)
        this.hotspots = [];
        
        // Objects (images and text)
        this.objects = [];
        
        // Event handlers (from EV_* strings)
        this.events = {
            [SCENE_EVENTS.ONINIT]: data.oninit || null,
            [SCENE_EVENTS.AFTERINIT]: data.afterinit || null,
            [SCENE_EVENTS.ONFOCUS]: data.onfocus || null,
            [SCENE_EVENTS.ONCLICK]: data.onclick || null,
            [SCENE_EVENTS.ONENTER]: data.onenter || null,
            [SCENE_EVENTS.ONLEAVE]: data.onleave || null
        };
        
        // Script commands to execute
        this.script = data.script || [];
        
        // Additional scene data
        this.variables = data.variables || {};
        this.transitions = data.transitions || {};
        
        // Runtime state
        this._loaded = false;
        this._active = false;
    }

    /**
     * Load scene resources
     * Port of scene loading logic from fcn.00417031
     */
    async load(engine) {
        if (this._loaded) {
            return true;
        }
        
        try {
            // Fire ONINIT event
            await this._fireEvent(SCENE_EVENTS.ONINIT, engine);
            
            // Load background image
            if (this.background) {
                await engine.loadBackground(this.background);
            }
            
            // Load music
            if (this.music) {
                const options = {
                    loop: (this.flags & SCENE_FLAGS.LOOP_MUSIC) !== 0
                };
                await engine.loadMusic(this.music, options);
            }
            
            // Load hotspots
            for (const hotspot of this.hotspots) {
                await engine.addHotspot(hotspot);
            }
            
            // Load objects
            for (const obj of this.objects) {
                if (obj.type === 'image') {
                    await engine.addImageObject(obj);
                } else if (obj.type === 'text') {
                    await engine.addTextObject(obj);
                }
            }
            
            this._loaded = true;
            
            // Fire AFTERINIT event
            await this._fireEvent(SCENE_EVENTS.AFTERINIT, engine);
            
            return true;
        } catch (error) {
            console.error(`Failed to load scene ${this.name}:`, error);
            return false;
        }
    }

    /**
     * Unload scene resources
     */
    async unload(engine) {
        if (!this._loaded) {
            return true;
        }
        
        // Fire ONLEAVE event
        await this._fireEvent(SCENE_EVENTS.ONLEAVE, engine);
        
        // Clear hotspots
        for (const hotspot of this.hotspots) {
            engine.removeHotspot(hotspot.id);
        }
        
        // Clear objects
        for (const obj of this.objects) {
            engine.removeObject(obj.name);
        }
        
        this._loaded = false;
        this._active = false;
        
        return true;
    }

    /**
     * Activate scene (make it the current scene)
     */
    async activate(engine) {
        if (!this._loaded) {
            await this.load(engine);
        }
        
        this._active = true;
        
        // Fire ONENTER event
        await this._fireEvent(SCENE_EVENTS.ONENTER, engine);
        
        // Execute scene script
        if (this.script && this.script.length > 0) {
            await engine.parser.executeScript(this.script);
        }
        
        return true;
    }

    /**
     * Deactivate scene
     */
    async deactivate(engine) {
        this._active = false;
        return true;
    }

    /**
     * Fire an event handler
     */
    async _fireEvent(eventType, engine) {
        const handler = this.events[eventType];
        
        if (!handler) {
            return;
        }
        
        if (typeof handler === 'function') {
            await handler(engine, this);
        } else if (typeof handler === 'string') {
            // Execute as command
            const cmd = engine.parser.parse(handler);
            if (cmd) {
                await engine.parser.execute(cmd);
            }
        } else if (Array.isArray(handler)) {
            // Execute as script
            await engine.parser.executeScript(handler);
        }
    }

    /**
     * Add a hotspot to the scene
     * Original: TVNHotspot linked list operations
     */
    addHotspot(hotspot) {
        const existing = this.hotspots.findIndex(h => h.id === hotspot.id);
        
        if (existing >= 0) {
            this.hotspots[existing] = hotspot;
        } else {
            this.hotspots.push(hotspot);
        }
        
        return hotspot;
    }

    /**
     * Remove a hotspot from the scene
     */
    removeHotspot(id) {
        const index = this.hotspots.findIndex(h => h.id === id);
        
        if (index >= 0) {
            this.hotspots.splice(index, 1);
            return true;
        }
        
        return false;
    }

    /**
     * Get hotspot by ID
     */
    getHotspot(id) {
        return this.hotspots.find(h => h.id === id);
    }

    /**
     * Find hotspot at point
     * Original: PtInRegion @ 0x004397ec
     */
    getHotspotAtPoint(x, y) {
        // Search in reverse order (top to bottom)
        for (let i = this.hotspots.length - 1; i >= 0; i--) {
            const h = this.hotspots[i];
            
            if (x >= h.x && x <= h.x + h.width &&
                y >= h.y && y <= h.y + h.height) {
                return h;
            }
        }
        
        return null;
    }

    /**
     * Add an object to the scene
     */
    addObject(obj) {
        const existing = this.objects.findIndex(o => o.name === obj.name);
        
        if (existing >= 0) {
            this.objects[existing] = obj;
        } else {
            this.objects.push(obj);
        }
        
        // Sort by layer
        this.objects.sort((a, b) => (a.layer || 0) - (b.layer || 0));
        
        return obj;
    }

    /**
     * Remove an object from the scene
     */
    removeObject(name) {
        const index = this.objects.findIndex(o => o.name === name);
        
        if (index >= 0) {
            this.objects.splice(index, 1);
            return true;
        }
        
        return false;
    }

    /**
     * Get object by name
     */
    getObject(name) {
        return this.objects.find(o => o.name === name);
    }

    /**
     * Set scene flag
     */
    setFlag(flag, value = true) {
        if (value) {
            this.flags |= flag;
        } else {
            this.flags &= ~flag;
        }
    }

    /**
     * Check scene flag
     */
    hasFlag(flag) {
        return (this.flags & flag) !== 0;
    }

    /**
     * Serialize scene to JSON (for save/load)
     */
    toJSON() {
        return {
            id: this.id,
            name: this.name,
            title: this.title,
            background: this.background,
            music: this.music,
            flags: this.flags,
            hotspots: this.hotspots,
            objects: this.objects,
            events: {
                oninit: typeof this.events.oninit === 'string' ? this.events.oninit : null,
                afterinit: typeof this.events.afterinit === 'string' ? this.events.afterinit : null,
                onfocus: typeof this.events.onfocus === 'string' ? this.events.onfocus : null,
                onclick: typeof this.events.onclick === 'string' ? this.events.onclick : null,
                onenter: typeof this.events.onenter === 'string' ? this.events.onenter : null,
                onleave: typeof this.events.onleave === 'string' ? this.events.onleave : null
            },
            script: this.script,
            variables: this.variables
        };
    }

    /**
     * Create scene from JSON
     */
    static fromJSON(data) {
        return new VNScene(data);
    }
}

/**
 * VNSceneArray - Port of TIArrayAsVector<TVNScene>
 * Original: 0x004183bd
 */
class VNSceneArray {
    constructor() {
        this._scenes = [];
        this._currentIndex = -1;
        this._sceneMap = new Map();
    }

    /**
     * Add a scene to the array
     */
    add(scene) {
        if (!(scene instanceof VNScene)) {
            scene = new VNScene(scene);
        }
        
        // Assign ID if not set
        if (!scene.id) {
            scene.id = this._scenes.length;
        }
        
        this._scenes.push(scene);
        this._sceneMap.set(scene.name.toLowerCase(), scene);
        
        return scene;
    }

    /**
     * Get scene by index
     */
    getByIndex(index) {
        if (index < 0 || index >= this._scenes.length) {
            return null;
        }
        return this._scenes[index];
    }

    /**
     * Get scene by name
     */
    getByName(name) {
        return this._sceneMap.get(name.toLowerCase()) || null;
    }

    /**
     * Get scene by ID or name
     */
    get(idOrName) {
        if (typeof idOrName === 'number') {
            return this.getByIndex(idOrName);
        }
        return this.getByName(idOrName);
    }

    /**
     * Remove scene
     */
    remove(idOrName) {
        let index;
        
        if (typeof idOrName === 'number') {
            index = idOrName;
        } else {
            index = this._scenes.findIndex(s => 
                s.name.toLowerCase() === idOrName.toLowerCase()
            );
        }
        
        if (index >= 0 && index < this._scenes.length) {
            const scene = this._scenes[index];
            this._scenes.splice(index, 1);
            this._sceneMap.delete(scene.name.toLowerCase());
            return true;
        }
        
        return false;
    }

    /**
     * Get current scene
     */
    get current() {
        return this.getByIndex(this._currentIndex);
    }

    /**
     * Set current scene index
     */
    set currentIndex(index) {
        if (index >= 0 && index < this._scenes.length) {
            this._currentIndex = index;
        }
    }

    get currentIndex() {
        return this._currentIndex;
    }

    /**
     * Get scene count
     */
    get count() {
        return this._scenes.length;
    }

    /**
     * Get all scenes
     */
    getAll() {
        return [...this._scenes];
    }

    /**
     * Clear all scenes
     */
    clear() {
        this._scenes = [];
        this._sceneMap.clear();
        this._currentIndex = -1;
    }

    /**
     * Iterate over scenes
     */
    forEach(callback) {
        this._scenes.forEach(callback);
    }

    /**
     * Find scene by predicate
     */
    find(predicate) {
        return this._scenes.find(predicate);
    }
}

export { VNScene, VNSceneArray, SCENE_FLAGS, SCENE_EVENTS };
export default VNScene;
