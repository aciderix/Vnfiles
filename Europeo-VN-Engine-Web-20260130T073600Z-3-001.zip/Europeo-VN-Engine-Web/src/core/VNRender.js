/**
 * VNRender - HTML Text Rendering Engine
 * 
 * EXACT PORT from fcn.004200cf (6624 bytes, 2006 lines ASM)
 * Source file: htmldata.cpp (referenced at 0x00420116)
 * 
 * This is the main text/HTML rendering function that handles:
 * - Text drawing with fonts
 * - Anchor links (hyperlinks)
 * - Text wrapping and positioning
 * - Color and style management
 * 
 * Original function signature (from disassembly):
 * fcn.004200cf(int32_t arg_8h, HDC hdc, int32_t arg_10h, uint32_t arg_14h)
 * 
 * @original_address 0x004200cf
 * @original_size 6624 bytes
 * @original_file htmldata.cpp
 */

/**
 * VNTextMetrics - Text measurement utilities
 * Maps to GetTextExtentPoint32 calls at various addresses
 * @original_address 0x00420189
 */
class VNTextMetrics {
    constructor() {
        // var_cch at 0x004200de - stores text metrics structure
        this.height = 0;          // offset 0x00
        this.ascent = 0;          // offset 0x04
        this.descent = 0;         // offset 0x08
        this.internalLeading = 0; // offset 0x0c
        this.externalLeading = 0; // offset 0x10
        this.aveCharWidth = 0;    // offset 0x14
        this.maxCharWidth = 0;    // offset 0x18
        this.weight = 0;          // offset 0x1c
        this.overhang = 0;        // offset 0x20
        this.digitizedAspectX = 0; // offset 0x24
        this.digitizedAspectY = 0; // offset 0x28
    }

    /**
     * Measure text using canvas context
     * @original_address 0x0042017d - push 0x5a (90 = GetTextMetrics)
     */
    measure(ctx, text) {
        const metrics = ctx.measureText(text);
        this.height = parseInt(ctx.font) || 16;
        this.ascent = metrics.actualBoundingBoxAscent || this.height * 0.8;
        this.descent = metrics.actualBoundingBoxDescent || this.height * 0.2;
        this.aveCharWidth = metrics.width / Math.max(text.length, 1);
        this.maxCharWidth = this.aveCharWidth * 1.5;
        return metrics.width;
    }
}

/**
 * VNTextStyle - Text styling information
 * Extracted from style handling code in render function
 * @original_address 0x00420191 - lea eax, [ebx + 8]
 */
class VNTextStyle {
    constructor() {
        // Style flags from [ebx + offset] accesses
        this.fontName = 'Arial';      // offset 0x08
        this.fontSize = 16;           // offset 0x0c
        this.fontWeight = 400;        // offset 0x10 (400 = normal, 700 = bold)
        this.italic = false;          // offset 0x14 bit 0
        this.underline = false;       // offset 0x14 bit 1
        this.strikeout = false;       // offset 0x14 bit 2
        this.color = 0x000000;        // offset 0x18
        this.backgroundColor = null;  // offset 0x1c
        this.alignment = 0;           // offset 0x20 (0=left, 1=center, 2=right)
    }

    /**
     * Apply style to canvas context
     * @original_address 0x00420198 - call dword [edx + 4]
     */
    applyTo(ctx) {
        let fontStyle = '';
        if (this.italic) fontStyle += 'italic ';
        if (this.fontWeight >= 700) fontStyle += 'bold ';
        
        ctx.font = `${fontStyle}${this.fontSize}px ${this.fontName}`;
        ctx.fillStyle = `#${this.color.toString(16).padStart(6, '0')}`;
        
        if (this.backgroundColor !== null) {
            ctx.save();
            ctx.fillStyle = `#${this.backgroundColor.toString(16).padStart(6, '0')}`;
        }
    }

    clone() {
        const copy = new VNTextStyle();
        Object.assign(copy, this);
        return copy;
    }
}

/**
 * VNRenderState - Rendering state machine
 * Tracks position, style stack, and line information
 * @original_address 0x004201a0 - var_224h structure
 */
class VNRenderState {
    constructor() {
        // Position tracking (var_d0h at 0x004201ad)
        this.x = 0;
        this.y = 0;
        this.lineStartX = 0;
        this.lineHeight = 0;
        this.maxWidth = 0;
        this.maxHeight = 0;
        
        // Style stack for nested tags
        this.styleStack = [];
        this.currentStyle = new VNTextStyle();
        
        // Line buffer for word wrapping
        this.lineBuffer = [];
        this.lineWidth = 0;
        
        // Anchor tracking
        this.inAnchor = false;
        this.anchorData = null;
        this.anchors = [];
    }

    pushStyle() {
        this.styleStack.push(this.currentStyle.clone());
    }

    popStyle() {
        if (this.styleStack.length > 0) {
            this.currentStyle = this.styleStack.pop();
        }
    }

    newLine(lineHeight) {
        this.x = this.lineStartX;
        this.y += lineHeight || this.lineHeight;
        this.lineBuffer = [];
        this.lineWidth = 0;
    }
}

/**
 * VNHtmlToken - Token from HTML parsing
 * @original_address 0x0041f121 - fcn.0041f121 (HTML tokenizer)
 */
class VNHtmlToken {
    static TYPE_TEXT = 0;
    static TYPE_TAG_OPEN = 1;
    static TYPE_TAG_CLOSE = 2;
    static TYPE_ENTITY = 3;

    constructor(type, value, attributes = {}) {
        this.type = type;
        this.value = value;
        this.attributes = attributes;
    }
}

/**
 * VNHtmlTokenizer - HTML text tokenizer
 * Port of fcn.0041f121 called at 0x004201a7
 * @original_address 0x0041f121
 */
class VNHtmlTokenizer {
    constructor(html) {
        this.html = html;
        this.pos = 0;
        this.length = html.length;
    }

    /**
     * Get next token
     * @original_address 0x0041f121 main loop
     */
    nextToken() {
        if (this.pos >= this.length) {
            return null;
        }

        const char = this.html[this.pos];

        // Tag detection at 0x0041f130
        if (char === '<') {
            return this.parseTag();
        }

        // Entity detection at 0x0041f150
        if (char === '&') {
            return this.parseEntity();
        }

        // Text content
        return this.parseText();
    }

    parseTag() {
        this.pos++; // skip '<'
        
        const isClosing = this.html[this.pos] === '/';
        if (isClosing) this.pos++;

        let tagName = '';
        let attributes = {};

        // Read tag name
        while (this.pos < this.length && /[a-zA-Z0-9]/.test(this.html[this.pos])) {
            tagName += this.html[this.pos++];
        }

        // Parse attributes for opening tags
        if (!isClosing) {
            attributes = this.parseAttributes();
        }

        // Skip to closing '>'
        while (this.pos < this.length && this.html[this.pos] !== '>') {
            this.pos++;
        }
        this.pos++; // skip '>'

        return new VNHtmlToken(
            isClosing ? VNHtmlToken.TYPE_TAG_CLOSE : VNHtmlToken.TYPE_TAG_OPEN,
            tagName.toLowerCase(),
            attributes
        );
    }

    parseAttributes() {
        const attributes = {};
        
        while (this.pos < this.length && this.html[this.pos] !== '>') {
            // Skip whitespace
            while (this.pos < this.length && /\s/.test(this.html[this.pos])) {
                this.pos++;
            }

            if (this.html[this.pos] === '>' || this.html[this.pos] === '/') break;

            // Read attribute name
            let attrName = '';
            while (this.pos < this.length && /[a-zA-Z0-9_-]/.test(this.html[this.pos])) {
                attrName += this.html[this.pos++];
            }

            // Skip whitespace and '='
            while (this.pos < this.length && /[\s=]/.test(this.html[this.pos])) {
                this.pos++;
            }

            // Read attribute value
            let attrValue = '';
            const quote = this.html[this.pos];
            if (quote === '"' || quote === "'") {
                this.pos++;
                while (this.pos < this.length && this.html[this.pos] !== quote) {
                    attrValue += this.html[this.pos++];
                }
                this.pos++; // skip closing quote
            } else {
                while (this.pos < this.length && !/[\s>]/.test(this.html[this.pos])) {
                    attrValue += this.html[this.pos++];
                }
            }

            if (attrName) {
                attributes[attrName.toLowerCase()] = attrValue;
            }
        }

        return attributes;
    }

    parseEntity() {
        this.pos++; // skip '&'
        let entity = '';
        
        while (this.pos < this.length && this.html[this.pos] !== ';' && entity.length < 10) {
            entity += this.html[this.pos++];
        }
        
        if (this.html[this.pos] === ';') {
            this.pos++;
        }

        // Entity mapping (from string table analysis)
        const entities = {
            'nbsp': '\u00A0',
            'lt': '<',
            'gt': '>',
            'amp': '&',
            'quot': '"',
            'apos': "'",
            'copy': '©',
            'reg': '®',
            'trade': '™',
            'mdash': '—',
            'ndash': '–',
            'hellip': '…',
            'euro': '€',
            'pound': '£',
            'yen': '¥',
            'cent': '¢'
        };

        const char = entities[entity.toLowerCase()] || `&${entity};`;
        return new VNHtmlToken(VNHtmlToken.TYPE_ENTITY, char);
    }

    parseText() {
        let text = '';
        
        while (this.pos < this.length) {
            const char = this.html[this.pos];
            if (char === '<' || char === '&') break;
            text += char;
            this.pos++;
        }

        return new VNHtmlToken(VNHtmlToken.TYPE_TEXT, text);
    }

    tokenize() {
        const tokens = [];
        let token;
        
        while ((token = this.nextToken()) !== null) {
            tokens.push(token);
        }
        
        return tokens;
    }
}

/**
 * VNRender - Main rendering class
 * Port of fcn.004200cf
 * @original_address 0x004200cf
 */
class VNRender {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.metrics = new VNTextMetrics();
        this.state = new VNRenderState();
        
        // Global settings from memory locations
        this.defaultFont = 'Arial';        // [0x444a34]
        this.defaultSize = 16;             // [0x444a38]
        this.defaultColor = 0x000000;      // [0x444a3c]
        this.linkColor = 0x0000FF;         // [0x444a40]
        this.visitedLinkColor = 0x800080;  // [0x444a44]
        this.activeLinkColor = 0xFF0000;   // [0x444a48]
    }

    /**
     * Main render function
     * @original_address 0x004200cf entry point
     * @param text HTML text to render
     * @param rect Bounding rectangle {x, y, width, height}
     */
    render(text, rect) {
        // Precondition check at 0x004200f1
        if (!text || text.length === 0) {
            // Error handling at 0x004200fb - 0x00420175
            console.warn('VNRender: Empty text');
            return;
        }

        // Initialize state
        this.state = new VNRenderState();
        this.state.x = rect.x;
        this.state.y = rect.y;
        this.state.lineStartX = rect.x;
        this.state.maxWidth = rect.width;
        this.state.maxHeight = rect.height;

        // Get text metrics at 0x0042017d
        this.state.currentStyle.fontSize = this.defaultSize;
        this.state.currentStyle.fontName = this.defaultFont;
        this.state.currentStyle.color = this.defaultColor;
        this.state.currentStyle.applyTo(this.ctx);
        
        // Measure line height at 0x00420189
        this.state.lineHeight = this.defaultSize * 1.2;

        // Initialize array at 0x00420191
        const textData = {
            // Structure from [ebx + offset]
            text: text,
            length: text.length,    // offset 0x06
            styles: [],             // offset 0x08
            anchors: []             // offset 0x36
        };

        // Tokenize HTML
        const tokenizer = new VNHtmlTokenizer(text);
        const tokens = tokenizer.tokenize();

        // Render tokens - main loop starts around 0x0042019e
        for (const token of tokens) {
            this.renderToken(token);
        }

        // Return anchor information for click detection
        return this.state.anchors;
    }

    /**
     * Render single token
     * Corresponds to switch statement in render function
     * @original_address ~0x004201c5
     */
    renderToken(token) {
        switch (token.type) {
            case VNHtmlToken.TYPE_TEXT:
                this.renderText(token.value);
                break;

            case VNHtmlToken.TYPE_TAG_OPEN:
                this.handleOpenTag(token.value, token.attributes);
                break;

            case VNHtmlToken.TYPE_TAG_CLOSE:
                this.handleCloseTag(token.value);
                break;

            case VNHtmlToken.TYPE_ENTITY:
                this.renderText(token.value);
                break;
        }
    }

    /**
     * Render text content with word wrapping
     * @original_address ~0x00420200
     */
    renderText(text) {
        if (!text || text.length === 0) return;

        const words = text.split(/(\s+)/);
        
        for (const word of words) {
            if (word.length === 0) continue;

            // Measure word
            this.state.currentStyle.applyTo(this.ctx);
            const wordWidth = this.ctx.measureText(word).width;

            // Check for line wrap
            if (this.state.x + wordWidth > this.state.lineStartX + this.state.maxWidth) {
                // Wrap to next line
                if (this.state.x > this.state.lineStartX) {
                    this.state.newLine(this.state.lineHeight);
                }
            }

            // Draw word
            this.ctx.fillText(word, this.state.x, this.state.y + this.state.lineHeight * 0.8);

            // Track anchor bounds if in anchor
            if (this.state.inAnchor && this.state.anchorData) {
                this.state.anchorData.bounds.push({
                    x: this.state.x,
                    y: this.state.y,
                    width: wordWidth,
                    height: this.state.lineHeight
                });
            }

            // Advance position
            this.state.x += wordWidth;
        }
    }

    /**
     * Handle opening HTML tag
     * Tag handling corresponds to various case blocks
     * @original_address distributed across function
     */
    handleOpenTag(tag, attributes) {
        this.state.pushStyle();

        switch (tag) {
            case 'b':
            case 'strong':
                this.state.currentStyle.fontWeight = 700;
                break;

            case 'i':
            case 'em':
                this.state.currentStyle.italic = true;
                break;

            case 'u':
                this.state.currentStyle.underline = true;
                break;

            case 's':
            case 'strike':
                this.state.currentStyle.strikeout = true;
                break;

            case 'font':
                if (attributes.face) {
                    this.state.currentStyle.fontName = attributes.face;
                }
                if (attributes.size) {
                    // Size 1-7 mapping (original used point sizes)
                    const sizeMap = [8, 10, 12, 14, 18, 24, 36];
                    const idx = parseInt(attributes.size) - 1;
                    if (idx >= 0 && idx < sizeMap.length) {
                        this.state.currentStyle.fontSize = sizeMap[idx];
                    }
                }
                if (attributes.color) {
                    this.state.currentStyle.color = this.parseColor(attributes.color);
                }
                break;

            case 'a':
                this.state.inAnchor = true;
                this.state.anchorData = {
                    href: attributes.href || '',
                    target: attributes.target || '_self',
                    bounds: []
                };
                this.state.currentStyle.color = this.linkColor;
                this.state.currentStyle.underline = true;
                break;

            case 'br':
                this.state.newLine(this.state.lineHeight);
                this.state.popStyle(); // BR is self-closing
                break;

            case 'p':
                if (this.state.x > this.state.lineStartX) {
                    this.state.newLine(this.state.lineHeight * 1.5);
                }
                if (attributes.align) {
                    const alignMap = { left: 0, center: 1, right: 2 };
                    this.state.currentStyle.alignment = alignMap[attributes.align] || 0;
                }
                break;

            case 'center':
                this.state.currentStyle.alignment = 1;
                break;

            case 'img':
                this.handleImage(attributes);
                this.state.popStyle(); // IMG is self-closing
                break;

            case 'hr':
                this.handleHorizontalRule(attributes);
                this.state.popStyle(); // HR is self-closing
                break;

            case 'h1':
            case 'h2':
            case 'h3':
            case 'h4':
            case 'h5':
            case 'h6':
                const level = parseInt(tag[1]);
                const hSizes = [32, 24, 20, 16, 14, 12];
                this.state.currentStyle.fontSize = hSizes[level - 1];
                this.state.currentStyle.fontWeight = 700;
                if (this.state.x > this.state.lineStartX) {
                    this.state.newLine(this.state.lineHeight);
                }
                break;

            case 'span':
                if (attributes.style) {
                    this.parseInlineStyle(attributes.style);
                }
                break;

            case 'div':
                if (this.state.x > this.state.lineStartX) {
                    this.state.newLine(this.state.lineHeight);
                }
                break;
        }

        // Update line height for new font size
        this.state.lineHeight = this.state.currentStyle.fontSize * 1.2;
    }

    /**
     * Handle closing HTML tag
     * @original_address various cleanup blocks
     */
    handleCloseTag(tag) {
        switch (tag) {
            case 'a':
                if (this.state.anchorData) {
                    this.state.anchors.push(this.state.anchorData);
                    this.state.anchorData = null;
                }
                this.state.inAnchor = false;
                break;

            case 'p':
            case 'div':
            case 'h1':
            case 'h2':
            case 'h3':
            case 'h4':
            case 'h5':
            case 'h6':
                this.state.newLine(this.state.lineHeight * 0.5);
                break;
        }

        this.state.popStyle();
        this.state.lineHeight = this.state.currentStyle.fontSize * 1.2;
    }

    /**
     * Parse color value (hex or named)
     * @original_address color parsing in attribute handlers
     */
    parseColor(colorStr) {
        if (!colorStr) return this.defaultColor;

        // Named colors (from string table)
        const namedColors = {
            'black': 0x000000,
            'white': 0xFFFFFF,
            'red': 0xFF0000,
            'green': 0x00FF00,
            'blue': 0x0000FF,
            'yellow': 0xFFFF00,
            'cyan': 0x00FFFF,
            'magenta': 0xFF00FF,
            'gray': 0x808080,
            'grey': 0x808080,
            'silver': 0xC0C0C0,
            'maroon': 0x800000,
            'olive': 0x808000,
            'navy': 0x000080,
            'purple': 0x800080,
            'teal': 0x008080,
            'orange': 0xFFA500
        };

        const lower = colorStr.toLowerCase();
        if (namedColors[lower] !== undefined) {
            return namedColors[lower];
        }

        // Hex color
        if (colorStr.startsWith('#')) {
            return parseInt(colorStr.slice(1), 16);
        }

        // RGB function (not in original, but for compatibility)
        const rgbMatch = colorStr.match(/rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
        if (rgbMatch) {
            return (parseInt(rgbMatch[1]) << 16) | 
                   (parseInt(rgbMatch[2]) << 8) | 
                   parseInt(rgbMatch[3]);
        }

        return this.defaultColor;
    }

    /**
     * Parse inline CSS style attribute
     */
    parseInlineStyle(styleStr) {
        const styles = styleStr.split(';');
        
        for (const style of styles) {
            const [prop, value] = style.split(':').map(s => s.trim().toLowerCase());
            
            switch (prop) {
                case 'color':
                    this.state.currentStyle.color = this.parseColor(value);
                    break;
                case 'background-color':
                case 'background':
                    this.state.currentStyle.backgroundColor = this.parseColor(value);
                    break;
                case 'font-size':
                    this.state.currentStyle.fontSize = parseInt(value) || this.defaultSize;
                    break;
                case 'font-weight':
                    this.state.currentStyle.fontWeight = value === 'bold' ? 700 : 
                                                         (parseInt(value) || 400);
                    break;
                case 'font-style':
                    this.state.currentStyle.italic = value === 'italic';
                    break;
                case 'text-decoration':
                    this.state.currentStyle.underline = value.includes('underline');
                    this.state.currentStyle.strikeout = value.includes('line-through');
                    break;
                case 'font-family':
                    this.state.currentStyle.fontName = value.split(',')[0].replace(/['"]/g, '');
                    break;
            }
        }
    }

    /**
     * Handle image tag
     * @original_address image handling in main render
     */
    handleImage(attributes) {
        const img = new Image();
        const width = parseInt(attributes.width) || 100;
        const height = parseInt(attributes.height) || 100;
        
        if (attributes.src) {
            img.src = attributes.src;
            
            // Draw placeholder or image
            img.onload = () => {
                this.ctx.drawImage(img, this.state.x, this.state.y, width, height);
            };
            
            // Reserve space immediately
            this.state.x += width;
        }
    }

    /**
     * Handle horizontal rule
     * @original_address HR handling
     */
    handleHorizontalRule(attributes) {
        const y = this.state.y + this.state.lineHeight / 2;
        
        this.state.newLine(this.state.lineHeight);
        
        this.ctx.save();
        this.ctx.strokeStyle = '#808080';
        this.ctx.lineWidth = parseInt(attributes.size) || 1;
        this.ctx.beginPath();
        this.ctx.moveTo(this.state.lineStartX, y);
        this.ctx.lineTo(this.state.lineStartX + this.state.maxWidth, y);
        this.ctx.stroke();
        this.ctx.restore();
        
        this.state.newLine(this.state.lineHeight / 2);
    }

    /**
     * Clear rendering area
     */
    clear(rect, color = 0xFFFFFF) {
        this.ctx.fillStyle = `#${color.toString(16).padStart(6, '0')}`;
        this.ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
    }
}

/**
 * VNMainLoop - Main application loop
 * Port of fcn.00434070 (5908 bytes)
 * @original_address 0x00434070
 */
class VNMainLoop {
    constructor(engine) {
        this.engine = engine;
        this.running = false;
        this.frameRate = 30;              // Target frame rate
        this.frameTime = 1000 / 30;       // ms per frame
        this.lastFrameTime = 0;
        this.accumulator = 0;
        
        // State flags from disassembly
        this.paused = false;              // [ebx + 4] bit 0
        this.waitingForInput = false;     // var_c1h at 0x00434171
        this.currentCommand = null;       // var_c8h at 0x00434152
        this.commandResult = 0;           // var_cch at 0x0043415a
        
        // Cursor handling at 0x004340e1-0x004340f6
        this.cursorId = 0x62;             // 'b' = 98 (default cursor)
    }

    /**
     * Start main loop
     * Entry point at 0x00434070
     */
    start() {
        this.running = true;
        this.lastFrameTime = performance.now();
        this.loop();
    }

    /**
     * Stop main loop
     */
    stop() {
        this.running = false;
    }

    /**
     * Main loop iteration
     * @original_address 0x00434070 main body
     */
    loop() {
        if (!this.running) return;

        const currentTime = performance.now();
        const deltaTime = currentTime - this.lastFrameTime;
        this.lastFrameTime = currentTime;
        
        // Accumulate time for fixed timestep
        this.accumulator += deltaTime;

        // Process at fixed timestep
        while (this.accumulator >= this.frameTime) {
            this.update(this.frameTime);
            this.accumulator -= this.frameTime;
        }

        // Render
        this.render();

        // Schedule next frame
        requestAnimationFrame(() => this.loop());
    }

    /**
     * Update game state
     * Corresponds to command processing section
     * @original_address ~0x00434147
     */
    update(dt) {
        if (this.paused) return;

        // Check for waiting state at 0x004340fc
        if (this.engine.currentMedia && this.engine.currentMedia.isPlaying) {
            return;
        }

        // Process commands at 0x0043414a-0x0043416e
        if (!this.waitingForInput && this.engine.commandQueue.length > 0) {
            this.processNextCommand();
        }
    }

    /**
     * Process next command in queue
     * @original_address 0x00434147-0x00434168
     */
    processNextCommand() {
        const command = this.engine.commandQueue.shift();
        if (!command) return;

        this.currentCommand = command;
        
        // Execute command (corresponds to vtable call at 0x0043416e)
        const result = this.engine.executeCommand(command);
        
        this.commandResult = result;
        
        // Check if command requires waiting
        if (command.waitForCompletion) {
            this.waitingForInput = true;
        }
    }

    /**
     * Render current frame
     * @original_address render section ~0x00434178
     */
    render() {
        if (!this.engine.scene) return;

        // Check scene validity at 0x00434184
        const scene = this.engine.scene;
        
        // Render scene layers
        this.engine.renderScene();
    }

    /**
     * Handle input event
     * Used to resume from waiting state
     */
    handleInput(event) {
        if (this.waitingForInput) {
            this.waitingForInput = false;
        }
    }
}

// Export all classes
export {
    VNTextMetrics,
    VNTextStyle,
    VNRenderState,
    VNHtmlToken,
    VNHtmlTokenizer,
    VNRender,
    VNMainLoop
};
