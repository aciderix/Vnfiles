/**
 * VNBitmap - Bitmap and graphics handling classes
 * 
 * Port of TVNBitmap, TVNBmpImg, TVNBkTexture, TVNTransparentBmp,
 * TVNGdiObject, TVNGdiObjectArray from europeo.exe
 */

import { VNObject, VNStreamable } from './VNObject.js';

/**
 * TVNGdiObject - GDI object wrapper
 * Port from europeo.exe (GDI handling)
 * Wraps canvas/WebGL graphics objects
 */
export class VNGdiObject extends VNStreamable {
    constructor() {
        super();
        this.id = VNGdiObject._nextId++;
        this.type = 'unknown'; // 'bitmap', 'brush', 'pen', 'font', 'region'
        this.handle = null;    // Reference to actual graphics object
        this.stock = false;    // Is this a stock object?
        this.deleted = false;
    }

    static _nextId = 1;

    /**
     * Delete the GDI object
     * Mirrors: DeleteObject
     */
    delete() {
        if (this.stock) return false; // Can't delete stock objects
        this.handle = null;
        this.deleted = true;
        return true;
    }

    /**
     * Check if object is valid
     */
    isValid() {
        return this.handle !== null && !this.deleted;
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            type: this.type,
            stock: this.stock
        };
    }
}

/**
 * TVNGdiObjectArray - Array of GDI objects
 * Port from europeo.exe
 */
export class VNGdiObjectArray extends VNStreamable {
    constructor() {
        super();
        this.objects = [];
    }

    add(obj) {
        if (obj instanceof VNGdiObject) {
            this.objects.push(obj);
            return obj.id;
        }
        return -1;
    }

    remove(id) {
        const index = this.objects.findIndex(o => o.id === id);
        if (index !== -1) {
            this.objects[index].delete();
            this.objects.splice(index, 1);
            return true;
        }
        return false;
    }

    get(id) {
        return this.objects.find(o => o.id === id);
    }

    clear() {
        this.objects.forEach(o => o.delete());
        this.objects = [];
    }

    getCount() {
        return this.objects.length;
    }
}

/**
 * TVNBitmap - Bitmap image handling
 * Port from europeo.exe (bitmap operations)
 * Uses HTML5 Canvas and ImageBitmap
 */
export class VNBitmap extends VNGdiObject {
    constructor() {
        super();
        this.type = 'bitmap';
        
        // Dimensions
        this.width = 0;
        this.height = 0;
        
        // Source
        this.src = '';
        this.loaded = false;
        this.error = null;
        
        // Internal canvas
        this._canvas = null;
        this._ctx = null;
        this._image = null;
        this._imageData = null;
        
        // Callbacks
        this._onLoad = null;
        this._onError = null;
    }

    /**
     * Load bitmap from URL
     * Mirrors: TVNBitmap::LoadFromFile
     */
    load(url) {
        return new Promise((resolve, reject) => {
            this.src = url;
            this.loaded = false;
            this.error = null;
            
            this._image = new Image();
            this._image.crossOrigin = 'anonymous';
            
            this._image.onload = () => {
                this.width = this._image.naturalWidth;
                this.height = this._image.naturalHeight;
                
                // Create canvas
                this._canvas = document.createElement('canvas');
                this._canvas.width = this.width;
                this._canvas.height = this.height;
                this._ctx = this._canvas.getContext('2d');
                this._ctx.drawImage(this._image, 0, 0);
                
                this.loaded = true;
                this.handle = this._canvas;
                
                if (this._onLoad) this._onLoad(this);
                resolve(this);
            };
            
            this._image.onerror = (e) => {
                this.error = e;
                this.loaded = false;
                if (this._onError) this._onError(e);
                reject(e);
            };
            
            this._image.src = url;
        });
    }

    /**
     * Create empty bitmap
     * Mirrors: TVNBitmap::Create
     */
    create(width, height) {
        this.width = width;
        this.height = height;
        
        this._canvas = document.createElement('canvas');
        this._canvas.width = width;
        this._canvas.height = height;
        this._ctx = this._canvas.getContext('2d');
        
        this.loaded = true;
        this.handle = this._canvas;
        
        return this;
    }

    /**
     * Get canvas context
     */
    getContext() {
        return this._ctx;
    }

    /**
     * Get canvas element
     */
    getCanvas() {
        return this._canvas;
    }

    /**
     * Get pixel data
     * Mirrors: GetPixel
     */
    getPixel(x, y) {
        if (!this._ctx || x < 0 || y < 0 || x >= this.width || y >= this.height) {
            return null;
        }
        
        const data = this._ctx.getImageData(x, y, 1, 1).data;
        return {
            r: data[0],
            g: data[1],
            b: data[2],
            a: data[3]
        };
    }

    /**
     * Set pixel data
     * Mirrors: SetPixel
     */
    setPixel(x, y, r, g, b, a = 255) {
        if (!this._ctx || x < 0 || y < 0 || x >= this.width || y >= this.height) {
            return false;
        }
        
        const imageData = this._ctx.createImageData(1, 1);
        imageData.data[0] = r;
        imageData.data[1] = g;
        imageData.data[2] = b;
        imageData.data[3] = a;
        this._ctx.putImageData(imageData, x, y);
        return true;
    }

    /**
     * Get full image data
     */
    getImageData() {
        if (!this._ctx) return null;
        return this._ctx.getImageData(0, 0, this.width, this.height);
    }

    /**
     * Set full image data
     */
    setImageData(imageData) {
        if (!this._ctx) return false;
        this._ctx.putImageData(imageData, 0, 0);
        return true;
    }

    /**
     * Draw to another context
     * Mirrors: BitBlt
     */
    drawTo(destCtx, destX = 0, destY = 0, destW = null, destH = null, 
           srcX = 0, srcY = 0, srcW = null, srcH = null) {
        if (!this._canvas) return false;
        
        destW = destW || this.width;
        destH = destH || this.height;
        srcW = srcW || this.width;
        srcH = srcH || this.height;
        
        destCtx.drawImage(this._canvas, srcX, srcY, srcW, srcH, destX, destY, destW, destH);
        return true;
    }

    /**
     * Copy from another bitmap
     */
    copyFrom(srcBitmap, srcX = 0, srcY = 0, srcW = null, srcH = null) {
        if (!srcBitmap._canvas || !this._ctx) return false;
        
        srcW = srcW || srcBitmap.width;
        srcH = srcH || srcBitmap.height;
        
        this._ctx.drawImage(srcBitmap._canvas, srcX, srcY, srcW, srcH, 0, 0, srcW, srcH);
        return true;
    }

    /**
     * Clone bitmap
     */
    clone() {
        const cloned = new VNBitmap();
        cloned.create(this.width, this.height);
        cloned.copyFrom(this);
        cloned.src = this.src;
        return cloned;
    }

    /**
     * Clear bitmap
     */
    clear(color = 'transparent') {
        if (!this._ctx) return;
        
        this._ctx.fillStyle = color;
        this._ctx.fillRect(0, 0, this.width, this.height);
    }

    /**
     * Convert to data URL
     */
    toDataURL(format = 'image/png', quality = 0.92) {
        if (!this._canvas) return null;
        return this._canvas.toDataURL(format, quality);
    }

    /**
     * Convert to Blob
     */
    toBlob(format = 'image/png', quality = 0.92) {
        return new Promise((resolve, reject) => {
            if (!this._canvas) {
                reject(new Error('No canvas'));
                return;
            }
            this._canvas.toBlob(resolve, format, quality);
        });
    }

    /**
     * Set load callback
     */
    onLoad(callback) {
        this._onLoad = callback;
        return this;
    }

    /**
     * Set error callback
     */
    onError(callback) {
        this._onError = callback;
        return this;
    }

    serialize() {
        return {
            ...super.serialize(),
            width: this.width,
            height: this.height,
            src: this.src
        };
    }
}

/**
 * TVNBmpImg - Bitmap image with position
 * Port from europeo.exe
 */
export class VNBmpImg extends VNBitmap {
    constructor() {
        super();
        
        // Position
        this.x = 0;
        this.y = 0;
        
        // Display properties
        this.visible = true;
        this.opacity = 1.0;
        this.zOrder = 0;
        
        // Transformation
        this.scaleX = 1.0;
        this.scaleY = 1.0;
        this.rotation = 0;
        this.flipH = false;
        this.flipV = false;
    }

    /**
     * Set position
     */
    setPosition(x, y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Draw with transformations
     */
    draw(destCtx) {
        if (!this._canvas || !this.visible) return;
        
        destCtx.save();
        
        // Apply transformations
        destCtx.globalAlpha = this.opacity;
        destCtx.translate(this.x + this.width / 2, this.y + this.height / 2);
        destCtx.rotate(this.rotation * Math.PI / 180);
        destCtx.scale(this.scaleX * (this.flipH ? -1 : 1), this.scaleY * (this.flipV ? -1 : 1));
        
        // Draw
        destCtx.drawImage(this._canvas, -this.width / 2, -this.height / 2);
        
        destCtx.restore();
    }

    /**
     * Hit test
     */
    containsPoint(px, py) {
        return px >= this.x && px < this.x + this.width * this.scaleX &&
               py >= this.y && py < this.y + this.height * this.scaleY;
    }

    serialize() {
        return {
            ...super.serialize(),
            x: this.x,
            y: this.y,
            visible: this.visible,
            opacity: this.opacity,
            zOrder: this.zOrder,
            scaleX: this.scaleX,
            scaleY: this.scaleY,
            rotation: this.rotation,
            flipH: this.flipH,
            flipV: this.flipV
        };
    }
}

/**
 * TVNTransparentBmp - Bitmap with transparency
 * Port from europeo.exe (transparent bitmap handling)
 */
export class VNTransparentBmp extends VNBmpImg {
    constructor() {
        super();
        
        this.transparentColor = { r: 255, g: 0, b: 255 }; // Magenta default
        this.useTransparency = true;
        this._maskCanvas = null;
    }

    /**
     * Set transparent color
     */
    setTransparentColor(r, g, b) {
        this.transparentColor = { r, g, b };
        this._createMask();
    }

    /**
     * Create transparency mask
     */
    _createMask() {
        if (!this._canvas || !this.useTransparency) return;
        
        const imageData = this._ctx.getImageData(0, 0, this.width, this.height);
        const data = imageData.data;
        
        const tr = this.transparentColor.r;
        const tg = this.transparentColor.g;
        const tb = this.transparentColor.b;
        
        // Set alpha to 0 for transparent color pixels
        for (let i = 0; i < data.length; i += 4) {
            if (data[i] === tr && data[i + 1] === tg && data[i + 2] === tb) {
                data[i + 3] = 0; // Set alpha to 0
            }
        }
        
        this._ctx.putImageData(imageData, 0, 0);
    }

    /**
     * Override load to create mask after loading
     */
    async load(url) {
        await super.load(url);
        if (this.useTransparency) {
            this._createMask();
        }
        return this;
    }

    serialize() {
        return {
            ...super.serialize(),
            transparentColor: this.transparentColor,
            useTransparency: this.useTransparency
        };
    }
}

/**
 * TVNBkTexture - Background texture
 * Port from europeo.exe (background tiling)
 */
export class VNBkTexture extends VNBitmap {
    constructor() {
        super();
        
        this.tileMode = 'repeat'; // 'repeat', 'repeat-x', 'repeat-y', 'no-repeat', 'stretch'
        this.offsetX = 0;
        this.offsetY = 0;
        this._pattern = null;
    }

    /**
     * Create pattern for tiling
     */
    createPattern(ctx) {
        if (!this._canvas) return null;
        
        if (this.tileMode === 'stretch') {
            return null; // Will use drawImage instead
        }
        
        this._pattern = ctx.createPattern(this._canvas, this.tileMode);
        return this._pattern;
    }

    /**
     * Fill area with texture
     */
    fillRect(destCtx, x, y, width, height) {
        if (!this._canvas) return;
        
        if (this.tileMode === 'stretch') {
            destCtx.drawImage(this._canvas, x, y, width, height);
            return;
        }
        
        const pattern = this.createPattern(destCtx);
        if (pattern) {
            destCtx.save();
            destCtx.translate(x + this.offsetX, y + this.offsetY);
            destCtx.fillStyle = pattern;
            destCtx.fillRect(-this.offsetX, -this.offsetY, width, height);
            destCtx.restore();
        }
    }

    serialize() {
        return {
            ...super.serialize(),
            tileMode: this.tileMode,
            offsetX: this.offsetX,
            offsetY: this.offsetY
        };
    }
}

/**
 * Bitmap manager for caching
 */
export class VNBitmapCache {
    constructor() {
        this.cache = new Map();
        this.maxSize = 100;
    }

    /**
     * Get or load bitmap
     */
    async get(url) {
        if (this.cache.has(url)) {
            return this.cache.get(url);
        }
        
        const bitmap = new VNBitmap();
        await bitmap.load(url);
        
        this.set(url, bitmap);
        return bitmap;
    }

    /**
     * Store bitmap in cache
     */
    set(url, bitmap) {
        // Remove oldest if at capacity
        if (this.cache.size >= this.maxSize) {
            const firstKey = this.cache.keys().next().value;
            this.cache.delete(firstKey);
        }
        
        this.cache.set(url, bitmap);
    }

    /**
     * Check if URL is cached
     */
    has(url) {
        return this.cache.has(url);
    }

    /**
     * Remove from cache
     */
    remove(url) {
        this.cache.delete(url);
    }

    /**
     * Clear cache
     */
    clear() {
        this.cache.clear();
    }

    /**
     * Get cache size
     */
    size() {
        return this.cache.size;
    }
}

export default {
    VNGdiObject,
    VNGdiObjectArray,
    VNBitmap,
    VNBmpImg,
    VNTransparentBmp,
    VNBkTexture,
    VNBitmapCache
};
