/**
 * VNScrollFx - Scroll and Transition Effects
 * 
 * EXACT PORT from europeo.exe scroll effects
 * 
 * Original classes from disassembly:
 * - TVNScrollFx @ 0x0041a706
 * - wm_scroll message @ 0x0044c55b
 * 
 * Window scroll handlers:
 * - @TWindow@EvVScroll$quiuip6HWND__ @ 0x0045328a
 * - @TWindow@EvHScroll$quiuip6HWND__ @ 0x004533b4
 */

/**
 * Scroll direction
 */
export const VNScrollDirection = {
    NONE: 0,
    LEFT: 1,
    RIGHT: 2,
    UP: 3,
    DOWN: 4,
    HORIZONTAL: 5,
    VERTICAL: 6
};

/**
 * Scroll effect type
 */
export const VNScrollFxType = {
    NONE: 0,
    SCROLL: 1,          // Simple scroll
    SLIDE: 2,           // Slide in/out
    PUSH: 3,            // Push existing content
    REVEAL: 4,          // Reveal (wipe)
    FADE: 5,            // Fade transition
    DISSOLVE: 6,        // Dissolve effect
    ZOOM: 7,            // Zoom in/out
    FLIP: 8,            // 3D flip
    CURTAIN: 9          // Curtain open/close
};

/**
 * VNScrollFx - Scroll effect class
 * Port of TVNScrollFx @ 0x0041a706
 */
export class VNScrollFx {
    constructor() {
        this.type = VNScrollFxType.SCROLL;
        this.direction = VNScrollDirection.NONE;
        this.duration = 500; // ms
        this.easing = 'ease-out';
        this.running = false;
        this.startTime = 0;
        this.progress = 0;
        
        // Source and destination
        this.srcCanvas = null;
        this.dstCanvas = null;
        this.outputCanvas = null;
        this.outputCtx = null;
        
        // Callbacks
        this.onStart = null;
        this.onProgress = null;
        this.onComplete = null;
    }

    /**
     * Initialize effect
     * @param {HTMLCanvasElement} srcCanvas - Source (current) canvas
     * @param {HTMLCanvasElement} dstCanvas - Destination (new) canvas
     * @param {HTMLCanvasElement} outputCanvas - Output canvas
     */
    init(srcCanvas, dstCanvas, outputCanvas) {
        this.srcCanvas = srcCanvas;
        this.dstCanvas = dstCanvas;
        this.outputCanvas = outputCanvas;
        this.outputCtx = outputCanvas.getContext('2d');
    }

    /**
     * Set effect type
     * @param {number} type 
     * @param {number} direction 
     */
    setType(type, direction = VNScrollDirection.LEFT) {
        this.type = type;
        this.direction = direction;
    }

    /**
     * Set duration
     * @param {number} ms 
     */
    setDuration(ms) {
        this.duration = ms;
    }

    /**
     * Set easing function
     * @param {string|Function} easing 
     */
    setEasing(easing) {
        this.easing = easing;
    }

    /**
     * Start effect
     * @returns {Promise<void>}
     */
    async start() {
        if (!this.srcCanvas || !this.dstCanvas || !this.outputCanvas) {
            throw new Error('Effect not initialized');
        }
        
        this.running = true;
        this.startTime = performance.now();
        this.progress = 0;
        
        if (this.onStart) {
            this.onStart();
        }
        
        return new Promise((resolve) => {
            const animate = (currentTime) => {
                if (!this.running) {
                    resolve();
                    return;
                }
                
                const elapsed = currentTime - this.startTime;
                this.progress = Math.min(elapsed / this.duration, 1);
                
                // Apply easing
                const easedProgress = this._applyEasing(this.progress);
                
                // Render frame
                this._renderFrame(easedProgress);
                
                if (this.onProgress) {
                    this.onProgress(this.progress);
                }
                
                if (this.progress >= 1) {
                    this.running = false;
                    if (this.onComplete) {
                        this.onComplete();
                    }
                    resolve();
                } else {
                    requestAnimationFrame(animate);
                }
            };
            
            requestAnimationFrame(animate);
        });
    }

    /**
     * Stop effect
     */
    stop() {
        this.running = false;
    }

    /**
     * Apply easing function
     * @private
     */
    _applyEasing(t) {
        if (typeof this.easing === 'function') {
            return this.easing(t);
        }
        
        switch (this.easing) {
            case 'linear':
                return t;
            case 'ease-in':
                return t * t;
            case 'ease-out':
                return t * (2 - t);
            case 'ease-in-out':
                return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
            case 'ease':
            default:
                // Cubic bezier approximation
                return t * t * (3 - 2 * t);
        }
    }

    /**
     * Render effect frame
     * @private
     */
    _renderFrame(progress) {
        const ctx = this.outputCtx;
        const w = this.outputCanvas.width;
        const h = this.outputCanvas.height;
        
        ctx.clearRect(0, 0, w, h);
        
        switch (this.type) {
            case VNScrollFxType.SCROLL:
            case VNScrollFxType.SLIDE:
                this._renderSlide(ctx, w, h, progress);
                break;
            case VNScrollFxType.PUSH:
                this._renderPush(ctx, w, h, progress);
                break;
            case VNScrollFxType.REVEAL:
                this._renderReveal(ctx, w, h, progress);
                break;
            case VNScrollFxType.FADE:
                this._renderFade(ctx, w, h, progress);
                break;
            case VNScrollFxType.DISSOLVE:
                this._renderDissolve(ctx, w, h, progress);
                break;
            case VNScrollFxType.ZOOM:
                this._renderZoom(ctx, w, h, progress);
                break;
            case VNScrollFxType.FLIP:
                this._renderFlip(ctx, w, h, progress);
                break;
            case VNScrollFxType.CURTAIN:
                this._renderCurtain(ctx, w, h, progress);
                break;
            default:
                // Just draw destination
                ctx.drawImage(this.dstCanvas, 0, 0);
        }
    }

    /**
     * Slide/scroll effect
     * @private
     */
    _renderSlide(ctx, w, h, progress) {
        let srcX = 0, srcY = 0, dstX = 0, dstY = 0;
        
        switch (this.direction) {
            case VNScrollDirection.LEFT:
                srcX = -w * progress;
                dstX = w * (1 - progress);
                break;
            case VNScrollDirection.RIGHT:
                srcX = w * progress;
                dstX = -w * (1 - progress);
                break;
            case VNScrollDirection.UP:
                srcY = -h * progress;
                dstY = h * (1 - progress);
                break;
            case VNScrollDirection.DOWN:
                srcY = h * progress;
                dstY = -h * (1 - progress);
                break;
        }
        
        ctx.drawImage(this.srcCanvas, srcX, srcY);
        ctx.drawImage(this.dstCanvas, dstX, dstY);
    }

    /**
     * Push effect
     * @private
     */
    _renderPush(ctx, w, h, progress) {
        let srcX = 0, srcY = 0, dstX = 0, dstY = 0;
        
        switch (this.direction) {
            case VNScrollDirection.LEFT:
                srcX = -w * progress;
                dstX = w - w * progress;
                break;
            case VNScrollDirection.RIGHT:
                srcX = w * progress;
                dstX = -w + w * progress;
                break;
            case VNScrollDirection.UP:
                srcY = -h * progress;
                dstY = h - h * progress;
                break;
            case VNScrollDirection.DOWN:
                srcY = h * progress;
                dstY = -h + h * progress;
                break;
        }
        
        ctx.drawImage(this.srcCanvas, srcX, srcY);
        ctx.drawImage(this.dstCanvas, dstX, dstY);
    }

    /**
     * Reveal/wipe effect
     * @private
     */
    _renderReveal(ctx, w, h, progress) {
        // Draw source first
        ctx.drawImage(this.srcCanvas, 0, 0);
        
        // Clip and draw destination
        ctx.save();
        ctx.beginPath();
        
        switch (this.direction) {
            case VNScrollDirection.LEFT:
                ctx.rect(0, 0, w * progress, h);
                break;
            case VNScrollDirection.RIGHT:
                ctx.rect(w * (1 - progress), 0, w * progress, h);
                break;
            case VNScrollDirection.UP:
                ctx.rect(0, 0, w, h * progress);
                break;
            case VNScrollDirection.DOWN:
                ctx.rect(0, h * (1 - progress), w, h * progress);
                break;
            case VNScrollDirection.HORIZONTAL:
                // From center
                const cx = w / 2;
                ctx.rect(cx - cx * progress, 0, w * progress, h);
                break;
            case VNScrollDirection.VERTICAL:
                // From center
                const cy = h / 2;
                ctx.rect(0, cy - cy * progress, w, h * progress);
                break;
        }
        
        ctx.clip();
        ctx.drawImage(this.dstCanvas, 0, 0);
        ctx.restore();
    }

    /**
     * Fade effect
     * @private
     */
    _renderFade(ctx, w, h, progress) {
        // Draw source
        ctx.globalAlpha = 1 - progress;
        ctx.drawImage(this.srcCanvas, 0, 0);
        
        // Draw destination
        ctx.globalAlpha = progress;
        ctx.drawImage(this.dstCanvas, 0, 0);
        
        ctx.globalAlpha = 1;
    }

    /**
     * Dissolve effect
     * @private
     */
    _renderDissolve(ctx, w, h, progress) {
        // Simple pixel dissolve using alpha
        ctx.drawImage(this.srcCanvas, 0, 0);
        
        // Create dissolve pattern
        const imgData = ctx.getImageData(0, 0, w, h);
        const dstImgData = ctx.createImageData(w, h);
        
        // Get destination data
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = w;
        tempCanvas.height = h;
        const tempCtx = tempCanvas.getContext('2d');
        tempCtx.drawImage(this.dstCanvas, 0, 0);
        const dstData = tempCtx.getImageData(0, 0, w, h);
        
        // Dissolve pixels
        for (let i = 0; i < imgData.data.length; i += 4) {
            const rand = Math.random();
            if (rand < progress) {
                dstImgData.data[i] = dstData.data[i];
                dstImgData.data[i + 1] = dstData.data[i + 1];
                dstImgData.data[i + 2] = dstData.data[i + 2];
                dstImgData.data[i + 3] = dstData.data[i + 3];
            } else {
                dstImgData.data[i] = imgData.data[i];
                dstImgData.data[i + 1] = imgData.data[i + 1];
                dstImgData.data[i + 2] = imgData.data[i + 2];
                dstImgData.data[i + 3] = imgData.data[i + 3];
            }
        }
        
        ctx.putImageData(dstImgData, 0, 0);
    }

    /**
     * Zoom effect
     * @private
     */
    _renderZoom(ctx, w, h, progress) {
        const cx = w / 2;
        const cy = h / 2;
        
        // Source zooms out
        ctx.save();
        ctx.globalAlpha = 1 - progress;
        const srcScale = 1 + progress * 0.5;
        ctx.translate(cx, cy);
        ctx.scale(srcScale, srcScale);
        ctx.translate(-cx, -cy);
        ctx.drawImage(this.srcCanvas, 0, 0);
        ctx.restore();
        
        // Destination zooms in
        ctx.save();
        ctx.globalAlpha = progress;
        const dstScale = 0.5 + progress * 0.5;
        ctx.translate(cx, cy);
        ctx.scale(dstScale, dstScale);
        ctx.translate(-cx, -cy);
        ctx.drawImage(this.dstCanvas, 0, 0);
        ctx.restore();
        
        ctx.globalAlpha = 1;
    }

    /**
     * 3D flip effect
     * @private
     */
    _renderFlip(ctx, w, h, progress) {
        const cx = w / 2;
        const cy = h / 2;
        
        if (progress < 0.5) {
            // First half - source flipping away
            const scale = Math.cos(progress * Math.PI);
            ctx.save();
            ctx.translate(cx, cy);
            if (this.direction === VNScrollDirection.HORIZONTAL) {
                ctx.scale(scale, 1);
            } else {
                ctx.scale(1, scale);
            }
            ctx.translate(-cx, -cy);
            ctx.drawImage(this.srcCanvas, 0, 0);
            ctx.restore();
        } else {
            // Second half - destination flipping in
            const scale = Math.cos((1 - progress) * Math.PI);
            ctx.save();
            ctx.translate(cx, cy);
            if (this.direction === VNScrollDirection.HORIZONTAL) {
                ctx.scale(scale, 1);
            } else {
                ctx.scale(1, scale);
            }
            ctx.translate(-cx, -cy);
            ctx.drawImage(this.dstCanvas, 0, 0);
            ctx.restore();
        }
    }

    /**
     * Curtain effect
     * @private
     */
    _renderCurtain(ctx, w, h, progress) {
        // Draw destination behind
        ctx.drawImage(this.dstCanvas, 0, 0);
        
        // Draw curtain (source) opening
        ctx.save();
        
        const openAmount = progress * (w / 2);
        
        // Left curtain
        ctx.beginPath();
        ctx.rect(0, 0, w / 2 - openAmount, h);
        ctx.clip();
        ctx.drawImage(this.srcCanvas, 0, 0);
        ctx.restore();
        
        ctx.save();
        // Right curtain
        ctx.beginPath();
        ctx.rect(w / 2 + openAmount, 0, w / 2 - openAmount, h);
        ctx.clip();
        ctx.drawImage(this.srcCanvas, 0, 0);
        ctx.restore();
    }
}

/**
 * VNScroller - Content scroller
 * Handles smooth scrolling of content
 */
export class VNScroller {
    /**
     * @param {HTMLElement} container 
     */
    constructor(container) {
        this.container = container;
        this.scrollX = 0;
        this.scrollY = 0;
        this.targetX = 0;
        this.targetY = 0;
        this.smoothing = 0.1;
        this.running = false;
    }

    /**
     * Scroll to position
     * @param {number} x 
     * @param {number} y 
     * @param {boolean} smooth 
     */
    scrollTo(x, y, smooth = true) {
        this.targetX = x;
        this.targetY = y;
        
        if (smooth) {
            this._startSmooth();
        } else {
            this.scrollX = x;
            this.scrollY = y;
            this._apply();
        }
    }

    /**
     * Scroll by amount
     * @param {number} dx 
     * @param {number} dy 
     * @param {boolean} smooth 
     */
    scrollBy(dx, dy, smooth = true) {
        this.scrollTo(this.targetX + dx, this.targetY + dy, smooth);
    }

    /**
     * Start smooth scroll animation
     * @private
     */
    _startSmooth() {
        if (this.running) return;
        this.running = true;
        
        const animate = () => {
            if (!this.running) return;
            
            // Lerp towards target
            this.scrollX += (this.targetX - this.scrollX) * this.smoothing;
            this.scrollY += (this.targetY - this.scrollY) * this.smoothing;
            
            // Check if close enough
            if (Math.abs(this.targetX - this.scrollX) < 0.5 &&
                Math.abs(this.targetY - this.scrollY) < 0.5) {
                this.scrollX = this.targetX;
                this.scrollY = this.targetY;
                this.running = false;
            }
            
            this._apply();
            
            if (this.running) {
                requestAnimationFrame(animate);
            }
        };
        
        requestAnimationFrame(animate);
    }

    /**
     * Apply scroll position
     * @private
     */
    _apply() {
        if (this.container) {
            this.container.scrollLeft = this.scrollX;
            this.container.scrollTop = this.scrollY;
        }
    }

    /**
     * Stop scrolling
     */
    stop() {
        this.running = false;
        this.targetX = this.scrollX;
        this.targetY = this.scrollY;
    }

    /**
     * Get scroll position
     * @returns {{x: number, y: number}}
     */
    getPosition() {
        return {
            x: this.scrollX,
            y: this.scrollY
        };
    }
}

export default {
    VNScrollDirection,
    VNScrollFxType,
    VNScrollFx,
    VNScroller
};
