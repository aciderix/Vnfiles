/**
 * VNZoomFx - Zoom Effects
 * 
 * EXACT PORT from europeo.exe zoom effects
 * 
 * Original classes from disassembly:
 * - TVNZoomFx @ detected in RTTI
 * - TVNTimerBasedFx @ detected in RTTI
 * - TVNBkTexture @ detected in RTTI
 */

/**
 * Zoom direction
 */
export const VNZoomDirection = {
    IN: 1,
    OUT: 2,
    NONE: 0
};

/**
 * Zoom origin
 */
export const VNZoomOrigin = {
    CENTER: 0,
    TOP_LEFT: 1,
    TOP_RIGHT: 2,
    BOTTOM_LEFT: 3,
    BOTTOM_RIGHT: 4,
    CUSTOM: 5
};

/**
 * VNTimerBasedFx - Base class for timer-based effects
 * Port of TVNTimerBasedFx
 */
export class VNTimerBasedFx {
    constructor() {
        this.duration = 1000; // ms
        this.startTime = 0;
        this.running = false;
        this.paused = false;
        this.progress = 0;
        this.timerInterval = 16; // ~60fps
        this.timerId = null;
        
        // Callbacks
        this.onStart = null;
        this.onProgress = null;
        this.onComplete = null;
        this.onPause = null;
        this.onResume = null;
    }

    /**
     * Set duration
     * @param {number} ms 
     */
    setDuration(ms) {
        this.duration = ms;
    }

    /**
     * Set timer interval
     * @param {number} ms 
     */
    setInterval(ms) {
        this.timerInterval = ms;
    }

    /**
     * Start effect
     */
    start() {
        if (this.running) return;
        
        this.running = true;
        this.paused = false;
        this.startTime = performance.now();
        this.progress = 0;
        
        if (this.onStart) {
            this.onStart();
        }
        
        this._tick();
    }

    /**
     * Stop effect
     */
    stop() {
        this.running = false;
        this.paused = false;
        
        if (this.timerId) {
            cancelAnimationFrame(this.timerId);
            this.timerId = null;
        }
    }

    /**
     * Pause effect
     */
    pause() {
        if (!this.running || this.paused) return;
        
        this.paused = true;
        
        if (this.onPause) {
            this.onPause();
        }
    }

    /**
     * Resume effect
     */
    resume() {
        if (!this.paused) return;
        
        this.paused = false;
        this.startTime = performance.now() - (this.progress * this.duration);
        
        if (this.onResume) {
            this.onResume();
        }
        
        this._tick();
    }

    /**
     * Timer tick
     * @private
     */
    _tick() {
        if (!this.running || this.paused) return;
        
        const elapsed = performance.now() - this.startTime;
        this.progress = Math.min(elapsed / this.duration, 1);
        
        this._update(this.progress);
        
        if (this.onProgress) {
            this.onProgress(this.progress);
        }
        
        if (this.progress >= 1) {
            this.running = false;
            if (this.onComplete) {
                this.onComplete();
            }
        } else {
            this.timerId = requestAnimationFrame(() => this._tick());
        }
    }

    /**
     * Update effect (override in subclass)
     * @param {number} progress 
     */
    _update(progress) {
        // Override in subclass
    }

    /**
     * Check if running
     * @returns {boolean}
     */
    isRunning() {
        return this.running && !this.paused;
    }

    /**
     * Get progress
     * @returns {number}
     */
    getProgress() {
        return this.progress;
    }
}

/**
 * VNZoomFx - Zoom effect
 * Port of TVNZoomFx
 */
export class VNZoomFx extends VNTimerBasedFx {
    constructor() {
        super();
        
        this.direction = VNZoomDirection.IN;
        this.origin = VNZoomOrigin.CENTER;
        this.originX = 0.5;
        this.originY = 0.5;
        this.startScale = 1;
        this.endScale = 2;
        this.currentScale = 1;
        
        // Target element/canvas
        this.target = null;
        this.ctx = null;
        this.sourceCanvas = null;
    }

    /**
     * Initialize zoom effect
     * @param {HTMLCanvasElement} canvas 
     * @param {HTMLCanvasElement|HTMLImageElement} source 
     */
    init(canvas, source) {
        this.target = canvas;
        this.ctx = canvas.getContext('2d');
        this.sourceCanvas = source;
    }

    /**
     * Set zoom direction
     * @param {number} direction 
     */
    setDirection(direction) {
        this.direction = direction;
        
        if (direction === VNZoomDirection.IN) {
            this.startScale = 1;
            this.endScale = 2;
        } else if (direction === VNZoomDirection.OUT) {
            this.startScale = 2;
            this.endScale = 1;
        }
    }

    /**
     * Set zoom range
     * @param {number} start 
     * @param {number} end 
     */
    setScaleRange(start, end) {
        this.startScale = start;
        this.endScale = end;
    }

    /**
     * Set zoom origin
     * @param {number} origin 
     * @param {number} customX 
     * @param {number} customY 
     */
    setOrigin(origin, customX = 0.5, customY = 0.5) {
        this.origin = origin;
        
        switch (origin) {
            case VNZoomOrigin.CENTER:
                this.originX = 0.5;
                this.originY = 0.5;
                break;
            case VNZoomOrigin.TOP_LEFT:
                this.originX = 0;
                this.originY = 0;
                break;
            case VNZoomOrigin.TOP_RIGHT:
                this.originX = 1;
                this.originY = 0;
                break;
            case VNZoomOrigin.BOTTOM_LEFT:
                this.originX = 0;
                this.originY = 1;
                break;
            case VNZoomOrigin.BOTTOM_RIGHT:
                this.originX = 1;
                this.originY = 1;
                break;
            case VNZoomOrigin.CUSTOM:
                this.originX = customX;
                this.originY = customY;
                break;
        }
    }

    /**
     * Update zoom effect
     * @param {number} progress 
     */
    _update(progress) {
        if (!this.ctx || !this.sourceCanvas) return;
        
        // Calculate current scale
        this.currentScale = this.startScale + (this.endScale - this.startScale) * progress;
        
        // Clear canvas
        const w = this.target.width;
        const h = this.target.height;
        this.ctx.clearRect(0, 0, w, h);
        
        // Calculate origin point
        const ox = w * this.originX;
        const oy = h * this.originY;
        
        // Apply transform
        this.ctx.save();
        this.ctx.translate(ox, oy);
        this.ctx.scale(this.currentScale, this.currentScale);
        this.ctx.translate(-ox, -oy);
        
        // Draw source
        this.ctx.drawImage(this.sourceCanvas, 0, 0);
        
        this.ctx.restore();
    }

    /**
     * Get current scale
     * @returns {number}
     */
    getCurrentScale() {
        return this.currentScale;
    }
}

/**
 * VNBkTexture - Background texture
 * Port of TVNBkTexture
 */
export class VNBkTexture {
    constructor() {
        this.texture = null;
        this.pattern = null;
        this.color = '#000000';
        this.mode = 'tile'; // 'tile', 'stretch', 'center', 'fit'
        this.opacity = 1;
    }

    /**
     * Load texture from URL
     * @param {string} url 
     * @returns {Promise<void>}
     */
    async load(url) {
        this.texture = new Image();
        
        await new Promise((resolve, reject) => {
            this.texture.onload = resolve;
            this.texture.onerror = reject;
            this.texture.src = url;
        });
    }

    /**
     * Set from image
     * @param {HTMLImageElement} image 
     */
    setImage(image) {
        this.texture = image;
        this.pattern = null;
    }

    /**
     * Set solid color
     * @param {string} color 
     */
    setColor(color) {
        this.color = color;
        this.texture = null;
        this.pattern = null;
    }

    /**
     * Set display mode
     * @param {string} mode 
     */
    setMode(mode) {
        this.mode = mode;
        this.pattern = null; // Invalidate pattern
    }

    /**
     * Set opacity
     * @param {number} opacity 
     */
    setOpacity(opacity) {
        this.opacity = Math.max(0, Math.min(1, opacity));
    }

    /**
     * Draw background
     * @param {CanvasRenderingContext2D} ctx 
     * @param {number} width 
     * @param {number} height 
     */
    draw(ctx, width, height) {
        ctx.save();
        ctx.globalAlpha = this.opacity;
        
        if (this.texture) {
            switch (this.mode) {
                case 'tile':
                    this._drawTiled(ctx, width, height);
                    break;
                case 'stretch':
                    ctx.drawImage(this.texture, 0, 0, width, height);
                    break;
                case 'center':
                    this._drawCentered(ctx, width, height);
                    break;
                case 'fit':
                    this._drawFit(ctx, width, height);
                    break;
            }
        } else {
            ctx.fillStyle = this.color;
            ctx.fillRect(0, 0, width, height);
        }
        
        ctx.restore();
    }

    /**
     * Draw tiled
     * @private
     */
    _drawTiled(ctx, width, height) {
        if (!this.pattern) {
            this.pattern = ctx.createPattern(this.texture, 'repeat');
        }
        
        if (this.pattern) {
            ctx.fillStyle = this.pattern;
            ctx.fillRect(0, 0, width, height);
        }
    }

    /**
     * Draw centered
     * @private
     */
    _drawCentered(ctx, width, height) {
        const x = (width - this.texture.width) / 2;
        const y = (height - this.texture.height) / 2;
        
        // Fill background with color first
        ctx.fillStyle = this.color;
        ctx.fillRect(0, 0, width, height);
        
        ctx.drawImage(this.texture, x, y);
    }

    /**
     * Draw fit (maintain aspect ratio)
     * @private
     */
    _drawFit(ctx, width, height) {
        const texW = this.texture.width;
        const texH = this.texture.height;
        
        const scale = Math.min(width / texW, height / texH);
        const scaledW = texW * scale;
        const scaledH = texH * scale;
        
        const x = (width - scaledW) / 2;
        const y = (height - scaledH) / 2;
        
        // Fill background with color first
        ctx.fillStyle = this.color;
        ctx.fillRect(0, 0, width, height);
        
        ctx.drawImage(this.texture, x, y, scaledW, scaledH);
    }

    /**
     * Get texture size
     * @returns {{width: number, height: number}|null}
     */
    getSize() {
        if (!this.texture) return null;
        return {
            width: this.texture.width,
            height: this.texture.height
        };
    }
}

/**
 * VNTransparentBmp - Transparent bitmap
 * Port of TVNTransparentBmp
 */
export class VNTransparentBmp {
    constructor() {
        this.image = null;
        this.transparentColor = null;
        this.canvas = null;
        this.ctx = null;
    }

    /**
     * Load bitmap
     * @param {string} url 
     * @returns {Promise<void>}
     */
    async load(url) {
        this.image = new Image();
        
        await new Promise((resolve, reject) => {
            this.image.onload = resolve;
            this.image.onerror = reject;
            this.image.src = url;
        });
        
        this._createCanvas();
    }

    /**
     * Set from image
     * @param {HTMLImageElement} image 
     */
    setImage(image) {
        this.image = image;
        this._createCanvas();
    }

    /**
     * Set transparent color
     * @param {number} r 
     * @param {number} g 
     * @param {number} b 
     */
    setTransparentColor(r, g, b) {
        this.transparentColor = { r, g, b };
        this._applyTransparency();
    }

    /**
     * Set transparent color from pixel
     * @param {number} x 
     * @param {number} y 
     */
    setTransparentColorFromPixel(x, y) {
        if (!this.ctx) return;
        
        const pixel = this.ctx.getImageData(x, y, 1, 1).data;
        this.transparentColor = {
            r: pixel[0],
            g: pixel[1],
            b: pixel[2]
        };
        
        this._applyTransparency();
    }

    /**
     * Create internal canvas
     * @private
     */
    _createCanvas() {
        if (!this.image) return;
        
        this.canvas = document.createElement('canvas');
        this.canvas.width = this.image.width;
        this.canvas.height = this.image.height;
        this.ctx = this.canvas.getContext('2d');
        this.ctx.drawImage(this.image, 0, 0);
    }

    /**
     * Apply transparency
     * @private
     */
    _applyTransparency() {
        if (!this.ctx || !this.transparentColor) return;
        
        const imgData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imgData.data;
        
        const { r, g, b } = this.transparentColor;
        const tolerance = 5; // Color matching tolerance
        
        for (let i = 0; i < data.length; i += 4) {
            if (Math.abs(data[i] - r) <= tolerance &&
                Math.abs(data[i + 1] - g) <= tolerance &&
                Math.abs(data[i + 2] - b) <= tolerance) {
                data[i + 3] = 0; // Set alpha to 0
            }
        }
        
        this.ctx.putImageData(imgData, 0, 0);
    }

    /**
     * Draw
     * @param {CanvasRenderingContext2D} destCtx 
     * @param {number} x 
     * @param {number} y 
     */
    draw(destCtx, x, y) {
        if (this.canvas) {
            destCtx.drawImage(this.canvas, x, y);
        } else if (this.image) {
            destCtx.drawImage(this.image, x, y);
        }
    }

    /**
     * Get size
     * @returns {{width: number, height: number}|null}
     */
    getSize() {
        const src = this.canvas || this.image;
        if (!src) return null;
        return {
            width: src.width,
            height: src.height
        };
    }

    /**
     * Get canvas
     * @returns {HTMLCanvasElement|null}
     */
    getCanvas() {
        return this.canvas;
    }
}

export default {
    VNZoomDirection,
    VNZoomOrigin,
    VNTimerBasedFx,
    VNZoomFx,
    VNBkTexture,
    VNTransparentBmp
};
