/**
 * VNVideoSystem - AVI/Video playback system
 * 
 * EXACT PORT from video handling functions
 * Classes: TVNAviMedia, TVNVideoBaseMedia
 * 
 * @original_file video handling in europeo.exe
 * @original_address 0x00425ab4 and related
 */

/**
 * VNVideoParms - Video parameter structure
 * Corresponds to playavi command parameters
 */
class VNVideoParms {
    constructor() {
        this.filename = '';       // Video file path
        this.left = 0;            // HSVIDEORECT left
        this.top = 0;             // HSVIDEORECT top
        this.width = 0;           // HSVIDEORECT width
        this.height = 0;          // HSVIDEORECT height
        this.loop = false;        // Loop playback
        this.autostart = true;    // Start immediately
        this.volume = 100;        // Volume 0-100
        this.flags = 0;           // HSVIDEOFLAGS
        this.showControls = false; // Show video controls
        this.fullscreen = false;  // Fullscreen mode
    }

    /**
     * Parse from command string
     * Format: playavi,filename[,left,top,width,height][,flags]
     */
    static parse(args) {
        const parms = new VNVideoParms();
        
        if (!args) return parms;
        
        const parts = args.split(',').map(s => s.trim());
        
        if (parts.length >= 1) parms.filename = parts[0];
        if (parts.length >= 2) parms.left = parseInt(parts[1]) || 0;
        if (parts.length >= 3) parms.top = parseInt(parts[2]) || 0;
        if (parts.length >= 4) parms.width = parseInt(parts[3]) || 0;
        if (parts.length >= 5) parms.height = parseInt(parts[4]) || 0;
        if (parts.length >= 6) parms.flags = parseInt(parts[5]) || 0;
        
        // Parse flags
        if (parms.flags & 0x01) parms.loop = true;
        if (parms.flags & 0x02) parms.fullscreen = true;
        if (parms.flags & 0x04) parms.showControls = true;
        if (parms.flags & 0x08) parms.autostart = false;
        
        return parms;
    }
}

/**
 * VNVideoState - Video state enumeration
 * Corresponds to MCI state values
 */
const VNVideoState = {
    STOPPED: 0,
    PLAYING: 1,
    PAUSED: 2,
    SEEKING: 3,
    LOADING: 4,
    ERROR: 5
};

/**
 * VNVideoBaseMedia - Base video media class
 * Port of TVNVideoBaseMedia
 * @original_address 0x0041c5fb (TVNVideoBaseMedia)
 */
class VNVideoBaseMedia {
    constructor() {
        // Internal state
        this._state = VNVideoState.STOPPED;
        this._position = 0;
        this._duration = 0;
        this._volume = 100;
        this._muted = false;
        this._loop = false;
        
        // Media element
        this._element = null;
        
        // Event callbacks
        this.onPlay = null;
        this.onPause = null;
        this.onStop = null;
        this.onEnd = null;
        this.onError = null;
        this.onTimeUpdate = null;
        this.onLoad = null;
    }

    get state() { return this._state; }
    get isPlaying() { return this._state === VNVideoState.PLAYING; }
    get isPaused() { return this._state === VNVideoState.PAUSED; }
    get isStopped() { return this._state === VNVideoState.STOPPED; }
    get position() { return this._position; }
    get duration() { return this._duration; }
    get volume() { return this._volume; }
    get loop() { return this._loop; }

    /**
     * Set volume (0-100)
     */
    setVolume(value) {
        this._volume = Math.max(0, Math.min(100, value));
        if (this._element) {
            this._element.volume = this._volume / 100;
        }
    }

    /**
     * Set muted state
     */
    setMuted(muted) {
        this._muted = muted;
        if (this._element) {
            this._element.muted = muted;
        }
    }

    /**
     * Set loop state
     */
    setLoop(loop) {
        this._loop = loop;
        if (this._element) {
            this._element.loop = loop;
        }
    }

    /**
     * Seek to position (milliseconds)
     */
    seek(position) {
        this._position = position;
        if (this._element) {
            this._element.currentTime = position / 1000;
        }
    }

    // Abstract methods to be implemented by subclasses
    open(filename) { throw new Error('Not implemented'); }
    play() { throw new Error('Not implemented'); }
    pause() { throw new Error('Not implemented'); }
    stop() { throw new Error('Not implemented'); }
    close() { throw new Error('Not implemented'); }
}

/**
 * VNAviMedia - AVI video player
 * Port of TVNAviMedia
 * @original_address 0x0043640c (TVNAviMedia)
 */
class VNAviMedia extends VNVideoBaseMedia {
    // Video ID counter (HSVIDEO_%u at 0x00441436)
    static _idCounter = 0;

    constructor(engine) {
        super();
        
        this.engine = engine;
        this.id = VNAviMedia._idCounter++;
        this.name = `HSVIDEO_${this.id}`;
        
        // Video element
        this._video = null;
        this._container = null;
        
        // Display rect (HSVIDEORECT)
        this.rect = {
            left: 0,
            top: 0,
            width: 320,
            height: 240
        };
        
        // Flags (HSVIDEOFLAGS)
        this.flags = 0;
        
        // File info
        this.filename = '';
        this.loaded = false;
        
        // Promise for async operations
        this._loadPromise = null;
    }

    /**
     * Open video file
     * @original_address MCI_OPEN equivalent
     */
    async open(filename, parms = null) {
        this.filename = filename;
        this._state = VNVideoState.LOADING;
        
        // Apply parameters if provided
        if (parms) {
            this.rect.left = parms.left;
            this.rect.top = parms.top;
            this.rect.width = parms.width || 320;
            this.rect.height = parms.height || 240;
            this.flags = parms.flags;
            this._loop = parms.loop;
        }

        // Create video element
        this._video = document.createElement('video');
        this._video.style.position = 'absolute';
        this._video.style.left = `${this.rect.left}px`;
        this._video.style.top = `${this.rect.top}px`;
        this._video.style.width = `${this.rect.width}px`;
        this._video.style.height = `${this.rect.height}px`;
        this._video.style.backgroundColor = '#000';
        this._video.playsInline = true;
        this._video.loop = this._loop;
        this._video.volume = this._volume / 100;
        
        // Attach event listeners
        this._attachEvents();

        // Create container if needed
        if (this.engine && this.engine.container) {
            this.engine.container.appendChild(this._video);
        }
        
        this._element = this._video;

        // Load video
        return new Promise((resolve, reject) => {
            this._video.onloadeddata = () => {
                this._duration = this._video.duration * 1000;
                this.loaded = true;
                this._state = VNVideoState.STOPPED;
                
                // Auto-adjust size if not specified
                if (this.rect.width === 0 || this.rect.height === 0) {
                    this.rect.width = this._video.videoWidth;
                    this.rect.height = this._video.videoHeight;
                    this._video.style.width = `${this.rect.width}px`;
                    this._video.style.height = `${this.rect.height}px`;
                }
                
                if (this.onLoad) this.onLoad(this);
                resolve(this);
            };
            
            this._video.onerror = (e) => {
                this._state = VNVideoState.ERROR;
                if (this.onError) this.onError(e);
                reject(e);
            };
            
            // Resolve path and set source
            const resolvedPath = this.engine ? 
                this.engine.resolvePath(filename) : filename;
            this._video.src = resolvedPath;
            this._video.load();
        });
    }

    /**
     * Attach event listeners to video element
     */
    _attachEvents() {
        if (!this._video) return;
        
        this._video.ontimeupdate = () => {
            this._position = this._video.currentTime * 1000;
            if (this.onTimeUpdate) this.onTimeUpdate(this._position);
        };
        
        this._video.onplay = () => {
            this._state = VNVideoState.PLAYING;
            if (this.onPlay) this.onPlay(this);
        };
        
        this._video.onpause = () => {
            if (this._state !== VNVideoState.STOPPED) {
                this._state = VNVideoState.PAUSED;
                if (this.onPause) this.onPause(this);
            }
        };
        
        this._video.onended = () => {
            if (!this._loop) {
                this._state = VNVideoState.STOPPED;
                if (this.onEnd) this.onEnd(this);
            }
        };
    }

    /**
     * Play video
     * @original_address MCI_PLAY equivalent
     */
    play() {
        if (!this._video || !this.loaded) {
            console.warn('VNAviMedia: Video not loaded');
            return false;
        }
        
        this._video.play().catch(e => {
            console.error('VNAviMedia: Playback failed:', e);
            if (this.onError) this.onError(e);
        });
        
        return true;
    }

    /**
     * Pause video
     * @original_address MCI_PAUSE equivalent
     */
    pause() {
        if (this._video && this.isPlaying) {
            this._video.pause();
            return true;
        }
        return false;
    }

    /**
     * Stop video (pause and rewind)
     * @original_address MCI_STOP equivalent
     */
    stop() {
        if (this._video) {
            this._video.pause();
            this._video.currentTime = 0;
            this._state = VNVideoState.STOPPED;
            this._position = 0;
            if (this.onStop) this.onStop(this);
            return true;
        }
        return false;
    }

    /**
     * Close video and cleanup
     * @original_address MCI_CLOSE / closeavi command
     */
    close() {
        this.stop();
        
        if (this._video) {
            this._video.src = '';
            if (this._video.parentNode) {
                this._video.parentNode.removeChild(this._video);
            }
            this._video = null;
        }
        
        this._element = null;
        this.loaded = false;
        this.filename = '';
    }

    /**
     * Set display rectangle
     * @original_address HSVIDEORECT setting
     */
    setRect(left, top, width, height) {
        this.rect.left = left;
        this.rect.top = top;
        this.rect.width = width;
        this.rect.height = height;
        
        if (this._video) {
            this._video.style.left = `${left}px`;
            this._video.style.top = `${top}px`;
            this._video.style.width = `${width}px`;
            this._video.style.height = `${height}px`;
        }
    }

    /**
     * Show video element
     */
    show() {
        if (this._video) {
            this._video.style.display = 'block';
        }
    }

    /**
     * Hide video element
     */
    hide() {
        if (this._video) {
            this._video.style.display = 'none';
        }
    }

    /**
     * Set fullscreen mode
     */
    setFullscreen(fullscreen) {
        if (!this._video) return;
        
        if (fullscreen) {
            if (this._video.requestFullscreen) {
                this._video.requestFullscreen();
            } else if (this._video.webkitRequestFullscreen) {
                this._video.webkitRequestFullscreen();
            }
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }
        }
    }

    /**
     * Get video dimensions
     */
    getVideoDimensions() {
        if (this._video) {
            return {
                width: this._video.videoWidth,
                height: this._video.videoHeight
            };
        }
        return { width: 0, height: 0 };
    }
}

/**
 * VNVideoManager - Video playback management
 * Manages multiple video instances
 */
class VNVideoManager {
    constructor(engine) {
        this.engine = engine;
        
        // Video instances by name
        this.videos = new Map();
        
        // Currently playing video
        this.currentVideo = null;
    }

    /**
     * Create and open video
     * @original_address playavi command handler
     */
    async playVideo(filename, parms = null) {
        // Parse parameters if string
        if (typeof parms === 'string') {
            parms = VNVideoParms.parse(parms);
        }
        
        // Create video instance
        const video = new VNAviMedia(this.engine);
        
        try {
            await video.open(filename, parms);
            
            // Store by name
            this.videos.set(video.name, video);
            
            // Set as current
            this.currentVideo = video;
            
            // Auto-play if requested
            if (!parms || parms.autostart !== false) {
                video.play();
            }
            
            return video;
            
        } catch (error) {
            console.error('VNVideoManager: Failed to play video:', error);
            return null;
        }
    }

    /**
     * Close video by name
     * @original_address closeavi command handler
     */
    closeVideo(name = null) {
        if (name) {
            const video = this.videos.get(name);
            if (video) {
                video.close();
                this.videos.delete(name);
                if (this.currentVideo === video) {
                    this.currentVideo = null;
                }
                return true;
            }
        } else if (this.currentVideo) {
            // Close current video
            const name = this.currentVideo.name;
            this.currentVideo.close();
            this.videos.delete(name);
            this.currentVideo = null;
            return true;
        }
        return false;
    }

    /**
     * Close all videos
     */
    closeAll() {
        for (const video of this.videos.values()) {
            video.close();
        }
        this.videos.clear();
        this.currentVideo = null;
    }

    /**
     * Get video by name
     */
    getVideo(name) {
        return this.videos.get(name) || null;
    }

    /**
     * Pause all videos
     */
    pauseAll() {
        for (const video of this.videos.values()) {
            video.pause();
        }
    }

    /**
     * Stop all videos
     */
    stopAll() {
        for (const video of this.videos.values()) {
            video.stop();
        }
    }

    /**
     * Set volume for all videos
     */
    setGlobalVolume(volume) {
        for (const video of this.videos.values()) {
            video.setVolume(volume);
        }
    }

    /**
     * Check if any video is playing
     */
    get isPlaying() {
        for (const video of this.videos.values()) {
            if (video.isPlaying) return true;
        }
        return false;
    }
}

/**
 * VNMciCommand - MCI command string builder
 * Maps to mciSendCommandA calls
 * @original_address mciSendCommandA import at 0x0045419e
 */
class VNMciCommand {
    // MCI command IDs
    static MCI_OPEN = 0x0803;
    static MCI_CLOSE = 0x0804;
    static MCI_PLAY = 0x0806;
    static MCI_STOP = 0x0808;
    static MCI_PAUSE = 0x0809;
    static MCI_SEEK = 0x0807;
    static MCI_STATUS = 0x0814;
    static MCI_SET = 0x080D;

    // MCI flags
    static MCI_NOTIFY = 0x00000001;
    static MCI_WAIT = 0x00000002;
    static MCI_FROM = 0x00000004;
    static MCI_TO = 0x00000008;

    // Device types
    static DEVICE_AVIVIDEO = 'avivideo';
    static DEVICE_WAVEAUDIO = 'waveaudio';
    static DEVICE_CDAUDIO = 'cdaudio';
    static DEVICE_SEQUENCER = 'sequencer';

    /**
     * Build open command string
     */
    static buildOpen(deviceType, filename, alias) {
        let cmd = `open ${filename} type ${deviceType}`;
        if (alias) {
            cmd += ` alias ${alias}`;
        }
        return cmd;
    }

    /**
     * Build play command string
     */
    static buildPlay(alias, from = null, to = null, notify = false) {
        let cmd = `play ${alias}`;
        if (from !== null) {
            cmd += ` from ${from}`;
        }
        if (to !== null) {
            cmd += ` to ${to}`;
        }
        if (notify) {
            cmd += ' notify';
        }
        return cmd;
    }

    /**
     * Build stop command string
     */
    static buildStop(alias) {
        return `stop ${alias}`;
    }

    /**
     * Build close command string
     */
    static buildClose(alias) {
        return `close ${alias}`;
    }

    /**
     * Build seek command string
     */
    static buildSeek(alias, position) {
        return `seek ${alias} to ${position}`;
    }

    /**
     * Build status command string
     */
    static buildStatus(alias, item) {
        return `status ${alias} ${item}`;
    }

    /**
     * Build set command string
     */
    static buildSet(alias, item, value) {
        return `set ${alias} ${item} ${value}`;
    }
}

// Export all classes
export {
    VNVideoParms,
    VNVideoState,
    VNVideoBaseMedia,
    VNAviMedia,
    VNVideoManager,
    VNMciCommand
};
