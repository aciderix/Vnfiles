/**
 * VNMedia - Port of TVNMediaCtrl and related media functions
 * 
 * Original Windows APIs used:
 * - mciSendCommandA @ 0x0043985e (MCI commands for audio/video)
 * - mciGetErrorStringA @ 0x00439864
 * - PlaySoundA @ 0x0043986a
 * - waveOutGetNumDevs @ 0x00439834
 * - midiOutGetNumDevs @ 0x00439858
 * - DirectDrawCreate @ 0x00439870 (for video/graphics)
 * - timeSetEvent / timeKillEvent @ 0x0043983a / 0x00439840 (timing)
 * 
 * MCI Command IDs (from WINMM):
 * - MCI_OPEN = 0x0803
 * - MCI_CLOSE = 0x0804
 * - MCI_PLAY = 0x0806
 * - MCI_STOP = 0x0808
 * - MCI_PAUSE = 0x0809
 * - MCI_RESUME = 0x0855
 * - MCI_SEEK = 0x0807
 */

/**
 * Media type constants
 */
const MEDIA_TYPE = {
    UNKNOWN: 0,
    WAVE: 1,      // WAV audio
    MIDI: 2,      // MIDI music
    CDAUDIO: 3,   // CD Audio
    AVI: 4,       // AVI video
    SEQUENCE: 5   // Sequence
};

/**
 * Media state constants
 */
const MEDIA_STATE = {
    STOPPED: 0,
    PLAYING: 1,
    PAUSED: 2,
    LOADING: 3,
    ERROR: 4
};

/**
 * VNAudio - Audio playback system
 * Port of WAV and MIDI handling
 */
class VNAudio {
    constructor() {
        // Audio context for Web Audio API
        this._audioContext = null;
        
        // Currently playing sounds (WAV)
        this._sounds = new Map();
        
        // Currently playing music (MIDI -> MP3 in web)
        this._music = null;
        this._musicElement = null;
        
        // Volume settings (0-100, like original)
        this._masterVolume = 100;
        this._musicVolume = 100;
        this._sfxVolume = 100;
        
        // Audio cache
        this._cache = new Map();
    }

    /**
     * Initialize audio system
     * Original: waveOutGetNumDevs check
     */
    async init() {
        try {
            this._audioContext = new (window.AudioContext || window.webkitAudioContext)();
            return true;
        } catch (error) {
            console.error('Failed to initialize audio:', error);
            return false;
        }
    }

    /**
     * Resume audio context (needed after user interaction)
     */
    async resume() {
        if (this._audioContext && this._audioContext.state === 'suspended') {
            await this._audioContext.resume();
        }
    }

    /**
     * Load audio file
     */
    async load(url, type = MEDIA_TYPE.WAVE) {
        const cacheKey = `${type}:${url}`;
        
        if (this._cache.has(cacheKey)) {
            return this._cache.get(cacheKey);
        }
        
        try {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            const audioBuffer = await this._audioContext.decodeAudioData(arrayBuffer);
            
            this._cache.set(cacheKey, audioBuffer);
            return audioBuffer;
        } catch (error) {
            console.error(`Failed to load audio ${url}:`, error);
            return null;
        }
    }

    /**
     * Play sound effect (WAV)
     * Original: PlaySoundA @ 0x0043986a
     * 
     * Flags from original:
     * - SND_ASYNC = 0x0001
     * - SND_LOOP = 0x0008
     * - SND_NODEFAULT = 0x0002
     */
    async playSound(url, options = {}) {
        await this.resume();
        
        const buffer = await this.load(url, MEDIA_TYPE.WAVE);
        if (!buffer) return null;
        
        const source = this._audioContext.createBufferSource();
        source.buffer = buffer;
        
        // Volume control
        const gainNode = this._audioContext.createGain();
        gainNode.gain.value = (this._masterVolume / 100) * (this._sfxVolume / 100);
        
        source.connect(gainNode);
        gainNode.connect(this._audioContext.destination);
        
        // Loop setting
        source.loop = options.loop || false;
        
        // Generate ID
        const id = options.id || `sound_${Date.now()}`;
        
        // Store reference
        this._sounds.set(id, {
            source,
            gainNode,
            state: MEDIA_STATE.PLAYING
        });
        
        // Cleanup on end
        source.onended = () => {
            this._sounds.delete(id);
        };
        
        source.start(0);
        
        return id;
    }

    /**
     * Stop sound effect
     */
    stopSound(id) {
        if (id) {
            const sound = this._sounds.get(id);
            if (sound) {
                try {
                    sound.source.stop();
                } catch (e) {}
                this._sounds.delete(id);
            }
        } else {
            // Stop all sounds
            for (const [soundId, sound] of this._sounds) {
                try {
                    sound.source.stop();
                } catch (e) {}
            }
            this._sounds.clear();
        }
        return true;
    }

    /**
     * Play music (MIDI -> converted to MP3/OGG in web)
     * Original: mciSendCommandA with MCI_OPEN + MCI_PLAY
     */
    async playMusic(url, options = {}) {
        await this.resume();
        
        // Stop current music
        this.stopMusic();
        
        // Create audio element for music (better for long audio)
        this._musicElement = new Audio();
        this._musicElement.src = url;
        this._musicElement.loop = options.loop !== false; // Default loop for music
        this._musicElement.volume = (this._masterVolume / 100) * (this._musicVolume / 100);
        
        try {
            await this._musicElement.play();
            this._music = {
                element: this._musicElement,
                url,
                state: MEDIA_STATE.PLAYING
            };
            return true;
        } catch (error) {
            console.error('Failed to play music:', error);
            return false;
        }
    }

    /**
     * Stop music
     * Original: mciSendCommandA with MCI_STOP
     */
    stopMusic() {
        if (this._musicElement) {
            this._musicElement.pause();
            this._musicElement.currentTime = 0;
            this._musicElement = null;
        }
        this._music = null;
        return true;
    }

    /**
     * Pause music
     * Original: mciSendCommandA with MCI_PAUSE
     */
    pauseMusic() {
        if (this._musicElement) {
            this._musicElement.pause();
            if (this._music) {
                this._music.state = MEDIA_STATE.PAUSED;
            }
        }
        return true;
    }

    /**
     * Resume music
     * Original: mciSendCommandA with MCI_RESUME
     */
    async resumeMusic() {
        if (this._musicElement) {
            try {
                await this._musicElement.play();
                if (this._music) {
                    this._music.state = MEDIA_STATE.PLAYING;
                }
                return true;
            } catch (error) {
                return false;
            }
        }
        return false;
    }

    /**
     * Set master volume (0-100)
     */
    setMasterVolume(volume) {
        this._masterVolume = Math.max(0, Math.min(100, volume));
        this._updateVolumes();
    }

    /**
     * Set music volume (0-100)
     */
    setMusicVolume(volume) {
        this._musicVolume = Math.max(0, Math.min(100, volume));
        this._updateVolumes();
    }

    /**
     * Set SFX volume (0-100)
     */
    setSfxVolume(volume) {
        this._sfxVolume = Math.max(0, Math.min(100, volume));
        this._updateVolumes();
    }

    /**
     * Update all volumes
     */
    _updateVolumes() {
        // Update music volume
        if (this._musicElement) {
            this._musicElement.volume = (this._masterVolume / 100) * (this._musicVolume / 100);
        }
        
        // Update sound effects volume
        for (const [id, sound] of this._sounds) {
            sound.gainNode.gain.value = (this._masterVolume / 100) * (this._sfxVolume / 100);
        }
    }

    /**
     * Get volumes
     */
    get masterVolume() { return this._masterVolume; }
    get musicVolume() { return this._musicVolume; }
    get sfxVolume() { return this._sfxVolume; }
}

/**
 * VNVideo - Video playback system
 * Port of AVI handling via MCI
 * Original: DirectDrawCreate @ 0x00439870
 */
class VNVideo {
    constructor() {
        this._videoElement = null;
        this._container = null;
        this._state = MEDIA_STATE.STOPPED;
        this._onEndCallback = null;
    }

    /**
     * Initialize video system
     */
    init(container) {
        this._container = container;
    }

    /**
     * Play video
     * Original: mciSendCommandA with MCI_OPEN (cdvideo) + MCI_PLAY
     */
    async play(url, options = {}) {
        // Stop current video
        this.stop();
        
        // Create video element
        this._videoElement = document.createElement('video');
        this._videoElement.src = url;
        this._videoElement.loop = options.loop || false;
        this._videoElement.muted = options.muted || false;
        
        // Set position and size
        this._videoElement.style.position = 'absolute';
        this._videoElement.style.left = (options.x || 0) + 'px';
        this._videoElement.style.top = (options.y || 0) + 'px';
        
        if (options.width) {
            this._videoElement.style.width = options.width + 'px';
        }
        if (options.height) {
            this._videoElement.style.height = options.height + 'px';
        }
        
        // Handle end
        this._videoElement.onended = () => {
            this._state = MEDIA_STATE.STOPPED;
            if (this._onEndCallback) {
                this._onEndCallback();
            }
            if (!options.keepVisible) {
                this.stop();
            }
        };
        
        // Add to container
        if (this._container) {
            this._container.appendChild(this._videoElement);
        }
        
        try {
            await this._videoElement.play();
            this._state = MEDIA_STATE.PLAYING;
            return true;
        } catch (error) {
            console.error('Failed to play video:', error);
            this._state = MEDIA_STATE.ERROR;
            return false;
        }
    }

    /**
     * Stop video
     * Original: mciSendCommandA with MCI_STOP + MCI_CLOSE
     */
    stop() {
        if (this._videoElement) {
            this._videoElement.pause();
            this._videoElement.remove();
            this._videoElement = null;
        }
        this._state = MEDIA_STATE.STOPPED;
        return true;
    }

    /**
     * Pause video
     */
    pause() {
        if (this._videoElement) {
            this._videoElement.pause();
            this._state = MEDIA_STATE.PAUSED;
        }
        return true;
    }

    /**
     * Resume video
     */
    async resume() {
        if (this._videoElement) {
            try {
                await this._videoElement.play();
                this._state = MEDIA_STATE.PLAYING;
                return true;
            } catch (error) {
                return false;
            }
        }
        return false;
    }

    /**
     * Set callback for video end
     */
    onEnd(callback) {
        this._onEndCallback = callback;
    }

    /**
     * Get current state
     */
    get state() {
        return this._state;
    }

    /**
     * Check if playing
     */
    get isPlaying() {
        return this._state === MEDIA_STATE.PLAYING;
    }
}

/**
 * VNTimer - Timer system
 * Port of timeSetEvent/timeKillEvent @ 0x0043983a/0x00439840
 */
class VNTimer {
    constructor() {
        this._timers = new Map();
        this._nextId = 1;
    }

    /**
     * Set a timer
     * Original: timeSetEvent(delay, resolution, callback, user, type)
     */
    set(delay, callback, repeat = false) {
        const id = this._nextId++;
        
        if (repeat) {
            const intervalId = setInterval(callback, delay);
            this._timers.set(id, { type: 'interval', handle: intervalId });
        } else {
            const timeoutId = setTimeout(() => {
                callback();
                this._timers.delete(id);
            }, delay);
            this._timers.set(id, { type: 'timeout', handle: timeoutId });
        }
        
        return id;
    }

    /**
     * Kill a timer
     * Original: timeKillEvent(timerId)
     */
    kill(id) {
        const timer = this._timers.get(id);
        
        if (timer) {
            if (timer.type === 'interval') {
                clearInterval(timer.handle);
            } else {
                clearTimeout(timer.handle);
            }
            this._timers.delete(id);
            return true;
        }
        
        return false;
    }

    /**
     * Kill all timers
     */
    killAll() {
        for (const [id, timer] of this._timers) {
            if (timer.type === 'interval') {
                clearInterval(timer.handle);
            } else {
                clearTimeout(timer.handle);
            }
        }
        this._timers.clear();
    }
}

export { VNAudio, VNVideo, VNTimer, MEDIA_TYPE, MEDIA_STATE };
export default { VNAudio, VNVideo, VNTimer };
