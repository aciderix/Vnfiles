/**
 * VNMciMedia - MCI Media classes
 * 
 * Port of TVNMciBase, TVNAviMedia, TVNCDAMedia, TVNMidiMedia, 
 * TVNWaveMedia, TVNVideoBaseMedia, TVNHiddenMedia from europeo.exe
 * 
 * These classes wrapped Windows MCI (Media Control Interface) commands.
 * The web port uses HTML5 Audio/Video APIs.
 */

import { VNStreamable } from '../core/VNObject.js';

/**
 * Media state enumeration
 */
export const VNMediaState = {
    STOPPED: 'stopped',
    PLAYING: 'playing',
    PAUSED: 'paused',
    LOADING: 'loading',
    ERROR: 'error'
};

/**
 * TVNMciBase - Base MCI media class
 * Port from europeo.exe (MCI wrapper base)
 */
export class VNMciBase extends VNStreamable {
    constructor() {
        super();
        
        this.id = VNMciBase._nextId++;
        this.name = '';
        this.alias = '';
        this.fileName = '';
        this.deviceType = '';
        
        // State
        this.state = VNMediaState.STOPPED;
        this.position = 0;
        this.duration = 0;
        this.volume = 100;
        this.muted = false;
        this.loop = false;
        this.autoPlay = false;
        
        // Error handling
        this.lastError = null;
        
        // Callbacks
        this._onStateChange = null;
        this._onEnd = null;
        this._onError = null;
        this._onLoad = null;
    }

    static _nextId = 1;

    /**
     * Open media file (abstract)
     */
    async open(fileName, options = {}) {
        throw new Error('Not implemented');
    }

    /**
     * Close media
     */
    close() {
        this.state = VNMediaState.STOPPED;
        this.position = 0;
    }

    /**
     * Play media
     */
    play() {
        this.state = VNMediaState.PLAYING;
    }

    /**
     * Pause media
     */
    pause() {
        this.state = VNMediaState.PAUSED;
    }

    /**
     * Stop media
     */
    stop() {
        this.state = VNMediaState.STOPPED;
        this.position = 0;
    }

    /**
     * Seek to position
     */
    seek(position) {
        this.position = Math.max(0, Math.min(position, this.duration));
    }

    /**
     * Set volume (0-100)
     */
    setVolume(volume) {
        this.volume = Math.max(0, Math.min(100, volume));
    }

    /**
     * Get volume
     */
    getVolume() {
        return this.volume;
    }

    /**
     * Set muted state
     */
    setMuted(muted) {
        this.muted = muted;
    }

    /**
     * Toggle muted
     */
    toggleMute() {
        this.muted = !this.muted;
    }

    /**
     * Get current position
     */
    getPosition() {
        return this.position;
    }

    /**
     * Get duration
     */
    getDuration() {
        return this.duration;
    }

    /**
     * Get state
     */
    getState() {
        return this.state;
    }

    /**
     * Check if playing
     */
    isPlaying() {
        return this.state === VNMediaState.PLAYING;
    }

    /**
     * Check if paused
     */
    isPaused() {
        return this.state === VNMediaState.PAUSED;
    }

    /**
     * Check if stopped
     */
    isStopped() {
        return this.state === VNMediaState.STOPPED;
    }

    /**
     * Set callbacks
     */
    onStateChange(callback) { this._onStateChange = callback; return this; }
    onEnd(callback) { this._onEnd = callback; return this; }
    onError(callback) { this._onError = callback; return this; }
    onLoad(callback) { this._onLoad = callback; return this; }

    /**
     * Fire state change
     */
    _fireStateChange(newState) {
        const oldState = this.state;
        this.state = newState;
        if (this._onStateChange) {
            this._onStateChange(newState, oldState, this);
        }
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            name: this.name,
            fileName: this.fileName,
            volume: this.volume,
            loop: this.loop
        };
    }
}

/**
 * TVNWaveMedia - WAV audio playback
 * Port from europeo.exe (waveaudio MCI device)
 */
export class VNWaveMedia extends VNMciBase {
    constructor() {
        super();
        this.deviceType = 'waveaudio';
        this._audio = null;
    }

    async open(fileName, options = {}) {
        this.fileName = fileName;
        this._fireStateChange(VNMediaState.LOADING);
        
        return new Promise((resolve, reject) => {
            this._audio = new Audio();
            
            this._audio.onloadedmetadata = () => {
                this.duration = this._audio.duration * 1000; // Convert to ms
                this._fireStateChange(VNMediaState.STOPPED);
                if (this._onLoad) this._onLoad(this);
                
                if (options.autoPlay || this.autoPlay) {
                    this.play();
                }
                resolve(this);
            };
            
            this._audio.onerror = (e) => {
                this.lastError = e;
                this._fireStateChange(VNMediaState.ERROR);
                if (this._onError) this._onError(e, this);
                reject(e);
            };
            
            this._audio.onended = () => {
                if (this.loop) {
                    this._audio.currentTime = 0;
                    this._audio.play();
                } else {
                    this._fireStateChange(VNMediaState.STOPPED);
                    if (this._onEnd) this._onEnd(this);
                }
            };
            
            this._audio.ontimeupdate = () => {
                this.position = this._audio.currentTime * 1000;
            };
            
            // Apply settings
            this._audio.loop = this.loop && !this._onEnd; // Use native loop if no onEnd callback
            this._audio.volume = this.muted ? 0 : this.volume / 100;
            
            this._audio.src = fileName;
            this._audio.load();
        });
    }

    close() {
        if (this._audio) {
            this._audio.pause();
            this._audio.src = '';
            this._audio = null;
        }
        super.close();
    }

    play() {
        if (this._audio) {
            this._audio.play().then(() => {
                this._fireStateChange(VNMediaState.PLAYING);
            }).catch(e => {
                this.lastError = e;
                if (this._onError) this._onError(e, this);
            });
        }
    }

    pause() {
        if (this._audio) {
            this._audio.pause();
            this._fireStateChange(VNMediaState.PAUSED);
        }
    }

    stop() {
        if (this._audio) {
            this._audio.pause();
            this._audio.currentTime = 0;
        }
        super.stop();
    }

    seek(position) {
        if (this._audio) {
            this._audio.currentTime = position / 1000;
        }
        super.seek(position);
    }

    setVolume(volume) {
        super.setVolume(volume);
        if (this._audio) {
            this._audio.volume = this.muted ? 0 : this.volume / 100;
        }
    }

    setMuted(muted) {
        super.setMuted(muted);
        if (this._audio) {
            this._audio.volume = muted ? 0 : this.volume / 100;
        }
    }
}

/**
 * TVNMidiMedia - MIDI playback
 * Port from europeo.exe (sequencer MCI device)
 * Note: Web MIDI is limited. Using Web Audio API with MIDI.js or Tone.js would be ideal.
 * For now, we'll use a simple audio player for MIDI files converted to audio.
 */
export class VNMidiMedia extends VNWaveMedia {
    constructor() {
        super();
        this.deviceType = 'sequencer';
        this._midiData = null;
    }

    // MIDI playback would require a MIDI synthesizer library
    // For basic support, treat MIDI like any audio file
    // Real implementation would use Web MIDI API or libraries like Tone.js
}

/**
 * TVNCDAMedia - CD Audio playback
 * Port from europeo.exe (cdaudio MCI device)
 * Note: CD Audio is not available in web browsers.
 * This implementation will work with audio files instead.
 */
export class VNCDAMedia extends VNWaveMedia {
    constructor() {
        super();
        this.deviceType = 'cdaudio';
        this.track = 1;
        this.tracks = [];
    }

    /**
     * Set track list (URLs to audio files)
     */
    setTracks(tracks) {
        this.tracks = tracks;
    }

    /**
     * Play track
     */
    async playTrack(trackNumber) {
        if (trackNumber >= 1 && trackNumber <= this.tracks.length) {
            this.track = trackNumber;
            await this.open(this.tracks[trackNumber - 1]);
            this.play();
        }
    }

    /**
     * Next track
     */
    async nextTrack() {
        if (this.track < this.tracks.length) {
            await this.playTrack(this.track + 1);
        }
    }

    /**
     * Previous track
     */
    async previousTrack() {
        if (this.track > 1) {
            await this.playTrack(this.track - 1);
        }
    }
}

/**
 * TVNVideoBaseMedia - Base video class
 * Port from europeo.exe (video media base)
 */
export class VNVideoBaseMedia extends VNMciBase {
    constructor() {
        super();
        this.deviceType = 'video';
        this._video = null;
        this._container = null;
        
        // Video properties
        this.width = 0;
        this.height = 0;
        this.x = 0;
        this.y = 0;
        this.visible = true;
    }

    /**
     * Set container element
     */
    setContainer(element) {
        this._container = element;
        if (this._video && element) {
            element.appendChild(this._video);
        }
        return this;
    }

    async open(fileName, options = {}) {
        this.fileName = fileName;
        this._fireStateChange(VNMediaState.LOADING);
        
        return new Promise((resolve, reject) => {
            this._video = document.createElement('video');
            this._video.style.position = 'absolute';
            
            this._video.onloadedmetadata = () => {
                this.duration = this._video.duration * 1000;
                this.width = this._video.videoWidth;
                this.height = this._video.videoHeight;
                
                this._updatePosition();
                this._fireStateChange(VNMediaState.STOPPED);
                if (this._onLoad) this._onLoad(this);
                
                if (options.autoPlay || this.autoPlay) {
                    this.play();
                }
                resolve(this);
            };
            
            this._video.onerror = (e) => {
                this.lastError = e;
                this._fireStateChange(VNMediaState.ERROR);
                if (this._onError) this._onError(e, this);
                reject(e);
            };
            
            this._video.onended = () => {
                if (this.loop) {
                    this._video.currentTime = 0;
                    this._video.play();
                } else {
                    this._fireStateChange(VNMediaState.STOPPED);
                    if (this._onEnd) this._onEnd(this);
                }
            };
            
            this._video.ontimeupdate = () => {
                this.position = this._video.currentTime * 1000;
            };
            
            this._video.volume = this.muted ? 0 : this.volume / 100;
            this._video.src = fileName;
            
            if (this._container) {
                this._container.appendChild(this._video);
            }
            
            this._video.load();
        });
    }

    close() {
        if (this._video) {
            this._video.pause();
            if (this._video.parentNode) {
                this._video.parentNode.removeChild(this._video);
            }
            this._video.src = '';
            this._video = null;
        }
        super.close();
    }

    play() {
        if (this._video) {
            this._video.play().then(() => {
                this._fireStateChange(VNMediaState.PLAYING);
            }).catch(e => {
                this.lastError = e;
                if (this._onError) this._onError(e, this);
            });
        }
    }

    pause() {
        if (this._video) {
            this._video.pause();
            this._fireStateChange(VNMediaState.PAUSED);
        }
    }

    stop() {
        if (this._video) {
            this._video.pause();
            this._video.currentTime = 0;
        }
        super.stop();
    }

    seek(position) {
        if (this._video) {
            this._video.currentTime = position / 1000;
        }
        super.seek(position);
    }

    setVolume(volume) {
        super.setVolume(volume);
        if (this._video) {
            this._video.volume = this.muted ? 0 : this.volume / 100;
        }
    }

    setMuted(muted) {
        super.setMuted(muted);
        if (this._video) {
            this._video.volume = muted ? 0 : this.volume / 100;
        }
    }

    /**
     * Set position on screen
     */
    setPosition(x, y) {
        this.x = x;
        this.y = y;
        this._updatePosition();
    }

    /**
     * Set size
     */
    setSize(width, height) {
        this.width = width;
        this.height = height;
        this._updatePosition();
    }

    /**
     * Show video
     */
    show() {
        this.visible = true;
        if (this._video) {
            this._video.style.display = 'block';
        }
    }

    /**
     * Hide video
     */
    hide() {
        this.visible = false;
        if (this._video) {
            this._video.style.display = 'none';
        }
    }

    /**
     * Update video element position
     */
    _updatePosition() {
        if (this._video) {
            this._video.style.left = `${this.x}px`;
            this._video.style.top = `${this.y}px`;
            if (this.width) this._video.style.width = `${this.width}px`;
            if (this.height) this._video.style.height = `${this.height}px`;
            this._video.style.display = this.visible ? 'block' : 'none';
        }
    }

    /**
     * Get video element
     */
    getVideoElement() {
        return this._video;
    }
}

/**
 * TVNAviMedia - AVI video playback
 * Port from europeo.exe (avivideo MCI device)
 */
export class VNAviMedia extends VNVideoBaseMedia {
    constructor() {
        super();
        this.deviceType = 'avivideo';
    }
    
    // AVI is handled the same as other video formats in modern browsers
}

/**
 * TVNHiddenMedia - Background/hidden media player
 * Port from europeo.exe (media without visual component)
 */
export class VNHiddenMedia extends VNWaveMedia {
    constructor() {
        super();
        this.visible = false;
    }

    async open(fileName, options = {}) {
        await super.open(fileName, options);
        if (this._audio) {
            // Hide any visual representation
            this._audio.style = 'display: none;';
        }
        return this;
    }
}

/**
 * Media manager for handling multiple media instances
 */
export class VNMediaManager {
    constructor() {
        this.media = new Map();
        this.globalVolume = 100;
        this.globalMuted = false;
    }

    /**
     * Create media instance
     */
    create(type, name) {
        let media;
        switch (type.toLowerCase()) {
            case 'wave':
            case 'wav':
            case 'audio':
                media = new VNWaveMedia();
                break;
            case 'midi':
            case 'mid':
                media = new VNMidiMedia();
                break;
            case 'cda':
            case 'cdaudio':
                media = new VNCDAMedia();
                break;
            case 'video':
            case 'avi':
            case 'mp4':
                media = new VNAviMedia();
                break;
            case 'hidden':
                media = new VNHiddenMedia();
                break;
            default:
                media = new VNMciBase();
        }
        
        media.name = name;
        this.media.set(name, media);
        return media;
    }

    /**
     * Get media by name
     */
    get(name) {
        return this.media.get(name);
    }

    /**
     * Remove media
     */
    remove(name) {
        const media = this.media.get(name);
        if (media) {
            media.close();
            this.media.delete(name);
        }
    }

    /**
     * Stop all media
     */
    stopAll() {
        this.media.forEach(m => m.stop());
    }

    /**
     * Pause all media
     */
    pauseAll() {
        this.media.forEach(m => m.pause());
    }

    /**
     * Set global volume
     */
    setGlobalVolume(volume) {
        this.globalVolume = volume;
        this.media.forEach(m => m.setVolume(volume));
    }

    /**
     * Set global mute
     */
    setGlobalMuted(muted) {
        this.globalMuted = muted;
        this.media.forEach(m => m.setMuted(muted));
    }

    /**
     * Close all media
     */
    closeAll() {
        this.media.forEach(m => m.close());
        this.media.clear();
    }

    /**
     * Get all active media
     */
    getAll() {
        return Array.from(this.media.values());
    }

    /**
     * Get playing media
     */
    getPlaying() {
        return this.getAll().filter(m => m.isPlaying());
    }
}

export default {
    VNMediaState,
    VNMciBase,
    VNWaveMedia,
    VNMidiMedia,
    VNCDAMedia,
    VNVideoBaseMedia,
    VNAviMedia,
    VNHiddenMedia,
    VNMediaManager
};
