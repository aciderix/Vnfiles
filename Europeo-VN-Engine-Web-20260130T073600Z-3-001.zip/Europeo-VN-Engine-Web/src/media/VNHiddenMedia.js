/**
 * VNHiddenMedia - Hidden/Background Media Management
 * 
 * EXACT PORT from europeo.exe hidden media classes
 * 
 * Original classes from disassembly:
 * - TVNHiddenMedia @ detected in RTTI
 * - Used for background music, ambient sounds that persist across scenes
 */

/**
 * Hidden media state
 */
export const VNHiddenMediaState = {
    STOPPED: 0,
    PLAYING: 1,
    PAUSED: 2,
    FADING: 3
};

/**
 * Hidden media type
 */
export const VNHiddenMediaType = {
    NONE: 0,
    BGM: 1,         // Background music
    AMBIENT: 2,     // Ambient sound
    VOICE: 3,       // Voice-over
    SFX_LOOP: 4     // Looping sound effect
};

/**
 * VNHiddenMedia - Hidden media that plays across scenes
 * Port of TVNHiddenMedia
 */
export class VNHiddenMedia {
    constructor() {
        this.id = '';
        this.type = VNHiddenMediaType.BGM;
        this.state = VNHiddenMediaState.STOPPED;
        this.source = '';
        this.volume = 1.0;
        this.targetVolume = 1.0;
        this.loop = true;
        this.fadeTime = 0;
        this.fadeStartTime = 0;
        this.fadeStartVolume = 0;
        
        // Audio element
        this.audio = null;
        this.audioContext = null;
        this.gainNode = null;
        
        // Persistence
        this.persistent = true;  // Survives scene changes
        this.sceneRestrictions = []; // Scenes where this media is allowed
    }

    /**
     * Initialize audio
     * @param {string} src 
     */
    async init(src) {
        this.source = src;
        
        // Create audio element
        this.audio = new Audio();
        this.audio.src = src;
        this.audio.loop = this.loop;
        
        // Create audio context for advanced control
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const track = this.audioContext.createMediaElementSource(this.audio);
            this.gainNode = this.audioContext.createGain();
            track.connect(this.gainNode);
            this.gainNode.connect(this.audioContext.destination);
        } catch (e) {
            console.warn('AudioContext not available:', e);
        }
        
        // Preload
        await new Promise((resolve, reject) => {
            this.audio.addEventListener('canplaythrough', resolve, { once: true });
            this.audio.addEventListener('error', reject, { once: true });
            this.audio.load();
        });
    }

    /**
     * Play media
     */
    async play() {
        if (!this.audio) return;
        
        if (this.audioContext && this.audioContext.state === 'suspended') {
            await this.audioContext.resume();
        }
        
        try {
            await this.audio.play();
            this.state = VNHiddenMediaState.PLAYING;
        } catch (e) {
            console.error('Failed to play hidden media:', e);
        }
    }

    /**
     * Pause media
     */
    pause() {
        if (this.audio) {
            this.audio.pause();
            this.state = VNHiddenMediaState.PAUSED;
        }
    }

    /**
     * Stop media
     */
    stop() {
        if (this.audio) {
            this.audio.pause();
            this.audio.currentTime = 0;
            this.state = VNHiddenMediaState.STOPPED;
        }
    }

    /**
     * Resume media
     */
    async resume() {
        if (this.state === VNHiddenMediaState.PAUSED) {
            await this.play();
        }
    }

    /**
     * Set volume
     * @param {number} vol - Volume 0-1
     */
    setVolume(vol) {
        this.volume = Math.max(0, Math.min(1, vol));
        
        if (this.gainNode) {
            this.gainNode.gain.value = this.volume;
        } else if (this.audio) {
            this.audio.volume = this.volume;
        }
    }

    /**
     * Fade to volume
     * @param {number} targetVol 
     * @param {number} duration - Duration in ms
     * @returns {Promise<void>}
     */
    async fadeTo(targetVol, duration) {
        this.targetVolume = Math.max(0, Math.min(1, targetVol));
        this.fadeTime = duration;
        this.fadeStartTime = performance.now();
        this.fadeStartVolume = this.volume;
        this.state = VNHiddenMediaState.FADING;
        
        return new Promise((resolve) => {
            const fade = () => {
                const elapsed = performance.now() - this.fadeStartTime;
                const progress = Math.min(elapsed / this.fadeTime, 1);
                
                const newVolume = this.fadeStartVolume + 
                    (this.targetVolume - this.fadeStartVolume) * progress;
                this.setVolume(newVolume);
                
                if (progress < 1) {
                    requestAnimationFrame(fade);
                } else {
                    this.state = this.audio && !this.audio.paused 
                        ? VNHiddenMediaState.PLAYING 
                        : VNHiddenMediaState.STOPPED;
                    resolve();
                }
            };
            
            requestAnimationFrame(fade);
        });
    }

    /**
     * Fade in
     * @param {number} duration 
     */
    async fadeIn(duration = 1000) {
        this.setVolume(0);
        await this.play();
        await this.fadeTo(1, duration);
    }

    /**
     * Fade out
     * @param {number} duration 
     */
    async fadeOut(duration = 1000) {
        await this.fadeTo(0, duration);
        this.stop();
    }

    /**
     * Cross-fade to new source
     * @param {string} newSource 
     * @param {number} duration 
     */
    async crossFade(newSource, duration = 1000) {
        // Fade out current
        await this.fadeOut(duration / 2);
        
        // Load new source
        await this.init(newSource);
        
        // Fade in new
        await this.fadeIn(duration / 2);
    }

    /**
     * Set loop
     * @param {boolean} loop 
     */
    setLoop(loop) {
        this.loop = loop;
        if (this.audio) {
            this.audio.loop = loop;
        }
    }

    /**
     * Check if allowed in scene
     * @param {string} sceneId 
     * @returns {boolean}
     */
    isAllowedInScene(sceneId) {
        if (this.sceneRestrictions.length === 0) {
            return true;  // No restrictions
        }
        return this.sceneRestrictions.includes(sceneId);
    }

    /**
     * Add scene restriction
     * @param {string} sceneId 
     */
    addSceneRestriction(sceneId) {
        if (!this.sceneRestrictions.includes(sceneId)) {
            this.sceneRestrictions.push(sceneId);
        }
    }

    /**
     * Get current time
     * @returns {number}
     */
    getCurrentTime() {
        return this.audio ? this.audio.currentTime : 0;
    }

    /**
     * Get duration
     * @returns {number}
     */
    getDuration() {
        return this.audio ? this.audio.duration : 0;
    }

    /**
     * Seek to time
     * @param {number} time 
     */
    seek(time) {
        if (this.audio) {
            this.audio.currentTime = time;
        }
    }

    /**
     * Dispose
     */
    dispose() {
        this.stop();
        
        if (this.audioContext) {
            this.audioContext.close();
        }
        
        this.audio = null;
        this.audioContext = null;
        this.gainNode = null;
    }
}

/**
 * VNHiddenMediaManager - Manage all hidden media
 */
export class VNHiddenMediaManager {
    constructor() {
        this.media = new Map();
        this.currentScene = '';
    }

    /**
     * Add hidden media
     * @param {string} id 
     * @param {VNHiddenMedia} media 
     */
    add(id, media) {
        media.id = id;
        this.media.set(id, media);
    }

    /**
     * Get hidden media
     * @param {string} id 
     * @returns {VNHiddenMedia|null}
     */
    get(id) {
        return this.media.get(id) || null;
    }

    /**
     * Remove hidden media
     * @param {string} id 
     */
    remove(id) {
        const media = this.media.get(id);
        if (media) {
            media.dispose();
            this.media.delete(id);
        }
    }

    /**
     * Create and add BGM
     * @param {string} id 
     * @param {string} source 
     * @returns {Promise<VNHiddenMedia>}
     */
    async createBGM(id, source) {
        const media = new VNHiddenMedia();
        media.type = VNHiddenMediaType.BGM;
        await media.init(source);
        this.add(id, media);
        return media;
    }

    /**
     * Create and add ambient sound
     * @param {string} id 
     * @param {string} source 
     * @returns {Promise<VNHiddenMedia>}
     */
    async createAmbient(id, source) {
        const media = new VNHiddenMedia();
        media.type = VNHiddenMediaType.AMBIENT;
        media.loop = true;
        await media.init(source);
        this.add(id, media);
        return media;
    }

    /**
     * Play media by id
     * @param {string} id 
     */
    async play(id) {
        const media = this.media.get(id);
        if (media) {
            await media.play();
        }
    }

    /**
     * Stop media by id
     * @param {string} id 
     */
    stop(id) {
        const media = this.media.get(id);
        if (media) {
            media.stop();
        }
    }

    /**
     * Stop all media
     */
    stopAll() {
        for (const media of this.media.values()) {
            media.stop();
        }
    }

    /**
     * Pause all media
     */
    pauseAll() {
        for (const media of this.media.values()) {
            if (media.state === VNHiddenMediaState.PLAYING) {
                media.pause();
            }
        }
    }

    /**
     * Resume all media
     */
    async resumeAll() {
        for (const media of this.media.values()) {
            if (media.state === VNHiddenMediaState.PAUSED) {
                await media.resume();
            }
        }
    }

    /**
     * Handle scene change
     * @param {string} newScene 
     */
    async onSceneChange(newScene) {
        this.currentScene = newScene;
        
        // Check each media for scene restrictions
        for (const media of this.media.values()) {
            if (!media.isAllowedInScene(newScene)) {
                await media.fadeOut(500);
            }
        }
    }

    /**
     * Set master volume for all media of type
     * @param {number} type 
     * @param {number} volume 
     */
    setVolumeByType(type, volume) {
        for (const media of this.media.values()) {
            if (media.type === type) {
                media.setVolume(volume);
            }
        }
    }

    /**
     * Dispose all
     */
    dispose() {
        for (const media of this.media.values()) {
            media.dispose();
        }
        this.media.clear();
    }
}

/**
 * Global hidden media manager
 */
export const hiddenMediaManager = new VNHiddenMediaManager();

export default {
    VNHiddenMediaState,
    VNHiddenMediaType,
    VNHiddenMedia,
    VNHiddenMediaManager,
    hiddenMediaManager
};
