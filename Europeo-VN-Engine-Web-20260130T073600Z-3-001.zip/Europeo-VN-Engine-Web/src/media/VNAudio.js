/**
 * VNAudio - Audio system for VN Engine
 * 
 * Handles audio playback (music, sound effects)
 * The original engine uses:
 *   - MCI for MIDI playback (mciSendCommand)
 *   - PlaySound for WAV files
 *   - CD Audio for tracks (cdaudio)
 * 
 * Web version uses Web Audio API / HTMLAudioElement
 */

class VNAudioChannel {
    constructor(type = 'sfx') {
        this.type = type;
        this._audio = null;
        this._volume = 1.0;
        this._loop = false;
        this._playing = false;
        this._filename = null;
    }

    get playing() { return this._playing; }
    get filename() { return this._filename; }
    get volume() { return this._volume; }
    get loop() { return this._loop; }

    set volume(val) {
        this._volume = Math.max(0, Math.min(1, val));
        if (this._audio) {
            this._audio.volume = this._volume;
        }
    }

    set loop(val) {
        this._loop = val;
        if (this._audio) {
            this._audio.loop = val;
        }
    }
}

class VNAudio extends EventEmitter {
    constructor(engine) {
        super(engine);
        this.engine = engine;
        
        // Audio channels
        this._music = new VNAudioChannel('music');
        this._sfx = new Map(); // Multiple SFX can play simultaneously
        this._maxSfx = 8;
        
        // Volume settings
        this._masterVolume = 0.8;
        this._musicVolume = 0.8;
        this._sfxVolume = 0.8;
        
        // Audio context (for advanced audio features)
        this._audioContext = null;
        
        // Preloaded audio
        this._preloaded = new Map();
    }

    /**
     * Initialize audio context
     */
    _initAudioContext() {
        if (this._audioContext) return;
        
        try {
            this._audioContext = new (window.AudioContext || window.webkitAudioContext)();
        } catch (e) {
            console.warn('Web Audio API not available:', e);
        }
    }

    /**
     * Resume audio context (needed after user interaction)
     */
    async resume() {
        if (this._audioContext && this._audioContext.state === 'suspended') {
            await this._audioContext.resume();
        }
    }

    /**
     * Get resolved audio path
     * @param {string} filename - Original filename
     * @returns {string}
     */
    _resolvePath(filename) {
        if (!filename) return null;
        
        if (filename.startsWith('http://') || filename.startsWith('https://') || filename.startsWith('data:')) {
            return filename;
        }

        const basePath = this.engine.config?.basePath || 'assets';
        const normalizedPath = filename.replace(/\\/g, '/');
        
        // Convert old formats
        let convertedPath = normalizedPath;
        const ext = normalizedPath.split('.').pop()?.toLowerCase();
        
        const audioConversions = {
            'mid': 'mp3',
            'midi': 'mp3',
            'mod': 'mp3',
            'xm': 'mp3',
            's3m': 'mp3',
            'it': 'mp3'
        };
        
        if (audioConversions[ext]) {
            convertedPath = normalizedPath.replace(new RegExp(`\\.${ext}$`, 'i'), `.${audioConversions[ext]}`);
        }

        return `${basePath}/audio/${convertedPath}`;
    }

    /**
     * Create audio element
     * @param {string} src - Audio source URL
     * @returns {HTMLAudioElement}
     */
    _createAudio(src) {
        const audio = new Audio();
        audio.src = src;
        audio.preload = 'auto';
        return audio;
    }

    /**
     * Play music (background music channel)
     * @param {string} filename - Audio filename
     * @param {Object} options - Playback options
     * @returns {Promise<void>}
     */
    async playMusic(filename, options = {}) {
        const { loop = true, fadeIn = 0, volume = this._musicVolume } = options;
        
        // Stop current music
        this.stopMusic(options.fadeOut);
        
        const src = this._resolvePath(filename);
        if (!src) return;
        
        return new Promise((resolve, reject) => {
            const audio = this._createAudio(src);
            audio.loop = loop;
            audio.volume = fadeIn > 0 ? 0 : volume * this._masterVolume;
            
            audio.oncanplaythrough = async () => {
                this._music._audio = audio;
                this._music._filename = filename;
                this._music._loop = loop;
                this._music._volume = volume;
                this._music._playing = true;
                
                try {
                    await audio.play();
                    
                    // Fade in if requested
                    if (fadeIn > 0) {
                        this._fadeVolume(audio, 0, volume * this._masterVolume, fadeIn);
                    }
                    
                    this.emit(VNEvents.AUDIO_STARTED, { type: 'music', filename });
                    resolve();
                } catch (e) {
                    console.warn('Music autoplay blocked:', e);
                    resolve(); // Don't reject, autoplay restrictions are common
                }
            };
            
            audio.onended = () => {
                if (!loop) {
                    this._music._playing = false;
                    this.emit(VNEvents.AUDIO_ENDED, { type: 'music', filename });
                }
            };
            
            audio.onerror = (e) => {
                console.error('Failed to load music:', filename, e);
                reject(new Error(`Failed to load music: ${filename}`));
            };
        });
    }

    /**
     * Stop music
     * @param {number} fadeOut - Fade out duration in ms
     */
    stopMusic(fadeOut = 0) {
        if (!this._music._audio) return;
        
        const audio = this._music._audio;
        
        if (fadeOut > 0) {
            this._fadeVolume(audio, audio.volume, 0, fadeOut, () => {
                audio.pause();
                audio.currentTime = 0;
                this._music._playing = false;
            });
        } else {
            audio.pause();
            audio.currentTime = 0;
            this._music._playing = false;
        }
        
        this.emit(VNEvents.AUDIO_ENDED, { type: 'music', filename: this._music._filename });
    }

    /**
     * Pause music
     */
    pauseMusic() {
        if (this._music._audio && this._music._playing) {
            this._music._audio.pause();
            this._music._playing = false;
        }
    }

    /**
     * Resume music
     */
    async resumeMusic() {
        if (this._music._audio && !this._music._playing) {
            try {
                await this._music._audio.play();
                this._music._playing = true;
            } catch (e) {
                console.warn('Failed to resume music:', e);
            }
        }
    }

    /**
     * Play sound effect
     * @param {string} filename - Audio filename
     * @param {Object} options - Playback options
     * @returns {Promise<string>} SFX ID
     */
    async playSound(filename, options = {}) {
        const { loop = false, volume = this._sfxVolume } = options;
        
        const src = this._resolvePath(filename);
        if (!src) return null;
        
        // Clean up finished SFX
        this._cleanupSfx();
        
        // Check max simultaneous SFX
        if (this._sfx.size >= this._maxSfx) {
            // Remove oldest
            const oldest = this._sfx.keys().next().value;
            this.stopSound(oldest);
        }
        
        return new Promise((resolve, reject) => {
            const audio = this._createAudio(src);
            audio.loop = loop;
            audio.volume = volume * this._masterVolume;
            
            const sfxId = `sfx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            
            audio.oncanplaythrough = async () => {
                try {
                    await audio.play();
                    
                    this._sfx.set(sfxId, {
                        audio,
                        filename,
                        playing: true
                    });
                    
                    this.emit(VNEvents.AUDIO_STARTED, { type: 'sfx', filename, id: sfxId });
                    resolve(sfxId);
                } catch (e) {
                    console.warn('SFX autoplay blocked:', e);
                    resolve(sfxId);
                }
            };
            
            audio.onended = () => {
                const sfx = this._sfx.get(sfxId);
                if (sfx && !loop) {
                    sfx.playing = false;
                    this.emit(VNEvents.AUDIO_ENDED, { type: 'sfx', filename, id: sfxId });
                }
            };
            
            audio.onerror = (e) => {
                console.error('Failed to load sound:', filename, e);
                reject(new Error(`Failed to load sound: ${filename}`));
            };
        });
    }

    /**
     * Stop a specific sound effect
     * @param {string} sfxId - SFX ID
     */
    stopSound(sfxId) {
        const sfx = this._sfx.get(sfxId);
        if (sfx) {
            sfx.audio.pause();
            sfx.audio.currentTime = 0;
            sfx.playing = false;
            this._sfx.delete(sfxId);
        }
    }

    /**
     * Stop all sound effects
     */
    stopAllSounds() {
        this._sfx.forEach((sfx, id) => {
            sfx.audio.pause();
            sfx.audio.currentTime = 0;
            sfx.playing = false;
        });
        this._sfx.clear();
    }

    /**
     * Clean up finished SFX
     */
    _cleanupSfx() {
        const toRemove = [];
        this._sfx.forEach((sfx, id) => {
            if (!sfx.playing && sfx.audio.ended) {
                toRemove.push(id);
            }
        });
        toRemove.forEach(id => this._sfx.delete(id));
    }

    /**
     * Fade volume
     * @param {HTMLAudioElement} audio - Audio element
     * @param {number} from - Start volume
     * @param {number} to - End volume
     * @param {number} duration - Duration in ms
     * @param {Function} callback - Completion callback
     */
    _fadeVolume(audio, from, to, duration, callback) {
        const startTime = Date.now();
        const diff = to - from;
        
        const update = () => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(1, elapsed / duration);
            
            audio.volume = from + diff * progress;
            
            if (progress < 1) {
                requestAnimationFrame(update);
            } else if (callback) {
                callback();
            }
        };
        
        update();
    }

    /**
     * Set master volume
     * @param {number} volume - Volume (0-1)
     */
    setMasterVolume(volume) {
        this._masterVolume = Math.max(0, Math.min(1, volume));
        this._updateVolumes();
    }

    /**
     * Set music volume
     * @param {number} volume - Volume (0-1)
     */
    setMusicVolume(volume) {
        this._musicVolume = Math.max(0, Math.min(1, volume));
        this._updateVolumes();
    }

    /**
     * Set SFX volume
     * @param {number} volume - Volume (0-1)
     */
    setSfxVolume(volume) {
        this._sfxVolume = Math.max(0, Math.min(1, volume));
        this._updateVolumes();
    }

    /**
     * Update all audio volumes
     */
    _updateVolumes() {
        if (this._music._audio) {
            this._music._audio.volume = this._musicVolume * this._masterVolume;
        }
        
        this._sfx.forEach(sfx => {
            sfx.audio.volume = this._sfxVolume * this._masterVolume;
        });
    }

    /**
     * Preload audio file
     * @param {string} filename - Audio filename
     * @returns {Promise<void>}
     */
    async preload(filename) {
        const src = this._resolvePath(filename);
        if (!src || this._preloaded.has(filename)) return;
        
        return new Promise((resolve) => {
            const audio = this._createAudio(src);
            audio.oncanplaythrough = () => {
                this._preloaded.set(filename, audio);
                resolve();
            };
            audio.onerror = () => resolve(); // Don't fail on preload errors
        });
    }

    /**
     * Stop all audio
     */
    stopAll() {
        this.stopMusic();
        this.stopAllSounds();
    }

    /**
     * Get audio state for saving
     * @returns {Object}
     */
    getState() {
        return {
            music: this._music._playing ? {
                filename: this._music._filename,
                currentTime: this._music._audio?.currentTime || 0,
                loop: this._music._loop
            } : null,
            volumes: {
                master: this._masterVolume,
                music: this._musicVolume,
                sfx: this._sfxVolume
            }
        };
    }

    /**
     * Restore audio state
     * @param {Object} state - Saved state
     */
    async restoreState(state) {
        if (state.volumes) {
            this._masterVolume = state.volumes.master ?? 0.8;
            this._musicVolume = state.volumes.music ?? 0.8;
            this._sfxVolume = state.volumes.sfx ?? 0.8;
        }
        
        if (state.music) {
            await this.playMusic(state.music.filename, { loop: state.music.loop });
            if (this._music._audio && state.music.currentTime) {
                this._music._audio.currentTime = state.music.currentTime;
            }
        }
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNAudio };
}
