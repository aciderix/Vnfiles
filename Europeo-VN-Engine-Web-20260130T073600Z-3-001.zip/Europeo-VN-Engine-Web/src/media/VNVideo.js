/**
 * VNVideo - Video playback for VN Engine
 * 
 * Handles video playback (cutscenes, animations)
 * The original engine uses MCI (mciSendCommand) for AVI playback
 * 
 * Web version uses HTML5 video element
 */

class VNVideo extends EventEmitter {
    constructor(engine) {
        super(engine);
        this.engine = engine;
        
        this._videoElement = null;
        this._container = null;
        this._playing = false;
        this._filename = null;
        this._options = {};
    }

    get playing() { return this._playing; }
    get filename() { return this._filename; }

    /**
     * Initialize video system
     */
    init() {
        this._container = document.getElementById('vn-video-layer');
        this._videoElement = document.getElementById('vn-video');
        
        if (!this._videoElement) {
            this._videoElement = document.createElement('video');
            this._videoElement.id = 'vn-video';
            this._videoElement.style.display = 'none';
            this._container.appendChild(this._videoElement);
        }
        
        // Event handlers
        this._videoElement.addEventListener('ended', () => this._onEnded());
        this._videoElement.addEventListener('error', (e) => this._onError(e));
        this._videoElement.addEventListener('canplay', () => this._onCanPlay());
    }

    /**
     * Get resolved video path
     * @param {string} filename - Original filename
     * @returns {string}
     */
    _resolvePath(filename) {
        if (!filename) return null;
        
        if (filename.startsWith('http://') || filename.startsWith('https://') || filename.startsWith('data:')) {
            return filename;
        }

        const basePath = this.engine.config?.basePath || 'assets';
        const normalizedPath = filename.replace(/\\/g, '/');
        
        // Convert old formats
        let convertedPath = normalizedPath;
        const ext = normalizedPath.split('.').pop()?.toLowerCase();
        
        const videoConversions = {
            'avi': 'mp4',
            'mov': 'mp4',
            'wmv': 'mp4',
            'mpg': 'mp4',
            'mpeg': 'mp4'
        };
        
        if (videoConversions[ext]) {
            convertedPath = normalizedPath.replace(new RegExp(`\\.${ext}$`, 'i'), `.${videoConversions[ext]}`);
        }

        return `${basePath}/video/${convertedPath}`;
    }

    /**
     * Play video
     * @param {string} filename - Video filename
     * @param {Object} options - Playback options
     * @returns {Promise<void>}
     */
    async play(filename, options = {}) {
        const {
            x = 0,
            y = 0,
            width = null,
            height = null,
            loop = false,
            autoClose = true,
            skipOnClick = true
        } = options;

        // Stop any current video
        this.stop();

        const src = this._resolvePath(filename);
        if (!src) {
            throw new Error('Invalid video filename');
        }

        this._filename = filename;
        this._options = options;

        return new Promise((resolve, reject) => {
            this._resolvePromise = resolve;
            this._rejectPromise = reject;
            
            // Configure video element
            this._videoElement.src = src;
            this._videoElement.loop = loop;
            this._videoElement.muted = false;
            
            // Position and size
            this._videoElement.style.position = 'absolute';
            this._videoElement.style.left = `${x}px`;
            this._videoElement.style.top = `${y}px`;
            
            if (width) {
                this._videoElement.style.width = `${width}px`;
            } else {
                this._videoElement.style.width = 'auto';
            }
            
            if (height) {
                this._videoElement.style.height = `${height}px`;
            } else {
                this._videoElement.style.height = 'auto';
            }
            
            // Click to skip
            if (skipOnClick) {
                this._clickHandler = () => {
                    if (this._playing) {
                        this.stop();
                    }
                };
                this._videoElement.addEventListener('click', this._clickHandler);
            }
            
            // Show and load
            this._videoElement.style.display = 'block';
            this._videoElement.load();
        });
    }

    /**
     * Handle can play event
     */
    async _onCanPlay() {
        try {
            await this._videoElement.play();
            this._playing = true;
            this.emit(VNEvents.VIDEO_STARTED, { filename: this._filename });
        } catch (e) {
            console.warn('Video autoplay blocked:', e);
            // Try muted autoplay
            this._videoElement.muted = true;
            try {
                await this._videoElement.play();
                this._playing = true;
                this.emit(VNEvents.VIDEO_STARTED, { filename: this._filename });
            } catch (e2) {
                console.error('Video play failed:', e2);
                this._onError(e2);
            }
        }
    }

    /**
     * Handle video ended event
     */
    _onEnded() {
        const wasPlaying = this._playing;
        
        if (!this._options.loop) {
            this._playing = false;
            
            if (this._options.autoClose !== false) {
                this._videoElement.style.display = 'none';
            }
            
            if (wasPlaying) {
                this.emit(VNEvents.VIDEO_ENDED, { filename: this._filename });
                
                if (this._resolvePromise) {
                    this._resolvePromise();
                    this._resolvePromise = null;
                }
            }
        }
    }

    /**
     * Handle video error
     * @param {Event} e - Error event
     */
    _onError(e) {
        console.error('Video error:', this._filename, e);
        this._playing = false;
        this._videoElement.style.display = 'none';
        
        this.emit(VNEvents.MEDIA_ERROR, { 
            type: 'video', 
            filename: this._filename, 
            error: e 
        });
        
        if (this._rejectPromise) {
            this._rejectPromise(new Error(`Video playback failed: ${this._filename}`));
            this._rejectPromise = null;
        }
    }

    /**
     * Stop video playback
     */
    stop() {
        if (this._videoElement) {
            this._videoElement.pause();
            this._videoElement.currentTime = 0;
            this._videoElement.style.display = 'none';
            this._videoElement.src = '';
            
            // Remove click handler
            if (this._clickHandler) {
                this._videoElement.removeEventListener('click', this._clickHandler);
                this._clickHandler = null;
            }
        }
        
        const wasPlaying = this._playing;
        this._playing = false;
        
        if (wasPlaying) {
            this.emit(VNEvents.VIDEO_ENDED, { filename: this._filename });
            
            if (this._resolvePromise) {
                this._resolvePromise();
                this._resolvePromise = null;
            }
        }
        
        this._filename = null;
    }

    /**
     * Pause video
     */
    pause() {
        if (this._videoElement && this._playing) {
            this._videoElement.pause();
        }
    }

    /**
     * Resume video
     */
    async resume() {
        if (this._videoElement && this._playing) {
            try {
                await this._videoElement.play();
            } catch (e) {
                console.warn('Video resume failed:', e);
            }
        }
    }

    /**
     * Set video position
     * @param {number} x - X position
     * @param {number} y - Y position
     */
    setPosition(x, y) {
        if (this._videoElement) {
            this._videoElement.style.left = `${x}px`;
            this._videoElement.style.top = `${y}px`;
        }
    }

    /**
     * Set video size
     * @param {number} width - Width
     * @param {number} height - Height
     */
    setSize(width, height) {
        if (this._videoElement) {
            this._videoElement.style.width = width ? `${width}px` : 'auto';
            this._videoElement.style.height = height ? `${height}px` : 'auto';
        }
    }

    /**
     * Set video volume
     * @param {number} volume - Volume (0-1)
     */
    setVolume(volume) {
        if (this._videoElement) {
            this._videoElement.volume = Math.max(0, Math.min(1, volume));
        }
    }

    /**
     * Get current playback time
     * @returns {number}
     */
    getCurrentTime() {
        return this._videoElement?.currentTime || 0;
    }

    /**
     * Get video duration
     * @returns {number}
     */
    getDuration() {
        return this._videoElement?.duration || 0;
    }

    /**
     * Seek to time
     * @param {number} time - Time in seconds
     */
    seek(time) {
        if (this._videoElement) {
            this._videoElement.currentTime = time;
        }
    }

    /**
     * Check if video is visible
     * @returns {boolean}
     */
    isVisible() {
        return this._videoElement?.style.display !== 'none';
    }

    /**
     * Get video state for saving
     * @returns {Object|null}
     */
    getState() {
        if (!this._playing) return null;
        
        return {
            filename: this._filename,
            currentTime: this.getCurrentTime(),
            options: this._options
        };
    }

    /**
     * Restore video state
     * @param {Object} state - Saved state
     */
    async restoreState(state) {
        if (!state) return;
        
        await this.play(state.filename, state.options);
        if (state.currentTime) {
            this.seek(state.currentTime);
        }
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNVideo };
}
