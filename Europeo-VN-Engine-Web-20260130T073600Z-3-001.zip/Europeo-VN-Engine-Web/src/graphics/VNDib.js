/**
 * VNDib - Device Independent Bitmap
 * 
 * EXACT PORT from OWL TDib class
 * 
 * Original class from RTTI:
 * - TDib @ 0x0041e7be
 * - TBitmap @ 0x0041e8d4
 * 
 * Key functions:
 * - @TDib@$bctr$qpxc @ 0x00453024 (constructor from filename)
 * - @TDib@$bctr$qp11HINSTANCE__6TResId @ 0x00453024 (constructor from resource)
 * - @TDib@$bdtr$qv @ 0x004538e2 (destructor)
 * - @TBitmap@Create$qrx4TDibrx8TPalette @ 0x00453a6a
 */

/**
 * BITMAPFILEHEADER structure
 */
export class BITMAPFILEHEADER {
    constructor() {
        this.bfType = 0x4D42; // 'BM'
        this.bfSize = 0;
        this.bfReserved1 = 0;
        this.bfReserved2 = 0;
        this.bfOffBits = 0;
    }

    /**
     * Read from buffer
     * @param {DataView} view 
     * @param {number} offset 
     */
    read(view, offset = 0) {
        this.bfType = view.getUint16(offset, true);
        this.bfSize = view.getUint32(offset + 2, true);
        this.bfReserved1 = view.getUint16(offset + 6, true);
        this.bfReserved2 = view.getUint16(offset + 8, true);
        this.bfOffBits = view.getUint32(offset + 10, true);
    }

    /**
     * Write to buffer
     * @param {DataView} view 
     * @param {number} offset 
     */
    write(view, offset = 0) {
        view.setUint16(offset, this.bfType, true);
        view.setUint32(offset + 2, this.bfSize, true);
        view.setUint16(offset + 6, this.bfReserved1, true);
        view.setUint16(offset + 8, this.bfReserved2, true);
        view.setUint32(offset + 10, this.bfOffBits, true);
    }

    static SIZE = 14;
}

/**
 * BITMAPINFOHEADER structure
 */
export class BITMAPINFOHEADER {
    constructor() {
        this.biSize = 40;
        this.biWidth = 0;
        this.biHeight = 0;
        this.biPlanes = 1;
        this.biBitCount = 24;
        this.biCompression = 0; // BI_RGB
        this.biSizeImage = 0;
        this.biXPelsPerMeter = 0;
        this.biYPelsPerMeter = 0;
        this.biClrUsed = 0;
        this.biClrImportant = 0;
    }

    /**
     * Read from buffer
     * @param {DataView} view 
     * @param {number} offset 
     */
    read(view, offset = 0) {
        this.biSize = view.getUint32(offset, true);
        this.biWidth = view.getInt32(offset + 4, true);
        this.biHeight = view.getInt32(offset + 8, true);
        this.biPlanes = view.getUint16(offset + 12, true);
        this.biBitCount = view.getUint16(offset + 14, true);
        this.biCompression = view.getUint32(offset + 16, true);
        this.biSizeImage = view.getUint32(offset + 20, true);
        this.biXPelsPerMeter = view.getInt32(offset + 24, true);
        this.biYPelsPerMeter = view.getInt32(offset + 28, true);
        this.biClrUsed = view.getUint32(offset + 32, true);
        this.biClrImportant = view.getUint32(offset + 36, true);
    }

    /**
     * Write to buffer
     * @param {DataView} view 
     * @param {number} offset 
     */
    write(view, offset = 0) {
        view.setUint32(offset, this.biSize, true);
        view.setInt32(offset + 4, this.biWidth, true);
        view.setInt32(offset + 8, this.biHeight, true);
        view.setUint16(offset + 12, this.biPlanes, true);
        view.setUint16(offset + 14, this.biBitCount, true);
        view.setUint32(offset + 16, this.biCompression, true);
        view.setUint32(offset + 20, this.biSizeImage, true);
        view.setInt32(offset + 24, this.biXPelsPerMeter, true);
        view.setInt32(offset + 28, this.biYPelsPerMeter, true);
        view.setUint32(offset + 32, this.biClrUsed, true);
        view.setUint32(offset + 36, this.biClrImportant, true);
    }

    static SIZE = 40;
}

/**
 * Compression types
 */
export const BI_COMPRESSION = {
    BI_RGB: 0,
    BI_RLE8: 1,
    BI_RLE4: 2,
    BI_BITFIELDS: 3
};

/**
 * VNDib - Device Independent Bitmap
 * Port of TDib
 */
export class VNDib {
    constructor() {
        this.fileHeader = new BITMAPFILEHEADER();
        this.infoHeader = new BITMAPINFOHEADER();
        this.palette = null; // Color palette (for 1, 4, 8 bit)
        this.bits = null; // Pixel data
        this.imageData = null; // Canvas ImageData
        this.canvas = null; // Canvas for rendering
    }

    /**
     * Get width
     * @returns {number}
     */
    get width() {
        return Math.abs(this.infoHeader.biWidth);
    }

    /**
     * Get height
     * @returns {number}
     */
    get height() {
        return Math.abs(this.infoHeader.biHeight);
    }

    /**
     * Get bits per pixel
     * @returns {number}
     */
    get bitsPerPixel() {
        return this.infoHeader.biBitCount;
    }

    /**
     * Check if bitmap is bottom-up (standard)
     * @returns {boolean}
     */
    get isBottomUp() {
        return this.infoHeader.biHeight > 0;
    }

    /**
     * Get number of colors in palette
     * @returns {number}
     */
    get numColors() {
        if (this.infoHeader.biClrUsed > 0) {
            return this.infoHeader.biClrUsed;
        }
        if (this.infoHeader.biBitCount <= 8) {
            return 1 << this.infoHeader.biBitCount;
        }
        return 0;
    }

    /**
     * Load from file (BMP format)
     * Port of @TDib@$bctr$qpxc @ 0x00453024
     * @param {ArrayBuffer} buffer 
     * @returns {boolean}
     */
    loadFromBuffer(buffer) {
        try {
            const view = new DataView(buffer);
            
            // Read file header
            this.fileHeader.read(view, 0);
            
            // Verify BMP signature
            if (this.fileHeader.bfType !== 0x4D42) {
                console.error('Invalid BMP signature');
                return false;
            }
            
            // Read info header
            this.infoHeader.read(view, BITMAPFILEHEADER.SIZE);
            
            // Read color palette
            const paletteOffset = BITMAPFILEHEADER.SIZE + this.infoHeader.biSize;
            const paletteSize = this.numColors;
            
            if (paletteSize > 0) {
                this.palette = [];
                for (let i = 0; i < paletteSize; i++) {
                    const offset = paletteOffset + i * 4;
                    this.palette.push({
                        b: view.getUint8(offset),
                        g: view.getUint8(offset + 1),
                        r: view.getUint8(offset + 2),
                        a: 255
                    });
                }
            }
            
            // Read pixel data
            const bitsOffset = this.fileHeader.bfOffBits;
            const rowSize = Math.floor((this.infoHeader.biBitCount * this.width + 31) / 32) * 4;
            const dataSize = rowSize * this.height;
            
            this.bits = new Uint8Array(buffer, bitsOffset, dataSize);
            
            // Convert to ImageData
            this._convertToImageData();
            
            return true;
        } catch (e) {
            console.error('Error loading BMP:', e);
            return false;
        }
    }

    /**
     * Load from URL
     * @param {string} url 
     * @returns {Promise<boolean>}
     */
    async loadFromUrl(url) {
        try {
            const response = await fetch(url);
            const buffer = await response.arrayBuffer();
            return this.loadFromBuffer(buffer);
        } catch (e) {
            console.error('Error loading BMP from URL:', e);
            return false;
        }
    }

    /**
     * Load from Image element
     * @param {HTMLImageElement} img 
     */
    loadFromImage(img) {
        this.canvas = document.createElement('canvas');
        this.canvas.width = img.width;
        this.canvas.height = img.height;
        
        const ctx = this.canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        
        this.imageData = ctx.getImageData(0, 0, img.width, img.height);
        
        this.infoHeader.biWidth = img.width;
        this.infoHeader.biHeight = img.height;
        this.infoHeader.biBitCount = 32;
    }

    /**
     * Convert BMP bits to ImageData
     * @private
     */
    _convertToImageData() {
        const width = this.width;
        const height = this.height;
        
        this.canvas = document.createElement('canvas');
        this.canvas.width = width;
        this.canvas.height = height;
        
        const ctx = this.canvas.getContext('2d');
        this.imageData = ctx.createImageData(width, height);
        
        const rowSize = Math.floor((this.infoHeader.biBitCount * width + 31) / 32) * 4;
        const bottomUp = this.isBottomUp;
        
        for (let y = 0; y < height; y++) {
            const srcY = bottomUp ? (height - 1 - y) : y;
            const srcRowStart = srcY * rowSize;
            
            for (let x = 0; x < width; x++) {
                const destIdx = (y * width + x) * 4;
                let r, g, b, a = 255;
                
                switch (this.infoHeader.biBitCount) {
                    case 1: {
                        const byteIdx = srcRowStart + Math.floor(x / 8);
                        const bitIdx = 7 - (x % 8);
                        const colorIdx = (this.bits[byteIdx] >> bitIdx) & 1;
                        const color = this.palette[colorIdx];
                        r = color.r; g = color.g; b = color.b;
                        break;
                    }
                    
                    case 4: {
                        const byteIdx = srcRowStart + Math.floor(x / 2);
                        const colorIdx = (x % 2 === 0) ? 
                            (this.bits[byteIdx] >> 4) & 0x0F :
                            this.bits[byteIdx] & 0x0F;
                        const color = this.palette[colorIdx];
                        r = color.r; g = color.g; b = color.b;
                        break;
                    }
                    
                    case 8: {
                        const colorIdx = this.bits[srcRowStart + x];
                        const color = this.palette[colorIdx];
                        r = color.r; g = color.g; b = color.b;
                        break;
                    }
                    
                    case 16: {
                        const offset = srcRowStart + x * 2;
                        const pixel = this.bits[offset] | (this.bits[offset + 1] << 8);
                        // 5-5-5 format
                        r = ((pixel >> 10) & 0x1F) * 8;
                        g = ((pixel >> 5) & 0x1F) * 8;
                        b = (pixel & 0x1F) * 8;
                        break;
                    }
                    
                    case 24: {
                        const offset = srcRowStart + x * 3;
                        b = this.bits[offset];
                        g = this.bits[offset + 1];
                        r = this.bits[offset + 2];
                        break;
                    }
                    
                    case 32: {
                        const offset = srcRowStart + x * 4;
                        b = this.bits[offset];
                        g = this.bits[offset + 1];
                        r = this.bits[offset + 2];
                        a = this.bits[offset + 3];
                        break;
                    }
                    
                    default:
                        r = g = b = 0;
                }
                
                this.imageData.data[destIdx] = r;
                this.imageData.data[destIdx + 1] = g;
                this.imageData.data[destIdx + 2] = b;
                this.imageData.data[destIdx + 3] = a;
            }
        }
        
        ctx.putImageData(this.imageData, 0, 0);
    }

    /**
     * Create from canvas
     * @param {HTMLCanvasElement} canvas 
     */
    createFromCanvas(canvas) {
        this.canvas = document.createElement('canvas');
        this.canvas.width = canvas.width;
        this.canvas.height = canvas.height;
        
        const ctx = this.canvas.getContext('2d');
        ctx.drawImage(canvas, 0, 0);
        
        this.imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        
        this.infoHeader.biWidth = canvas.width;
        this.infoHeader.biHeight = canvas.height;
        this.infoHeader.biBitCount = 32;
    }

    /**
     * Create empty DIB
     * @param {number} width 
     * @param {number} height 
     * @param {number} bitCount 
     */
    create(width, height, bitCount = 32) {
        this.infoHeader.biWidth = width;
        this.infoHeader.biHeight = height;
        this.infoHeader.biBitCount = bitCount;
        
        this.canvas = document.createElement('canvas');
        this.canvas.width = width;
        this.canvas.height = height;
        
        const ctx = this.canvas.getContext('2d');
        this.imageData = ctx.createImageData(width, height);
    }

    /**
     * Get pixel at position
     * @param {number} x 
     * @param {number} y 
     * @returns {{r: number, g: number, b: number, a: number}}
     */
    getPixel(x, y) {
        if (!this.imageData) return { r: 0, g: 0, b: 0, a: 0 };
        
        const idx = (y * this.width + x) * 4;
        return {
            r: this.imageData.data[idx],
            g: this.imageData.data[idx + 1],
            b: this.imageData.data[idx + 2],
            a: this.imageData.data[idx + 3]
        };
    }

    /**
     * Set pixel at position
     * @param {number} x 
     * @param {number} y 
     * @param {number} r 
     * @param {number} g 
     * @param {number} b 
     * @param {number} a 
     */
    setPixel(x, y, r, g, b, a = 255) {
        if (!this.imageData) return;
        
        const idx = (y * this.width + x) * 4;
        this.imageData.data[idx] = r;
        this.imageData.data[idx + 1] = g;
        this.imageData.data[idx + 2] = b;
        this.imageData.data[idx + 3] = a;
    }

    /**
     * Update canvas from imageData
     */
    updateCanvas() {
        if (this.canvas && this.imageData) {
            const ctx = this.canvas.getContext('2d');
            ctx.putImageData(this.imageData, 0, 0);
        }
    }

    /**
     * Draw to context
     * @param {CanvasRenderingContext2D} ctx 
     * @param {number} x 
     * @param {number} y 
     */
    draw(ctx, x = 0, y = 0) {
        if (this.canvas) {
            ctx.drawImage(this.canvas, x, y);
        }
    }

    /**
     * Draw stretched to context
     * @param {CanvasRenderingContext2D} ctx 
     * @param {number} x 
     * @param {number} y 
     * @param {number} width 
     * @param {number} height 
     */
    drawStretched(ctx, x, y, width, height) {
        if (this.canvas) {
            ctx.drawImage(this.canvas, x, y, width, height);
        }
    }

    /**
     * Export to BMP buffer
     * @returns {ArrayBuffer}
     */
    toBuffer() {
        const width = this.width;
        const height = this.height;
        const rowSize = Math.floor((24 * width + 31) / 32) * 4;
        const dataSize = rowSize * height;
        const fileSize = BITMAPFILEHEADER.SIZE + BITMAPINFOHEADER.SIZE + dataSize;
        
        const buffer = new ArrayBuffer(fileSize);
        const view = new DataView(buffer);
        const bytes = new Uint8Array(buffer);
        
        // File header
        this.fileHeader.bfType = 0x4D42;
        this.fileHeader.bfSize = fileSize;
        this.fileHeader.bfOffBits = BITMAPFILEHEADER.SIZE + BITMAPINFOHEADER.SIZE;
        this.fileHeader.write(view, 0);
        
        // Info header
        this.infoHeader.biSize = BITMAPINFOHEADER.SIZE;
        this.infoHeader.biWidth = width;
        this.infoHeader.biHeight = height;
        this.infoHeader.biBitCount = 24;
        this.infoHeader.biSizeImage = dataSize;
        this.infoHeader.write(view, BITMAPFILEHEADER.SIZE);
        
        // Pixel data (bottom-up, BGR)
        const pixelOffset = this.fileHeader.bfOffBits;
        
        for (let y = 0; y < height; y++) {
            const srcY = height - 1 - y;
            for (let x = 0; x < width; x++) {
                const srcIdx = (srcY * width + x) * 4;
                const destIdx = pixelOffset + y * rowSize + x * 3;
                
                bytes[destIdx] = this.imageData.data[srcIdx + 2]; // B
                bytes[destIdx + 1] = this.imageData.data[srcIdx + 1]; // G
                bytes[destIdx + 2] = this.imageData.data[srcIdx]; // R
            }
        }
        
        return buffer;
    }

    /**
     * Export to Blob
     * @returns {Blob}
     */
    toBlob() {
        return new Blob([this.toBuffer()], { type: 'image/bmp' });
    }

    /**
     * Export to data URL
     * @returns {string}
     */
    toDataUrl() {
        if (this.canvas) {
            return this.canvas.toDataURL('image/png');
        }
        return '';
    }
}

/**
 * VNTransparentBmp - Transparent bitmap
 * Port of TVNTransparentBmp @ 0x0041e862
 */
export class VNTransparentBmp extends VNDib {
    constructor() {
        super();
        this.transparentColor = 0xFF00FF; // Magenta
        this.hasTransparency = false;
    }

    /**
     * Set transparent color
     * @param {number} color - RGB color
     */
    setTransparentColor(color) {
        this.transparentColor = color;
        this.hasTransparency = true;
        this._applyTransparency();
    }

    /**
     * Apply transparency to image data
     * @private
     */
    _applyTransparency() {
        if (!this.imageData || !this.hasTransparency) return;
        
        const r = (this.transparentColor >> 16) & 0xFF;
        const g = (this.transparentColor >> 8) & 0xFF;
        const b = this.transparentColor & 0xFF;
        
        const data = this.imageData.data;
        for (let i = 0; i < data.length; i += 4) {
            if (data[i] === r && data[i + 1] === g && data[i + 2] === b) {
                data[i + 3] = 0; // Set alpha to 0
            }
        }
        
        this.updateCanvas();
    }

    /**
     * Draw with transparency
     * @param {CanvasRenderingContext2D} ctx 
     * @param {number} x 
     * @param {number} y 
     */
    drawTransparent(ctx, x = 0, y = 0) {
        if (this.canvas) {
            ctx.drawImage(this.canvas, x, y);
        }
    }
}

export default {
    BITMAPFILEHEADER,
    BITMAPINFOHEADER,
    BI_COMPRESSION,
    VNDib,
    VNTransparentBmp
};
