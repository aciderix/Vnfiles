/**
 * VNGdiObjects - GDI Object Classes (Font, Brush, Pen, Cursor, Icon)
 * 
 * EXACT PORT from OWL/Windows GDI classes
 * 
 * Original classes from disassembly:
 * - TFont @ 0x0041e76e
 * - TBrush @ 0x0042a3d8
 * - TPen (via @TPen@$bctr$qrx6TColorii @ 0x00453a90)
 * - Cursor functions @ multiple addresses
 * - Icon functions @ multiple addresses
 * 
 * Key functions:
 * - @TFont@$bctr$qpx11tagLOGFONTA @ 0x00452c84
 * - @TBrush@$bctr$qrx6TColor @ 0x00453836
 * - @TPen@$bctr$qrx6TColorii @ 0x00453a90
 * - LoadCursorA @ 0x0045201a
 * - SetCursor @ 0x00452168
 * - LoadCursorFromFileA @ 0x00451ff8
 */

/**
 * Font weight constants
 */
export const VNFontWeight = {
    DONTCARE: 0,
    THIN: 100,
    EXTRALIGHT: 200,
    LIGHT: 300,
    NORMAL: 400,
    MEDIUM: 500,
    SEMIBOLD: 600,
    BOLD: 700,
    EXTRABOLD: 800,
    HEAVY: 900
};

/**
 * Font charset constants
 */
export const VNCharset = {
    ANSI: 0,
    DEFAULT: 1,
    SYMBOL: 2,
    SHIFTJIS: 128,
    HANGEUL: 129,
    GB2312: 134,
    CHINESEBIG5: 136,
    OEM: 255,
    JOHAB: 130,
    HEBREW: 177,
    ARABIC: 178,
    GREEK: 161,
    TURKISH: 162,
    VIETNAMESE: 163,
    THAI: 222,
    EASTEUROPE: 238,
    RUSSIAN: 204
};

/**
 * Pen style constants
 */
export const VNPenStyle = {
    SOLID: 0,
    DASH: 1,
    DOT: 2,
    DASHDOT: 3,
    DASHDOTDOT: 4,
    NULL: 5,
    INSIDEFRAME: 6
};

/**
 * Brush style constants
 */
export const VNBrushStyle = {
    SOLID: 0,
    HOLLOW: 1,
    NULL: 1,
    HATCHED: 2,
    PATTERN: 3,
    INDEXED: 4,
    DIBPATTERN: 5
};

/**
 * Hatch style constants
 */
export const VNHatchStyle = {
    HORIZONTAL: 0,
    VERTICAL: 1,
    FDIAGONAL: 2,
    BDIAGONAL: 3,
    CROSS: 4,
    DIAGCROSS: 5
};

/**
 * Standard cursors
 */
export const VNCursors = {
    ARROW: 'default',
    IBEAM: 'text',
    WAIT: 'wait',
    CROSS: 'crosshair',
    UPARROW: 'n-resize',
    SIZE: 'nwse-resize',
    ICON: 'default',
    SIZENWSE: 'nwse-resize',
    SIZENESW: 'nesw-resize',
    SIZEWE: 'ew-resize',
    SIZENS: 'ns-resize',
    SIZEALL: 'move',
    NO: 'not-allowed',
    HAND: 'pointer',
    APPSTARTING: 'progress',
    HELP: 'help'
};

/**
 * VNFont - Font class
 * Port of TFont @ 0x0041e76e
 */
export class VNFont {
    /**
     * @param {string} faceName 
     * @param {number} height 
     * @param {Object} options 
     */
    constructor(faceName = 'Arial', height = 12, options = {}) {
        this.faceName = faceName;
        this.height = height;
        this.width = options.width || 0;
        this.weight = options.weight || VNFontWeight.NORMAL;
        this.italic = options.italic || false;
        this.underline = options.underline || false;
        this.strikeOut = options.strikeOut || false;
        this.charset = options.charset || VNCharset.DEFAULT;
        this.escapement = options.escapement || 0;
        this.orientation = options.orientation || 0;
        this.pitchAndFamily = options.pitchAndFamily || 0;
        
        // Handle (for compatibility)
        this.handle = Math.random().toString(36).substr(2, 9);
    }

    /**
     * Create from LOGFONT
     * Port of @TFont@$bctr$qpx11tagLOGFONTA @ 0x00452c84
     * @param {Object} logFont 
     * @returns {VNFont}
     */
    static fromLogFont(logFont) {
        return new VNFont(logFont.lfFaceName, Math.abs(logFont.lfHeight), {
            width: logFont.lfWidth,
            weight: logFont.lfWeight,
            italic: logFont.lfItalic !== 0,
            underline: logFont.lfUnderline !== 0,
            strikeOut: logFont.lfStrikeOut !== 0,
            charset: logFont.lfCharSet,
            escapement: logFont.lfEscapement,
            orientation: logFont.lfOrientation
        });
    }

    /**
     * Get CSS font string
     * @returns {string}
     */
    toCss() {
        let style = '';
        
        if (this.italic) style += 'italic ';
        
        // Weight
        style += this.weight + ' ';
        
        // Size
        style += Math.abs(this.height) + 'px ';
        
        // Family
        style += `"${this.faceName}", sans-serif`;
        
        return style.trim();
    }

    /**
     * Apply to canvas context
     * @param {CanvasRenderingContext2D} ctx 
     */
    applyTo(ctx) {
        ctx.font = this.toCss();
    }

    /**
     * Clone font
     * @returns {VNFont}
     */
    clone() {
        return new VNFont(this.faceName, this.height, {
            width: this.width,
            weight: this.weight,
            italic: this.italic,
            underline: this.underline,
            strikeOut: this.strikeOut,
            charset: this.charset,
            escapement: this.escapement,
            orientation: this.orientation,
            pitchAndFamily: this.pitchAndFamily
        });
    }

    /**
     * Get LOGFONT structure
     * @returns {Object}
     */
    getLogFont() {
        return {
            lfHeight: this.height,
            lfWidth: this.width,
            lfEscapement: this.escapement,
            lfOrientation: this.orientation,
            lfWeight: this.weight,
            lfItalic: this.italic ? 1 : 0,
            lfUnderline: this.underline ? 1 : 0,
            lfStrikeOut: this.strikeOut ? 1 : 0,
            lfCharSet: this.charset,
            lfOutPrecision: 0,
            lfClipPrecision: 0,
            lfQuality: 0,
            lfPitchAndFamily: this.pitchAndFamily,
            lfFaceName: this.faceName
        };
    }

    /**
     * Get text metrics
     * @param {CanvasRenderingContext2D} ctx 
     * @param {string} text 
     * @returns {TextMetrics}
     */
    measureText(ctx, text) {
        this.applyTo(ctx);
        return ctx.measureText(text);
    }
}

/**
 * VNBrush - Brush class
 * Port of TBrush @ 0x0042a3d8
 */
export class VNBrush {
    /**
     * @param {string|Object} color - Color string or options
     * @param {number} style 
     * @param {number} hatch 
     */
    constructor(color = '#000000', style = VNBrushStyle.SOLID, hatch = 0) {
        if (typeof color === 'object') {
            this.color = color.color || '#000000';
            this.style = color.style || VNBrushStyle.SOLID;
            this.hatch = color.hatch || 0;
            this.pattern = color.pattern || null;
        } else {
            this.color = color;
            this.style = style;
            this.hatch = hatch;
            this.pattern = null;
        }
        
        this.handle = Math.random().toString(36).substr(2, 9);
    }

    /**
     * Create from color
     * Port of @TBrush@$bctr$qrx6TColor @ 0x00453836
     * @param {string} color 
     * @returns {VNBrush}
     */
    static fromColor(color) {
        return new VNBrush(color, VNBrushStyle.SOLID);
    }

    /**
     * Create from bitmap pattern
     * Port of @TBrush@$bctr$qrx7TBitmap @ 0x004537a0
     * @param {HTMLImageElement|HTMLCanvasElement} bitmap 
     * @returns {VNBrush}
     */
    static fromBitmap(bitmap) {
        const brush = new VNBrush('#000000', VNBrushStyle.PATTERN);
        brush.pattern = bitmap;
        return brush;
    }

    /**
     * Create hatched brush
     * @param {number} hatchStyle 
     * @param {string} color 
     * @returns {VNBrush}
     */
    static hatched(hatchStyle, color = '#000000') {
        return new VNBrush(color, VNBrushStyle.HATCHED, hatchStyle);
    }

    /**
     * Create null/hollow brush
     * @returns {VNBrush}
     */
    static hollow() {
        return new VNBrush('transparent', VNBrushStyle.HOLLOW);
    }

    /**
     * Apply to canvas context
     * @param {CanvasRenderingContext2D} ctx 
     */
    applyTo(ctx) {
        if (this.style === VNBrushStyle.HOLLOW || this.style === VNBrushStyle.NULL) {
            ctx.fillStyle = 'transparent';
        } else if (this.style === VNBrushStyle.PATTERN && this.pattern) {
            const pattern = ctx.createPattern(this.pattern, 'repeat');
            ctx.fillStyle = pattern || this.color;
        } else if (this.style === VNBrushStyle.HATCHED) {
            ctx.fillStyle = this._createHatchPattern(ctx);
        } else {
            ctx.fillStyle = this.color;
        }
    }

    /**
     * Create hatch pattern
     * @private
     */
    _createHatchPattern(ctx) {
        const size = 8;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const pCtx = canvas.getContext('2d');
        
        pCtx.strokeStyle = this.color;
        pCtx.lineWidth = 1;
        
        switch (this.hatch) {
            case VNHatchStyle.HORIZONTAL:
                pCtx.beginPath();
                pCtx.moveTo(0, size / 2);
                pCtx.lineTo(size, size / 2);
                pCtx.stroke();
                break;
            case VNHatchStyle.VERTICAL:
                pCtx.beginPath();
                pCtx.moveTo(size / 2, 0);
                pCtx.lineTo(size / 2, size);
                pCtx.stroke();
                break;
            case VNHatchStyle.FDIAGONAL:
                pCtx.beginPath();
                pCtx.moveTo(0, size);
                pCtx.lineTo(size, 0);
                pCtx.stroke();
                break;
            case VNHatchStyle.BDIAGONAL:
                pCtx.beginPath();
                pCtx.moveTo(0, 0);
                pCtx.lineTo(size, size);
                pCtx.stroke();
                break;
            case VNHatchStyle.CROSS:
                pCtx.beginPath();
                pCtx.moveTo(0, size / 2);
                pCtx.lineTo(size, size / 2);
                pCtx.moveTo(size / 2, 0);
                pCtx.lineTo(size / 2, size);
                pCtx.stroke();
                break;
            case VNHatchStyle.DIAGCROSS:
                pCtx.beginPath();
                pCtx.moveTo(0, 0);
                pCtx.lineTo(size, size);
                pCtx.moveTo(0, size);
                pCtx.lineTo(size, 0);
                pCtx.stroke();
                break;
        }
        
        return ctx.createPattern(canvas, 'repeat') || this.color;
    }

    /**
     * Clone brush
     * @returns {VNBrush}
     */
    clone() {
        const brush = new VNBrush(this.color, this.style, this.hatch);
        brush.pattern = this.pattern;
        return brush;
    }
}

/**
 * VNPen - Pen class
 * Port of TPen
 */
export class VNPen {
    /**
     * @param {string|Object} color 
     * @param {number} width 
     * @param {number} style 
     */
    constructor(color = '#000000', width = 1, style = VNPenStyle.SOLID) {
        if (typeof color === 'object') {
            this.color = color.color || '#000000';
            this.width = color.width || 1;
            this.style = color.style || VNPenStyle.SOLID;
        } else {
            this.color = color;
            this.width = width;
            this.style = style;
        }
        
        this.handle = Math.random().toString(36).substr(2, 9);
    }

    /**
     * Create from color
     * Port of @TPen@$bctr$qrx6TColorii @ 0x00453a90
     * @param {string} color 
     * @param {number} width 
     * @param {number} style 
     * @returns {VNPen}
     */
    static create(color, width = 1, style = VNPenStyle.SOLID) {
        return new VNPen(color, width, style);
    }

    /**
     * Create null pen
     * @returns {VNPen}
     */
    static null() {
        return new VNPen('transparent', 0, VNPenStyle.NULL);
    }

    /**
     * Apply to canvas context
     * @param {CanvasRenderingContext2D} ctx 
     */
    applyTo(ctx) {
        ctx.strokeStyle = this.color;
        ctx.lineWidth = this.width;
        
        // Set dash pattern
        switch (this.style) {
            case VNPenStyle.DASH:
                ctx.setLineDash([8, 4]);
                break;
            case VNPenStyle.DOT:
                ctx.setLineDash([2, 2]);
                break;
            case VNPenStyle.DASHDOT:
                ctx.setLineDash([8, 4, 2, 4]);
                break;
            case VNPenStyle.DASHDOTDOT:
                ctx.setLineDash([8, 4, 2, 4, 2, 4]);
                break;
            case VNPenStyle.NULL:
                ctx.strokeStyle = 'transparent';
                break;
            default:
                ctx.setLineDash([]);
        }
    }

    /**
     * Clone pen
     * @returns {VNPen}
     */
    clone() {
        return new VNPen(this.color, this.width, this.style);
    }
}

/**
 * VNCursor - Cursor management
 * Emulates Windows cursor functions
 */
export class VNCursor {
    constructor() {
        this.currentCursor = 'default';
        this.customCursors = new Map();
        this.visible = true;
        this.position = { x: 0, y: 0 };
    }

    /**
     * Load cursor from file
     * Port of LoadCursorFromFileA @ 0x00451ff8
     * @param {string} filename 
     * @returns {string} - Cursor name/URL
     */
    loadFromFile(filename) {
        // Convert to CSS cursor URL
        return `url(${filename}), auto`;
    }

    /**
     * Load standard cursor
     * Port of LoadCursorA @ 0x0045201a
     * @param {string} cursorName 
     * @returns {string}
     */
    load(cursorName) {
        return VNCursors[cursorName] || 'default';
    }

    /**
     * Set cursor
     * Port of SetCursor @ 0x00452168
     * @param {string} cursor 
     * @param {HTMLElement} element 
     */
    set(cursor, element = document.body) {
        this.currentCursor = cursor;
        if (element) {
            element.style.cursor = cursor;
        }
    }

    /**
     * Get cursor position
     * Port of GetCursorPos @ 0x00451f1c
     * @returns {{x: number, y: number}}
     */
    getPosition() {
        return { ...this.position };
    }

    /**
     * Update position (call from mousemove)
     * @param {number} x 
     * @param {number} y 
     */
    updatePosition(x, y) {
        this.position.x = x;
        this.position.y = y;
    }

    /**
     * Show/hide cursor
     * Port of ShowCursor @ 0x00452126
     * @param {boolean} show 
     * @returns {number} - Display count
     */
    show(show) {
        this.visible = show;
        document.body.style.cursor = show ? this.currentCursor : 'none';
        return show ? 1 : -1;
    }

    /**
     * Register custom cursor
     * @param {string} name 
     * @param {string} url 
     */
    registerCustom(name, url) {
        this.customCursors.set(name, `url(${url}), auto`);
    }

    /**
     * Get custom cursor
     * @param {string} name 
     * @returns {string}
     */
    getCustom(name) {
        return this.customCursors.get(name) || 'default';
    }

    /**
     * Destroy cursor
     * Port of DestroyCursor @ 0x00451a38
     * @param {string} cursor 
     */
    destroy(cursor) {
        // In web, nothing to destroy
    }
}

/**
 * Global cursor instance
 */
export const cursor = new VNCursor();

/**
 * VNIcon - Icon management
 */
export class VNIcon {
    /**
     * @param {string} src 
     * @param {number} width 
     * @param {number} height 
     */
    constructor(src = '', width = 32, height = 32) {
        this.src = src;
        this.width = width;
        this.height = height;
        this.image = null;
        this.handle = Math.random().toString(36).substr(2, 9);
    }

    /**
     * Load icon
     * @returns {Promise<void>}
     */
    async load() {
        if (!this.src) return;
        
        this.image = new Image();
        this.image.width = this.width;
        this.image.height = this.height;
        
        await new Promise((resolve, reject) => {
            this.image.onload = resolve;
            this.image.onerror = reject;
            this.image.src = this.src;
        });
    }

    /**
     * Draw icon
     * @param {CanvasRenderingContext2D} ctx 
     * @param {number} x 
     * @param {number} y 
     */
    draw(ctx, x, y) {
        if (this.image) {
            ctx.drawImage(this.image, x, y, this.width, this.height);
        }
    }

    /**
     * Check if iconic (minimized)
     * Port of IsIconic @ 0x00451fb2
     * @param {HTMLElement} element 
     * @returns {boolean}
     */
    static isIconic(element) {
        // In web context, check if minimized/hidden
        return element && (
            element.classList.contains('minimized') ||
            getComputedStyle(element).display === 'none'
        );
    }
}

export default {
    VNFontWeight,
    VNCharset,
    VNPenStyle,
    VNBrushStyle,
    VNHatchStyle,
    VNCursors,
    VNFont,
    VNBrush,
    VNPen,
    VNCursor,
    cursor,
    VNIcon
};
