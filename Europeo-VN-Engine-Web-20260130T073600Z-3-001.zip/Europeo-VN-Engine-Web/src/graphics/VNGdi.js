/**
 * VNGdi - GDI (Graphics Device Interface) emulation classes
 * 
 * Port of Windows GDI classes from OWL framework:
 * TDC, TClientDC, TPen, TBrush, TFont, TDib, TRegion, TGdiBase, TGdiObject
 * 
 * Original addresses from europeo.exe:
 * - TGdiBase: 0x004142fe
 * - TGdiObject: 0x0041d4cd
 * - TDib: 0x0041e64b
 * - TFont: 0x0041e76e
 * - TBrush: 0x0042a3d8
 * - TRegion: 0x0041401e
 * - TClientDC: 0x004363b8
 */

// ============================================================================
// TPoint - Point class
// Original: Windows POINT structure
// ============================================================================
export class TPoint {
    constructor(x = 0, y = 0) {
        this.x = x;
        this.y = y;
    }

    /**
     * Offset point by delta
     * @param {number} dx - X delta
     * @param {number} dy - Y delta
     */
    offset(dx, dy) {
        this.x += dx;
        this.y += dy;
        return this;
    }

    /**
     * Check equality
     * @param {TPoint} other 
     */
    equals(other) {
        return this.x === other.x && this.y === other.y;
    }

    /**
     * Clone point
     */
    clone() {
        return new TPoint(this.x, this.y);
    }

    /**
     * Distance to another point
     */
    distanceTo(other) {
        const dx = this.x - other.x;
        const dy = this.y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}

// ============================================================================
// TSize - Size class
// Original: Windows SIZE structure
// ============================================================================
export class TSize {
    constructor(cx = 0, cy = 0) {
        this.cx = cx;
        this.cy = cy;
    }

    get width() { return this.cx; }
    set width(v) { this.cx = v; }

    get height() { return this.cy; }
    set height(v) { this.cy = v; }

    /**
     * Check equality
     */
    equals(other) {
        return this.cx === other.cx && this.cy === other.cy;
    }

    /**
     * Clone size
     */
    clone() {
        return new TSize(this.cx, this.cy);
    }
}

// ============================================================================
// TRect - Rectangle class
// Original: Windows RECT structure with OWL extensions
// Methods from: @TRect@Offset$qii (0x00451b6a), @TRect@Normalize$qv (0x00451b8a)
//               @TRect@Inflate$qii (0x00451bea), @TRect@$brand$qrx5TRect (0x00451b0a)
// ============================================================================
export class TRect {
    constructor(left = 0, top = 0, right = 0, bottom = 0) {
        if (typeof left === 'object') {
            // Copy constructor
            this.left = left.left || left.x || 0;
            this.top = left.top || left.y || 0;
            this.right = left.right || (left.x + left.width) || 0;
            this.bottom = left.bottom || (left.y + left.height) || 0;
        } else {
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
        }
    }

    // Accessors
    get x() { return this.left; }
    set x(v) { 
        const w = this.width;
        this.left = v;
        this.right = v + w;
    }

    get y() { return this.top; }
    set y(v) {
        const h = this.height;
        this.top = v;
        this.bottom = v + h;
    }

    get width() { return this.right - this.left; }
    set width(v) { this.right = this.left + v; }

    get height() { return this.bottom - this.top; }
    set height(v) { this.bottom = this.top + v; }

    /**
     * Offset rectangle
     * Original: @TRect@Offset$qii at 0x00451b6a
     */
    offset(dx, dy) {
        this.left += dx;
        this.top += dy;
        this.right += dx;
        this.bottom += dy;
        return this;
    }

    /**
     * Normalize rectangle (ensure left < right, top < bottom)
     * Original: @TRect@Normalize$qv at 0x00451b8a
     */
    normalize() {
        if (this.left > this.right) {
            [this.left, this.right] = [this.right, this.left];
        }
        if (this.top > this.bottom) {
            [this.top, this.bottom] = [this.bottom, this.top];
        }
        return this;
    }

    /**
     * Inflate rectangle
     * Original: @TRect@Inflate$qii at 0x00451bea
     */
    inflate(dx, dy) {
        this.left -= dx;
        this.top -= dy;
        this.right += dx;
        this.bottom += dy;
        return this;
    }

    /**
     * Intersect with another rectangle
     * Original: @TRect@$brand$qrx5TRect at 0x00451b0a
     */
    intersect(other) {
        return new TRect(
            Math.max(this.left, other.left),
            Math.max(this.top, other.top),
            Math.min(this.right, other.right),
            Math.min(this.bottom, other.bottom)
        );
    }

    /**
     * Union with another rectangle
     * Original: @TRect@$bror$qrx5TRect at 0x00451cac
     */
    union(other) {
        return new TRect(
            Math.min(this.left, other.left),
            Math.min(this.top, other.top),
            Math.max(this.right, other.right),
            Math.max(this.bottom, other.bottom)
        );
    }

    /**
     * Check if point is inside rectangle
     */
    contains(x, y) {
        if (typeof x === 'object') {
            return x.x >= this.left && x.x < this.right &&
                   x.y >= this.top && x.y < this.bottom;
        }
        return x >= this.left && x < this.right &&
               y >= this.top && y < this.bottom;
    }

    /**
     * Check if rectangles intersect
     */
    intersects(other) {
        return !(other.left >= this.right || other.right <= this.left ||
                 other.top >= this.bottom || other.bottom <= this.top);
    }

    /**
     * Check if rectangle is empty
     */
    isEmpty() {
        return this.left >= this.right || this.top >= this.bottom;
    }

    /**
     * Set rectangle to empty
     */
    setEmpty() {
        this.left = this.top = this.right = this.bottom = 0;
        return this;
    }

    /**
     * Clone rectangle
     */
    clone() {
        return new TRect(this.left, this.top, this.right, this.bottom);
    }

    /**
     * Get center point
     */
    center() {
        return new TPoint(
            (this.left + this.right) / 2,
            (this.top + this.bottom) / 2
        );
    }

    /**
     * Get top-left point
     */
    topLeft() {
        return new TPoint(this.left, this.top);
    }

    /**
     * Get bottom-right point
     */
    bottomRight() {
        return new TPoint(this.right, this.bottom);
    }

    /**
     * Get size
     */
    size() {
        return new TSize(this.width, this.height);
    }
}

// ============================================================================
// TGdiBase - Base class for GDI objects
// Original: 0x004142fe
// Methods: @TGdiBase@CheckValid$qui at 0x004521e4
// ============================================================================
export class TGdiBase {
    constructor() {
        this._handle = null;
        this._shouldDelete = true;
    }

    /**
     * Get handle
     */
    getHandle() {
        return this._handle;
    }

    /**
     * Check if valid
     * Original: @TGdiBase@CheckValid$qui at 0x004521e4
     */
    checkValid(resId = 0) {
        return this._handle !== null;
    }

    /**
     * Release resources
     */
    destroy() {
        if (this._handle && this._shouldDelete) {
            this._handle = null;
        }
    }
}

// ============================================================================
// TGdiObject - GDI Object with reference counting
// Original: 0x0041d4cd
// Methods: @TGdiObject@RefAdd$qpv16TGdiObject@TType at 0x00452182
//          @TGdiObject@$bdtr$qv at 0x004521ae
// ============================================================================
export class TGdiObject extends TGdiBase {
    // GDI Object types
    static Type = {
        Pen: 1,
        Brush: 2,
        Font: 3,
        Bitmap: 4,
        Region: 5,
        Palette: 6
    };

    constructor(type) {
        super();
        this._type = type;
        this._refCount = 1;
    }

    /**
     * Get object type
     */
    getType() {
        return this._type;
    }

    /**
     * Add reference
     * Original: @TGdiObject@RefAdd$qpv16TGdiObject@TType at 0x00452182
     */
    refAdd() {
        this._refCount++;
        return this._refCount;
    }

    /**
     * Release reference
     */
    refRemove() {
        this._refCount--;
        if (this._refCount <= 0) {
            this.destroy();
        }
        return this._refCount;
    }

    /**
     * Destructor
     * Original: @TGdiObject@$bdtr$qv at 0x004521ae
     */
    destroy() {
        super.destroy();
    }
}

// ============================================================================
// TPen - Pen object for line drawing
// Original: Windows HPEN wrapper
// ============================================================================
export class TPen extends TGdiObject {
    // Pen styles
    static Style = {
        PS_SOLID: 0,
        PS_DASH: 1,
        PS_DOT: 2,
        PS_DASHDOT: 3,
        PS_DASHDOTDOT: 4,
        PS_NULL: 5,
        PS_INSIDEFRAME: 6
    };

    constructor(color = '#000000', width = 1, style = TPen.Style.PS_SOLID) {
        super(TGdiObject.Type.Pen);
        this._color = color;
        this._width = width;
        this._style = style;
        this._handle = { type: 'pen', color, width, style };
    }

    get color() { return this._color; }
    get width() { return this._width; }
    get style() { return this._style; }

    /**
     * Apply pen to canvas context
     */
    applyTo(ctx) {
        ctx.strokeStyle = this._color;
        ctx.lineWidth = this._width;
        
        switch (this._style) {
            case TPen.Style.PS_DASH:
                ctx.setLineDash([10, 5]);
                break;
            case TPen.Style.PS_DOT:
                ctx.setLineDash([2, 2]);
                break;
            case TPen.Style.PS_DASHDOT:
                ctx.setLineDash([10, 5, 2, 5]);
                break;
            case TPen.Style.PS_DASHDOTDOT:
                ctx.setLineDash([10, 5, 2, 5, 2, 5]);
                break;
            case TPen.Style.PS_NULL:
                ctx.strokeStyle = 'transparent';
                break;
            default:
                ctx.setLineDash([]);
        }
    }
}

// ============================================================================
// TBrush - Brush object for filling
// Original: 0x0042a3d8
// Methods: @TBrush@$bdtr$qv at 0x004536e4
// ============================================================================
export class TBrush extends TGdiObject {
    // Brush styles
    static Style = {
        BS_SOLID: 0,
        BS_NULL: 1,
        BS_HOLLOW: 1,
        BS_HATCHED: 2,
        BS_PATTERN: 3
    };

    // Hatch styles
    static Hatch = {
        HS_HORIZONTAL: 0,
        HS_VERTICAL: 1,
        HS_FDIAGONAL: 2,
        HS_BDIAGONAL: 3,
        HS_CROSS: 4,
        HS_DIAGCROSS: 5
    };

    constructor(color = '#000000', style = TBrush.Style.BS_SOLID, hatch = null) {
        super(TGdiObject.Type.Brush);
        this._color = color;
        this._style = style;
        this._hatch = hatch;
        this._pattern = null;
        this._handle = { type: 'brush', color, style, hatch };
    }

    get color() { return this._color; }
    get style() { return this._style; }

    /**
     * Create pattern brush
     */
    static createPattern(image) {
        const brush = new TBrush('#000000', TBrush.Style.BS_PATTERN);
        brush._pattern = image;
        return brush;
    }

    /**
     * Apply brush to canvas context
     */
    applyTo(ctx) {
        if (this._style === TBrush.Style.BS_NULL || this._style === TBrush.Style.BS_HOLLOW) {
            ctx.fillStyle = 'transparent';
        } else if (this._style === TBrush.Style.BS_PATTERN && this._pattern) {
            ctx.fillStyle = ctx.createPattern(this._pattern, 'repeat');
        } else {
            ctx.fillStyle = this._color;
        }
    }

    /**
     * Destructor
     * Original: @TBrush@$bdtr$qv at 0x004536e4
     */
    destroy() {
        this._pattern = null;
        super.destroy();
    }
}

// ============================================================================
// TFont - Font object
// Original: 0x0041e76e
// Methods: @TFont@$bctr$qrx5TFont at 0x00452b64
//          @TFont@$bctr$qpxciiiiiucucucucucucucuc at 0x00452c14
//          @TFont@$bctr$qpx11tagLOGFONTA at 0x00452c84
// ============================================================================
export class TFont extends TGdiObject {
    // Font weights
    static Weight = {
        FW_DONTCARE: 0,
        FW_THIN: 100,
        FW_EXTRALIGHT: 200,
        FW_LIGHT: 300,
        FW_NORMAL: 400,
        FW_MEDIUM: 500,
        FW_SEMIBOLD: 600,
        FW_BOLD: 700,
        FW_EXTRABOLD: 800,
        FW_HEAVY: 900
    };

    constructor(faceName = 'Arial', height = 12, weight = TFont.Weight.FW_NORMAL, italic = false, underline = false, strikeOut = false) {
        super(TGdiObject.Type.Font);
        this._faceName = faceName;
        this._height = height;
        this._weight = weight;
        this._italic = italic;
        this._underline = underline;
        this._strikeOut = strikeOut;
        this._handle = { 
            type: 'font', 
            faceName, 
            height, 
            weight, 
            italic, 
            underline, 
            strikeOut 
        };
    }

    // Accessors
    get faceName() { return this._faceName; }
    get height() { return this._height; }
    get weight() { return this._weight; }
    get italic() { return this._italic; }
    get underline() { return this._underline; }
    get strikeOut() { return this._strikeOut; }

    /**
     * Create from LOGFONT structure
     * Original: @TFont@$bctr$qpx11tagLOGFONTA at 0x00452c84
     */
    static fromLogFont(logFont) {
        return new TFont(
            logFont.lfFaceName || 'Arial',
            Math.abs(logFont.lfHeight || 12),
            logFont.lfWeight || TFont.Weight.FW_NORMAL,
            logFont.lfItalic || false,
            logFont.lfUnderline || false,
            logFont.lfStrikeOut || false
        );
    }

    /**
     * Copy constructor
     * Original: @TFont@$bctr$qrx5TFont at 0x00452b64
     */
    clone() {
        return new TFont(
            this._faceName,
            this._height,
            this._weight,
            this._italic,
            this._underline,
            this._strikeOut
        );
    }

    /**
     * Get CSS font string
     */
    toCssString() {
        let style = '';
        if (this._italic) style += 'italic ';
        
        let weight = 'normal';
        if (this._weight >= TFont.Weight.FW_BOLD) weight = 'bold';
        else if (this._weight >= TFont.Weight.FW_SEMIBOLD) weight = '600';
        else if (this._weight >= TFont.Weight.FW_MEDIUM) weight = '500';
        else if (this._weight <= TFont.Weight.FW_LIGHT) weight = '300';
        
        return `${style}${weight} ${this._height}px ${this._faceName}`;
    }

    /**
     * Apply font to canvas context
     */
    applyTo(ctx) {
        ctx.font = this.toCssString();
    }
}

// ============================================================================
// TRegion - Region object for clipping
// Original: 0x0041401e
// ============================================================================
export class TRegion extends TGdiObject {
    constructor() {
        super(TGdiObject.Type.Region);
        this._path = new Path2D();
        this._bounds = new TRect();
    }

    /**
     * Create rectangular region
     */
    static createRect(rect) {
        const region = new TRegion();
        region._path.rect(rect.left, rect.top, rect.width, rect.height);
        region._bounds = rect.clone();
        return region;
    }

    /**
     * Create elliptic region
     */
    static createElliptic(rect) {
        const region = new TRegion();
        const cx = (rect.left + rect.right) / 2;
        const cy = (rect.top + rect.bottom) / 2;
        const rx = rect.width / 2;
        const ry = rect.height / 2;
        region._path.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        region._bounds = rect.clone();
        return region;
    }

    /**
     * Create polygon region
     */
    static createPolygon(points) {
        const region = new TRegion();
        if (points.length > 0) {
            region._path.moveTo(points[0].x, points[0].y);
            for (let i = 1; i < points.length; i++) {
                region._path.lineTo(points[i].x, points[i].y);
            }
            region._path.closePath();
            
            // Calculate bounds
            let minX = Infinity, minY = Infinity;
            let maxX = -Infinity, maxY = -Infinity;
            for (const p of points) {
                minX = Math.min(minX, p.x);
                minY = Math.min(minY, p.y);
                maxX = Math.max(maxX, p.x);
                maxY = Math.max(maxY, p.y);
            }
            region._bounds = new TRect(minX, minY, maxX, maxY);
        }
        return region;
    }

    /**
     * Get bounding rectangle
     */
    getBounds() {
        return this._bounds.clone();
    }

    /**
     * Check if point is in region
     */
    contains(x, y, ctx) {
        if (ctx) {
            return ctx.isPointInPath(this._path, x, y);
        }
        return this._bounds.contains(x, y);
    }

    /**
     * Combine with another region
     */
    combine(other, mode = 'union') {
        // In web we need to use path operations
        // This is a simplified implementation
        if (mode === 'union') {
            this._bounds = this._bounds.union(other._bounds);
        } else if (mode === 'intersect') {
            this._bounds = this._bounds.intersect(other._bounds);
        }
        return this;
    }
}

// ============================================================================
// TDib - Device Independent Bitmap
// Original: 0x0041e64b
// Methods: @TDib@$bctr$qpxc at 0x00452f92
//          @TDib@$bctr$qp11HINSTANCE__6TResId at 0x00453024
// ============================================================================
export class TDib extends TGdiObject {
    constructor() {
        super(TGdiObject.Type.Bitmap);
        this._width = 0;
        this._height = 0;
        this._bitsPerPixel = 32;
        this._imageData = null;
        this._canvas = null;
    }

    // Accessors
    get width() { return this._width; }
    get height() { return this._height; }
    get bitsPerPixel() { return this._bitsPerPixel; }

    /**
     * Create from file
     * Original: @TDib@$bctr$qpxc at 0x00452f92
     */
    static async fromFile(path) {
        const dib = new TDib();
        
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                dib._width = img.width;
                dib._height = img.height;
                
                // Create canvas to get image data
                dib._canvas = document.createElement('canvas');
                dib._canvas.width = img.width;
                dib._canvas.height = img.height;
                
                const ctx = dib._canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                dib._imageData = ctx.getImageData(0, 0, img.width, img.height);
                dib._handle = img;
                
                resolve(dib);
            };
            img.onerror = reject;
            img.src = path;
        });
    }

    /**
     * Create empty DIB
     */
    static create(width, height, bitsPerPixel = 32) {
        const dib = new TDib();
        dib._width = width;
        dib._height = height;
        dib._bitsPerPixel = bitsPerPixel;
        
        dib._canvas = document.createElement('canvas');
        dib._canvas.width = width;
        dib._canvas.height = height;
        
        const ctx = dib._canvas.getContext('2d');
        dib._imageData = ctx.createImageData(width, height);
        
        return dib;
    }

    /**
     * Get pixel at coordinates
     */
    getPixel(x, y) {
        if (!this._imageData || x < 0 || y < 0 || x >= this._width || y >= this._height) {
            return null;
        }
        
        const idx = (y * this._width + x) * 4;
        return {
            r: this._imageData.data[idx],
            g: this._imageData.data[idx + 1],
            b: this._imageData.data[idx + 2],
            a: this._imageData.data[idx + 3]
        };
    }

    /**
     * Set pixel at coordinates
     */
    setPixel(x, y, r, g, b, a = 255) {
        if (!this._imageData || x < 0 || y < 0 || x >= this._width || y >= this._height) {
            return;
        }
        
        const idx = (y * this._width + x) * 4;
        this._imageData.data[idx] = r;
        this._imageData.data[idx + 1] = g;
        this._imageData.data[idx + 2] = b;
        this._imageData.data[idx + 3] = a;
    }

    /**
     * Apply changes to canvas
     */
    flush() {
        if (this._canvas && this._imageData) {
            const ctx = this._canvas.getContext('2d');
            ctx.putImageData(this._imageData, 0, 0);
        }
    }

    /**
     * Get canvas for drawing
     */
    getCanvas() {
        return this._canvas;
    }

    /**
     * Draw to context
     */
    draw(ctx, x = 0, y = 0, width = null, height = null) {
        if (this._canvas) {
            this.flush();
            ctx.drawImage(
                this._canvas, 
                x, y, 
                width || this._width, 
                height || this._height
            );
        }
    }
}

// ============================================================================
// TDC - Device Context (main drawing context)
// Original: Windows HDC wrapper
// Methods: @TDC@$bctr$qp5HDC__ at 0x00452d74
//          @TDC@$bdtr$qv at 0x00452ca4
//          @TDC@SaveDC$xqv at 0x004522f8
//          @TDC@RestoreDC$qi at 0x0045240c
//          @TDC@GetDeviceCaps$xqi at 0x00452838
//          @TDC@SelectObject$qrx4TPen at 0x004521c6
//          @TDC@DrawTextA$qpxcirx5TRectus at 0x00452b7e
//          @TDC@ExtTextOutA$qiiuspx5TRectpxcipxi at 0x00452a7a
// ============================================================================
export class TDC {
    // Device capabilities
    static DevCaps = {
        HORZRES: 8,
        VERTRES: 10,
        BITSPIXEL: 12,
        PLANES: 14,
        LOGPIXELSX: 88,
        LOGPIXELSY: 90
    };

    // DrawText flags
    static DrawTextFlags = {
        DT_TOP: 0x0000,
        DT_LEFT: 0x0000,
        DT_CENTER: 0x0001,
        DT_RIGHT: 0x0002,
        DT_VCENTER: 0x0004,
        DT_BOTTOM: 0x0008,
        DT_WORDBREAK: 0x0010,
        DT_SINGLELINE: 0x0020,
        DT_NOCLIP: 0x0100,
        DT_CALCRECT: 0x0400
    };

    constructor(canvas = null) {
        this._canvas = canvas;
        this._ctx = canvas ? canvas.getContext('2d') : null;
        this._handle = this._ctx;
        
        // Current objects
        this._pen = new TPen();
        this._brush = new TBrush();
        this._font = new TFont();
        this._region = null;
        
        // State stack
        this._savedStates = [];
        
        // Text properties
        this._textColor = '#000000';
        this._bkColor = '#FFFFFF';
        this._bkMode = 1; // OPAQUE = 1, TRANSPARENT = 2
        
        // Mapping mode
        this._mapMode = 1; // MM_TEXT
        this._viewportOrg = new TPoint();
        this._windowOrg = new TPoint();
        this._viewportExt = new TSize(1, 1);
        this._windowExt = new TSize(1, 1);
    }

    /**
     * Get handle
     */
    getHandle() {
        return this._handle;
    }

    /**
     * Get attribute HDC
     * Original: @TDC@GetAttributeHDC$xqv at 0x00452966
     */
    getAttributeHDC() {
        return this._handle;
    }

    /**
     * Save device context state
     * Original: @TDC@SaveDC$xqv at 0x004522f8
     */
    saveDC() {
        if (this._ctx) {
            this._ctx.save();
        }
        
        this._savedStates.push({
            pen: this._pen,
            brush: this._brush,
            font: this._font,
            textColor: this._textColor,
            bkColor: this._bkColor,
            bkMode: this._bkMode,
            viewportOrg: this._viewportOrg.clone(),
            windowOrg: this._windowOrg.clone()
        });
        
        return this._savedStates.length;
    }

    /**
     * Restore device context state
     * Original: @TDC@RestoreDC$qi at 0x0045240c
     */
    restoreDC(savedDC = -1) {
        if (this._ctx) {
            this._ctx.restore();
        }
        
        if (savedDC === -1 && this._savedStates.length > 0) {
            const state = this._savedStates.pop();
            Object.assign(this, {
                _pen: state.pen,
                _brush: state.brush,
                _font: state.font,
                _textColor: state.textColor,
                _bkColor: state.bkColor,
                _bkMode: state.bkMode,
                _viewportOrg: state.viewportOrg,
                _windowOrg: state.windowOrg
            });
        }
        
        return true;
    }

    /**
     * Get device capabilities
     * Original: @TDC@GetDeviceCaps$xqi at 0x00452838
     */
    getDeviceCaps(capability) {
        switch (capability) {
            case TDC.DevCaps.HORZRES:
                return this._canvas ? this._canvas.width : window.innerWidth;
            case TDC.DevCaps.VERTRES:
                return this._canvas ? this._canvas.height : window.innerHeight;
            case TDC.DevCaps.BITSPIXEL:
                return 32;
            case TDC.DevCaps.PLANES:
                return 1;
            case TDC.DevCaps.LOGPIXELSX:
            case TDC.DevCaps.LOGPIXELSY:
                return 96;
            default:
                return 0;
        }
    }

    /**
     * Select pen
     * Original: @TDC@SelectObject$qrx4TPen at 0x004521c6
     */
    selectObject(obj) {
        const oldObj = null;
        
        if (obj instanceof TPen) {
            const old = this._pen;
            this._pen = obj;
            obj.applyTo(this._ctx);
            return old;
        } else if (obj instanceof TBrush) {
            const old = this._brush;
            this._brush = obj;
            obj.applyTo(this._ctx);
            return old;
        } else if (obj instanceof TFont) {
            const old = this._font;
            this._font = obj;
            obj.applyTo(this._ctx);
            return old;
        } else if (obj instanceof TRegion) {
            const old = this._region;
            this._region = obj;
            return old;
        }
        
        return oldObj;
    }

    /**
     * Restore font
     * Original: @TDC@RestoreFont$qv at 0x00452378
     */
    restoreFont() {
        if (this._font) {
            this._font.applyTo(this._ctx);
        }
    }

    /**
     * Restore brush
     * Original: @TDC@RestoreBrush$qv at 0x00452494
     */
    restoreBrush() {
        if (this._brush) {
            this._brush.applyTo(this._ctx);
        }
    }

    /**
     * Set text color
     */
    setTextColor(color) {
        const old = this._textColor;
        this._textColor = color;
        if (this._ctx) {
            this._ctx.fillStyle = color;
        }
        return old;
    }

    /**
     * Set background color
     */
    setBkColor(color) {
        const old = this._bkColor;
        this._bkColor = color;
        return old;
    }

    /**
     * Set background mode
     */
    setBkMode(mode) {
        const old = this._bkMode;
        this._bkMode = mode;
        return old;
    }

    /**
     * Offset viewport origin
     * Original: @TDC@OffsetViewportOrg$qrx6TPointp6TPoint at 0x004525e2
     */
    offsetViewportOrg(point, oldPoint = null) {
        if (oldPoint) {
            oldPoint.x = this._viewportOrg.x;
            oldPoint.y = this._viewportOrg.y;
        }
        this._viewportOrg.offset(point.x, point.y);
        
        if (this._ctx) {
            this._ctx.translate(point.x, point.y);
        }
        
        return true;
    }

    /**
     * Scale window extent
     * Original: @TDC@ScaleWindowExt$qiiiip5TSize at 0x00452214
     */
    scaleWindowExt(xNum, xDenom, yNum, yDenom, oldSize = null) {
        if (oldSize) {
            oldSize.cx = this._windowExt.cx;
            oldSize.cy = this._windowExt.cy;
        }
        this._windowExt.cx = (this._windowExt.cx * xNum) / xDenom;
        this._windowExt.cy = (this._windowExt.cy * yNum) / yDenom;
        return true;
    }

    /**
     * Scale viewport extent
     * Original: @TDC@ScaleViewportExt$qiiiip5TSize at 0x00452294
     */
    scaleViewportExt(xNum, xDenom, yNum, yDenom, oldSize = null) {
        if (oldSize) {
            oldSize.cx = this._viewportExt.cx;
            oldSize.cy = this._viewportExt.cy;
        }
        this._viewportExt.cx = (this._viewportExt.cx * xNum) / xDenom;
        this._viewportExt.cy = (this._viewportExt.cy * yNum) / yDenom;
        return true;
    }

    /**
     * Draw text
     * Original: @TDC@DrawTextA$qpxcirx5TRectus at 0x00452b7e
     */
    drawText(text, rect, flags = 0) {
        if (!this._ctx) return 0;
        
        this._ctx.save();
        this._font.applyTo(this._ctx);
        
        // Calculate text position
        let x = rect.left;
        let y = rect.top;
        
        const metrics = this._ctx.measureText(text);
        const textHeight = this._font.height;
        
        // Horizontal alignment
        if (flags & TDC.DrawTextFlags.DT_CENTER) {
            x = rect.left + (rect.width - metrics.width) / 2;
        } else if (flags & TDC.DrawTextFlags.DT_RIGHT) {
            x = rect.right - metrics.width;
        }
        
        // Vertical alignment
        if (flags & TDC.DrawTextFlags.DT_VCENTER) {
            y = rect.top + (rect.height - textHeight) / 2;
        } else if (flags & TDC.DrawTextFlags.DT_BOTTOM) {
            y = rect.bottom - textHeight;
        }
        
        // Draw background if opaque
        if (this._bkMode === 1) {
            this._ctx.fillStyle = this._bkColor;
            this._ctx.fillRect(rect.left, rect.top, rect.width, rect.height);
        }
        
        // Draw text
        this._ctx.fillStyle = this._textColor;
        this._ctx.textBaseline = 'top';
        
        if (flags & TDC.DrawTextFlags.DT_WORDBREAK) {
            this._drawWrappedText(text, x, y, rect.width);
        } else {
            this._ctx.fillText(text, x, y);
        }
        
        this._ctx.restore();
        
        return textHeight;
    }

    /**
     * Draw wrapped text helper
     */
    _drawWrappedText(text, x, y, maxWidth) {
        const words = text.split(' ');
        let line = '';
        const lineHeight = this._font.height * 1.2;
        
        for (const word of words) {
            const testLine = line + word + ' ';
            const metrics = this._ctx.measureText(testLine);
            
            if (metrics.width > maxWidth && line !== '') {
                this._ctx.fillText(line, x, y);
                line = word + ' ';
                y += lineHeight;
            } else {
                line = testLine;
            }
        }
        
        this._ctx.fillText(line, x, y);
    }

    /**
     * Extended text output
     * Original: @TDC@ExtTextOutA$qiiuspx5TRectpxcipxi at 0x00452a7a
     */
    extTextOut(x, y, options, rect, text, dx = null) {
        if (!this._ctx) return false;
        
        this._ctx.save();
        this._font.applyTo(this._ctx);
        
        // Draw background if opaque
        if (this._bkMode === 1 && rect) {
            this._ctx.fillStyle = this._bkColor;
            this._ctx.fillRect(rect.left, rect.top, rect.width, rect.height);
        }
        
        // Draw text
        this._ctx.fillStyle = this._textColor;
        this._ctx.textBaseline = 'top';
        
        if (dx && dx.length > 0) {
            // Character spacing
            let currentX = x;
            for (let i = 0; i < text.length; i++) {
                this._ctx.fillText(text[i], currentX, y);
                currentX += dx[i] || this._ctx.measureText(text[i]).width;
            }
        } else {
            this._ctx.fillText(text, x, y);
        }
        
        this._ctx.restore();
        
        return true;
    }

    /**
     * Gray string (disabled text)
     * Original: @TDC@GrayStringA at 0x00452656
     */
    grayString(brush, callback, data, count, rect) {
        if (!this._ctx) return false;
        
        this._ctx.save();
        this._ctx.globalAlpha = 0.5;
        this._font.applyTo(this._ctx);
        this._ctx.fillStyle = '#808080';
        this._ctx.textBaseline = 'top';
        this._ctx.fillText(data, rect.left, rect.top);
        this._ctx.restore();
        
        return true;
    }

    /**
     * Move to position
     */
    moveTo(x, y) {
        if (this._ctx) {
            this._ctx.beginPath();
            this._ctx.moveTo(x, y);
        }
    }

    /**
     * Line to position
     */
    lineTo(x, y) {
        if (this._ctx) {
            this._ctx.lineTo(x, y);
            this._pen.applyTo(this._ctx);
            this._ctx.stroke();
        }
    }

    /**
     * Draw rectangle
     */
    rectangle(rect) {
        if (!this._ctx) return false;
        
        this._brush.applyTo(this._ctx);
        this._ctx.fillRect(rect.left, rect.top, rect.width, rect.height);
        
        this._pen.applyTo(this._ctx);
        this._ctx.strokeRect(rect.left, rect.top, rect.width, rect.height);
        
        return true;
    }

    /**
     * Draw ellipse
     */
    ellipse(rect) {
        if (!this._ctx) return false;
        
        const cx = (rect.left + rect.right) / 2;
        const cy = (rect.top + rect.bottom) / 2;
        const rx = rect.width / 2;
        const ry = rect.height / 2;
        
        this._ctx.beginPath();
        this._ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        
        this._brush.applyTo(this._ctx);
        this._ctx.fill();
        
        this._pen.applyTo(this._ctx);
        this._ctx.stroke();
        
        return true;
    }

    /**
     * Fill rectangle
     */
    fillRect(rect, brush = null) {
        if (!this._ctx) return false;
        
        (brush || this._brush).applyTo(this._ctx);
        this._ctx.fillRect(rect.left, rect.top, rect.width, rect.height);
        
        return true;
    }

    /**
     * Frame rectangle
     */
    frameRect(rect, brush = null) {
        if (!this._ctx) return false;
        
        (brush || this._brush).applyTo(this._ctx);
        this._ctx.strokeRect(rect.left, rect.top, rect.width, rect.height);
        
        return true;
    }

    /**
     * Draw focus rectangle
     */
    drawFocusRect(rect) {
        if (!this._ctx) return false;
        
        this._ctx.save();
        this._ctx.setLineDash([1, 1]);
        this._ctx.strokeStyle = '#000000';
        this._ctx.strokeRect(rect.left, rect.top, rect.width, rect.height);
        this._ctx.restore();
        
        return true;
    }

    /**
     * Bit block transfer
     */
    bitBlt(destX, destY, width, height, srcDC, srcX, srcY, rop = 'copy') {
        if (!this._ctx || !srcDC._canvas) return false;
        
        this._ctx.drawImage(
            srcDC._canvas,
            srcX, srcY, width, height,
            destX, destY, width, height
        );
        
        return true;
    }

    /**
     * Stretch bit block transfer
     */
    stretchBlt(destX, destY, destW, destH, srcDC, srcX, srcY, srcW, srcH, rop = 'copy') {
        if (!this._ctx || !srcDC._canvas) return false;
        
        this._ctx.drawImage(
            srcDC._canvas,
            srcX, srcY, srcW, srcH,
            destX, destY, destW, destH
        );
        
        return true;
    }

    /**
     * Destructor
     * Original: @TDC@$bdtr$qv at 0x00452ca4
     */
    destroy() {
        this._ctx = null;
        this._canvas = null;
        this._savedStates = [];
    }
}

// ============================================================================
// TClientDC - Client area device context
// Original: 0x004363b8
// Methods: @TClientDC@$bctr$qp6HWND__ at 0x0045318e
// ============================================================================
export class TClientDC extends TDC {
    constructor(window = null) {
        super(window ? window.getCanvas() : null);
        this._window = window;
    }

    /**
     * Get associated window
     */
    getWindow() {
        return this._window;
    }
}

// ============================================================================
// TPaintDC - Paint device context (for WM_PAINT handling)
// ============================================================================
export class TPaintDC extends TDC {
    constructor(window = null) {
        super(window ? window.getCanvas() : null);
        this._window = window;
        this._paintStruct = {
            rcPaint: new TRect(),
            fErase: true
        };
        
        // Set paint rect to client area
        if (window) {
            this._paintStruct.rcPaint = new TRect(0, 0, window.width, window.height);
        }
    }

    /**
     * Get paint structure
     */
    getPaintStruct() {
        return this._paintStruct;
    }

    /**
     * Get paint rect
     */
    getPaintRect() {
        return this._paintStruct.rcPaint;
    }
}

// ============================================================================
// TMemoryDC - Memory device context (off-screen drawing)
// ============================================================================
export class TMemoryDC extends TDC {
    constructor(refDC = null, width = 0, height = 0) {
        const canvas = document.createElement('canvas');
        canvas.width = width || (refDC ? refDC._canvas.width : 100);
        canvas.height = height || (refDC ? refDC._canvas.height : 100);
        super(canvas);
        this._refDC = refDC;
    }

    /**
     * Select bitmap into memory DC
     */
    selectBitmap(dib) {
        if (dib && dib._canvas) {
            this._canvas.width = dib._canvas.width;
            this._canvas.height = dib._canvas.height;
            this._ctx = this._canvas.getContext('2d');
            this._ctx.drawImage(dib._canvas, 0, 0);
        }
        return null;
    }

    /**
     * Get canvas
     */
    getCanvas() {
        return this._canvas;
    }
}

export default {
    TPoint,
    TSize,
    TRect,
    TGdiBase,
    TGdiObject,
    TPen,
    TBrush,
    TFont,
    TRegion,
    TDib,
    TDC,
    TClientDC,
    TPaintDC,
    TMemoryDC
};
