/**
 * VNDeviceContext - Device Context System
 * 
 * EXACT PORT from OWL TDC classes
 * 
 * Original classes from RTTI:
 * - TDC @ base class
 * - TMemoryDC @ 0x0041a650
 * - TClientDC @ 0x004363b8
 * - TWindowDC @ 0x0041d1d3
 * - TPaintDC @ 0x00453b28
 * 
 * Key functions:
 * - @TDC@SelectObject$qrx4TPen @ 0x004521c6
 * - @TDC@SaveDC$xqv @ 0x004522f8
 * - @TDC@RestoreDC$qi @ 0x0045240c
 * - @TDC@GetDeviceCaps$xqi @ 0x0045283a
 * - @TDC@TextOutA$qiipxci @ 0x004538ca
 * - @TDC@DrawTextA$qpxcirx5TRectus @ 0x00452b7e
 * - @TDC@ExtTextOutA$qiiuspx5TRectpxcipxi @ 0x00452a7a
 */

/**
 * Device Capabilities constants
 * Match Windows GetDeviceCaps indices
 */
export const VNDC_CAPS = {
    DRIVERVERSION: 0,
    TECHNOLOGY: 2,
    HORZSIZE: 4,
    VERTSIZE: 6,
    HORZRES: 8,
    VERTRES: 10,
    BITSPIXEL: 12,
    PLANES: 14,
    NUMBRUSHES: 16,
    NUMPENS: 18,
    NUMMARKERS: 20,
    NUMFONTS: 22,
    NUMCOLORS: 24,
    PDEVICESIZE: 26,
    CURVECAPS: 28,
    LINECAPS: 30,
    POLYGONALCAPS: 32,
    TEXTCAPS: 34,
    CLIPCAPS: 36,
    RASTERCAPS: 38,
    ASPECTX: 40,
    ASPECTY: 42,
    ASPECTXY: 44,
    LOGPIXELSX: 88,
    LOGPIXELSY: 90,
    SIZEPALETTE: 104,
    NUMRESERVED: 106,
    COLORRES: 108
};

/**
 * Text alignment constants
 */
export const VNTA = {
    LEFT: 0,
    RIGHT: 2,
    CENTER: 6,
    TOP: 0,
    BOTTOM: 8,
    BASELINE: 24,
    NOUPDATECP: 0,
    UPDATECP: 1
};

/**
 * DrawText format constants
 */
export const VNDT = {
    TOP: 0x00000000,
    LEFT: 0x00000000,
    CENTER: 0x00000001,
    RIGHT: 0x00000002,
    VCENTER: 0x00000004,
    BOTTOM: 0x00000008,
    WORDBREAK: 0x00000010,
    SINGLELINE: 0x00000020,
    EXPANDTABS: 0x00000040,
    TABSTOP: 0x00000080,
    NOCLIP: 0x00000100,
    EXTERNALLEADING: 0x00000200,
    CALCRECT: 0x00000400,
    NOPREFIX: 0x00000800,
    INTERNAL: 0x00001000,
    EDITCONTROL: 0x00002000,
    PATH_ELLIPSIS: 0x00004000,
    END_ELLIPSIS: 0x00008000,
    MODIFYSTRING: 0x00010000,
    RTLREADING: 0x00020000,
    WORD_ELLIPSIS: 0x00040000,
    HIDEPREFIX: 0x00100000,
    PREFIXONLY: 0x00200000
};

/**
 * Background mode constants
 */
export const VNBK = {
    TRANSPARENT: 1,
    OPAQUE: 2
};

/**
 * Raster operation constants
 */
export const VNROP = {
    SRCCOPY: 0x00CC0020,
    SRCPAINT: 0x00EE0086,
    SRCAND: 0x008800C6,
    SRCINVERT: 0x00660046,
    SRCERASE: 0x00440328,
    NOTSRCCOPY: 0x00330008,
    NOTSRCERASE: 0x001100A6,
    MERGECOPY: 0x00C000CA,
    MERGEPAINT: 0x00BB0226,
    PATCOPY: 0x00F00021,
    PATPAINT: 0x00FB0A09,
    PATINVERT: 0x005A0049,
    DSTINVERT: 0x00550009,
    BLACKNESS: 0x00000042,
    WHITENESS: 0x00FF0062
};

/**
 * VNDC - Base Device Context class
 * Port of TDC
 */
export class VNDC {
    /**
     * @param {CanvasRenderingContext2D} ctx 
     */
    constructor(ctx) {
        this.ctx = ctx;
        this.canvas = ctx?.canvas || null;
        
        // State stack for SaveDC/RestoreDC
        this.stateStack = [];
        this.stateIndex = 0;
        
        // Current state
        this.state = this._createDefaultState();
        
        // Attribute HDC (for GetAttributeHDC)
        this.attributeHDC = this;
    }

    /**
     * Create default state
     * @private
     */
    _createDefaultState() {
        return {
            // Pen
            penColor: '#000000',
            penWidth: 1,
            penStyle: 'solid',
            
            // Brush
            brushColor: '#FFFFFF',
            brushStyle: 'solid',
            
            // Font
            fontFamily: 'Arial',
            fontSize: 12,
            fontWeight: 'normal',
            fontStyle: 'normal',
            
            // Text
            textColor: '#000000',
            textAlign: VNTA.LEFT,
            bkMode: VNBK.TRANSPARENT,
            bkColor: '#FFFFFF',
            
            // Transform
            mapMode: 1, // MM_TEXT
            windowOrg: { x: 0, y: 0 },
            windowExt: { x: 1, y: 1 },
            viewportOrg: { x: 0, y: 0 },
            viewportExt: { x: 1, y: 1 },
            
            // Current position
            currentPos: { x: 0, y: 0 },
            
            // Clipping
            clipRect: null
        };
    }

    /**
     * Save device context state
     * Port of @TDC@SaveDC$xqv @ 0x004522f8
     * @returns {number} - State index
     */
    saveDC() {
        // Original ASM:
        // push [this+hdc]
        // call SaveDC
        // mov [this+stateIndex], eax
        // ret
        
        this.stateStack.push(JSON.parse(JSON.stringify(this.state)));
        this.stateIndex = this.stateStack.length;
        
        if (this.ctx) {
            this.ctx.save();
        }
        
        return this.stateIndex;
    }

    /**
     * Restore device context state
     * Port of @TDC@RestoreDC$qi @ 0x0045240c
     * @param {number} savedDC - State index (-1 for most recent)
     * @returns {boolean}
     */
    restoreDC(savedDC = -1) {
        // Original ASM:
        // push [esp+4]      ; savedDC
        // push [this+hdc]
        // call RestoreDC
        // ret
        
        if (savedDC === -1) {
            if (this.stateStack.length > 0) {
                this.state = this.stateStack.pop();
                this.stateIndex = this.stateStack.length;
                if (this.ctx) {
                    this.ctx.restore();
                }
                return true;
            }
        } else if (savedDC > 0 && savedDC <= this.stateStack.length) {
            while (this.stateStack.length >= savedDC) {
                this.state = this.stateStack.pop();
                if (this.ctx) {
                    this.ctx.restore();
                }
            }
            this.stateIndex = this.stateStack.length;
            return true;
        }
        return false;
    }

    /**
     * Get device capabilities
     * Port of @TDC@GetDeviceCaps$xqi @ 0x0045283a
     * @param {number} index 
     * @returns {number}
     */
    getDeviceCaps(index) {
        if (!this.canvas) return 0;
        
        switch (index) {
            case VNDC_CAPS.HORZRES:
                return this.canvas.width;
            case VNDC_CAPS.VERTRES:
                return this.canvas.height;
            case VNDC_CAPS.BITSPIXEL:
                return 32;
            case VNDC_CAPS.PLANES:
                return 1;
            case VNDC_CAPS.LOGPIXELSX:
            case VNDC_CAPS.LOGPIXELSY:
                return 96;
            case VNDC_CAPS.NUMCOLORS:
                return 16777216;
            default:
                return 0;
        }
    }

    /**
     * Get attribute HDC
     * Port of @TDC@GetAttributeHDC$xqv @ 0x00452966
     * @returns {VNDC}
     */
    getAttributeHDC() {
        return this.attributeHDC;
    }

    /**
     * Select pen object
     * Port of @TDC@SelectObject$qrx4TPen @ 0x004521c6
     * @param {Object} pen 
     * @returns {Object} - Previous pen
     */
    selectPen(pen) {
        const prevPen = {
            color: this.state.penColor,
            width: this.state.penWidth,
            style: this.state.penStyle
        };
        
        if (pen) {
            this.state.penColor = pen.color || this.state.penColor;
            this.state.penWidth = pen.width || this.state.penWidth;
            this.state.penStyle = pen.style || this.state.penStyle;
        }
        
        return prevPen;
    }

    /**
     * Select brush object
     * @param {Object} brush 
     * @returns {Object} - Previous brush
     */
    selectBrush(brush) {
        const prevBrush = {
            color: this.state.brushColor,
            style: this.state.brushStyle
        };
        
        if (brush) {
            this.state.brushColor = brush.color || this.state.brushColor;
            this.state.brushStyle = brush.style || this.state.brushStyle;
        }
        
        return prevBrush;
    }

    /**
     * Select font object
     * @param {Object} font 
     * @returns {Object} - Previous font
     */
    selectFont(font) {
        const prevFont = {
            family: this.state.fontFamily,
            size: this.state.fontSize,
            weight: this.state.fontWeight,
            style: this.state.fontStyle
        };
        
        if (font) {
            this.state.fontFamily = font.family || this.state.fontFamily;
            this.state.fontSize = font.size || this.state.fontSize;
            this.state.fontWeight = font.weight || this.state.fontWeight;
            this.state.fontStyle = font.style || this.state.fontStyle;
        }
        
        this._applyFont();
        return prevFont;
    }

    /**
     * Restore font to default
     * Port of @TDC@RestoreFont$qv @ 0x004523a0
     */
    restoreFont() {
        this.state.fontFamily = 'Arial';
        this.state.fontSize = 12;
        this.state.fontWeight = 'normal';
        this.state.fontStyle = 'normal';
        this._applyFont();
    }

    /**
     * Restore brush to default
     * Port of @TDC@RestoreBrush$qv @ 0x00452494
     */
    restoreBrush() {
        this.state.brushColor = '#FFFFFF';
        this.state.brushStyle = 'solid';
    }

    /**
     * Apply font to context
     * @private
     */
    _applyFont() {
        if (this.ctx) {
            const style = this.state.fontStyle === 'italic' ? 'italic ' : '';
            const weight = this.state.fontWeight === 'bold' ? 'bold ' : '';
            this.ctx.font = `${style}${weight}${this.state.fontSize}px ${this.state.fontFamily}`;
        }
    }

    /**
     * Set text color
     * @param {string|number} color 
     * @returns {string} - Previous color
     */
    setTextColor(color) {
        const prev = this.state.textColor;
        this.state.textColor = typeof color === 'number' ? 
            `#${color.toString(16).padStart(6, '0')}` : color;
        return prev;
    }

    /**
     * Get text color
     * @returns {string}
     */
    getTextColor() {
        return this.state.textColor;
    }

    /**
     * Set background color
     * @param {string|number} color 
     * @returns {string} - Previous color
     */
    setBkColor(color) {
        const prev = this.state.bkColor;
        this.state.bkColor = typeof color === 'number' ? 
            `#${color.toString(16).padStart(6, '0')}` : color;
        return prev;
    }

    /**
     * Set background mode
     * @param {number} mode - VNBK.TRANSPARENT or VNBK.OPAQUE
     * @returns {number} - Previous mode
     */
    setBkMode(mode) {
        const prev = this.state.bkMode;
        this.state.bkMode = mode;
        return prev;
    }

    /**
     * Set text alignment
     * @param {number} align 
     * @returns {number} - Previous alignment
     */
    setTextAlign(align) {
        const prev = this.state.textAlign;
        this.state.textAlign = align;
        return prev;
    }

    /**
     * Text output
     * Port of @TDC@TextOutA$qiipxci @ 0x004538ca
     * @param {number} x 
     * @param {number} y 
     * @param {string} text 
     * @param {number} count - Optional character count
     * @returns {boolean}
     */
    textOut(x, y, text, count = -1) {
        if (!this.ctx) return false;
        
        const str = count >= 0 ? text.substring(0, count) : text;
        
        // Apply text alignment
        let alignX = x;
        const metrics = this.ctx.measureText(str);
        
        if (this.state.textAlign & VNTA.CENTER) {
            alignX = x - metrics.width / 2;
        } else if (this.state.textAlign & VNTA.RIGHT) {
            alignX = x - metrics.width;
        }
        
        // Background mode
        if (this.state.bkMode === VNBK.OPAQUE) {
            this.ctx.fillStyle = this.state.bkColor;
            this.ctx.fillRect(alignX, y - this.state.fontSize, metrics.width, this.state.fontSize * 1.2);
        }
        
        // Draw text
        this.ctx.fillStyle = this.state.textColor;
        this._applyFont();
        this.ctx.fillText(str, alignX, y);
        
        return true;
    }

    /**
     * Extended text output
     * Port of @TDC@ExtTextOutA$qiiuspx5TRectpxcipxi @ 0x00452a7a
     * @param {number} x 
     * @param {number} y 
     * @param {number} options 
     * @param {Object} rect - Clipping/opaque rectangle
     * @param {string} text 
     * @param {number} count 
     * @param {number[]} dx - Character widths array
     * @returns {boolean}
     */
    extTextOut(x, y, options, rect, text, count = -1, dx = null) {
        if (!this.ctx) return false;
        
        const str = count >= 0 ? text.substring(0, count) : text;
        
        this.ctx.save();
        
        // Apply clipping rectangle
        if (rect && options & 0x0004) { // ETO_CLIPPED
            this.ctx.beginPath();
            this.ctx.rect(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);
            this.ctx.clip();
        }
        
        // Opaque background
        if (rect && options & 0x0002) { // ETO_OPAQUE
            this.ctx.fillStyle = this.state.bkColor;
            this.ctx.fillRect(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);
        }
        
        // Draw text
        this.ctx.fillStyle = this.state.textColor;
        this._applyFont();
        
        if (dx && dx.length > 0) {
            // Character-by-character with custom spacing
            let currentX = x;
            for (let i = 0; i < str.length; i++) {
                this.ctx.fillText(str[i], currentX, y);
                currentX += dx[i] || this.ctx.measureText(str[i]).width;
            }
        } else {
            this.ctx.fillText(str, x, y);
        }
        
        this.ctx.restore();
        return true;
    }

    /**
     * Draw text in rectangle
     * Port of @TDC@DrawTextA$qpxcirx5TRectus @ 0x00452b7e
     * @param {string} text 
     * @param {number} count 
     * @param {Object} rect 
     * @param {number} format 
     * @returns {number} - Height of text
     */
    drawText(text, count, rect, format) {
        if (!this.ctx) return 0;
        
        const str = count >= 0 ? text.substring(0, count) : text;
        
        this.ctx.save();
        this._applyFont();
        
        const lineHeight = this.state.fontSize * 1.2;
        const rectWidth = rect.right - rect.left;
        const rectHeight = rect.bottom - rect.top;
        
        // Word wrap if needed
        let lines = [];
        if (format & VNDT.WORDBREAK) {
            const words = str.split(' ');
            let currentLine = '';
            
            for (const word of words) {
                const testLine = currentLine ? `${currentLine} ${word}` : word;
                const metrics = this.ctx.measureText(testLine);
                
                if (metrics.width > rectWidth && currentLine) {
                    lines.push(currentLine);
                    currentLine = word;
                } else {
                    currentLine = testLine;
                }
            }
            if (currentLine) {
                lines.push(currentLine);
            }
        } else if (format & VNDT.SINGLELINE) {
            lines = [str.replace(/\n/g, ' ')];
        } else {
            lines = str.split('\n');
        }
        
        // Calculate vertical position
        let startY = rect.top + this.state.fontSize;
        const totalHeight = lines.length * lineHeight;
        
        if (format & VNDT.VCENTER) {
            startY = rect.top + (rectHeight - totalHeight) / 2 + this.state.fontSize;
        } else if (format & VNDT.BOTTOM) {
            startY = rect.bottom - totalHeight + this.state.fontSize;
        }
        
        // Draw lines
        this.ctx.fillStyle = this.state.textColor;
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const metrics = this.ctx.measureText(line);
            
            let x = rect.left;
            if (format & VNDT.CENTER) {
                x = rect.left + (rectWidth - metrics.width) / 2;
            } else if (format & VNDT.RIGHT) {
                x = rect.right - metrics.width;
            }
            
            const y = startY + i * lineHeight;
            
            if (!(format & VNDT.CALCRECT)) {
                this.ctx.fillText(line, x, y);
            }
        }
        
        this.ctx.restore();
        
        // Update rect if CALCRECT
        if (format & VNDT.CALCRECT) {
            rect.bottom = rect.top + totalHeight;
        }
        
        return totalHeight;
    }

    /**
     * Tabbed text output
     * Port of @TDC@TabbedTextOutA$qrx6TPointpxciipxiir5TSize @ 0x004539a0
     * @param {Object} point 
     * @param {string} text 
     * @param {number} count 
     * @param {number} numTabs 
     * @param {number[]} tabStops 
     * @returns {Object} - Size of output
     */
    tabbedTextOut(point, text, count, numTabs, tabStops) {
        if (!this.ctx) return { cx: 0, cy: 0 };
        
        const str = count >= 0 ? text.substring(0, count) : text;
        const parts = str.split('\t');
        
        let x = point.x;
        let maxWidth = 0;
        
        this.ctx.fillStyle = this.state.textColor;
        this._applyFont();
        
        for (let i = 0; i < parts.length; i++) {
            this.ctx.fillText(parts[i], x, point.y);
            const metrics = this.ctx.measureText(parts[i]);
            x += metrics.width;
            
            // Apply tab stop
            if (i < parts.length - 1 && tabStops && tabStops[i]) {
                x = point.x + tabStops[i];
            } else if (i < parts.length - 1) {
                // Default tab width
                x = Math.ceil(x / 64) * 64;
            }
            
            maxWidth = Math.max(maxWidth, x - point.x);
        }
        
        return {
            cx: maxWidth,
            cy: this.state.fontSize * 1.2
        };
    }

    /**
     * Move to position
     * @param {number} x 
     * @param {number} y 
     * @returns {Object} - Previous position
     */
    moveTo(x, y) {
        const prev = { ...this.state.currentPos };
        this.state.currentPos.x = x;
        this.state.currentPos.y = y;
        if (this.ctx) {
            this.ctx.moveTo(x, y);
        }
        return prev;
    }

    /**
     * Line to position
     * @param {number} x 
     * @param {number} y 
     * @returns {boolean}
     */
    lineTo(x, y) {
        if (!this.ctx) return false;
        
        this.ctx.beginPath();
        this.ctx.moveTo(this.state.currentPos.x, this.state.currentPos.y);
        this.ctx.lineTo(x, y);
        this.ctx.strokeStyle = this.state.penColor;
        this.ctx.lineWidth = this.state.penWidth;
        this.ctx.stroke();
        
        this.state.currentPos.x = x;
        this.state.currentPos.y = y;
        return true;
    }

    /**
     * Draw rectangle
     * @param {number} left 
     * @param {number} top 
     * @param {number} right 
     * @param {number} bottom 
     * @returns {boolean}
     */
    rectangle(left, top, right, bottom) {
        if (!this.ctx) return false;
        
        // Fill with brush
        this.ctx.fillStyle = this.state.brushColor;
        this.ctx.fillRect(left, top, right - left, bottom - top);
        
        // Stroke with pen
        this.ctx.strokeStyle = this.state.penColor;
        this.ctx.lineWidth = this.state.penWidth;
        this.ctx.strokeRect(left, top, right - left, bottom - top);
        
        return true;
    }

    /**
     * Fill rectangle
     * @param {Object} rect 
     * @param {Object} brush 
     * @returns {boolean}
     */
    fillRect(rect, brush = null) {
        if (!this.ctx) return false;
        
        this.ctx.fillStyle = brush?.color || this.state.brushColor;
        this.ctx.fillRect(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);
        return true;
    }

    /**
     * Draw ellipse
     * @param {number} left 
     * @param {number} top 
     * @param {number} right 
     * @param {number} bottom 
     * @returns {boolean}
     */
    ellipse(left, top, right, bottom) {
        if (!this.ctx) return false;
        
        const cx = (left + right) / 2;
        const cy = (top + bottom) / 2;
        const rx = (right - left) / 2;
        const ry = (bottom - top) / 2;
        
        this.ctx.beginPath();
        this.ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        
        this.ctx.fillStyle = this.state.brushColor;
        this.ctx.fill();
        
        this.ctx.strokeStyle = this.state.penColor;
        this.ctx.lineWidth = this.state.penWidth;
        this.ctx.stroke();
        
        return true;
    }

    /**
     * Draw polygon
     * @param {Array<{x: number, y: number}>} points 
     * @param {number} count 
     * @returns {boolean}
     */
    polygon(points, count = -1) {
        if (!this.ctx || points.length < 3) return false;
        
        const n = count >= 0 ? Math.min(count, points.length) : points.length;
        
        this.ctx.beginPath();
        this.ctx.moveTo(points[0].x, points[0].y);
        
        for (let i = 1; i < n; i++) {
            this.ctx.lineTo(points[i].x, points[i].y);
        }
        
        this.ctx.closePath();
        
        this.ctx.fillStyle = this.state.brushColor;
        this.ctx.fill();
        
        this.ctx.strokeStyle = this.state.penColor;
        this.ctx.lineWidth = this.state.penWidth;
        this.ctx.stroke();
        
        return true;
    }

    /**
     * BitBlt operation
     * @param {number} destX 
     * @param {number} destY 
     * @param {number} width 
     * @param {number} height 
     * @param {VNDC} srcDC 
     * @param {number} srcX 
     * @param {number} srcY 
     * @param {number} rop 
     * @returns {boolean}
     */
    bitBlt(destX, destY, width, height, srcDC, srcX, srcY, rop = VNROP.SRCCOPY) {
        if (!this.ctx || !srcDC?.ctx) return false;
        
        // Simple copy for SRCCOPY
        if (rop === VNROP.SRCCOPY) {
            this.ctx.drawImage(srcDC.canvas, srcX, srcY, width, height, destX, destY, width, height);
            return true;
        }
        
        // For other ROPs, we need to manipulate pixels
        const srcImageData = srcDC.ctx.getImageData(srcX, srcY, width, height);
        const destImageData = this.ctx.getImageData(destX, destY, width, height);
        
        this._applyROP(destImageData.data, srcImageData.data, rop);
        
        this.ctx.putImageData(destImageData, destX, destY);
        return true;
    }

    /**
     * Apply raster operation
     * @private
     */
    _applyROP(dest, src, rop) {
        for (let i = 0; i < dest.length; i += 4) {
            switch (rop) {
                case VNROP.SRCPAINT:
                    dest[i] |= src[i];
                    dest[i + 1] |= src[i + 1];
                    dest[i + 2] |= src[i + 2];
                    break;
                case VNROP.SRCAND:
                    dest[i] &= src[i];
                    dest[i + 1] &= src[i + 1];
                    dest[i + 2] &= src[i + 2];
                    break;
                case VNROP.SRCINVERT:
                    dest[i] ^= src[i];
                    dest[i + 1] ^= src[i + 1];
                    dest[i + 2] ^= src[i + 2];
                    break;
                case VNROP.DSTINVERT:
                    dest[i] = 255 - dest[i];
                    dest[i + 1] = 255 - dest[i + 1];
                    dest[i + 2] = 255 - dest[i + 2];
                    break;
                case VNROP.BLACKNESS:
                    dest[i] = dest[i + 1] = dest[i + 2] = 0;
                    break;
                case VNROP.WHITENESS:
                    dest[i] = dest[i + 1] = dest[i + 2] = 255;
                    break;
                default:
                    dest[i] = src[i];
                    dest[i + 1] = src[i + 1];
                    dest[i + 2] = src[i + 2];
                    dest[i + 3] = src[i + 3];
            }
        }
    }

    /**
     * StretchBlt operation
     * @param {number} destX 
     * @param {number} destY 
     * @param {number} destWidth 
     * @param {number} destHeight 
     * @param {VNDC} srcDC 
     * @param {number} srcX 
     * @param {number} srcY 
     * @param {number} srcWidth 
     * @param {number} srcHeight 
     * @param {number} rop 
     * @returns {boolean}
     */
    stretchBlt(destX, destY, destWidth, destHeight, srcDC, srcX, srcY, srcWidth, srcHeight, rop = VNROP.SRCCOPY) {
        if (!this.ctx || !srcDC?.ctx) return false;
        
        this.ctx.drawImage(
            srcDC.canvas,
            srcX, srcY, srcWidth, srcHeight,
            destX, destY, destWidth, destHeight
        );
        
        return true;
    }

    /**
     * Set viewport origin
     * @param {Object} point 
     * @returns {Object} - Previous origin
     */
    setViewportOrg(point) {
        const prev = { ...this.state.viewportOrg };
        this.state.viewportOrg = { ...point };
        if (this.ctx) {
            this.ctx.translate(point.x - prev.x, point.y - prev.y);
        }
        return prev;
    }

    /**
     * Offset viewport origin
     * Port of @TDC@OffsetViewportOrg$qrx6TPointp6TPoint @ 0x004525e2
     * @param {Object} delta 
     * @returns {Object} - New origin
     */
    offsetViewportOrg(delta) {
        this.state.viewportOrg.x += delta.x;
        this.state.viewportOrg.y += delta.y;
        if (this.ctx) {
            this.ctx.translate(delta.x, delta.y);
        }
        return { ...this.state.viewportOrg };
    }

    /**
     * Scale window extent
     * Port of @TDC@ScaleWindowExt$qiiiip5TSize @ 0x00452214
     * @param {number} xNum 
     * @param {number} xDenom 
     * @param {number} yNum 
     * @param {number} yDenom 
     * @returns {Object} - New extent
     */
    scaleWindowExt(xNum, xDenom, yNum, yDenom) {
        this.state.windowExt.x = (this.state.windowExt.x * xNum) / xDenom;
        this.state.windowExt.y = (this.state.windowExt.y * yNum) / yDenom;
        return { ...this.state.windowExt };
    }

    /**
     * Scale viewport extent
     * Port of @TDC@ScaleViewportExt$qiiiip5TSize @ 0x00452294
     * @param {number} xNum 
     * @param {number} xDenom 
     * @param {number} yNum 
     * @param {number} yDenom 
     * @returns {Object} - New extent
     */
    scaleViewportExt(xNum, xDenom, yNum, yDenom) {
        this.state.viewportExt.x = (this.state.viewportExt.x * xNum) / xDenom;
        this.state.viewportExt.y = (this.state.viewportExt.y * yNum) / yDenom;
        if (this.ctx) {
            this.ctx.scale(xNum / xDenom, yNum / yDenom);
        }
        return { ...this.state.viewportExt };
    }
}

/**
 * VNMemoryDC - Memory device context
 * Port of TMemoryDC @ 0x0041a650
 */
export class VNMemoryDC extends VNDC {
    /**
     * @param {number} width 
     * @param {number} height 
     */
    constructor(width = 640, height = 480) {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        super(ctx);
        
        this.width = width;
        this.height = height;
    }

    /**
     * Create compatible DC
     * @param {VNDC} dc 
     * @returns {VNMemoryDC}
     */
    static createCompatible(dc) {
        const width = dc.canvas?.width || 640;
        const height = dc.canvas?.height || 480;
        return new VNMemoryDC(width, height);
    }

    /**
     * Resize the memory DC
     * @param {number} width 
     * @param {number} height 
     */
    resize(width, height) {
        const imageData = this.ctx.getImageData(0, 0, this.width, this.height);
        this.canvas.width = width;
        this.canvas.height = height;
        this.width = width;
        this.height = height;
        this.ctx.putImageData(imageData, 0, 0);
    }

    /**
     * Clear the memory DC
     * @param {string} color 
     */
    clear(color = '#000000') {
        this.ctx.fillStyle = color;
        this.ctx.fillRect(0, 0, this.width, this.height);
    }
}

/**
 * VNClientDC - Client area device context
 * Port of TClientDC @ 0x004363b8
 */
export class VNClientDC extends VNDC {
    /**
     * @param {HTMLCanvasElement} canvas 
     */
    constructor(canvas) {
        const ctx = canvas.getContext('2d');
        super(ctx);
    }
}

/**
 * VNWindowDC - Window device context
 * Port of TWindowDC @ 0x0041d1d3
 */
export class VNWindowDC extends VNDC {
    /**
     * @param {HTMLCanvasElement} canvas 
     */
    constructor(canvas) {
        const ctx = canvas.getContext('2d');
        super(ctx);
    }
}

/**
 * VNPaintDC - Paint device context (for WM_PAINT)
 * Port of TPaintDC @ 0x00453b28
 */
export class VNPaintDC extends VNDC {
    /**
     * @param {HTMLCanvasElement} canvas 
     * @param {Object} paintStruct 
     */
    constructor(canvas, paintStruct = null) {
        const ctx = canvas.getContext('2d');
        super(ctx);
        
        this.paintStruct = paintStruct || {
            fErase: false,
            rcPaint: {
                left: 0,
                top: 0,
                right: canvas.width,
                bottom: canvas.height
            }
        };
    }

    /**
     * Get paint rectangle
     * @returns {Object}
     */
    getPaintRect() {
        return { ...this.paintStruct.rcPaint };
    }

    /**
     * Check if background needs erasing
     * @returns {boolean}
     */
    needsErase() {
        return this.paintStruct.fErase;
    }
}

export default {
    VNDC_CAPS,
    VNTA,
    VNDT,
    VNBK,
    VNROP,
    VNDC,
    VNMemoryDC,
    VNClientDC,
    VNWindowDC,
    VNPaintDC
};
