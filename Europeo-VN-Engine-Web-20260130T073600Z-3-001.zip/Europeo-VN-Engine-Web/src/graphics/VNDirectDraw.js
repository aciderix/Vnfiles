/**
 * VNDirectDraw - DirectDraw emulation layer
 * 
 * Port of DirectDraw functionality from europeo.exe
 * The original engine uses DirectDraw for:
 * - Surface creation and management
 * - Blitting operations
 * - Palette management
 * - Display mode switching
 * 
 * Web implementation uses HTML5 Canvas 2D API
 * 
 * Original imports (from disassembly):
 * - DirectDrawCreate
 * - IDirectDraw::CreateSurface
 * - IDirectDrawSurface::Blt, BltFast
 * - IDirectDrawSurface::GetDC, ReleaseDC
 * - CreateHalftonePalette (GDI fallback)
 */

import { VNStreamable } from '../core/VNObject.js';
import { EventEmitter } from '../utils/EventEmitter.js';

/**
 * Surface capabilities flags (simulated)
 */
export const DDSCAPS = {
    PRIMARYSURFACE: 0x00000200,
    BACKBUFFER: 0x00000004,
    OFFSCREENPLAIN: 0x00000040,
    SYSTEMMEMORY: 0x00000800,
    VIDEOMEMORY: 0x00004000
};

/**
 * Blt flags (simulated)
 */
export const DDBLT = {
    COLORFILL: 0x00000400,
    KEYSRC: 0x00008000,
    KEYSRCOVERRIDE: 0x00010000,
    WAIT: 0x01000000
};

/**
 * VNDirectDrawSurface - DirectDraw surface emulation
 */
export class VNDirectDrawSurface extends VNStreamable {
    constructor(options = {}) {
        super();
        
        this.width = options.width || 640;
        this.height = options.height || 480;
        this.caps = options.caps || DDSCAPS.OFFSCREENPLAIN;
        
        // Create canvas for surface
        this._canvas = document.createElement('canvas');
        this._canvas.width = this.width;
        this._canvas.height = this.height;
        this._ctx = this._canvas.getContext('2d', { 
            alpha: true,
            willReadFrequently: true 
        });
        
        // Color key for transparency
        this._colorKey = options.colorKey || null;
        this._colorKeyEnabled = false;
        
        // Locked state
        this._locked = false;
        this._imageData = null;
        
        // Attached clipper
        this._clipper = null;
        
        // Palette (for 8-bit surfaces)
        this._palette = null;
    }

    /**
     * Get canvas element
     */
    get canvas() {
        return this._canvas;
    }

    /**
     * Get 2D context
     */
    get context() {
        return this._ctx;
    }

    /**
     * Get width
     */
    getWidth() {
        return this.width;
    }

    /**
     * Get height
     */
    getHeight() {
        return this.height;
    }

    /**
     * Get DC (device context) - returns canvas context
     */
    getDC() {
        return this._ctx;
    }

    /**
     * Release DC
     */
    releaseDC() {
        // No-op in web implementation
        return true;
    }

    /**
     * Lock surface for direct pixel access
     */
    lock(rect = null) {
        if (this._locked) return null;
        
        const x = rect?.x || 0;
        const y = rect?.y || 0;
        const w = rect?.width || this.width;
        const h = rect?.height || this.height;
        
        this._imageData = this._ctx.getImageData(x, y, w, h);
        this._locked = true;
        this._lockRect = { x, y, width: w, height: h };
        
        return {
            pitch: w * 4,
            data: this._imageData.data,
            width: w,
            height: h
        };
    }

    /**
     * Unlock surface
     */
    unlock() {
        if (!this._locked) return;
        
        this._ctx.putImageData(
            this._imageData,
            this._lockRect.x,
            this._lockRect.y
        );
        
        this._imageData = null;
        this._locked = false;
        this._lockRect = null;
    }

    /**
     * Blt - Block transfer (full featured)
     */
    blt(destRect, srcSurface, srcRect, flags = 0, params = {}) {
        // Color fill
        if (flags & DDBLT.COLORFILL) {
            const color = params.fillColor || '#000000';
            this._ctx.fillStyle = color;
            this._ctx.fillRect(
                destRect?.x || 0,
                destRect?.y || 0,
                destRect?.width || this.width,
                destRect?.height || this.height
            );
            return true;
        }
        
        if (!srcSurface) return false;
        
        const sx = srcRect?.x || 0;
        const sy = srcRect?.y || 0;
        const sw = srcRect?.width || srcSurface.width;
        const sh = srcRect?.height || srcSurface.height;
        
        const dx = destRect?.x || 0;
        const dy = destRect?.y || 0;
        const dw = destRect?.width || sw;
        const dh = destRect?.height || sh;
        
        // Apply color key transparency
        if ((flags & DDBLT.KEYSRC) && srcSurface._colorKeyEnabled) {
            this._bltWithColorKey(srcSurface, sx, sy, sw, sh, dx, dy, dw, dh);
        } else {
            this._ctx.drawImage(
                srcSurface._canvas,
                sx, sy, sw, sh,
                dx, dy, dw, dh
            );
        }
        
        return true;
    }

    /**
     * BltFast - Fast block transfer (no stretch)
     */
    bltFast(x, y, srcSurface, srcRect, flags = 0) {
        if (!srcSurface) return false;
        
        const sx = srcRect?.x || 0;
        const sy = srcRect?.y || 0;
        const sw = srcRect?.width || srcSurface.width;
        const sh = srcRect?.height || srcSurface.height;
        
        // Apply color key transparency
        if (srcSurface._colorKeyEnabled) {
            this._bltWithColorKey(srcSurface, sx, sy, sw, sh, x, y, sw, sh);
        } else {
            this._ctx.drawImage(
                srcSurface._canvas,
                sx, sy, sw, sh,
                x, y, sw, sh
            );
        }
        
        return true;
    }

    /**
     * Blt with color key transparency
     */
    _bltWithColorKey(srcSurface, sx, sy, sw, sh, dx, dy, dw, dh) {
        const srcData = srcSurface._ctx.getImageData(sx, sy, sw, sh);
        const pixels = srcData.data;
        const colorKey = srcSurface._colorKey;
        
        // Make color key pixels transparent
        if (colorKey) {
            const kr = colorKey.r;
            const kg = colorKey.g;
            const kb = colorKey.b;
            
            for (let i = 0; i < pixels.length; i += 4) {
                if (pixels[i] === kr && 
                    pixels[i + 1] === kg && 
                    pixels[i + 2] === kb) {
                    pixels[i + 3] = 0; // Make transparent
                }
            }
        }
        
        // Create temp canvas for scaled blit
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = sw;
        tempCanvas.height = sh;
        const tempCtx = tempCanvas.getContext('2d');
        tempCtx.putImageData(srcData, 0, 0);
        
        // Draw with scaling
        this._ctx.drawImage(tempCanvas, 0, 0, sw, sh, dx, dy, dw, dh);
    }

    /**
     * Set color key
     */
    setColorKey(flags, colorKey) {
        if (typeof colorKey === 'number') {
            // Convert from RGB integer
            this._colorKey = {
                r: (colorKey >> 16) & 0xFF,
                g: (colorKey >> 8) & 0xFF,
                b: colorKey & 0xFF
            };
        } else if (typeof colorKey === 'string') {
            // Parse CSS color
            const temp = document.createElement('canvas');
            temp.width = temp.height = 1;
            const ctx = temp.getContext('2d');
            ctx.fillStyle = colorKey;
            ctx.fillRect(0, 0, 1, 1);
            const data = ctx.getImageData(0, 0, 1, 1).data;
            this._colorKey = { r: data[0], g: data[1], b: data[2] };
        } else {
            this._colorKey = colorKey;
        }
        
        this._colorKeyEnabled = true;
        return true;
    }

    /**
     * Clear color key
     */
    clearColorKey() {
        this._colorKey = null;
        this._colorKeyEnabled = false;
    }

    /**
     * Set clipper
     */
    setClipper(clipper) {
        this._clipper = clipper;
        if (clipper && clipper._rect) {
            this._ctx.save();
            this._ctx.beginPath();
            this._ctx.rect(
                clipper._rect.x,
                clipper._rect.y,
                clipper._rect.width,
                clipper._rect.height
            );
            this._ctx.clip();
        }
    }

    /**
     * Set palette
     */
    setPalette(palette) {
        this._palette = palette;
    }

    /**
     * Fill with color
     */
    fill(color, rect = null) {
        this._ctx.fillStyle = color;
        if (rect) {
            this._ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
        } else {
            this._ctx.fillRect(0, 0, this.width, this.height);
        }
    }

    /**
     * Clear surface
     */
    clear() {
        this._ctx.clearRect(0, 0, this.width, this.height);
    }

    /**
     * Load from image
     */
    loadFromImage(image) {
        this._ctx.drawImage(image, 0, 0);
    }

    /**
     * Load from URL
     */
    async loadFromURL(url) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => {
                this.width = img.naturalWidth;
                this.height = img.naturalHeight;
                this._canvas.width = this.width;
                this._canvas.height = this.height;
                this._ctx.drawImage(img, 0, 0);
                resolve(this);
            };
            img.onerror = reject;
            img.src = url;
        });
    }

    /**
     * Get as data URL
     */
    toDataURL(type = 'image/png') {
        return this._canvas.toDataURL(type);
    }

    /**
     * Get as blob
     */
    toBlob(type = 'image/png') {
        return new Promise(resolve => {
            this._canvas.toBlob(resolve, type);
        });
    }

    /**
     * Release surface
     */
    release() {
        this._canvas = null;
        this._ctx = null;
        this._imageData = null;
    }
}

/**
 * VNDirectDrawClipper - Clipper for surfaces
 */
export class VNDirectDrawClipper {
    constructor() {
        this._hwnd = null;
        this._rect = null;
    }

    /**
     * Set clip list
     */
    setClipList(rect) {
        this._rect = rect;
    }

    /**
     * Set associated window
     */
    setHWnd(hwnd) {
        this._hwnd = hwnd;
    }
}

/**
 * VNDirectDrawPalette - Palette for 8-bit surfaces
 */
export class VNDirectDrawPalette {
    constructor(entries = []) {
        this._entries = new Uint8Array(256 * 4);
        
        // Initialize with entries
        if (entries.length > 0) {
            this.setEntries(entries);
        } else {
            // Default grayscale palette
            for (let i = 0; i < 256; i++) {
                this._entries[i * 4] = i;
                this._entries[i * 4 + 1] = i;
                this._entries[i * 4 + 2] = i;
                this._entries[i * 4 + 3] = 255;
            }
        }
    }

    /**
     * Set palette entries
     */
    setEntries(entries, start = 0) {
        for (let i = 0; i < entries.length && start + i < 256; i++) {
            const entry = entries[i];
            const idx = (start + i) * 4;
            
            if (typeof entry === 'number') {
                // RGB integer
                this._entries[idx] = (entry >> 16) & 0xFF;
                this._entries[idx + 1] = (entry >> 8) & 0xFF;
                this._entries[idx + 2] = entry & 0xFF;
                this._entries[idx + 3] = 255;
            } else if (entry.r !== undefined) {
                // Object with r, g, b
                this._entries[idx] = entry.r;
                this._entries[idx + 1] = entry.g;
                this._entries[idx + 2] = entry.b;
                this._entries[idx + 3] = entry.a ?? 255;
            }
        }
    }

    /**
     * Get palette entries
     */
    getEntries(start = 0, count = 256) {
        const entries = [];
        for (let i = start; i < start + count && i < 256; i++) {
            const idx = i * 4;
            entries.push({
                r: this._entries[idx],
                g: this._entries[idx + 1],
                b: this._entries[idx + 2],
                a: this._entries[idx + 3]
            });
        }
        return entries;
    }

    /**
     * Get color at index
     */
    getColor(index) {
        const idx = index * 4;
        return {
            r: this._entries[idx],
            g: this._entries[idx + 1],
            b: this._entries[idx + 2],
            a: this._entries[idx + 3]
        };
    }

    /**
     * Convert to CSS color
     */
    toCSSColor(index) {
        const color = this.getColor(index);
        return `rgba(${color.r}, ${color.g}, ${color.b}, ${color.a / 255})`;
    }
}

/**
 * VNDirectDraw - Main DirectDraw emulation
 */
export class VNDirectDraw {
    constructor(options = {}) {
        this._container = options.container || document.body;
        this._width = options.width || 800;
        this._height = options.height || 600;
        
        // Create primary surface
        this._primarySurface = null;
        this._backBuffer = null;
        
        // Display mode
        this._fullscreen = false;
        this._displayMode = {
            width: this._width,
            height: this._height,
            bpp: 32
        };
        
        // Cooperative level
        this._cooperative = false;
        
        // Events
        this._events = new EventEmitter();
    }

    /**
     * Initialize DirectDraw
     */
    initialize() {
        // Create primary surface canvas
        this._primarySurface = new VNDirectDrawSurface({
            width: this._width,
            height: this._height,
            caps: DDSCAPS.PRIMARYSURFACE
        });
        
        // Style the canvas
        this._primarySurface._canvas.style.cssText = `
            display: block;
            image-rendering: pixelated;
            image-rendering: crisp-edges;
        `;
        
        // Add to container
        this._container.appendChild(this._primarySurface._canvas);
        
        // Create back buffer
        this._backBuffer = new VNDirectDrawSurface({
            width: this._width,
            height: this._height,
            caps: DDSCAPS.BACKBUFFER
        });
        
        return true;
    }

    /**
     * Set cooperative level
     */
    setCooperativeLevel(hwnd, flags) {
        this._cooperative = true;
        return true;
    }

    /**
     * Set display mode
     */
    setDisplayMode(width, height, bpp) {
        this._displayMode = { width, height, bpp };
        
        // Resize surfaces
        if (this._primarySurface) {
            this._primarySurface._canvas.width = width;
            this._primarySurface._canvas.height = height;
            this._primarySurface.width = width;
            this._primarySurface.height = height;
        }
        
        if (this._backBuffer) {
            this._backBuffer._canvas.width = width;
            this._backBuffer._canvas.height = height;
            this._backBuffer.width = width;
            this._backBuffer.height = height;
        }
        
        return true;
    }

    /**
     * Create surface
     */
    createSurface(desc) {
        return new VNDirectDrawSurface({
            width: desc.width || this._width,
            height: desc.height || this._height,
            caps: desc.caps || DDSCAPS.OFFSCREENPLAIN
        });
    }

    /**
     * Create clipper
     */
    createClipper() {
        return new VNDirectDrawClipper();
    }

    /**
     * Create palette
     */
    createPalette(entries) {
        return new VNDirectDrawPalette(entries);
    }

    /**
     * Get primary surface
     */
    getPrimarySurface() {
        return this._primarySurface;
    }

    /**
     * Get back buffer
     */
    getBackBuffer() {
        return this._backBuffer;
    }

    /**
     * Flip (swap buffers)
     */
    flip() {
        if (!this._backBuffer || !this._primarySurface) return false;
        
        // Copy back buffer to primary
        this._primarySurface._ctx.drawImage(this._backBuffer._canvas, 0, 0);
        
        return true;
    }

    /**
     * Wait for vertical blank
     */
    waitForVerticalBlank() {
        // Use requestAnimationFrame for vsync
        return new Promise(resolve => {
            requestAnimationFrame(resolve);
        });
    }

    /**
     * Get display mode
     */
    getDisplayMode() {
        return { ...this._displayMode };
    }

    /**
     * Restore display mode
     */
    restoreDisplayMode() {
        // No-op in web
        return true;
    }

    /**
     * Check if DirectDraw is enabled
     * Port of DirectDrawEnabled export from vndllapi.dll
     */
    static isEnabled() {
        // Always return true in web (canvas is always available)
        return true;
    }

    /**
     * Release DirectDraw
     */
    release() {
        if (this._primarySurface) {
            if (this._primarySurface._canvas.parentNode) {
                this._primarySurface._canvas.parentNode.removeChild(
                    this._primarySurface._canvas
                );
            }
            this._primarySurface.release();
            this._primarySurface = null;
        }
        
        if (this._backBuffer) {
            this._backBuffer.release();
            this._backBuffer = null;
        }
    }

    /**
     * Event subscription
     */
    on(event, handler) {
        this._events.on(event, handler);
        return this;
    }

    off(event, handler) {
        this._events.off(event, handler);
        return this;
    }
}

export default {
    DDSCAPS,
    DDBLT,
    VNDirectDrawSurface,
    VNDirectDrawClipper,
    VNDirectDrawPalette,
    VNDirectDraw
};
