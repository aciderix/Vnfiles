/**
 * VNAnimation - Animation and Image Sequence System
 * 
 * EXACT PORT from europeo.exe animation classes
 * 
 * Original classes from RTTI:
 * - TVNImgSeqParms @ 0x0040f0b6
 * - TVNFrame @ 0x00436bbf
 * - TFrameWindow @ 0x00436dc5
 * 
 * Strings:
 * - "sequencer" @ 0x00443d46
 */

/**
 * VNFrame - Single animation frame
 * Port of TVNFrame
 */
export class VNFrame {
    /**
     * @param {Object} options 
     */
    constructor(options = {}) {
        // Frame image data
        this.image = options.image || null;
        this.imageUrl = options.imageUrl || '';
        
        // Frame rectangle
        this.x = options.x || 0;
        this.y = options.y || 0;
        this.width = options.width || 0;
        this.height = options.height || 0;
        
        // Timing
        this.duration = options.duration || 100; // ms
        this.delay = options.delay || 0; // ms before this frame
        
        // Source rectangle (for sprite sheets)
        this.srcX = options.srcX || 0;
        this.srcY = options.srcY || 0;
        this.srcWidth = options.srcWidth || this.width;
        this.srcHeight = options.srcHeight || this.height;
        
        // Frame properties
        this.visible = options.visible !== false;
        this.opacity = options.opacity !== undefined ? options.opacity : 1.0;
        
        // Hotspot (for cursor frames)
        this.hotspotX = options.hotspotX || 0;
        this.hotspotY = options.hotspotY || 0;
        
        // User data
        this.userData = options.userData || null;
    }

    /**
     * Clone frame
     * @returns {VNFrame}
     */
    clone() {
        return new VNFrame({
            image: this.image,
            imageUrl: this.imageUrl,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            duration: this.duration,
            delay: this.delay,
            srcX: this.srcX,
            srcY: this.srcY,
            srcWidth: this.srcWidth,
            srcHeight: this.srcHeight,
            visible: this.visible,
            opacity: this.opacity,
            hotspotX: this.hotspotX,
            hotspotY: this.hotspotY,
            userData: this.userData
        });
    }

    /**
     * Get rectangle
     * @returns {{x: number, y: number, width: number, height: number}}
     */
    getRect() {
        return {
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height
        };
    }

    /**
     * Get source rectangle
     * @returns {{x: number, y: number, width: number, height: number}}
     */
    getSrcRect() {
        return {
            x: this.srcX,
            y: this.srcY,
            width: this.srcWidth,
            height: this.srcHeight
        };
    }
}

/**
 * VNImgSeqParms - Image sequence parameters
 * Port of TVNImgSeqParms
 */
export class VNImgSeqParms {
    constructor() {
        // File pattern
        this.filenamePattern = '';  // e.g., "frame_%03d.bmp"
        this.basePath = '';
        
        // Frame range
        this.startFrame = 0;
        this.endFrame = 0;
        this.frameStep = 1;
        
        // Timing
        this.frameDuration = 100;   // ms per frame
        this.totalDuration = 0;     // 0 = calculate from frames
        
        // Position
        this.x = 0;
        this.y = 0;
        
        // Playback
        this.loop = false;
        this.pingPong = false;      // Play forward then backward
        this.autoStart = false;
        this.reverse = false;
        
        // Display
        this.visible = true;
        this.transparent = false;
        this.transparentColor = 0xFF00FF;
    }

    /**
     * Get total frame count
     * @returns {number}
     */
    getFrameCount() {
        return Math.floor((this.endFrame - this.startFrame) / this.frameStep) + 1;
    }

    /**
     * Get filename for frame index
     * @param {number} frameIndex 
     * @returns {string}
     */
    getFilename(frameIndex) {
        const frameNum = this.startFrame + (frameIndex * this.frameStep);
        
        // Handle printf-style pattern
        if (this.filenamePattern.includes('%')) {
            return this.filenamePattern.replace(/%(\d*)d/, (_, width) => {
                const numStr = String(frameNum);
                const padWidth = parseInt(width) || 0;
                return numStr.padStart(padWidth, '0');
            });
        }
        
        return `${this.basePath}${frameNum}`;
    }

    /**
     * Clone parameters
     * @returns {VNImgSeqParms}
     */
    clone() {
        const p = new VNImgSeqParms();
        Object.assign(p, this);
        return p;
    }
}

/**
 * VNAnimation - Animation controller
 * Manages a sequence of frames
 */
export class VNAnimation {
    /**
     * @param {string} name 
     */
    constructor(name = '') {
        this.name = name;
        this.frames = [];
        this.currentFrame = 0;
        
        // Playback state
        this.playing = false;
        this.paused = false;
        this.loop = false;
        this.pingPong = false;
        this.direction = 1; // 1 = forward, -1 = backward
        
        // Timing
        this.elapsed = 0;
        this.speed = 1.0;
        this.defaultDuration = 100;
        
        // Position and transform
        this.x = 0;
        this.y = 0;
        this.scaleX = 1.0;
        this.scaleY = 1.0;
        this.rotation = 0;
        this.opacity = 1.0;
        this.visible = true;
        
        // Callbacks
        this.onFrame = null;
        this.onComplete = null;
        this.onLoop = null;
    }

    /**
     * Add frame
     * @param {VNFrame} frame 
     */
    addFrame(frame) {
        this.frames.push(frame);
    }

    /**
     * Add frames from image sequence parameters
     * @param {VNImgSeqParms} params 
     * @param {Function} loadImage - Image loader function
     * @returns {Promise<void>}
     */
    async loadFromParams(params, loadImage) {
        const count = params.getFrameCount();
        
        for (let i = 0; i < count; i++) {
            const filename = params.getFilename(i);
            const image = await loadImage(filename);
            
            const frame = new VNFrame({
                image: image,
                imageUrl: filename,
                x: params.x,
                y: params.y,
                width: image.width,
                height: image.height,
                duration: params.frameDuration,
                visible: params.visible,
                opacity: params.transparent ? 1.0 : 1.0
            });
            
            this.addFrame(frame);
        }
        
        this.loop = params.loop;
        this.pingPong = params.pingPong;
        
        if (params.autoStart) {
            this.play();
        }
    }

    /**
     * Load from sprite sheet
     * @param {HTMLImageElement} spriteSheet 
     * @param {number} frameWidth 
     * @param {number} frameHeight 
     * @param {number} frameCount 
     * @param {number} frameDuration 
     */
    loadFromSpriteSheet(spriteSheet, frameWidth, frameHeight, frameCount, frameDuration = 100) {
        const cols = Math.floor(spriteSheet.width / frameWidth);
        
        for (let i = 0; i < frameCount; i++) {
            const col = i % cols;
            const row = Math.floor(i / cols);
            
            const frame = new VNFrame({
                image: spriteSheet,
                srcX: col * frameWidth,
                srcY: row * frameHeight,
                srcWidth: frameWidth,
                srcHeight: frameHeight,
                width: frameWidth,
                height: frameHeight,
                duration: frameDuration
            });
            
            this.addFrame(frame);
        }
    }

    /**
     * Play animation
     */
    play() {
        this.playing = true;
        this.paused = false;
    }

    /**
     * Pause animation
     */
    pause() {
        this.paused = true;
    }

    /**
     * Resume animation
     */
    resume() {
        this.paused = false;
    }

    /**
     * Stop animation
     */
    stop() {
        this.playing = false;
        this.paused = false;
        this.currentFrame = 0;
        this.elapsed = 0;
        this.direction = 1;
    }

    /**
     * Reset to first frame
     */
    reset() {
        this.currentFrame = 0;
        this.elapsed = 0;
        this.direction = 1;
    }

    /**
     * Go to specific frame
     * @param {number} frameIndex 
     */
    gotoFrame(frameIndex) {
        this.currentFrame = Math.max(0, Math.min(frameIndex, this.frames.length - 1));
        this.elapsed = 0;
    }

    /**
     * Go to and play from frame
     * @param {number} frameIndex 
     */
    gotoAndPlay(frameIndex) {
        this.gotoFrame(frameIndex);
        this.play();
    }

    /**
     * Go to and stop at frame
     * @param {number} frameIndex 
     */
    gotoAndStop(frameIndex) {
        this.gotoFrame(frameIndex);
        this.stop();
        this.currentFrame = frameIndex;
    }

    /**
     * Update animation
     * @param {number} deltaTime - Time in milliseconds
     */
    update(deltaTime) {
        if (!this.playing || this.paused || this.frames.length === 0) {
            return;
        }

        this.elapsed += deltaTime * this.speed;
        
        const currentFrameObj = this.frames[this.currentFrame];
        const duration = currentFrameObj.duration || this.defaultDuration;
        
        while (this.elapsed >= duration) {
            this.elapsed -= duration;
            this._advanceFrame();
        }
    }

    /**
     * Advance to next frame
     * @private
     */
    _advanceFrame() {
        const prevFrame = this.currentFrame;
        this.currentFrame += this.direction;
        
        // Trigger frame callback
        if (this.onFrame) {
            this.onFrame(this.currentFrame, prevFrame);
        }

        // Check bounds
        if (this.currentFrame >= this.frames.length) {
            if (this.pingPong) {
                this.direction = -1;
                this.currentFrame = this.frames.length - 2;
                if (this.onLoop) {
                    this.onLoop();
                }
            } else if (this.loop) {
                this.currentFrame = 0;
                if (this.onLoop) {
                    this.onLoop();
                }
            } else {
                this.currentFrame = this.frames.length - 1;
                this.playing = false;
                if (this.onComplete) {
                    this.onComplete();
                }
            }
        } else if (this.currentFrame < 0) {
            if (this.pingPong) {
                this.direction = 1;
                this.currentFrame = 1;
                if (this.loop) {
                    if (this.onLoop) {
                        this.onLoop();
                    }
                } else {
                    this.currentFrame = 0;
                    this.playing = false;
                    if (this.onComplete) {
                        this.onComplete();
                    }
                }
            } else if (this.loop) {
                this.currentFrame = this.frames.length - 1;
                if (this.onLoop) {
                    this.onLoop();
                }
            } else {
                this.currentFrame = 0;
                this.playing = false;
                if (this.onComplete) {
                    this.onComplete();
                }
            }
        }
    }

    /**
     * Get current frame
     * @returns {VNFrame|null}
     */
    getCurrentFrame() {
        if (this.currentFrame >= 0 && this.currentFrame < this.frames.length) {
            return this.frames[this.currentFrame];
        }
        return null;
    }

    /**
     * Get frame count
     * @returns {number}
     */
    getFrameCount() {
        return this.frames.length;
    }

    /**
     * Get total duration
     * @returns {number}
     */
    getTotalDuration() {
        let total = 0;
        for (const frame of this.frames) {
            total += frame.duration || this.defaultDuration;
        }
        return total;
    }

    /**
     * Set all frame durations
     * @param {number} duration 
     */
    setFrameDuration(duration) {
        for (const frame of this.frames) {
            frame.duration = duration;
        }
    }

    /**
     * Render current frame to context
     * @param {CanvasRenderingContext2D} ctx 
     */
    render(ctx) {
        if (!this.visible) return;
        
        const frame = this.getCurrentFrame();
        if (!frame || !frame.image || !frame.visible) return;

        ctx.save();
        
        // Apply transform
        ctx.globalAlpha = this.opacity * frame.opacity;
        ctx.translate(this.x + frame.x, this.y + frame.y);
        
        if (this.rotation !== 0) {
            const cx = frame.width / 2;
            const cy = frame.height / 2;
            ctx.translate(cx, cy);
            ctx.rotate(this.rotation);
            ctx.translate(-cx, -cy);
        }
        
        if (this.scaleX !== 1 || this.scaleY !== 1) {
            ctx.scale(this.scaleX, this.scaleY);
        }

        // Draw frame
        if (frame.srcWidth && frame.srcHeight) {
            // Sprite sheet frame
            ctx.drawImage(
                frame.image,
                frame.srcX, frame.srcY, frame.srcWidth, frame.srcHeight,
                0, 0, frame.width, frame.height
            );
        } else {
            // Full image frame
            ctx.drawImage(frame.image, 0, 0, frame.width, frame.height);
        }

        ctx.restore();
    }

    /**
     * Check if animation is playing
     * @returns {boolean}
     */
    isPlaying() {
        return this.playing && !this.paused;
    }

    /**
     * Check if animation is complete
     * @returns {boolean}
     */
    isComplete() {
        return !this.playing && this.currentFrame >= this.frames.length - 1;
    }
}

/**
 * VNAnimationManager - Manages multiple animations
 */
export class VNAnimationManager {
    constructor() {
        this.animations = new Map();
        this.activeAnimations = new Set();
    }

    /**
     * Add animation
     * @param {VNAnimation} animation 
     */
    add(animation) {
        this.animations.set(animation.name, animation);
    }

    /**
     * Get animation by name
     * @param {string} name 
     * @returns {VNAnimation|undefined}
     */
    get(name) {
        return this.animations.get(name);
    }

    /**
     * Remove animation
     * @param {string} name 
     */
    remove(name) {
        this.animations.delete(name);
        this.activeAnimations.delete(name);
    }

    /**
     * Play animation
     * @param {string} name 
     */
    play(name) {
        const anim = this.animations.get(name);
        if (anim) {
            anim.play();
            this.activeAnimations.add(name);
        }
    }

    /**
     * Stop animation
     * @param {string} name 
     */
    stop(name) {
        const anim = this.animations.get(name);
        if (anim) {
            anim.stop();
            this.activeAnimations.delete(name);
        }
    }

    /**
     * Stop all animations
     */
    stopAll() {
        for (const anim of this.animations.values()) {
            anim.stop();
        }
        this.activeAnimations.clear();
    }

    /**
     * Update all active animations
     * @param {number} deltaTime 
     */
    update(deltaTime) {
        for (const name of this.activeAnimations) {
            const anim = this.animations.get(name);
            if (anim) {
                anim.update(deltaTime);
                if (!anim.isPlaying()) {
                    this.activeAnimations.delete(name);
                }
            }
        }
    }

    /**
     * Render all visible animations
     * @param {CanvasRenderingContext2D} ctx 
     */
    render(ctx) {
        // Render in order added
        for (const anim of this.animations.values()) {
            if (anim.visible) {
                anim.render(ctx);
            }
        }
    }

    /**
     * Clear all animations
     */
    clear() {
        this.animations.clear();
        this.activeAnimations.clear();
    }
}

/**
 * VNSequencer - Scene sequencer for timed events
 * Based on "sequencer" string @ 0x00443d46
 */
export class VNSequencer {
    constructor() {
        this.events = [];
        this.currentTime = 0;
        this.playing = false;
        this.paused = false;
        this.loop = false;
        this.currentEventIndex = 0;
    }

    /**
     * Add timed event
     * @param {number} time - Time in ms
     * @param {Function} callback 
     * @param {Object} data 
     */
    addEvent(time, callback, data = null) {
        this.events.push({
            time: time,
            callback: callback,
            data: data,
            triggered: false
        });
        
        // Sort by time
        this.events.sort((a, b) => a.time - b.time);
    }

    /**
     * Clear all events
     */
    clear() {
        this.events = [];
        this.reset();
    }

    /**
     * Play sequence
     */
    play() {
        this.playing = true;
        this.paused = false;
    }

    /**
     * Pause sequence
     */
    pause() {
        this.paused = true;
    }

    /**
     * Stop and reset sequence
     */
    stop() {
        this.playing = false;
        this.reset();
    }

    /**
     * Reset sequence
     */
    reset() {
        this.currentTime = 0;
        this.currentEventIndex = 0;
        for (const event of this.events) {
            event.triggered = false;
        }
    }

    /**
     * Update sequencer
     * @param {number} deltaTime 
     */
    update(deltaTime) {
        if (!this.playing || this.paused) return;

        this.currentTime += deltaTime;

        // Trigger events
        while (this.currentEventIndex < this.events.length) {
            const event = this.events[this.currentEventIndex];
            
            if (event.time <= this.currentTime && !event.triggered) {
                event.triggered = true;
                if (event.callback) {
                    event.callback(event.data, this.currentTime);
                }
                this.currentEventIndex++;
            } else {
                break;
            }
        }

        // Check for end
        if (this.currentEventIndex >= this.events.length) {
            if (this.loop) {
                this.reset();
            } else {
                this.playing = false;
            }
        }
    }

    /**
     * Seek to time
     * @param {number} time 
     */
    seek(time) {
        this.currentTime = time;
        this.currentEventIndex = 0;
        
        for (const event of this.events) {
            event.triggered = event.time <= time;
            if (!event.triggered) {
                break;
            }
            this.currentEventIndex++;
        }
    }

    /**
     * Get total duration
     * @returns {number}
     */
    getDuration() {
        if (this.events.length === 0) return 0;
        return this.events[this.events.length - 1].time;
    }
}

export default {
    VNFrame,
    VNImgSeqParms,
    VNAnimation,
    VNAnimationManager,
    VNSequencer
};
