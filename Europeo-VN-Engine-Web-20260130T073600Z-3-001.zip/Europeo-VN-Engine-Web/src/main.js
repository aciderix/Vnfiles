/**
 * Main entry point for Europeo VN Engine (Web Port)
 * 
 * This file initializes the engine and loads the project.
 * 
 * Original entry point: entry0 @ 0x00401000
 * Original main: WinMain via TApplication_Run
 */

import { VNEngine, ENGINE_STATE } from './core/VNEngine.js';
import { vnVariables } from './core/VNVariable.js';

// Global engine instance
let engine = null;

/**
 * Initialize and start the VN engine
 * 
 * @param {string|HTMLElement} container - Container element or ID
 * @param {Object} config - Configuration options
 * @returns {Promise<VNEngine>} The initialized engine
 */
async function startVNEngine(container, config = {}) {
    // Create engine
    engine = new VNEngine(config);
    
    // Initialize
    const initialized = await engine.init(container);
    if (!initialized) {
        console.error('Failed to initialize VN engine');
        return null;
    }
    
    // Load project if specified
    if (config.project) {
        const loaded = await engine.loadProject(config.project);
        if (!loaded) {
            console.error('Failed to load project');
        }
    }
    
    return engine;
}

/**
 * Get the current engine instance
 */
function getEngine() {
    return engine;
}

/**
 * Get the variable system
 */
function getVariables() {
    return vnVariables;
}

// Auto-initialize if DOM is ready and config is present
document.addEventListener('DOMContentLoaded', async () => {
    // Look for config in script tag
    const configScript = document.getElementById('vn-config');
    let config = {};
    
    if (configScript) {
        try {
            config = JSON.parse(configScript.textContent);
        } catch (e) {
            console.error('Failed to parse VN config:', e);
        }
    }
    
    // Look for URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('project')) {
        config.project = urlParams.get('project');
    }
    if (urlParams.has('debug')) {
        config.debug = urlParams.get('debug') === 'true';
    }
    
    // Find container
    const container = document.getElementById('vn-container');
    if (container && (config.project || config.autoStart)) {
        await startVNEngine(container, config);
    }
});

// Export for ES modules
export { startVNEngine, getEngine, getVariables, VNEngine };

// Also expose on window for non-module usage
if (typeof window !== 'undefined') {
    window.VNEngine = VNEngine;
    window.startVNEngine = startVNEngine;
    window.getVNEngine = getEngine;
    window.getVNVariables = getVariables;
}
