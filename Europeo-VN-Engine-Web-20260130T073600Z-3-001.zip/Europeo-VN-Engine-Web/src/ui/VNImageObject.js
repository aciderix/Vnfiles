/**
 * VNImageObject - Image display object for VN Engine
 * 
 * Handles image rendering with transparency support
 * Mirrors TVNImageObject and TVNTransparentBmp from the original engine
 */

class VNImageObject extends EventEmitter {
    constructor(engine, options = {}) {
        super();
        this.engine = engine;
        
        this.id = options.id || `img_${Date.now()}`;
        this.filename = options.filename || null;
        this.x = options.x || 0;
        this.y = options.y || 0;
        this.width = options.width || null;
        this.height = options.height || null;
        this.visible = options.visible !== false;
        this.transparent = options.transparent || false;
        this.zIndex = options.zIndex || 10;
        
        this._element = null;
        this._imageElement = null;
        this._attached = false;
        this._loaded = false;
    }

    /**
     * Create DOM element
     */
    _createElement() {
        this._element = document.createElement('div');
        this._element.id = `vn-img-${this.id}`;
        this._element.className = 'vn-image-object';
        
        this._imageElement = document.createElement('img');
        this._imageElement.style.display = 'block';
        
        this._element.appendChild(this._imageElement);
        
        this._updateStyles();
    }

    /**
     * Update element styles
     */
    _updateStyles() {
        if (!this._element) return;
        
        Object.assign(this._element.style, {
            position: 'absolute',
            left: `${this.x}px`,
            top: `${this.y}px`,
            display: this.visible ? 'block' : 'none',
            zIndex: this.zIndex,
            pointerEvents: 'auto'
        });
        
        if (this.width) {
            this._imageElement.style.width = `${this.width}px`;
        }
        if (this.height) {
            this._imageElement.style.height = `${this.height}px`;
        }
    }

    /**
     * Load image
     * @param {string} filename - Image filename
     * @returns {Promise<void>}
     */
    async load(filename) {
        this.filename = filename;
        this._loaded = false;
        
        const src = this._resolvePath(filename);
        if (!src) {
            throw new Error('Invalid image filename');
        }
        
        return new Promise((resolve, reject) => {
            this._imageElement.onload = () => {
                this._loaded = true;
                
                // Set natural dimensions if not specified
                if (!this.width) {
                    this._element.style.width = `${this._imageElement.naturalWidth}px`;
                }
                if (!this.height) {
                    this._element.style.height = `${this._imageElement.naturalHeight}px`;
                }
                
                this.emit(VNEvents.MEDIA_LOADED, { type: 'image', filename });
                resolve();
            };
            
            this._imageElement.onerror = (e) => {
                console.error('Failed to load image:', filename);
                this.emit(VNEvents.MEDIA_ERROR, { type: 'image', filename, error: e });
                reject(new Error(`Failed to load image: ${filename}`));
            };
            
            this._imageElement.src = src;
        });
    }

    /**
     * Resolve image path
     * @param {string} filename - Original filename
     * @returns {string}
     */
    _resolvePath(filename) {
        if (!filename) return null;
        
        if (filename.startsWith('http://') || filename.startsWith('https://') || filename.startsWith('data:')) {
            return filename;
        }

        const basePath = this.engine.config?.basePath || 'assets';
        const normalizedPath = filename.replace(/\\/g, '/');
        
        // Convert old formats
        let convertedPath = normalizedPath;
        const ext = normalizedPath.split('.').pop()?.toLowerCase();
        
        const imageConversions = {
            'bmp': 'png',
            'pcx': 'png',
            'tga': 'png'
        };
        
        if (imageConversions[ext]) {
            convertedPath = normalizedPath.replace(new RegExp(`\\.${ext}$`, 'i'), `.${imageConversions[ext]}`);
        }

        return `${basePath}/images/${convertedPath}`;
    }

    /**
     * Attach to DOM
     */
    attach() {
        if (this._attached) return;
        
        if (!this._element) {
            this._createElement();
        }
        
        const container = document.getElementById('vn-scene-layer');
        if (container) {
            container.appendChild(this._element);
            this._attached = true;
        }
    }

    /**
     * Detach from DOM
     */
    detach() {
        if (!this._attached || !this._element) return;
        
        this._element.remove();
        this._attached = false;
    }

    /**
     * Destroy object
     */
    destroy() {
        this.detach();
        this._element = null;
        this._imageElement = null;
        this.removeAllListeners();
    }

    /**
     * Set position
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     */
    setPosition(x, y) {
        this.x = x;
        this.y = y;
        this._updateStyles();
    }

    /**
     * Set size
     * @param {number} width - Width
     * @param {number} height - Height
     */
    setSize(width, height) {
        this.width = width;
        this.height = height;
        
        if (this._imageElement) {
            this._imageElement.style.width = width ? `${width}px` : 'auto';
            this._imageElement.style.height = height ? `${height}px` : 'auto';
        }
    }

    /**
     * Show object
     */
    show() {
        this.visible = true;
        if (this._element) {
            this._element.style.display = 'block';
        }
    }

    /**
     * Hide object
     */
    hide() {
        this.visible = false;
        if (this._element) {
            this._element.style.display = 'none';
        }
    }

    /**
     * Set z-index
     * @param {number} z - Z-index value
     */
    setZIndex(z) {
        this.zIndex = z;
        if (this._element) {
            this._element.style.zIndex = z;
        }
    }

    /**
     * Get natural dimensions
     * @returns {Object}
     */
    getNaturalSize() {
        if (this._imageElement && this._loaded) {
            return {
                width: this._imageElement.naturalWidth,
                height: this._imageElement.naturalHeight
            };
        }
        return { width: 0, height: 0 };
    }

    /**
     * Get state for saving
     * @returns {Object}
     */
    getState() {
        return {
            id: this.id,
            filename: this.filename,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            visible: this.visible,
            transparent: this.transparent,
            zIndex: this.zIndex
        };
    }

    /**
     * Restore state
     * @param {Object} state - Saved state
     */
    async restoreState(state) {
        Object.assign(this, state);
        if (state.filename) {
            await this.load(state.filename);
        }
        this._updateStyles();
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNImageObject };
}
