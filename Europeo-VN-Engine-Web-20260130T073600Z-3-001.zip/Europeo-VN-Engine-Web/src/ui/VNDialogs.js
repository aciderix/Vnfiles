/**
 * VNDialogs - Dialog UI components
 * 
 * Port of TVNAboutDlg, TVNLoadingDlg, TVNUserPrefsDlg, TVNPrjCapsDlg
 * from europeo.exe and vnoption.dll
 */

import { VNStreamable } from '../core/VNObject.js';

/**
 * Base dialog class
 */
export class VNBaseDialog extends VNStreamable {
    constructor(options = {}) {
        super();
        
        this.title = options.title || 'Dialog';
        this.width = options.width || 400;
        this.height = options.height || 'auto';
        this.modal = options.modal !== false;
        this.closable = options.closable !== false;
        this.draggable = options.draggable || false;
        
        // State
        this.visible = false;
        this.result = null;
        
        // DOM elements
        this._overlay = null;
        this._dialog = null;
        this._content = null;
        
        // Callbacks
        this._onClose = null;
        this._onOpen = null;
        
        // Drag state
        this._isDragging = false;
        this._dragOffset = { x: 0, y: 0 };
    }

    /**
     * Set close callback
     */
    onClose(callback) {
        this._onClose = callback;
        return this;
    }

    /**
     * Set open callback
     */
    onOpen(callback) {
        this._onOpen = callback;
        return this;
    }

    /**
     * Create dialog DOM structure
     */
    _createDialog() {
        // Overlay
        this._overlay = document.createElement('div');
        this._overlay.className = 'vn-dialog-overlay';
        if (!this.modal) {
            this._overlay.style.pointerEvents = 'none';
        }
        
        // Dialog container
        this._dialog = document.createElement('div');
        this._dialog.className = 'vn-dialog';
        this._dialog.style.width = typeof this.width === 'number' ? `${this.width}px` : this.width;
        if (this.height !== 'auto') {
            this._dialog.style.height = typeof this.height === 'number' ? `${this.height}px` : this.height;
        }
        
        // Header
        const header = document.createElement('div');
        header.className = 'vn-dialog-header';
        
        const titleEl = document.createElement('span');
        titleEl.className = 'vn-dialog-title';
        titleEl.textContent = this.title;
        header.appendChild(titleEl);
        
        if (this.closable) {
            const closeBtn = document.createElement('button');
            closeBtn.className = 'vn-dialog-close';
            closeBtn.innerHTML = '×';
            closeBtn.addEventListener('click', () => this.close());
            header.appendChild(closeBtn);
        }
        
        // Draggable
        if (this.draggable) {
            header.style.cursor = 'move';
            header.addEventListener('mousedown', (e) => this._startDrag(e));
        }
        
        this._dialog.appendChild(header);
        
        // Content
        this._content = document.createElement('div');
        this._content.className = 'vn-dialog-content';
        this._dialog.appendChild(this._content);
        
        this._overlay.appendChild(this._dialog);
        
        // Close on overlay click if modal
        if (this.modal && this.closable) {
            this._overlay.addEventListener('click', (e) => {
                if (e.target === this._overlay) {
                    this.close();
                }
            });
        }
        
        // Close on escape
        this._escHandler = (e) => {
            if (e.key === 'Escape' && this.closable) {
                this.close();
            }
        };
    }

    /**
     * Start dragging
     */
    _startDrag(e) {
        if (!this.draggable) return;
        
        this._isDragging = true;
        const rect = this._dialog.getBoundingClientRect();
        this._dragOffset = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
        
        const moveHandler = (e) => {
            if (!this._isDragging) return;
            this._dialog.style.left = `${e.clientX - this._dragOffset.x}px`;
            this._dialog.style.top = `${e.clientY - this._dragOffset.y}px`;
            this._dialog.style.transform = 'none';
        };
        
        const upHandler = () => {
            this._isDragging = false;
            document.removeEventListener('mousemove', moveHandler);
            document.removeEventListener('mouseup', upHandler);
        };
        
        document.addEventListener('mousemove', moveHandler);
        document.addEventListener('mouseup', upHandler);
    }

    /**
     * Build dialog content (override in subclasses)
     */
    _buildContent() {
        // Override in subclasses
    }

    /**
     * Open dialog
     */
    open() {
        if (this.visible) return this;
        
        this._createDialog();
        this._buildContent();
        
        document.body.appendChild(this._overlay);
        document.addEventListener('keydown', this._escHandler);
        
        this.visible = true;
        
        if (this._onOpen) {
            this._onOpen(this);
        }
        
        return this;
    }

    /**
     * Close dialog
     */
    close(result = null) {
        if (!this.visible) return this;
        
        this.result = result;
        this.visible = false;
        
        document.removeEventListener('keydown', this._escHandler);
        
        if (this._overlay && this._overlay.parentNode) {
            this._overlay.parentNode.removeChild(this._overlay);
        }
        
        if (this._onClose) {
            this._onClose(result, this);
        }
        
        return this;
    }

    /**
     * Show dialog and wait for result
     */
    showModal() {
        return new Promise((resolve) => {
            this.onClose((result) => resolve(result));
            this.open();
        });
    }
}

/**
 * TVNAboutDlg - About dialog
 * Port from europeo.exe (about dialog)
 */
export class VNAboutDialog extends VNBaseDialog {
    constructor(options = {}) {
        super({
            title: 'About',
            width: 350,
            ...options
        });
        
        this.appName = options.appName || 'Europeo VN Engine';
        this.version = options.version || '2.0.0 Web Port';
        this.author = options.author || '';
        this.copyright = options.copyright || '';
        this.description = options.description || '';
        this.logo = options.logo || null;
    }

    _buildContent() {
        let html = '<div class="vn-about-content">';
        
        if (this.logo) {
            html += `<img src="${this.logo}" class="vn-about-logo" alt="Logo">`;
        }
        
        html += `<h2>${this.appName}</h2>`;
        html += `<p class="vn-about-version">Version ${this.version}</p>`;
        
        if (this.author) {
            html += `<p>By ${this.author}</p>`;
        }
        
        if (this.copyright) {
            html += `<p class="vn-about-copyright">${this.copyright}</p>`;
        }
        
        if (this.description) {
            html += `<p class="vn-about-description">${this.description}</p>`;
        }
        
        html += '</div>';
        
        // Footer with OK button
        html += '<div class="vn-dialog-footer">';
        html += '<button class="vn-btn vn-btn-primary" id="vn-about-ok">OK</button>';
        html += '</div>';
        
        this._content.innerHTML = html;
        
        this._content.querySelector('#vn-about-ok').addEventListener('click', () => {
            this.close();
        });
    }
}

/**
 * TVNLoadingDlg - Loading dialog
 * Port from europeo.exe (loading indicator)
 */
export class VNLoadingDialog extends VNBaseDialog {
    constructor(options = {}) {
        super({
            title: 'Loading',
            width: 300,
            closable: false,
            modal: true,
            ...options
        });
        
        this.message = options.message || 'Loading...';
        this.progress = 0;
        this.showProgress = options.showProgress || false;
        this.indeterminate = options.indeterminate !== false;
        
        this._progressBar = null;
        this._messageEl = null;
    }

    _buildContent() {
        let html = '<div class="vn-loading-content">';
        
        html += '<div class="vn-loading-spinner"></div>';
        html += `<p class="vn-loading-message">${this.message}</p>`;
        
        if (this.showProgress) {
            html += '<div class="vn-progress-bar">';
            html += '<div class="vn-progress-fill"></div>';
            html += '</div>';
            html += '<p class="vn-progress-text">0%</p>';
        }
        
        html += '</div>';
        
        this._content.innerHTML = html;
        
        this._messageEl = this._content.querySelector('.vn-loading-message');
        this._progressBar = this._content.querySelector('.vn-progress-fill');
        this._progressText = this._content.querySelector('.vn-progress-text');
        
        if (this.indeterminate && this._progressBar) {
            this._progressBar.classList.add('indeterminate');
        }
    }

    /**
     * Update message
     */
    setMessage(message) {
        this.message = message;
        if (this._messageEl) {
            this._messageEl.textContent = message;
        }
    }

    /**
     * Update progress (0-100)
     */
    setProgress(progress) {
        this.progress = Math.max(0, Math.min(100, progress));
        
        if (this._progressBar) {
            this._progressBar.style.width = `${this.progress}%`;
            this._progressBar.classList.remove('indeterminate');
        }
        
        if (this._progressText) {
            this._progressText.textContent = `${Math.round(this.progress)}%`;
        }
    }
}

/**
 * TVNUserPrefsDlg - User preferences dialog
 * Port from vnoption.dll (VNCreateDLLWindow @ 0x00402e82)
 */
export class VNUserPrefsDialog extends VNBaseDialog {
    constructor(options = {}) {
        super({
            title: 'Preferences',
            width: 450,
            ...options
        });
        
        // Default preferences
        this.preferences = {
            musicVolume: options.musicVolume ?? 100,
            soundVolume: options.soundVolume ?? 100,
            voiceVolume: options.voiceVolume ?? 100,
            textSpeed: options.textSpeed ?? 50,
            autoAdvance: options.autoAdvance ?? false,
            autoAdvanceDelay: options.autoAdvanceDelay ?? 5000,
            fullscreen: options.fullscreen ?? false,
            skipRead: options.skipRead ?? true,
            ...options.preferences
        };
    }

    _buildContent() {
        let html = '<div class="vn-prefs-content">';
        
        // Audio section
        html += '<div class="vn-prefs-section">';
        html += '<h3>Audio</h3>';
        
        html += this._createSlider('musicVolume', 'Music Volume', this.preferences.musicVolume);
        html += this._createSlider('soundVolume', 'Sound Effects', this.preferences.soundVolume);
        html += this._createSlider('voiceVolume', 'Voice Volume', this.preferences.voiceVolume);
        
        html += '</div>';
        
        // Text section
        html += '<div class="vn-prefs-section">';
        html += '<h3>Text</h3>';
        
        html += this._createSlider('textSpeed', 'Text Speed', this.preferences.textSpeed);
        html += this._createCheckbox('autoAdvance', 'Auto-advance text', this.preferences.autoAdvance);
        
        html += '</div>';
        
        // Display section
        html += '<div class="vn-prefs-section">';
        html += '<h3>Display</h3>';
        
        html += this._createCheckbox('fullscreen', 'Fullscreen mode', this.preferences.fullscreen);
        html += this._createCheckbox('skipRead', 'Skip previously read text', this.preferences.skipRead);
        
        html += '</div>';
        
        html += '</div>';
        
        // Footer
        html += '<div class="vn-dialog-footer">';
        html += '<button class="vn-btn" id="vn-prefs-cancel">Cancel</button>';
        html += '<button class="vn-btn vn-btn-primary" id="vn-prefs-ok">OK</button>';
        html += '</div>';
        
        this._content.innerHTML = html;
        
        // Bind events
        this._content.querySelector('#vn-prefs-cancel').addEventListener('click', () => {
            this.close(null);
        });
        
        this._content.querySelector('#vn-prefs-ok').addEventListener('click', () => {
            this._savePreferences();
            this.close(this.preferences);
        });
        
        // Bind sliders
        this._content.querySelectorAll('input[type="range"]').forEach(input => {
            const valueEl = input.parentElement.querySelector('.vn-slider-value');
            input.addEventListener('input', () => {
                valueEl.textContent = input.value;
            });
        });
    }

    _createSlider(id, label, value) {
        return `
            <div class="vn-prefs-row">
                <label for="vn-pref-${id}">${label}</label>
                <div class="vn-slider-container">
                    <input type="range" id="vn-pref-${id}" min="0" max="100" value="${value}">
                    <span class="vn-slider-value">${value}</span>
                </div>
            </div>
        `;
    }

    _createCheckbox(id, label, checked) {
        return `
            <div class="vn-prefs-row">
                <label>
                    <input type="checkbox" id="vn-pref-${id}" ${checked ? 'checked' : ''}>
                    ${label}
                </label>
            </div>
        `;
    }

    _savePreferences() {
        this.preferences.musicVolume = parseInt(this._content.querySelector('#vn-pref-musicVolume').value);
        this.preferences.soundVolume = parseInt(this._content.querySelector('#vn-pref-soundVolume').value);
        this.preferences.voiceVolume = parseInt(this._content.querySelector('#vn-pref-voiceVolume').value);
        this.preferences.textSpeed = parseInt(this._content.querySelector('#vn-pref-textSpeed').value);
        this.preferences.autoAdvance = this._content.querySelector('#vn-pref-autoAdvance').checked;
        this.preferences.fullscreen = this._content.querySelector('#vn-pref-fullscreen').checked;
        this.preferences.skipRead = this._content.querySelector('#vn-pref-skipRead').checked;
    }

    /**
     * Get preferences
     */
    getPreferences() {
        return { ...this.preferences };
    }
}

/**
 * TVNPrjCapsDlg - Project capabilities/info dialog
 * Port from europeo.exe
 */
export class VNProjectCapsDialog extends VNBaseDialog {
    constructor(options = {}) {
        super({
            title: 'Project Information',
            width: 400,
            ...options
        });
        
        this.project = options.project || {};
    }

    _buildContent() {
        const p = this.project;
        
        let html = '<div class="vn-caps-content">';
        
        html += '<table class="vn-caps-table">';
        html += this._createRow('Name', p.name || 'Unknown');
        html += this._createRow('Version', p.version || '1.0');
        html += this._createRow('Author', p.author || 'Unknown');
        html += this._createRow('Resolution', `${p.width || 800} × ${p.height || 600}`);
        html += this._createRow('Scenes', p.sceneCount || 0);
        html += this._createRow('Total Size', this._formatSize(p.totalSize || 0));
        html += '</table>';
        
        if (p.description) {
            html += `<div class="vn-caps-description">${p.description}</div>`;
        }
        
        html += '</div>';
        
        html += '<div class="vn-dialog-footer">';
        html += '<button class="vn-btn vn-btn-primary" id="vn-caps-ok">OK</button>';
        html += '</div>';
        
        this._content.innerHTML = html;
        
        this._content.querySelector('#vn-caps-ok').addEventListener('click', () => {
            this.close();
        });
    }

    _createRow(label, value) {
        return `<tr><th>${label}</th><td>${value}</td></tr>`;
    }

    _formatSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
        return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
    }
}

/**
 * Message box dialog
 */
export class VNMessageBox extends VNBaseDialog {
    constructor(options = {}) {
        super({
            title: options.title || 'Message',
            width: 350,
            ...options
        });
        
        this.message = options.message || '';
        this.type = options.type || 'info'; // 'info', 'warning', 'error', 'question'
        this.buttons = options.buttons || ['OK'];
    }

    _buildContent() {
        const icons = {
            info: 'ℹ️',
            warning: '⚠️',
            error: '❌',
            question: '❓'
        };
        
        let html = '<div class="vn-msgbox-content">';
        html += `<span class="vn-msgbox-icon">${icons[this.type] || ''}</span>`;
        html += `<p class="vn-msgbox-message">${this.message}</p>`;
        html += '</div>';
        
        html += '<div class="vn-dialog-footer">';
        this.buttons.forEach((btn, index) => {
            const isPrimary = index === this.buttons.length - 1;
            html += `<button class="vn-btn ${isPrimary ? 'vn-btn-primary' : ''}" data-result="${btn}">${btn}</button>`;
        });
        html += '</div>';
        
        this._content.innerHTML = html;
        
        this._content.querySelectorAll('.vn-dialog-footer button').forEach(btn => {
            btn.addEventListener('click', () => {
                this.close(btn.dataset.result);
            });
        });
    }

    /**
     * Static helper methods
     */
    static info(message, title = 'Information') {
        return new VNMessageBox({ message, title, type: 'info' }).showModal();
    }

    static warning(message, title = 'Warning') {
        return new VNMessageBox({ message, title, type: 'warning' }).showModal();
    }

    static error(message, title = 'Error') {
        return new VNMessageBox({ message, title, type: 'error' }).showModal();
    }

    static confirm(message, title = 'Confirm') {
        return new VNMessageBox({ 
            message, 
            title, 
            type: 'question',
            buttons: ['Cancel', 'OK']
        }).showModal();
    }
}

/**
 * Inject dialog styles
 */
export function injectDialogStyles() {
    if (document.getElementById('vn-dialog-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'vn-dialog-styles';
    style.textContent = `
        .vn-dialog-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        }
        
        .vn-dialog {
            background: #2d2d2d;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            max-width: 90vw;
            max-height: 90vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .vn-dialog-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            background: #3d3d3d;
            border-bottom: 1px solid #4d4d4d;
        }
        
        .vn-dialog-title {
            font-weight: bold;
            color: #fff;
        }
        
        .vn-dialog-close {
            background: none;
            border: none;
            color: #999;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            line-height: 1;
        }
        
        .vn-dialog-close:hover {
            color: #fff;
        }
        
        .vn-dialog-content {
            padding: 20px;
            overflow-y: auto;
            color: #ddd;
        }
        
        .vn-dialog-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            padding: 12px 16px;
            background: #3d3d3d;
            border-top: 1px solid #4d4d4d;
        }
        
        .vn-btn {
            padding: 8px 16px;
            border: 1px solid #555;
            border-radius: 4px;
            background: #444;
            color: #fff;
            cursor: pointer;
            font-size: 14px;
        }
        
        .vn-btn:hover {
            background: #555;
        }
        
        .vn-btn-primary {
            background: #0066cc;
            border-color: #0055aa;
        }
        
        .vn-btn-primary:hover {
            background: #0077dd;
        }
        
        /* About dialog */
        .vn-about-content {
            text-align: center;
        }
        
        .vn-about-logo {
            max-width: 100px;
            margin-bottom: 15px;
        }
        
        .vn-about-version {
            color: #999;
        }
        
        /* Loading dialog */
        .vn-loading-content {
            text-align: center;
        }
        
        .vn-loading-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #444;
            border-top-color: #0066cc;
            border-radius: 50%;
            animation: vn-spin 1s linear infinite;
            margin: 0 auto 15px;
        }
        
        @keyframes vn-spin {
            to { transform: rotate(360deg); }
        }
        
        .vn-progress-bar {
            height: 8px;
            background: #444;
            border-radius: 4px;
            overflow: hidden;
            margin: 10px 0;
        }
        
        .vn-progress-fill {
            height: 100%;
            background: #0066cc;
            transition: width 0.3s;
        }
        
        .vn-progress-fill.indeterminate {
            width: 30%;
            animation: vn-progress-indeterminate 1.5s ease-in-out infinite;
        }
        
        @keyframes vn-progress-indeterminate {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(400%); }
        }
        
        /* Preferences dialog */
        .vn-prefs-section {
            margin-bottom: 20px;
        }
        
        .vn-prefs-section h3 {
            margin: 0 0 10px;
            color: #fff;
            border-bottom: 1px solid #444;
            padding-bottom: 5px;
        }
        
        .vn-prefs-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: 10px 0;
        }
        
        .vn-slider-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .vn-slider-value {
            min-width: 30px;
            text-align: right;
        }
        
        /* Message box */
        .vn-msgbox-content {
            display: flex;
            align-items: flex-start;
            gap: 15px;
        }
        
        .vn-msgbox-icon {
            font-size: 32px;
        }
        
        .vn-msgbox-message {
            margin: 0;
            flex: 1;
        }
        
        /* Caps dialog */
        .vn-caps-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .vn-caps-table th,
        .vn-caps-table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #444;
        }
        
        .vn-caps-table th {
            color: #999;
            width: 40%;
        }
        
        .vn-caps-description {
            margin-top: 15px;
            padding: 10px;
            background: #3d3d3d;
            border-radius: 4px;
        }
    `;
    document.head.appendChild(style);
}

export default {
    VNBaseDialog,
    VNAboutDialog,
    VNLoadingDialog,
    VNUserPrefsDialog,
    VNProjectCapsDialog,
    VNMessageBox,
    injectDialogStyles
};
