/**
 * VNSpecialDialogs - Special System Dialogs
 * 
 * EXACT PORT from europeo.exe special dialogs
 * 
 * Original classes from disassembly:
 * - TVNLoadingDlg @ detected in RTTI
 * - TVNPrjCapsDlg @ detected in RTTI
 * - TVNUserPrefsDlg @ detected in RTTI
 * - TVNAboutDlg @ detected in RTTI
 */

/**
 * VNLoadingDlg - Loading dialog
 * Port of TVNLoadingDlg
 */
export class VNLoadingDlg {
    constructor() {
        this.element = null;
        this.progressBar = null;
        this.statusText = null;
        this.visible = false;
        this.progress = 0;
        this.total = 100;
        this.title = 'Loading...';
        this.message = '';
        
        // Callbacks
        this.onCancel = null;
    }

    /**
     * Create dialog
     * @param {HTMLElement} parent 
     */
    create(parent = document.body) {
        this.element = document.createElement('div');
        this.element.className = 'vn-loading-dialog';
        this.element.innerHTML = `
            <div class="vn-loading-content">
                <div class="vn-loading-title">${this.title}</div>
                <div class="vn-loading-progress">
                    <div class="vn-loading-bar"></div>
                </div>
                <div class="vn-loading-status"></div>
                <button class="vn-loading-cancel">Cancel</button>
            </div>
        `;
        
        // Apply styles
        this.element.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 10000;
        `;
        
        const content = this.element.querySelector('.vn-loading-content');
        content.style.cssText = `
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            min-width: 300px;
            text-align: center;
        `;
        
        const titleEl = this.element.querySelector('.vn-loading-title');
        titleEl.style.cssText = `
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
        `;
        
        const progressContainer = this.element.querySelector('.vn-loading-progress');
        progressContainer.style.cssText = `
            background: #e0e0e0;
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 10px;
        `;
        
        this.progressBar = this.element.querySelector('.vn-loading-bar');
        this.progressBar.style.cssText = `
            background: linear-gradient(90deg, #4CAF50, #8BC34A);
            height: 100%;
            width: 0%;
            transition: width 0.2s ease;
        `;
        
        this.statusText = this.element.querySelector('.vn-loading-status');
        this.statusText.style.cssText = `
            color: #666;
            margin-bottom: 15px;
        `;
        
        const cancelBtn = this.element.querySelector('.vn-loading-cancel');
        cancelBtn.style.cssText = `
            padding: 8px 20px;
            cursor: pointer;
        `;
        cancelBtn.onclick = () => {
            if (this.onCancel) {
                this.onCancel();
            }
            this.hide();
        };
        
        parent.appendChild(this.element);
    }

    /**
     * Show dialog
     */
    show() {
        if (!this.element) {
            this.create();
        }
        this.element.style.display = 'flex';
        this.visible = true;
    }

    /**
     * Hide dialog
     */
    hide() {
        if (this.element) {
            this.element.style.display = 'none';
        }
        this.visible = false;
    }

    /**
     * Set progress
     * @param {number} value 
     * @param {number} total 
     */
    setProgress(value, total = 100) {
        this.progress = value;
        this.total = total;
        
        const percent = (value / total) * 100;
        if (this.progressBar) {
            this.progressBar.style.width = `${percent}%`;
        }
    }

    /**
     * Set status message
     * @param {string} message 
     */
    setStatus(message) {
        this.message = message;
        if (this.statusText) {
            this.statusText.textContent = message;
        }
    }

    /**
     * Set title
     * @param {string} title 
     */
    setTitle(title) {
        this.title = title;
        const titleEl = this.element?.querySelector('.vn-loading-title');
        if (titleEl) {
            titleEl.textContent = title;
        }
    }

    /**
     * Destroy dialog
     */
    destroy() {
        if (this.element && this.element.parentNode) {
            this.element.parentNode.removeChild(this.element);
        }
        this.element = null;
    }
}

/**
 * VNPrjCapsDlg - Project capabilities dialog
 * Port of TVNPrjCapsDlg
 */
export class VNPrjCapsDlg {
    constructor() {
        this.element = null;
        this.visible = false;
        this.capabilities = {
            audio: true,
            video: true,
            midi: false,
            cdaudio: false,
            html: true,
            save: true,
            print: true,
            fullscreen: true
        };
        
        // Callbacks
        this.onClose = null;
    }

    /**
     * Create dialog
     * @param {HTMLElement} parent 
     */
    create(parent = document.body) {
        this.element = document.createElement('div');
        this.element.className = 'vn-prjcaps-dialog';
        
        const capsHtml = Object.entries(this.capabilities)
            .map(([key, value]) => `
                <div class="vn-cap-item">
                    <span class="vn-cap-name">${key}</span>
                    <span class="vn-cap-value ${value ? 'enabled' : 'disabled'}">
                        ${value ? '✓ Enabled' : '✗ Disabled'}
                    </span>
                </div>
            `).join('');
        
        this.element.innerHTML = `
            <div class="vn-prjcaps-content">
                <div class="vn-prjcaps-title">Project Capabilities</div>
                <div class="vn-prjcaps-list">${capsHtml}</div>
                <button class="vn-prjcaps-close">Close</button>
            </div>
        `;
        
        // Apply styles
        this.element.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 10000;
        `;
        
        const content = this.element.querySelector('.vn-prjcaps-content');
        content.style.cssText = `
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            min-width: 300px;
        `;
        
        const closeBtn = this.element.querySelector('.vn-prjcaps-close');
        closeBtn.onclick = () => {
            if (this.onClose) {
                this.onClose();
            }
            this.hide();
        };
        
        parent.appendChild(this.element);
    }

    /**
     * Set capabilities
     * @param {Object} caps 
     */
    setCapabilities(caps) {
        this.capabilities = { ...this.capabilities, ...caps };
    }

    /**
     * Check capability
     * @param {string} name 
     * @returns {boolean}
     */
    hasCapability(name) {
        return !!this.capabilities[name];
    }

    /**
     * Show dialog
     */
    show() {
        if (!this.element) {
            this.create();
        }
        this.element.style.display = 'flex';
        this.visible = true;
    }

    /**
     * Hide dialog
     */
    hide() {
        if (this.element) {
            this.element.style.display = 'none';
        }
        this.visible = false;
    }

    /**
     * Destroy
     */
    destroy() {
        if (this.element && this.element.parentNode) {
            this.element.parentNode.removeChild(this.element);
        }
        this.element = null;
    }
}

/**
 * VNUserPrefsDlg - User preferences dialog
 * Port of TVNUserPrefsDlg
 */
export class VNUserPrefsDlg {
    constructor() {
        this.element = null;
        this.visible = false;
        this.preferences = {
            volume: 100,
            musicVolume: 100,
            sfxVolume: 100,
            textSpeed: 50,
            autoSave: true,
            fullscreen: false,
            skipRead: false,
            language: 'en'
        };
        
        // Callbacks
        this.onSave = null;
        this.onCancel = null;
    }

    /**
     * Create dialog
     * @param {HTMLElement} parent 
     */
    create(parent = document.body) {
        this.element = document.createElement('div');
        this.element.className = 'vn-userprefs-dialog';
        this.element.innerHTML = `
            <div class="vn-userprefs-content">
                <div class="vn-userprefs-title">User Preferences</div>
                <div class="vn-userprefs-form">
                    <div class="vn-pref-group">
                        <label>Master Volume</label>
                        <input type="range" id="vn-pref-volume" min="0" max="100" value="${this.preferences.volume}">
                        <span class="vn-pref-value">${this.preferences.volume}%</span>
                    </div>
                    <div class="vn-pref-group">
                        <label>Music Volume</label>
                        <input type="range" id="vn-pref-music" min="0" max="100" value="${this.preferences.musicVolume}">
                        <span class="vn-pref-value">${this.preferences.musicVolume}%</span>
                    </div>
                    <div class="vn-pref-group">
                        <label>SFX Volume</label>
                        <input type="range" id="vn-pref-sfx" min="0" max="100" value="${this.preferences.sfxVolume}">
                        <span class="vn-pref-value">${this.preferences.sfxVolume}%</span>
                    </div>
                    <div class="vn-pref-group">
                        <label>Text Speed</label>
                        <input type="range" id="vn-pref-textspeed" min="1" max="100" value="${this.preferences.textSpeed}">
                        <span class="vn-pref-value">${this.preferences.textSpeed}</span>
                    </div>
                    <div class="vn-pref-group">
                        <label>
                            <input type="checkbox" id="vn-pref-autosave" ${this.preferences.autoSave ? 'checked' : ''}>
                            Auto-save
                        </label>
                    </div>
                    <div class="vn-pref-group">
                        <label>
                            <input type="checkbox" id="vn-pref-fullscreen" ${this.preferences.fullscreen ? 'checked' : ''}>
                            Fullscreen
                        </label>
                    </div>
                    <div class="vn-pref-group">
                        <label>
                            <input type="checkbox" id="vn-pref-skipread" ${this.preferences.skipRead ? 'checked' : ''}>
                            Skip read text
                        </label>
                    </div>
                </div>
                <div class="vn-userprefs-buttons">
                    <button class="vn-userprefs-save">Save</button>
                    <button class="vn-userprefs-cancel">Cancel</button>
                </div>
            </div>
        `;
        
        // Apply styles
        this.element.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 10000;
        `;
        
        // Add event listeners
        this._setupEventListeners();
        
        parent.appendChild(this.element);
    }

    /**
     * Setup event listeners
     * @private
     */
    _setupEventListeners() {
        // Range sliders
        const sliders = this.element.querySelectorAll('input[type="range"]');
        sliders.forEach(slider => {
            slider.oninput = () => {
                const valueSpan = slider.parentElement.querySelector('.vn-pref-value');
                if (valueSpan) {
                    valueSpan.textContent = slider.id.includes('textspeed') 
                        ? slider.value 
                        : slider.value + '%';
                }
            };
        });
        
        // Save button
        const saveBtn = this.element.querySelector('.vn-userprefs-save');
        saveBtn.onclick = () => {
            this._collectValues();
            if (this.onSave) {
                this.onSave(this.preferences);
            }
            this.hide();
        };
        
        // Cancel button
        const cancelBtn = this.element.querySelector('.vn-userprefs-cancel');
        cancelBtn.onclick = () => {
            if (this.onCancel) {
                this.onCancel();
            }
            this.hide();
        };
    }

    /**
     * Collect values from form
     * @private
     */
    _collectValues() {
        this.preferences.volume = parseInt(this.element.querySelector('#vn-pref-volume').value);
        this.preferences.musicVolume = parseInt(this.element.querySelector('#vn-pref-music').value);
        this.preferences.sfxVolume = parseInt(this.element.querySelector('#vn-pref-sfx').value);
        this.preferences.textSpeed = parseInt(this.element.querySelector('#vn-pref-textspeed').value);
        this.preferences.autoSave = this.element.querySelector('#vn-pref-autosave').checked;
        this.preferences.fullscreen = this.element.querySelector('#vn-pref-fullscreen').checked;
        this.preferences.skipRead = this.element.querySelector('#vn-pref-skipread').checked;
    }

    /**
     * Set preferences
     * @param {Object} prefs 
     */
    setPreferences(prefs) {
        this.preferences = { ...this.preferences, ...prefs };
    }

    /**
     * Get preferences
     * @returns {Object}
     */
    getPreferences() {
        return { ...this.preferences };
    }

    /**
     * Show dialog
     */
    show() {
        if (!this.element) {
            this.create();
        }
        this.element.style.display = 'flex';
        this.visible = true;
    }

    /**
     * Hide dialog
     */
    hide() {
        if (this.element) {
            this.element.style.display = 'none';
        }
        this.visible = false;
    }

    /**
     * Destroy
     */
    destroy() {
        if (this.element && this.element.parentNode) {
            this.element.parentNode.removeChild(this.element);
        }
        this.element = null;
    }
}

/**
 * VNAboutDlg - About dialog
 * Port of TVNAboutDlg
 */
export class VNAboutDlg {
    constructor() {
        this.element = null;
        this.visible = false;
        this.info = {
            title: 'Europeo VN Engine',
            version: '1.0.0',
            author: '',
            copyright: '',
            description: ''
        };
        
        // Callbacks
        this.onClose = null;
    }

    /**
     * Set info
     * @param {Object} info 
     */
    setInfo(info) {
        this.info = { ...this.info, ...info };
    }

    /**
     * Create dialog
     * @param {HTMLElement} parent 
     */
    create(parent = document.body) {
        this.element = document.createElement('div');
        this.element.className = 'vn-about-dialog';
        this.element.innerHTML = `
            <div class="vn-about-content">
                <div class="vn-about-title">${this.info.title}</div>
                <div class="vn-about-version">Version ${this.info.version}</div>
                ${this.info.author ? `<div class="vn-about-author">By ${this.info.author}</div>` : ''}
                ${this.info.description ? `<div class="vn-about-desc">${this.info.description}</div>` : ''}
                ${this.info.copyright ? `<div class="vn-about-copyright">${this.info.copyright}</div>` : ''}
                <div class="vn-about-powered">
                    Powered by Europeo VN Engine Web Port
                </div>
                <button class="vn-about-close">OK</button>
            </div>
        `;
        
        // Apply styles
        this.element.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 10000;
        `;
        
        const content = this.element.querySelector('.vn-about-content');
        content.style.cssText = `
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: #fff;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            min-width: 350px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        `;
        
        const closeBtn = this.element.querySelector('.vn-about-close');
        closeBtn.style.cssText = `
            margin-top: 20px;
            padding: 10px 30px;
            font-size: 16px;
            cursor: pointer;
        `;
        closeBtn.onclick = () => {
            if (this.onClose) {
                this.onClose();
            }
            this.hide();
        };
        
        parent.appendChild(this.element);
    }

    /**
     * Show dialog
     */
    show() {
        if (!this.element) {
            this.create();
        }
        this.element.style.display = 'flex';
        this.visible = true;
    }

    /**
     * Hide dialog
     */
    hide() {
        if (this.element) {
            this.element.style.display = 'none';
        }
        this.visible = false;
    }

    /**
     * Destroy
     */
    destroy() {
        if (this.element && this.element.parentNode) {
            this.element.parentNode.removeChild(this.element);
        }
        this.element = null;
    }
}

export default {
    VNLoadingDlg,
    VNPrjCapsDlg,
    VNUserPrefsDlg,
    VNAboutDlg
};
