/**
 * VNDialog - Text dialog/textbox system for VN Engine
 * 
 * Handles dialog text display with typewriter effect
 * Supports character names and text formatting
 */

class VNDialog extends EventEmitter {
    constructor(engine, options = {}) {
        super();
        this.engine = engine;
        
        // Configuration
        this.textSpeed = options.textSpeed || 30; // chars per second
        this.autoPlay = options.autoPlay || false;
        this.autoPlayDelay = options.autoPlayDelay || 3000; // ms
        
        // State
        this._visible = false;
        this._currentText = '';
        this._displayedText = '';
        this._characterName = '';
        this._typing = false;
        this._typeTimeout = null;
        this._autoTimeout = null;
        
        // DOM elements
        this._container = null;
        this._nameElement = null;
        this._textElement = null;
        
        this._init();
    }

    /**
     * Initialize dialog elements
     */
    _init() {
        this._container = document.getElementById('vn-dialog');
        this._nameElement = document.getElementById('vn-dialog-name');
        this._textElement = document.getElementById('vn-dialog-text');
        
        // Click to advance
        if (this._container) {
            this._container.addEventListener('click', () => this._onClick());
        }
        
        // Keyboard support
        document.addEventListener('keydown', (e) => {
            if (this._visible && (e.key === 'Enter' || e.key === ' ')) {
                this._onClick();
            }
        });
    }

    /**
     * Handle dialog click
     */
    _onClick() {
        if (this._typing) {
            // Skip to end of text
            this._finishTyping();
        } else {
            // Advance/close dialog
            this.emit(VNEvents.DIALOG_CLICK);
            this.engine.emit(VNEvents.DIALOG_CLICK);
        }
    }

    /**
     * Show dialog with text
     * @param {string} text - Text to display
     * @param {string} name - Character name (optional)
     * @param {Object} options - Display options
     * @returns {Promise<void>} Resolves when dialog is clicked/dismissed
     */
    async show(text, name = '', options = {}) {
        const { instant = false, wait = true } = options;
        
        this._currentText = text;
        this._displayedText = '';
        this._characterName = name;
        this._visible = true;
        
        // Update UI
        if (this._nameElement) {
            this._nameElement.textContent = name;
            this._nameElement.style.display = name ? 'block' : 'none';
        }
        
        if (this._textElement) {
            this._textElement.innerHTML = '';
        }
        
        if (this._container) {
            this._container.classList.add('visible');
        }
        
        // Clear any pending timeouts
        this._clearTimeouts();
        
        if (instant) {
            this._displayedText = text;
            if (this._textElement) {
                this._textElement.innerHTML = this._parseText(text);
            }
            this._typing = false;
            this.emit(VNEvents.TEXT_COMPLETE);
        } else {
            // Start typewriter effect
            await this._startTyping();
        }
        
        if (wait) {
            return this._waitForClick();
        }
    }

    /**
     * Start typewriter effect
     */
    async _startTyping() {
        this._typing = true;
        const chars = this._currentText.split('');
        let index = 0;
        
        return new Promise((resolve) => {
            const typeNextChar = () => {
                if (!this._typing) {
                    resolve();
                    return;
                }
                
                if (index < chars.length) {
                    this._displayedText += chars[index];
                    if (this._textElement) {
                        this._textElement.innerHTML = this._parseText(this._displayedText);
                    }
                    index++;
                    
                    // Calculate delay (handle tags)
                    let delay = 1000 / this.textSpeed;
                    
                    // Pause longer on punctuation
                    const lastChar = chars[index - 1];
                    if ('.!?'.includes(lastChar)) {
                        delay *= 3;
                    } else if (',;:'.includes(lastChar)) {
                        delay *= 2;
                    }
                    
                    this._typeTimeout = setTimeout(typeNextChar, delay);
                } else {
                    this._typing = false;
                    this.emit(VNEvents.TEXT_COMPLETE);
                    resolve();
                    
                    // Auto-play if enabled
                    if (this.autoPlay) {
                        this._autoTimeout = setTimeout(() => {
                            this.emit(VNEvents.DIALOG_CLICK);
                        }, this.autoPlayDelay);
                    }
                }
            };
            
            typeNextChar();
        });
    }

    /**
     * Finish typing immediately
     */
    _finishTyping() {
        this._clearTimeouts();
        this._typing = false;
        this._displayedText = this._currentText;
        
        if (this._textElement) {
            this._textElement.innerHTML = this._parseText(this._currentText);
        }
        
        this.emit(VNEvents.TEXT_COMPLETE);
        
        // Auto-play if enabled
        if (this.autoPlay) {
            this._autoTimeout = setTimeout(() => {
                this.emit(VNEvents.DIALOG_CLICK);
            }, this.autoPlayDelay);
        }
    }

    /**
     * Wait for click
     * @returns {Promise<void>}
     */
    _waitForClick() {
        return new Promise((resolve) => {
            this.once(VNEvents.DIALOG_CLICK, resolve);
        });
    }

    /**
     * Clear pending timeouts
     */
    _clearTimeouts() {
        if (this._typeTimeout) {
            clearTimeout(this._typeTimeout);
            this._typeTimeout = null;
        }
        if (this._autoTimeout) {
            clearTimeout(this._autoTimeout);
            this._autoTimeout = null;
        }
    }

    /**
     * Parse text for simple formatting
     * @param {string} text - Raw text
     * @returns {string} HTML formatted text
     */
    _parseText(text) {
        if (!text) return '';
        
        let html = text;
        
        // Escape HTML entities first
        html = html.replace(/&/g, '&amp;')
                   .replace(/</g, '&lt;')
                   .replace(/>/g, '&gt;');
        
        // Convert newlines to <br>
        html = html.replace(/\n/g, '<br>');
        
        // Basic formatting (using custom markers)
        // *bold* -> <b>bold</b>
        html = html.replace(/\*([^*]+)\*/g, '<b>$1</b>');
        
        // _italic_ -> <i>italic</i>
        html = html.replace(/_([^_]+)_/g, '<i>$1</i>');
        
        // {color:#FF0000}text{/color} -> <span style="color:#FF0000">text</span>
        html = html.replace(/\{color:([^}]+)\}([^{]*)\{\/color\}/gi, 
            '<span style="color:$1">$2</span>');
        
        return html;
    }

    /**
     * Hide dialog
     */
    hide() {
        this._clearTimeouts();
        this._visible = false;
        this._typing = false;
        
        if (this._container) {
            this._container.classList.remove('visible');
        }
    }

    /**
     * Set text speed
     * @param {number} speed - Characters per second
     */
    setTextSpeed(speed) {
        this.textSpeed = Math.max(1, Math.min(100, speed));
    }

    /**
     * Set auto-play mode
     * @param {boolean} enabled - Enable/disable
     * @param {number} delay - Delay in ms
     */
    setAutoPlay(enabled, delay = 3000) {
        this.autoPlay = enabled;
        this.autoPlayDelay = delay;
    }

    /**
     * Check if dialog is visible
     * @returns {boolean}
     */
    isVisible() {
        return this._visible;
    }

    /**
     * Check if typing is in progress
     * @returns {boolean}
     */
    isTyping() {
        return this._typing;
    }

    /**
     * Get current text
     * @returns {string}
     */
    getCurrentText() {
        return this._currentText;
    }

    /**
     * Get state for saving
     * @returns {Object}
     */
    getState() {
        return {
            visible: this._visible,
            text: this._currentText,
            name: this._characterName,
            textSpeed: this.textSpeed,
            autoPlay: this.autoPlay,
            autoPlayDelay: this.autoPlayDelay
        };
    }

    /**
     * Restore state
     * @param {Object} state - Saved state
     */
    restoreState(state) {
        this.textSpeed = state.textSpeed ?? this.textSpeed;
        this.autoPlay = state.autoPlay ?? this.autoPlay;
        this.autoPlayDelay = state.autoPlayDelay ?? this.autoPlayDelay;
        
        if (state.visible && state.text) {
            this.show(state.text, state.name, { instant: true, wait: false });
        }
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNDialog };
}
