/**
 * VNHotspot - Clickable area for VN Engine
 * 
 * Handles interactive regions (buttons, clickable areas)
 * Mirrors the hotspot system from the original engine
 * 
 * From analysis:
 *   - HOTSPOT_%u format in scene data
 *   - HSVIDEORECT_%u for video-mapped hotspots
 *   - Events: EV_ONCLICK, EV_ONFOCUS
 */

class VNHotspot extends EventEmitter {
    constructor(engine, options = {}) {
        super();
        this.engine = engine;
        
        this.id = options.id || `hotspot_${Date.now()}`;
        this.x = options.x || 0;
        this.y = options.y || 0;
        this.width = options.width || 100;
        this.height = options.height || 50;
        this.cursor = options.cursor || 'pointer';
        this.tipText = options.tipText || null;
        this.visible = options.visible !== false;
        this.enabled = options.enabled !== false;
        this.debug = options.debug || false;
        
        this._element = null;
        this._attached = false;
        this._focused = false;
    }

    /**
     * Create DOM element
     */
    _createElement() {
        this._element = document.createElement('div');
        this._element.id = `vn-hotspot-${this.id}`;
        this._element.className = 'vn-hotspot';
        
        if (this.debug) {
            this._element.classList.add('debug');
        }
        
        this._updateStyles();
        this._bindEvents();
    }

    /**
     * Update element styles
     */
    _updateStyles() {
        if (!this._element) return;
        
        Object.assign(this._element.style, {
            position: 'absolute',
            left: `${this.x}px`,
            top: `${this.y}px`,
            width: `${this.width}px`,
            height: `${this.height}px`,
            cursor: this.enabled ? this.cursor : 'default',
            display: this.visible ? 'block' : 'none'
        });
        
        // Set tooltip
        if (this.tipText) {
            this._element.title = this.tipText;
        }
    }

    /**
     * Bind event handlers
     */
    _bindEvents() {
        if (!this._element) return;
        
        // Click handler
        this._element.addEventListener('click', (e) => {
            if (!this.enabled) return;
            
            e.stopPropagation();
            this.emit('click', { 
                x: e.offsetX, 
                y: e.offsetY,
                id: this.id 
            });
            this.engine.emit(VNEvents.HOTSPOT_CLICK, { 
                hotspot: this,
                x: e.offsetX, 
                y: e.offsetY 
            });
        });
        
        // Mouse enter (focus)
        this._element.addEventListener('mouseenter', () => {
            if (!this.enabled) return;
            
            this._focused = true;
            this.emit('focus', { id: this.id });
            this.engine.emit(VNEvents.HOTSPOT_FOCUS, { 
                hotspot: this, 
                focused: true 
            });
            
            // Show tooltip
            if (this.tipText) {
                this.engine.showTooltip(this.tipText, this.x, this.y);
            }
        });
        
        // Mouse leave (blur)
        this._element.addEventListener('mouseleave', () => {
            this._focused = false;
            this.emit('blur', { id: this.id });
            this.engine.emit(VNEvents.HOTSPOT_FOCUS, { 
                hotspot: this, 
                focused: false 
            });
            
            // Hide tooltip
            this.engine.hideTooltip();
        });
        
        // Touch support
        this._element.addEventListener('touchstart', (e) => {
            if (!this.enabled) return;
            
            e.preventDefault();
            const touch = e.touches[0];
            const rect = this._element.getBoundingClientRect();
            
            this.emit('click', { 
                x: touch.clientX - rect.left, 
                y: touch.clientY - rect.top,
                id: this.id 
            });
            this.engine.emit(VNEvents.HOTSPOT_CLICK, { 
                hotspot: this,
                x: touch.clientX - rect.left, 
                y: touch.clientY - rect.top 
            });
        });
    }

    /**
     * Attach to DOM
     */
    attach() {
        if (this._attached) return;
        
        if (!this._element) {
            this._createElement();
        }
        
        const container = document.getElementById('vn-hotspot-layer');
        if (container) {
            container.appendChild(this._element);
            this._attached = true;
        }
    }

    /**
     * Detach from DOM
     */
    detach() {
        if (!this._attached || !this._element) return;
        
        this._element.remove();
        this._attached = false;
    }

    /**
     * Destroy hotspot
     */
    destroy() {
        this.detach();
        this._element = null;
        this.removeAllListeners();
    }

    /**
     * Set position
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     */
    setPosition(x, y) {
        this.x = x;
        this.y = y;
        this._updateStyles();
    }

    /**
     * Set size
     * @param {number} width - Width
     * @param {number} height - Height
     */
    setSize(width, height) {
        this.width = width;
        this.height = height;
        this._updateStyles();
    }

    /**
     * Set bounds (position and size)
     * @param {Object} bounds - { x, y, width, height }
     */
    setBounds(bounds) {
        this.x = bounds.x ?? this.x;
        this.y = bounds.y ?? this.y;
        this.width = bounds.width ?? this.width;
        this.height = bounds.height ?? this.height;
        this._updateStyles();
    }

    /**
     * Show hotspot
     */
    show() {
        this.visible = true;
        if (this._element) {
            this._element.style.display = 'block';
        }
    }

    /**
     * Hide hotspot
     */
    hide() {
        this.visible = false;
        if (this._element) {
            this._element.style.display = 'none';
        }
    }

    /**
     * Enable hotspot
     */
    enable() {
        this.enabled = true;
        this._updateStyles();
    }

    /**
     * Disable hotspot
     */
    disable() {
        this.enabled = false;
        this._updateStyles();
    }

    /**
     * Set cursor
     * @param {string} cursor - CSS cursor value or cursor file
     */
    setCursor(cursor) {
        if (cursor.includes('.')) {
            // Custom cursor file
            const path = this.engine.media?.images?._resolvePath?.(cursor, 'cursors') || cursor;
            this.cursor = `url(${path}), auto`;
        } else {
            this.cursor = cursor;
        }
        this._updateStyles();
    }

    /**
     * Set tooltip text
     * @param {string} text - Tooltip text
     */
    setTipText(text) {
        this.tipText = text;
        if (this._element) {
            this._element.title = text || '';
        }
    }

    /**
     * Check if point is inside hotspot
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     * @returns {boolean}
     */
    containsPoint(x, y) {
        return x >= this.x && 
               x <= this.x + this.width && 
               y >= this.y && 
               y <= this.y + this.height;
    }

    /**
     * Toggle debug mode
     * @param {boolean} enabled - Enable/disable debug
     */
    setDebug(enabled) {
        this.debug = enabled;
        if (this._element) {
            this._element.classList.toggle('debug', enabled);
        }
    }

    /**
     * Get state for saving
     * @returns {Object}
     */
    getState() {
        return {
            id: this.id,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            cursor: this.cursor,
            tipText: this.tipText,
            visible: this.visible,
            enabled: this.enabled
        };
    }

    /**
     * Restore state
     * @param {Object} state - Saved state
     */
    restoreState(state) {
        Object.assign(this, state);
        this._updateStyles();
    }
}

/**
 * VNHotspotManager - Manages all hotspots in a scene
 */
class VNHotspotManager {
    constructor(engine) {
        this.engine = engine;
        this._hotspots = new Map();
    }

    /**
     * Add a hotspot
     * @param {string} id - Hotspot ID
     * @param {Object} options - Hotspot options
     * @returns {VNHotspot}
     */
    add(id, options = {}) {
        const hotspot = new VNHotspot(this.engine, { id, ...options });
        this._hotspots.set(id, hotspot);
        return hotspot;
    }

    /**
     * Get hotspot by ID
     * @param {string} id - Hotspot ID
     * @returns {VNHotspot|null}
     */
    get(id) {
        return this._hotspots.get(id) || null;
    }

    /**
     * Remove hotspot
     * @param {string} id - Hotspot ID
     */
    remove(id) {
        const hotspot = this._hotspots.get(id);
        if (hotspot) {
            hotspot.destroy();
            this._hotspots.delete(id);
        }
    }

    /**
     * Clear all hotspots
     */
    clear() {
        this._hotspots.forEach(hs => hs.destroy());
        this._hotspots.clear();
    }

    /**
     * Find hotspot at point
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     * @returns {VNHotspot|null}
     */
    findAtPoint(x, y) {
        for (const [id, hotspot] of this._hotspots) {
            if (hotspot.visible && hotspot.enabled && hotspot.containsPoint(x, y)) {
                return hotspot;
            }
        }
        return null;
    }

    /**
     * Get all hotspots
     * @returns {VNHotspot[]}
     */
    getAll() {
        return Array.from(this._hotspots.values());
    }

    /**
     * Toggle debug mode for all hotspots
     * @param {boolean} enabled - Enable/disable debug
     */
    setDebugAll(enabled) {
        this._hotspots.forEach(hs => hs.setDebug(enabled));
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNHotspot, VNHotspotManager };
}
