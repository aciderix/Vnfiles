/**
 * VNToolbar - Toolbar UI component
 * 
 * Port of TVNToolBar and TVNToolBarProperties from europeo.exe
 */

import { VNStreamable } from '../core/VNObject.js';

/**
 * TVNToolBarProperties - Toolbar configuration
 * Port from europeo.exe (toolbar properties)
 */
export class VNToolBarProperties extends VNStreamable {
    constructor() {
        super();
        
        // Position
        this.position = 'bottom';   // 'top', 'bottom', 'left', 'right'
        this.floating = false;
        this.x = 0;
        this.y = 0;
        
        // Size
        this.height = 40;
        this.buttonSize = 32;
        this.padding = 5;
        this.spacing = 5;
        
        // Appearance
        this.visible = true;
        this.transparent = false;
        this.backgroundColor = '#333333';
        this.borderColor = '#555555';
        this.borderWidth = 1;
        
        // Behavior
        this.autoHide = false;
        this.autoHideDelay = 2000;
        this.showTooltips = true;
    }

    serialize() {
        return {
            ...super.serialize(),
            position: this.position,
            floating: this.floating,
            x: this.x,
            y: this.y,
            height: this.height,
            buttonSize: this.buttonSize,
            visible: this.visible,
            backgroundColor: this.backgroundColor,
            autoHide: this.autoHide
        };
    }

    deserialize(data) {
        super.deserialize(data);
        Object.keys(data).forEach(key => {
            if (this.hasOwnProperty(key)) this[key] = data[key];
        });
        return this;
    }
}

/**
 * Toolbar button
 */
export class VNToolBarButton extends VNStreamable {
    constructor(id, options = {}) {
        super();
        
        this.id = id;
        this.tooltip = options.tooltip || '';
        this.icon = options.icon || '';       // URL or emoji
        this.iconType = options.iconType || 'emoji'; // 'emoji', 'url', 'svg'
        this.command = options.command || null;
        this.enabled = options.enabled !== false;
        this.visible = options.visible !== false;
        this.toggle = options.toggle || false;
        this.pressed = false;
        this.separator = options.separator || false;
        
        // DOM element
        this._element = null;
    }

    /**
     * Create DOM element
     */
    createElement() {
        if (this.separator) {
            this._element = document.createElement('div');
            this._element.className = 'vn-toolbar-separator';
            return this._element;
        }
        
        this._element = document.createElement('button');
        this._element.className = 'vn-toolbar-button';
        this._element.dataset.id = this.id;
        this._element.title = this.tooltip;
        this._element.disabled = !this.enabled;
        
        // Set icon
        if (this.iconType === 'emoji' || !this.icon.includes('/')) {
            this._element.textContent = this.icon;
        } else if (this.iconType === 'url') {
            const img = document.createElement('img');
            img.src = this.icon;
            img.alt = this.tooltip;
            this._element.appendChild(img);
        } else if (this.iconType === 'svg') {
            this._element.innerHTML = this.icon;
        }
        
        // Toggle state
        if (this.toggle && this.pressed) {
            this._element.classList.add('pressed');
        }
        
        // Visibility
        this._element.style.display = this.visible ? '' : 'none';
        
        return this._element;
    }

    /**
     * Update element state
     */
    updateElement() {
        if (!this._element) return;
        
        this._element.disabled = !this.enabled;
        this._element.style.display = this.visible ? '' : 'none';
        
        if (this.toggle) {
            this._element.classList.toggle('pressed', this.pressed);
        }
    }

    /**
     * Press button (for toggle)
     */
    press() {
        if (this.toggle) {
            this.pressed = true;
            this.updateElement();
        }
    }

    /**
     * Release button (for toggle)
     */
    release() {
        if (this.toggle) {
            this.pressed = false;
            this.updateElement();
        }
    }

    /**
     * Toggle pressed state
     */
    togglePressed() {
        if (this.toggle) {
            this.pressed = !this.pressed;
            this.updateElement();
        }
    }

    serialize() {
        return {
            ...super.serialize(),
            id: this.id,
            tooltip: this.tooltip,
            icon: this.icon,
            iconType: this.iconType,
            command: this.command,
            enabled: this.enabled,
            visible: this.visible,
            toggle: this.toggle,
            pressed: this.pressed
        };
    }
}

/**
 * TVNToolBar - Main toolbar class
 * Port from europeo.exe (TVNToolBar)
 */
export class VNToolBar extends VNStreamable {
    constructor(properties = null) {
        super();
        
        this.properties = properties || new VNToolBarProperties();
        this.buttons = [];
        
        // DOM elements
        this._container = null;
        this._element = null;
        
        // Callbacks
        this._onClick = null;
        this._onCommand = null;
        
        // Auto-hide timer
        this._hideTimer = null;
        this._isHovered = false;
    }

    /**
     * Add button
     */
    addButton(id, options = {}) {
        const button = new VNToolBarButton(id, options);
        this.buttons.push(button);
        return button;
    }

    /**
     * Add separator
     */
    addSeparator() {
        return this.addButton(`sep_${this.buttons.length}`, { separator: true });
    }

    /**
     * Get button by ID
     */
    getButton(id) {
        return this.buttons.find(b => b.id === id);
    }

    /**
     * Remove button
     */
    removeButton(id) {
        const index = this.buttons.findIndex(b => b.id === id);
        if (index !== -1) {
            this.buttons.splice(index, 1);
        }
    }

    /**
     * Set click callback
     */
    onClick(callback) {
        this._onClick = callback;
        return this;
    }

    /**
     * Set command callback
     */
    onCommand(callback) {
        this._onCommand = callback;
        return this;
    }

    /**
     * Create and mount toolbar
     */
    mount(container) {
        this._container = container;
        
        // Create toolbar element
        this._element = document.createElement('div');
        this._element.className = 'vn-toolbar';
        this._element.classList.add(`vn-toolbar-${this.properties.position}`);
        
        if (this.properties.floating) {
            this._element.classList.add('vn-toolbar-floating');
            this._element.style.left = `${this.properties.x}px`;
            this._element.style.top = `${this.properties.y}px`;
        }
        
        // Apply styles
        this._applyStyles();
        
        // Create buttons
        this.buttons.forEach(button => {
            const btnElement = button.createElement();
            
            if (!button.separator) {
                btnElement.addEventListener('click', () => this._handleClick(button));
            }
            
            this._element.appendChild(btnElement);
        });
        
        // Auto-hide behavior
        if (this.properties.autoHide) {
            this._element.addEventListener('mouseenter', () => {
                this._isHovered = true;
                this._cancelAutoHide();
                this.show();
            });
            
            this._element.addEventListener('mouseleave', () => {
                this._isHovered = false;
                this._startAutoHide();
            });
            
            // Start hidden if autoHide is enabled
            this.hide();
        }
        
        container.appendChild(this._element);
        
        // Show/hide based on properties
        this._element.style.display = this.properties.visible ? '' : 'none';
        
        return this;
    }

    /**
     * Apply CSS styles
     */
    _applyStyles() {
        if (!this._element) return;
        
        Object.assign(this._element.style, {
            backgroundColor: this.properties.transparent ? 'transparent' : this.properties.backgroundColor,
            borderColor: this.properties.borderColor,
            borderWidth: `${this.properties.borderWidth}px`,
            height: `${this.properties.height}px`,
            padding: `${this.properties.padding}px`,
            gap: `${this.properties.spacing}px`
        });
    }

    /**
     * Handle button click
     */
    _handleClick(button) {
        if (!button.enabled) return;
        
        // Toggle if applicable
        if (button.toggle) {
            button.togglePressed();
        }
        
        // Fire callbacks
        if (this._onClick) {
            this._onClick(button);
        }
        
        if (button.command && this._onCommand) {
            this._onCommand(button.command, button);
        }
    }

    /**
     * Start auto-hide timer
     */
    _startAutoHide() {
        if (!this.properties.autoHide) return;
        
        this._cancelAutoHide();
        this._hideTimer = setTimeout(() => {
            if (!this._isHovered) {
                this.hide();
            }
        }, this.properties.autoHideDelay);
    }

    /**
     * Cancel auto-hide timer
     */
    _cancelAutoHide() {
        if (this._hideTimer) {
            clearTimeout(this._hideTimer);
            this._hideTimer = null;
        }
    }

    /**
     * Show toolbar
     */
    show() {
        this.properties.visible = true;
        if (this._element) {
            this._element.style.display = '';
            this._element.style.opacity = '1';
        }
    }

    /**
     * Hide toolbar
     */
    hide() {
        if (this._element) {
            this._element.style.opacity = '0';
        }
    }

    /**
     * Toggle visibility
     */
    toggle() {
        if (this.properties.visible) {
            this.hide();
        } else {
            this.show();
        }
    }

    /**
     * Update button state
     */
    updateButton(id, updates) {
        const button = this.getButton(id);
        if (button) {
            Object.assign(button, updates);
            button.updateElement();
        }
    }

    /**
     * Enable button
     */
    enableButton(id) {
        this.updateButton(id, { enabled: true });
    }

    /**
     * Disable button
     */
    disableButton(id) {
        this.updateButton(id, { enabled: false });
    }

    /**
     * Unmount toolbar
     */
    unmount() {
        this._cancelAutoHide();
        if (this._element && this._element.parentNode) {
            this._element.parentNode.removeChild(this._element);
        }
        this._element = null;
        this._container = null;
    }

    /**
     * Create default VN toolbar buttons
     */
    createDefaultButtons() {
        this.addButton('prev', { icon: '⏮️', tooltip: 'Previous', command: 'prev' });
        this.addButton('play', { icon: '▶️', tooltip: 'Play/Pause', command: 'play', toggle: true });
        this.addButton('next', { icon: '⏭️', tooltip: 'Next', command: 'next' });
        this.addSeparator();
        this.addButton('save', { icon: '💾', tooltip: 'Save', command: 'save' });
        this.addButton('load', { icon: '📂', tooltip: 'Load', command: 'load' });
        this.addSeparator();
        this.addButton('volume', { icon: '🔊', tooltip: 'Volume', command: 'volume', toggle: true });
        this.addButton('fullscreen', { icon: '⛶', tooltip: 'Fullscreen', command: 'fullscreen', toggle: true });
        this.addSeparator();
        this.addButton('prefs', { icon: '⚙️', tooltip: 'Settings', command: 'prefs' });
        this.addButton('about', { icon: 'ℹ️', tooltip: 'About', command: 'about' });
        
        return this;
    }

    serialize() {
        return {
            ...super.serialize(),
            properties: this.properties.serialize(),
            buttons: this.buttons.map(b => b.serialize())
        };
    }

    deserialize(data) {
        super.deserialize(data);
        if (data.properties) this.properties.deserialize(data.properties);
        if (data.buttons) {
            this.buttons = data.buttons.map(btnData => {
                const btn = new VNToolBarButton(btnData.id);
                Object.assign(btn, btnData);
                return btn;
            });
        }
        return this;
    }
}

/**
 * Inject toolbar styles
 */
export function injectToolbarStyles() {
    if (document.getElementById('vn-toolbar-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'vn-toolbar-styles';
    style.textContent = `
        .vn-toolbar {
            display: flex;
            align-items: center;
            position: absolute;
            z-index: 1000;
            transition: opacity 0.3s ease;
            border-style: solid;
        }
        
        .vn-toolbar-top {
            top: 0;
            left: 0;
            right: 0;
            border-bottom-width: 1px;
        }
        
        .vn-toolbar-bottom {
            bottom: 0;
            left: 0;
            right: 0;
            border-top-width: 1px;
        }
        
        .vn-toolbar-left {
            top: 0;
            left: 0;
            bottom: 0;
            flex-direction: column;
            border-right-width: 1px;
        }
        
        .vn-toolbar-right {
            top: 0;
            right: 0;
            bottom: 0;
            flex-direction: column;
            border-left-width: 1px;
        }
        
        .vn-toolbar-floating {
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        
        .vn-toolbar-button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border: none;
            background: transparent;
            cursor: pointer;
            font-size: 18px;
            border-radius: 4px;
            transition: background 0.2s;
        }
        
        .vn-toolbar-button:hover:not(:disabled) {
            background: rgba(255,255,255,0.1);
        }
        
        .vn-toolbar-button:active:not(:disabled) {
            background: rgba(255,255,255,0.2);
        }
        
        .vn-toolbar-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .vn-toolbar-button.pressed {
            background: rgba(255,255,255,0.2);
        }
        
        .vn-toolbar-button img {
            width: 20px;
            height: 20px;
        }
        
        .vn-toolbar-separator {
            width: 1px;
            height: 24px;
            background: rgba(255,255,255,0.2);
            margin: 0 4px;
        }
        
        .vn-toolbar-left .vn-toolbar-separator,
        .vn-toolbar-right .vn-toolbar-separator {
            width: 24px;
            height: 1px;
            margin: 4px 0;
        }
    `;
    document.head.appendChild(style);
}

export default {
    VNToolBarProperties,
    VNToolBarButton,
    VNToolBar,
    injectToolbarStyles
};
