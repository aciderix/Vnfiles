/**
 * VNControls - UI Control classes
 * 
 * Port of OWL UI control classes:
 * TButton, TCheckBox, TStatic, TGauge, TUIHandle, TUIMetric
 * 
 * Original addresses from europeo.exe:
 * - TButton: 0x0042c403
 * - TCheckBox: 0x0042c277
 * - TStatic: 0x00437a09
 * - TGauge: 0x0042c824
 * - TUIHandle: 0x00453816
 * - TUIMetric: 0x00451c00
 */

import { TRect, TPoint } from '../graphics/VNGdi.js';

// ============================================================================
// TUIMetric - System UI metrics
// Original: @TUIMetric@CxScreen (0x00451c30), @TUIMetric@CyScreen (0x00451c18)
//           @TUIMetric@CxDoubleClk (0x00451c92), @TUIMetric@CyDoubleClk (0x00451c00)
// ============================================================================
export class TUIMetric {
    static get CxScreen() {
        return window.innerWidth;
    }

    static get CyScreen() {
        return window.innerHeight;
    }

    static get CxDoubleClk() {
        return 4; // Default double-click width
    }

    static get CyDoubleClk() {
        return 4; // Default double-click height
    }

    static get CxBorder() {
        return 1;
    }

    static get CyBorder() {
        return 1;
    }

    static get CxEdge() {
        return 2;
    }

    static get CyEdge() {
        return 2;
    }

    static get CxIcon() {
        return 32;
    }

    static get CyIcon() {
        return 32;
    }

    static get CxSmIcon() {
        return 16;
    }

    static get CySmIcon() {
        return 16;
    }

    static get CxCursor() {
        return 32;
    }

    static get CyCursor() {
        return 32;
    }

    static get CxVScroll() {
        return 17;
    }

    static get CyHScroll() {
        return 17;
    }

    static get CyCaption() {
        return 22;
    }

    static get CySmCaption() {
        return 15;
    }

    static get CyMenu() {
        return 20;
    }
}

// ============================================================================
// TUIHandle - UI handle for resizing/moving
// Original: 0x00453816
// Methods: @TUIHandle@Paint$xqr3TDC (0x0045374e)
//          @TUIHandle@HitTest$xqrx6TPoint (0x0045377e)
//          @TUIHandle@GetCursorId$q16TUIHandle@TWhere (0x004537bc)
//          @TUIHandle@$bctr$qrx5TRectuii (0x00450816)
// ============================================================================
export class TUIHandle {
    // Handle locations
    static Where = {
        TopLeft: 0,
        TopCenter: 1,
        TopRight: 2,
        MidLeft: 3,
        MidRight: 4,
        BottomLeft: 5,
        BottomCenter: 6,
        BottomRight: 7,
        Inside: 8,
        Outside: -1
    };

    // Cursor IDs for each location
    static Cursors = {
        [TUIHandle.Where.TopLeft]: 'nw-resize',
        [TUIHandle.Where.TopCenter]: 'n-resize',
        [TUIHandle.Where.TopRight]: 'ne-resize',
        [TUIHandle.Where.MidLeft]: 'w-resize',
        [TUIHandle.Where.MidRight]: 'e-resize',
        [TUIHandle.Where.BottomLeft]: 'sw-resize',
        [TUIHandle.Where.BottomCenter]: 's-resize',
        [TUIHandle.Where.BottomRight]: 'se-resize',
        [TUIHandle.Where.Inside]: 'move',
        [TUIHandle.Where.Outside]: 'default'
    };

    /**
     * Constructor
     * Original: @TUIHandle@$bctr$qrx5TRectuii at 0x00450816
     */
    constructor(rect, handleSize = 8, options = 0) {
        this._rect = rect.clone();
        this._handleSize = handleSize;
        this._options = options;
        this._visible = true;
        this._enabled = true;
    }

    /**
     * Get handle rectangles
     */
    getHandleRects() {
        const r = this._rect;
        const s = this._handleSize;
        const hs = s / 2;
        
        return {
            [TUIHandle.Where.TopLeft]: new TRect(r.left - hs, r.top - hs, r.left + hs, r.top + hs),
            [TUIHandle.Where.TopCenter]: new TRect(r.left + r.width/2 - hs, r.top - hs, r.left + r.width/2 + hs, r.top + hs),
            [TUIHandle.Where.TopRight]: new TRect(r.right - hs, r.top - hs, r.right + hs, r.top + hs),
            [TUIHandle.Where.MidLeft]: new TRect(r.left - hs, r.top + r.height/2 - hs, r.left + hs, r.top + r.height/2 + hs),
            [TUIHandle.Where.MidRight]: new TRect(r.right - hs, r.top + r.height/2 - hs, r.right + hs, r.top + r.height/2 + hs),
            [TUIHandle.Where.BottomLeft]: new TRect(r.left - hs, r.bottom - hs, r.left + hs, r.bottom + hs),
            [TUIHandle.Where.BottomCenter]: new TRect(r.left + r.width/2 - hs, r.bottom - hs, r.left + r.width/2 + hs, r.bottom + hs),
            [TUIHandle.Where.BottomRight]: new TRect(r.right - hs, r.bottom - hs, r.right + hs, r.bottom + hs)
        };
    }

    /**
     * Paint handles
     * Original: @TUIHandle@Paint$xqr3TDC at 0x0045374e
     */
    paint(dc) {
        if (!this._visible) return;
        
        const ctx = dc._ctx;
        if (!ctx) return;
        
        const handles = this.getHandleRects();
        
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 1;
        
        for (const where in handles) {
            const hr = handles[where];
            ctx.fillRect(hr.left, hr.top, hr.width, hr.height);
            ctx.strokeRect(hr.left, hr.top, hr.width, hr.height);
        }
    }

    /**
     * Hit test
     * Original: @TUIHandle@HitTest$xqrx6TPoint at 0x0045377e
     */
    hitTest(point) {
        const handles = this.getHandleRects();
        
        // Check each handle
        for (const where in handles) {
            if (handles[where].contains(point)) {
                return parseInt(where);
            }
        }
        
        // Check inside
        if (this._rect.contains(point)) {
            return TUIHandle.Where.Inside;
        }
        
        return TUIHandle.Where.Outside;
    }

    /**
     * Get cursor ID for location
     * Original: @TUIHandle@GetCursorId$q16TUIHandle@TWhere at 0x004537bc
     */
    getCursorId(where) {
        return TUIHandle.Cursors[where] || 'default';
    }

    /**
     * Move rectangle
     */
    move(dx, dy) {
        this._rect.offset(dx, dy);
    }

    /**
     * Resize based on handle location
     */
    resize(where, dx, dy) {
        switch (where) {
            case TUIHandle.Where.TopLeft:
                this._rect.left += dx;
                this._rect.top += dy;
                break;
            case TUIHandle.Where.TopCenter:
                this._rect.top += dy;
                break;
            case TUIHandle.Where.TopRight:
                this._rect.right += dx;
                this._rect.top += dy;
                break;
            case TUIHandle.Where.MidLeft:
                this._rect.left += dx;
                break;
            case TUIHandle.Where.MidRight:
                this._rect.right += dx;
                break;
            case TUIHandle.Where.BottomLeft:
                this._rect.left += dx;
                this._rect.bottom += dy;
                break;
            case TUIHandle.Where.BottomCenter:
                this._rect.bottom += dy;
                break;
            case TUIHandle.Where.BottomRight:
                this._rect.right += dx;
                this._rect.bottom += dy;
                break;
            case TUIHandle.Where.Inside:
                this._rect.offset(dx, dy);
                break;
        }
        
        this._rect.normalize();
    }

    /**
     * Get rectangle
     */
    getRect() {
        return this._rect.clone();
    }

    /**
     * Set rectangle
     */
    setRect(rect) {
        this._rect = rect.clone();
    }
}

// ============================================================================
// TControl - Base control class
// ============================================================================
export class TControl {
    constructor(parent = null, id = 0) {
        this._parent = parent;
        this._id = id;
        this._rect = new TRect();
        this._text = '';
        this._visible = true;
        this._enabled = true;
        this._focused = false;
        this._style = 0;
        this._element = null;
    }

    // Accessors
    get id() { return this._id; }
    get text() { return this._text; }
    set text(v) { this._text = v; this._updateElement(); }
    get visible() { return this._visible; }
    set visible(v) { this._visible = v; this._updateElement(); }
    get enabled() { return this._enabled; }
    set enabled(v) { this._enabled = v; this._updateElement(); }

    /**
     * Get window text
     */
    getText() {
        return this._text;
    }

    /**
     * Set window text
     */
    setText(text) {
        this._text = text;
        this._updateElement();
    }

    /**
     * Show window
     */
    show(show = true) {
        this._visible = show;
        this._updateElement();
    }

    /**
     * Hide window
     */
    hide() {
        this.show(false);
    }

    /**
     * Enable window
     */
    enable(enable = true) {
        this._enabled = enable;
        this._updateElement();
    }

    /**
     * Disable window
     */
    disable() {
        this.enable(false);
    }

    /**
     * Set focus
     */
    setFocus() {
        this._focused = true;
        if (this._element) {
            this._element.focus();
        }
    }

    /**
     * Get rectangle
     */
    getRect() {
        return this._rect.clone();
    }

    /**
     * Set rectangle
     */
    setRect(rect) {
        this._rect = rect.clone();
        this._updateElement();
    }

    /**
     * Move window
     */
    move(x, y, width, height) {
        this._rect.left = x;
        this._rect.top = y;
        this._rect.right = x + width;
        this._rect.bottom = y + height;
        this._updateElement();
    }

    /**
     * Create element
     */
    create() {
        // Override in subclasses
    }

    /**
     * Destroy element
     */
    destroy() {
        if (this._element && this._element.parentNode) {
            this._element.parentNode.removeChild(this._element);
        }
        this._element = null;
    }

    /**
     * Update element from properties
     */
    _updateElement() {
        if (!this._element) return;
        
        this._element.style.left = this._rect.left + 'px';
        this._element.style.top = this._rect.top + 'px';
        this._element.style.width = this._rect.width + 'px';
        this._element.style.height = this._rect.height + 'px';
        this._element.style.display = this._visible ? '' : 'none';
        this._element.disabled = !this._enabled;
    }
}

// ============================================================================
// TStatic - Static text control
// Original: 0x00437a09
// Methods: @TStatic@$bctr$qp7TWindowiuip7TModule at 0x00453852
// ============================================================================
export class TStatic extends TControl {
    // Styles
    static Style = {
        SS_LEFT: 0x0000,
        SS_CENTER: 0x0001,
        SS_RIGHT: 0x0002,
        SS_ICON: 0x0003,
        SS_BLACKRECT: 0x0004,
        SS_GRAYRECT: 0x0005,
        SS_WHITERECT: 0x0006,
        SS_BLACKFRAME: 0x0007,
        SS_GRAYFRAME: 0x0008,
        SS_WHITEFRAME: 0x0009,
        SS_SIMPLE: 0x000B,
        SS_SUNKEN: 0x1000
    };

    /**
     * Constructor
     * Original: @TStatic@$bctr$qp7TWindowiuip7TModule at 0x00453852
     */
    constructor(parent, id = 0, text = '', style = TStatic.Style.SS_LEFT) {
        super(parent, id);
        this._text = text;
        this._style = style;
    }

    /**
     * Create DOM element
     */
    create() {
        this._element = document.createElement('div');
        this._element.className = 'vn-static';
        this._element.textContent = this._text;
        this._element.style.position = 'absolute';
        
        // Apply style
        if (this._style & TStatic.Style.SS_CENTER) {
            this._element.style.textAlign = 'center';
        } else if (this._style & TStatic.Style.SS_RIGHT) {
            this._element.style.textAlign = 'right';
        }
        
        if (this._style & TStatic.Style.SS_SUNKEN) {
            this._element.style.borderStyle = 'inset';
            this._element.style.borderWidth = '2px';
        }
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    _updateElement() {
        super._updateElement();
        if (this._element) {
            this._element.textContent = this._text;
        }
    }
}

// ============================================================================
// TButton - Button control
// Original: 0x0042c403
// Methods: @TButton@$bdtr$qv at 0x004535f0
// ============================================================================
export class TButton extends TControl {
    // Styles
    static Style = {
        BS_PUSHBUTTON: 0x0000,
        BS_DEFPUSHBUTTON: 0x0001,
        BS_CHECKBOX: 0x0002,
        BS_AUTOCHECKBOX: 0x0003,
        BS_RADIOBUTTON: 0x0004,
        BS_3STATE: 0x0005,
        BS_AUTO3STATE: 0x0006,
        BS_GROUPBOX: 0x0007,
        BS_AUTORADIOBUTTON: 0x0009,
        BS_OWNERDRAW: 0x000B,
        BS_FLAT: 0x8000
    };

    // Button states
    static State = {
        BST_UNCHECKED: 0x0000,
        BST_CHECKED: 0x0001,
        BST_INDETERMINATE: 0x0002,
        BST_PUSHED: 0x0004,
        BST_FOCUS: 0x0008
    };

    constructor(parent, id = 0, text = '', style = TButton.Style.BS_PUSHBUTTON) {
        super(parent, id);
        this._text = text;
        this._style = style;
        this._state = TButton.State.BST_UNCHECKED;
        this._onClick = null;
    }

    /**
     * Create DOM element
     */
    create() {
        this._element = document.createElement('button');
        this._element.className = 'vn-button';
        this._element.textContent = this._text;
        this._element.style.position = 'absolute';
        
        if (this._style & TButton.Style.BS_FLAT) {
            this._element.style.border = 'none';
            this._element.style.background = 'transparent';
        }
        
        if (this._style & TButton.Style.BS_DEFPUSHBUTTON) {
            this._element.style.fontWeight = 'bold';
        }
        
        this._element.addEventListener('click', () => {
            if (this._onClick) {
                this._onClick(this);
            }
        });
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    /**
     * Set click handler
     */
    onClick(handler) {
        this._onClick = handler;
    }

    /**
     * Click button
     */
    click() {
        if (this._onClick) {
            this._onClick(this);
        }
    }

    /**
     * Destructor
     * Original: @TButton@$bdtr$qv at 0x004535f0
     */
    destroy() {
        this._onClick = null;
        super.destroy();
    }

    _updateElement() {
        super._updateElement();
        if (this._element) {
            this._element.textContent = this._text;
        }
    }
}

// ============================================================================
// TCheckBox - Checkbox control
// Original: 0x0042c277
// Methods: @TCheckBox@SetCheck$qui at 0x00453302
//          @TCheckBox@$bdtr$qv at 0x0045341e
//          @TCheckBox@$bctr$qp7TWindowip9TGroupBoxp7TModule at 0x004534f4
// ============================================================================
export class TCheckBox extends TControl {
    // Check states
    static State = {
        BF_UNCHECKED: 0,
        BF_CHECKED: 1,
        BF_GRAYED: 2
    };

    /**
     * Constructor
     * Original: @TCheckBox@$bctr$qp7TWindowip9TGroupBoxp7TModule at 0x004534f4
     */
    constructor(parent, id = 0, text = '', groupBox = null) {
        super(parent, id);
        this._text = text;
        this._groupBox = groupBox;
        this._checked = TCheckBox.State.BF_UNCHECKED;
        this._onChange = null;
    }

    /**
     * Create DOM element
     */
    create() {
        const container = document.createElement('div');
        container.className = 'vn-checkbox-container';
        container.style.position = 'absolute';
        
        this._input = document.createElement('input');
        this._input.type = 'checkbox';
        this._input.id = 'checkbox_' + this._id;
        this._input.className = 'vn-checkbox';
        
        this._label = document.createElement('label');
        this._label.htmlFor = this._input.id;
        this._label.textContent = this._text;
        
        container.appendChild(this._input);
        container.appendChild(this._label);
        
        this._element = container;
        
        this._input.addEventListener('change', () => {
            this._checked = this._input.checked ? 
                TCheckBox.State.BF_CHECKED : TCheckBox.State.BF_UNCHECKED;
            if (this._onChange) {
                this._onChange(this);
            }
        });
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    /**
     * Get check state
     */
    getCheck() {
        return this._checked;
    }

    /**
     * Set check state
     * Original: @TCheckBox@SetCheck$qui at 0x00453302
     */
    setCheck(state) {
        this._checked = state;
        if (this._input) {
            this._input.checked = (state === TCheckBox.State.BF_CHECKED);
            this._input.indeterminate = (state === TCheckBox.State.BF_GRAYED);
        }
    }

    /**
     * Toggle check
     */
    toggle() {
        if (this._checked === TCheckBox.State.BF_CHECKED) {
            this.setCheck(TCheckBox.State.BF_UNCHECKED);
        } else {
            this.setCheck(TCheckBox.State.BF_CHECKED);
        }
    }

    /**
     * Set change handler
     */
    onChange(handler) {
        this._onChange = handler;
    }

    /**
     * Destructor
     * Original: @TCheckBox@$bdtr$qv at 0x0045341e
     */
    destroy() {
        this._onChange = null;
        this._input = null;
        this._label = null;
        super.destroy();
    }

    _updateElement() {
        super._updateElement();
        if (this._label) {
            this._label.textContent = this._text;
        }
        if (this._input) {
            this._input.disabled = !this._enabled;
        }
    }
}

// ============================================================================
// TRadioButton - Radio button control
// ============================================================================
export class TRadioButton extends TControl {
    constructor(parent, id = 0, text = '', groupName = 'default') {
        super(parent, id);
        this._text = text;
        this._groupName = groupName;
        this._checked = false;
        this._onChange = null;
    }

    create() {
        const container = document.createElement('div');
        container.className = 'vn-radio-container';
        container.style.position = 'absolute';
        
        this._input = document.createElement('input');
        this._input.type = 'radio';
        this._input.id = 'radio_' + this._id;
        this._input.name = this._groupName;
        this._input.className = 'vn-radio';
        
        this._label = document.createElement('label');
        this._label.htmlFor = this._input.id;
        this._label.textContent = this._text;
        
        container.appendChild(this._input);
        container.appendChild(this._label);
        
        this._element = container;
        
        this._input.addEventListener('change', () => {
            this._checked = this._input.checked;
            if (this._onChange) {
                this._onChange(this);
            }
        });
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    getCheck() {
        return this._checked;
    }

    setCheck(checked) {
        this._checked = checked;
        if (this._input) {
            this._input.checked = checked;
        }
    }

    onChange(handler) {
        this._onChange = handler;
    }

    destroy() {
        this._onChange = null;
        this._input = null;
        this._label = null;
        super.destroy();
    }
}

// ============================================================================
// TGauge - Progress bar / gauge control
// Original: 0x0042c824
// Methods: @TGauge@StepIt$qv at 0x00452200
//          @TGauge@SetValue$qi at 0x00452268
//          @TGauge@SetStep$qi at 0x0045227e
//          @TGauge@SetRange$qii at 0x004522ba
//          @TGauge@$bctr$qp7TWindowip7TModule at 0x004522d2
// ============================================================================
export class TGauge extends TControl {
    /**
     * Constructor
     * Original: @TGauge@$bctr$qp7TWindowip7TModule at 0x004522d2
     */
    constructor(parent, id = 0) {
        super(parent, id);
        this._min = 0;
        this._max = 100;
        this._value = 0;
        this._step = 1;
        this._isLed = false;
        this._ledCount = 10;
        this._ledSpacing = 2;
        this._barColor = '#0078D7';
        this._backgroundColor = '#E0E0E0';
    }

    /**
     * Create DOM element
     */
    create() {
        this._element = document.createElement('div');
        this._element.className = 'vn-gauge';
        this._element.style.position = 'absolute';
        this._element.style.backgroundColor = this._backgroundColor;
        this._element.style.border = '1px solid #999';
        this._element.style.overflow = 'hidden';
        
        this._bar = document.createElement('div');
        this._bar.className = 'vn-gauge-bar';
        this._bar.style.height = '100%';
        this._bar.style.backgroundColor = this._barColor;
        this._bar.style.transition = 'width 0.1s ease-out';
        
        this._element.appendChild(this._bar);
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    /**
     * Get current value
     */
    getValue() {
        return this._value;
    }

    /**
     * Set value
     * Original: @TGauge@SetValue$qi at 0x00452268
     */
    setValue(value) {
        this._value = Math.max(this._min, Math.min(this._max, value));
        this._updateBar();
    }

    /**
     * Set range
     * Original: @TGauge@SetRange$qii at 0x004522ba
     */
    setRange(min, max) {
        this._min = min;
        this._max = max;
        this._value = Math.max(min, Math.min(max, this._value));
        this._updateBar();
    }

    /**
     * Set step
     * Original: @TGauge@SetStep$qi at 0x0045227e
     */
    setStep(step) {
        this._step = step;
    }

    /**
     * Step forward
     * Original: @TGauge@StepIt$qv at 0x00452200
     */
    stepIt() {
        this.setValue(this._value + this._step);
        return this._value;
    }

    /**
     * Step backward
     */
    stepBack() {
        this.setValue(this._value - this._step);
        return this._value;
    }

    /**
     * Set LED mode
     */
    setLed(isLed, count = 10) {
        this._isLed = isLed;
        this._ledCount = count;
        this._updateBar();
    }

    /**
     * Set colors
     */
    setColors(barColor, backgroundColor) {
        this._barColor = barColor;
        this._backgroundColor = backgroundColor;
        if (this._element) {
            this._element.style.backgroundColor = backgroundColor;
        }
        if (this._bar) {
            this._bar.style.backgroundColor = barColor;
        }
    }

    /**
     * Update bar display
     */
    _updateBar() {
        if (!this._bar) return;
        
        const range = this._max - this._min;
        const percent = range > 0 ? ((this._value - this._min) / range) * 100 : 0;
        
        if (this._isLed) {
            // LED style - create segments
            const activeCount = Math.floor((percent / 100) * this._ledCount);
            this._bar.style.width = percent + '%';
            this._bar.style.background = `repeating-linear-gradient(
                90deg,
                ${this._barColor} 0px,
                ${this._barColor} ${100/this._ledCount - 1}%,
                transparent ${100/this._ledCount - 1}%,
                transparent ${100/this._ledCount}%
            )`;
        } else {
            this._bar.style.width = percent + '%';
            this._bar.style.background = this._barColor;
        }
    }

    _updateElement() {
        super._updateElement();
        this._updateBar();
    }
}

// ============================================================================
// TSlider - Slider/trackbar control
// ============================================================================
export class TSlider extends TControl {
    constructor(parent, id = 0) {
        super(parent, id);
        this._min = 0;
        this._max = 100;
        this._value = 0;
        this._tickFreq = 10;
        this._onChange = null;
    }

    create() {
        this._element = document.createElement('div');
        this._element.className = 'vn-slider-container';
        this._element.style.position = 'absolute';
        
        this._input = document.createElement('input');
        this._input.type = 'range';
        this._input.className = 'vn-slider';
        this._input.min = this._min;
        this._input.max = this._max;
        this._input.value = this._value;
        this._input.style.width = '100%';
        
        this._element.appendChild(this._input);
        
        this._input.addEventListener('input', () => {
            this._value = parseInt(this._input.value);
            if (this._onChange) {
                this._onChange(this);
            }
        });
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    getValue() {
        return this._value;
    }

    setValue(value) {
        this._value = Math.max(this._min, Math.min(this._max, value));
        if (this._input) {
            this._input.value = this._value;
        }
    }

    setRange(min, max) {
        this._min = min;
        this._max = max;
        if (this._input) {
            this._input.min = min;
            this._input.max = max;
        }
    }

    onChange(handler) {
        this._onChange = handler;
    }

    destroy() {
        this._onChange = null;
        this._input = null;
        super.destroy();
    }
}

// ============================================================================
// TGroupBox - Group box control
// ============================================================================
export class TGroupBox extends TControl {
    constructor(parent, id = 0, text = '') {
        super(parent, id);
        this._text = text;
    }

    create() {
        this._element = document.createElement('fieldset');
        this._element.className = 'vn-groupbox';
        this._element.style.position = 'absolute';
        
        this._legend = document.createElement('legend');
        this._legend.textContent = this._text;
        
        this._element.appendChild(this._legend);
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    _updateElement() {
        super._updateElement();
        if (this._legend) {
            this._legend.textContent = this._text;
        }
    }
}

// ============================================================================
// TEdit - Edit control (text input)
// ============================================================================
export class TEdit extends TControl {
    static Style = {
        ES_LEFT: 0x0000,
        ES_CENTER: 0x0001,
        ES_RIGHT: 0x0002,
        ES_MULTILINE: 0x0004,
        ES_PASSWORD: 0x0020,
        ES_READONLY: 0x0800,
        ES_NUMBER: 0x2000
    };

    constructor(parent, id = 0, text = '', style = TEdit.Style.ES_LEFT) {
        super(parent, id);
        this._text = text;
        this._style = style;
        this._maxLength = 0;
        this._onChange = null;
    }

    create() {
        if (this._style & TEdit.Style.ES_MULTILINE) {
            this._element = document.createElement('textarea');
        } else {
            this._element = document.createElement('input');
            
            if (this._style & TEdit.Style.ES_PASSWORD) {
                this._element.type = 'password';
            } else if (this._style & TEdit.Style.ES_NUMBER) {
                this._element.type = 'number';
            } else {
                this._element.type = 'text';
            }
        }
        
        this._element.className = 'vn-edit';
        this._element.style.position = 'absolute';
        this._element.value = this._text;
        
        if (this._style & TEdit.Style.ES_CENTER) {
            this._element.style.textAlign = 'center';
        } else if (this._style & TEdit.Style.ES_RIGHT) {
            this._element.style.textAlign = 'right';
        }
        
        if (this._style & TEdit.Style.ES_READONLY) {
            this._element.readOnly = true;
        }
        
        if (this._maxLength > 0) {
            this._element.maxLength = this._maxLength;
        }
        
        this._element.addEventListener('input', () => {
            this._text = this._element.value;
            if (this._onChange) {
                this._onChange(this);
            }
        });
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    getText() {
        return this._text;
    }

    setText(text) {
        this._text = text;
        if (this._element) {
            this._element.value = text;
        }
    }

    setMaxLength(length) {
        this._maxLength = length;
        if (this._element) {
            this._element.maxLength = length;
        }
    }

    setReadOnly(readOnly) {
        if (this._element) {
            this._element.readOnly = readOnly;
        }
    }

    selectAll() {
        if (this._element) {
            this._element.select();
        }
    }

    onChange(handler) {
        this._onChange = handler;
    }

    destroy() {
        this._onChange = null;
        super.destroy();
    }

    _updateElement() {
        super._updateElement();
        if (this._element) {
            this._element.value = this._text;
        }
    }
}

// ============================================================================
// TListBox - List box control
// ============================================================================
export class TListBox extends TControl {
    constructor(parent, id = 0) {
        super(parent, id);
        this._items = [];
        this._selectedIndex = -1;
        this._onChange = null;
    }

    create() {
        this._element = document.createElement('select');
        this._element.className = 'vn-listbox';
        this._element.style.position = 'absolute';
        this._element.size = 5; // Show multiple items
        
        this._updateItems();
        
        this._element.addEventListener('change', () => {
            this._selectedIndex = this._element.selectedIndex;
            if (this._onChange) {
                this._onChange(this);
            }
        });
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }

    addString(str) {
        this._items.push(str);
        this._updateItems();
        return this._items.length - 1;
    }

    insertString(index, str) {
        this._items.splice(index, 0, str);
        this._updateItems();
        return index;
    }

    deleteString(index) {
        this._items.splice(index, 1);
        this._updateItems();
    }

    clearList() {
        this._items = [];
        this._selectedIndex = -1;
        this._updateItems();
    }

    getCount() {
        return this._items.length;
    }

    getString(index) {
        return this._items[index] || '';
    }

    getSelectedIndex() {
        return this._selectedIndex;
    }

    setSelectedIndex(index) {
        this._selectedIndex = index;
        if (this._element) {
            this._element.selectedIndex = index;
        }
    }

    onChange(handler) {
        this._onChange = handler;
    }

    _updateItems() {
        if (!this._element) return;
        
        this._element.innerHTML = '';
        for (const item of this._items) {
            const option = document.createElement('option');
            option.textContent = item;
            this._element.appendChild(option);
        }
        
        if (this._selectedIndex >= 0 && this._selectedIndex < this._items.length) {
            this._element.selectedIndex = this._selectedIndex;
        }
    }

    destroy() {
        this._onChange = null;
        this._items = [];
        super.destroy();
    }
}

// ============================================================================
// TComboBox - Combo box control
// ============================================================================
export class TComboBox extends TListBox {
    create() {
        this._element = document.createElement('select');
        this._element.className = 'vn-combobox';
        this._element.style.position = 'absolute';
        this._element.size = 1; // Dropdown style
        
        this._updateItems();
        
        this._element.addEventListener('change', () => {
            this._selectedIndex = this._element.selectedIndex;
            if (this._onChange) {
                this._onChange(this);
            }
        });
        
        this._updateElement();
        
        if (this._parent && this._parent._element) {
            this._parent._element.appendChild(this._element);
        }
        
        return true;
    }
}

export default {
    TUIMetric,
    TUIHandle,
    TControl,
    TStatic,
    TButton,
    TCheckBox,
    TRadioButton,
    TGauge,
    TSlider,
    TGroupBox,
    TEdit,
    TListBox,
    TComboBox
};
