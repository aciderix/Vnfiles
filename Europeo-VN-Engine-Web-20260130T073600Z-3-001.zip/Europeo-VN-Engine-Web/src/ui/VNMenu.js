/**
 * VNMenu - Menu System
 * 
 * EXACT PORT from OWL TMenu, TPopupMenu classes
 * 
 * Original classes from disassembly:
 * - TMenu @ 0x00453e04
 * - TPopupMenu @ 0x00453a1e
 * 
 * Key functions:
 * - @TMenu@GetMenuItemID$xqi @ 0x00453dcc
 * - @TMenu@$bdtr$qv @ 0x00453e04
 * - @TPopupMenu@$bctr$q11TAutoDelete @ 0x00453a1e
 * - GetMenuItemCount @ 0x00451f42
 * - InsertMenuA @ 0x00451f80
 */

/**
 * Menu item flags
 */
export const MF = {
    STRING: 0x0000,
    POPUP: 0x0010,
    SEPARATOR: 0x0800,
    ENABLED: 0x0000,
    GRAYED: 0x0001,
    DISABLED: 0x0002,
    CHECKED: 0x0008,
    UNCHECKED: 0x0000,
    MENUBARBREAK: 0x0020,
    MENUBREAK: 0x0040,
    BITMAP: 0x0004,
    OWNERDRAW: 0x0100
};

/**
 * VNMenuItem - Single menu item
 */
export class VNMenuItem {
    /**
     * @param {Object} options 
     */
    constructor(options = {}) {
        this.id = options.id || 0;
        this.text = options.text || '';
        this.flags = options.flags || MF.STRING;
        this.enabled = options.enabled !== false;
        this.checked = options.checked || false;
        this.submenu = options.submenu || null;
        this.icon = options.icon || null;
        this.shortcut = options.shortcut || '';
        this.userData = options.userData || null;
        this.onClick = options.onClick || null;
    }

    /**
     * Check if this is a separator
     * @returns {boolean}
     */
    isSeparator() {
        return (this.flags & MF.SEPARATOR) !== 0;
    }

    /**
     * Check if this has a submenu
     * @returns {boolean}
     */
    hasSubmenu() {
        return this.submenu !== null;
    }

    /**
     * Set enabled state
     * @param {boolean} enabled 
     */
    setEnabled(enabled) {
        this.enabled = enabled;
        if (enabled) {
            this.flags &= ~(MF.GRAYED | MF.DISABLED);
        } else {
            this.flags |= MF.GRAYED;
        }
    }

    /**
     * Set checked state
     * @param {boolean} checked 
     */
    setChecked(checked) {
        this.checked = checked;
        if (checked) {
            this.flags |= MF.CHECKED;
        } else {
            this.flags &= ~MF.CHECKED;
        }
    }

    /**
     * Clone this menu item
     * @returns {VNMenuItem}
     */
    clone() {
        return new VNMenuItem({
            id: this.id,
            text: this.text,
            flags: this.flags,
            enabled: this.enabled,
            checked: this.checked,
            submenu: this.submenu?.clone(),
            icon: this.icon,
            shortcut: this.shortcut,
            userData: this.userData,
            onClick: this.onClick
        });
    }
}

/**
 * VNMenu - Menu container
 * Port of TMenu
 */
export class VNMenu {
    constructor() {
        this.items = [];
        this.autoDelete = true;
    }

    /**
     * Get item count
     * Port of GetMenuItemCount @ 0x00451f42
     * @returns {number}
     */
    getItemCount() {
        return this.items.length;
    }

    /**
     * Get menu item ID at position
     * Port of @TMenu@GetMenuItemID$xqi @ 0x00453dcc
     * @param {number} pos 
     * @returns {number}
     */
    getMenuItemID(pos) {
        if (pos >= 0 && pos < this.items.length) {
            return this.items[pos].id;
        }
        return -1;
    }

    /**
     * Get menu item at position
     * @param {number} pos 
     * @returns {VNMenuItem|null}
     */
    getItem(pos) {
        return this.items[pos] || null;
    }

    /**
     * Find item by ID
     * @param {number} id 
     * @returns {VNMenuItem|null}
     */
    findItemById(id) {
        for (const item of this.items) {
            if (item.id === id) {
                return item;
            }
            if (item.submenu) {
                const found = item.submenu.findItemById(id);
                if (found) return found;
            }
        }
        return null;
    }

    /**
     * Append menu item
     * @param {VNMenuItem|Object} item 
     */
    append(item) {
        if (!(item instanceof VNMenuItem)) {
            item = new VNMenuItem(item);
        }
        this.items.push(item);
    }

    /**
     * Append separator
     */
    appendSeparator() {
        this.append(new VNMenuItem({ flags: MF.SEPARATOR }));
    }

    /**
     * Insert menu item
     * Port of InsertMenuA @ 0x00451f80
     * @param {number} pos 
     * @param {VNMenuItem|Object} item 
     */
    insert(pos, item) {
        if (!(item instanceof VNMenuItem)) {
            item = new VNMenuItem(item);
        }
        this.items.splice(pos, 0, item);
    }

    /**
     * Remove item at position
     * @param {number} pos 
     * @returns {VNMenuItem|null}
     */
    remove(pos) {
        if (pos >= 0 && pos < this.items.length) {
            return this.items.splice(pos, 1)[0];
        }
        return null;
    }

    /**
     * Remove item by ID
     * @param {number} id 
     * @returns {boolean}
     */
    removeById(id) {
        const index = this.items.findIndex(item => item.id === id);
        if (index !== -1) {
            this.items.splice(index, 1);
            return true;
        }
        return false;
    }

    /**
     * Clear all items
     */
    clear() {
        this.items = [];
    }

    /**
     * Enable item by ID
     * @param {number} id 
     * @param {boolean} enable 
     */
    enableItem(id, enable) {
        const item = this.findItemById(id);
        if (item) {
            item.setEnabled(enable);
        }
    }

    /**
     * Check item by ID
     * @param {number} id 
     * @param {boolean} check 
     */
    checkItem(id, check) {
        const item = this.findItemById(id);
        if (item) {
            item.setChecked(check);
        }
    }

    /**
     * Clone this menu
     * @returns {VNMenu}
     */
    clone() {
        const menu = new VNMenu();
        for (const item of this.items) {
            menu.append(item.clone());
        }
        return menu;
    }
}

/**
 * VNPopupMenu - Popup/context menu
 * Port of TPopupMenu @ 0x00453a1e
 */
export class VNPopupMenu extends VNMenu {
    constructor() {
        super();
        this.visible = false;
        this.x = 0;
        this.y = 0;
        this.element = null;
        this.selectedIndex = -1;
        this.onCommand = null;
        this._clickHandler = null;
    }

    /**
     * Show popup menu at position
     * @param {number} x 
     * @param {number} y 
     * @param {HTMLElement} parent 
     */
    show(x, y, parent = document.body) {
        this.x = x;
        this.y = y;
        this.visible = true;
        
        // Create menu element
        this._createMenuElement();
        
        // Position menu
        this.element.style.left = `${x}px`;
        this.element.style.top = `${y}px`;
        
        // Add to document
        parent.appendChild(this.element);
        
        // Add click outside handler
        this._clickHandler = (e) => {
            if (!this.element.contains(e.target)) {
                this.hide();
            }
        };
        setTimeout(() => {
            document.addEventListener('click', this._clickHandler);
        }, 0);
        
        // Adjust position if off-screen
        this._adjustPosition();
    }

    /**
     * Hide popup menu
     */
    hide() {
        this.visible = false;
        
        if (this._clickHandler) {
            document.removeEventListener('click', this._clickHandler);
            this._clickHandler = null;
        }
        
        if (this.element && this.element.parentNode) {
            this.element.parentNode.removeChild(this.element);
        }
        this.element = null;
    }

    /**
     * Create menu DOM element
     * @private
     */
    _createMenuElement() {
        this.element = document.createElement('div');
        this.element.className = 'vn-popup-menu';
        this.element.style.cssText = `
            position: fixed;
            background: #fff;
            border: 1px solid #ccc;
            box-shadow: 2px 2px 5px rgba(0,0,0,0.2);
            padding: 4px 0;
            min-width: 120px;
            z-index: 10000;
            font-family: Arial, sans-serif;
            font-size: 12px;
        `;
        
        for (let i = 0; i < this.items.length; i++) {
            const item = this.items[i];
            const itemEl = this._createItemElement(item, i);
            this.element.appendChild(itemEl);
        }
    }

    /**
     * Create menu item element
     * @private
     */
    _createItemElement(item, index) {
        const el = document.createElement('div');
        
        if (item.isSeparator()) {
            el.style.cssText = `
                height: 1px;
                background: #ccc;
                margin: 4px 8px;
            `;
        } else {
            el.className = 'vn-menu-item';
            el.style.cssText = `
                padding: 4px 24px 4px 24px;
                cursor: ${item.enabled ? 'pointer' : 'default'};
                color: ${item.enabled ? '#000' : '#999'};
                display: flex;
                justify-content: space-between;
                align-items: center;
            `;
            
            // Check mark
            if (item.checked) {
                el.style.paddingLeft = '8px';
                const check = document.createElement('span');
                check.textContent = '✓';
                check.style.marginRight = '8px';
                el.insertBefore(check, el.firstChild);
            }
            
            // Text
            const textSpan = document.createElement('span');
            textSpan.textContent = item.text.replace('&', '');
            el.appendChild(textSpan);
            
            // Shortcut
            if (item.shortcut) {
                const shortcutSpan = document.createElement('span');
                shortcutSpan.textContent = item.shortcut;
                shortcutSpan.style.color = '#888';
                shortcutSpan.style.marginLeft = '16px';
                el.appendChild(shortcutSpan);
            }
            
            // Submenu indicator
            if (item.hasSubmenu()) {
                const arrow = document.createElement('span');
                arrow.textContent = '▶';
                arrow.style.marginLeft = '16px';
                el.appendChild(arrow);
            }
            
            // Hover effect
            if (item.enabled) {
                el.addEventListener('mouseenter', () => {
                    el.style.background = '#0078d7';
                    el.style.color = '#fff';
                    this.selectedIndex = index;
                });
                
                el.addEventListener('mouseleave', () => {
                    el.style.background = '';
                    el.style.color = '#000';
                });
                
                // Click handler
                el.addEventListener('click', (e) => {
                    e.stopPropagation();
                    
                    if (item.hasSubmenu()) {
                        // Show submenu
                        // TODO: Implement submenu display
                    } else {
                        // Execute command
                        if (item.onClick) {
                            item.onClick(item);
                        }
                        if (this.onCommand) {
                            this.onCommand(item.id, item);
                        }
                        this.hide();
                    }
                });
            }
        }
        
        return el;
    }

    /**
     * Adjust menu position to stay on screen
     * @private
     */
    _adjustPosition() {
        if (!this.element) return;
        
        const rect = this.element.getBoundingClientRect();
        const viewWidth = window.innerWidth;
        const viewHeight = window.innerHeight;
        
        if (rect.right > viewWidth) {
            this.element.style.left = `${viewWidth - rect.width - 10}px`;
        }
        
        if (rect.bottom > viewHeight) {
            this.element.style.top = `${viewHeight - rect.height - 10}px`;
        }
    }

    /**
     * Track popup (show and wait for selection)
     * @param {number} x 
     * @param {number} y 
     * @param {HTMLElement} parent 
     * @returns {Promise<number>} - Selected item ID or 0
     */
    async trackPopup(x, y, parent = document.body) {
        return new Promise((resolve) => {
            const originalOnCommand = this.onCommand;
            
            this.onCommand = (id, item) => {
                this.onCommand = originalOnCommand;
                resolve(id);
            };
            
            // Also resolve with 0 if hidden without selection
            const checkHidden = setInterval(() => {
                if (!this.visible) {
                    clearInterval(checkHidden);
                    this.onCommand = originalOnCommand;
                    resolve(0);
                }
            }, 100);
            
            this.show(x, y, parent);
        });
    }
}

/**
 * VNMenuBar - Horizontal menu bar
 */
export class VNMenuBar extends VNMenu {
    constructor() {
        super();
        this.element = null;
        this.activeMenu = null;
        this.onCommand = null;
    }

    /**
     * Create menu bar
     * @param {HTMLElement} parent 
     */
    create(parent) {
        this.element = document.createElement('div');
        this.element.className = 'vn-menubar';
        this.element.style.cssText = `
            background: #f0f0f0;
            border-bottom: 1px solid #ccc;
            display: flex;
            font-family: Arial, sans-serif;
            font-size: 12px;
            user-select: none;
        `;
        
        for (const item of this.items) {
            const itemEl = this._createMenuBarItem(item);
            this.element.appendChild(itemEl);
        }
        
        parent.appendChild(this.element);
    }

    /**
     * Create menu bar item
     * @private
     */
    _createMenuBarItem(item) {
        const el = document.createElement('div');
        el.className = 'vn-menubar-item';
        el.style.cssText = `
            padding: 4px 12px;
            cursor: pointer;
        `;
        el.textContent = item.text.replace('&', '');
        
        el.addEventListener('mouseenter', () => {
            el.style.background = '#e0e0e0';
        });
        
        el.addEventListener('mouseleave', () => {
            el.style.background = '';
        });
        
        el.addEventListener('click', (e) => {
            if (item.hasSubmenu()) {
                const rect = el.getBoundingClientRect();
                const popup = new VNPopupMenu();
                popup.items = item.submenu.items;
                popup.onCommand = this.onCommand;
                popup.show(rect.left, rect.bottom);
                this.activeMenu = popup;
            }
        });
        
        return el;
    }

    /**
     * Destroy menu bar
     */
    destroy() {
        if (this.element && this.element.parentNode) {
            this.element.parentNode.removeChild(this.element);
        }
        this.element = null;
    }
}

/**
 * Standard menu IDs
 */
export const IDM = {
    // File menu
    FILE_NEW: 100,
    FILE_OPEN: 101,
    FILE_SAVE: 102,
    FILE_SAVEAS: 103,
    FILE_EXIT: 104,
    
    // Edit menu
    EDIT_UNDO: 110,
    EDIT_REDO: 111,
    EDIT_CUT: 112,
    EDIT_COPY: 113,
    EDIT_PASTE: 114,
    EDIT_DELETE: 115,
    EDIT_SELECTALL: 116,
    
    // View menu
    VIEW_TOOLBAR: 120,
    VIEW_STATUSBAR: 121,
    VIEW_FULLSCREEN: 122,
    
    // Help menu
    HELP_ABOUT: 130,
    HELP_CONTENTS: 131
};

/**
 * Create standard menus
 * @returns {VNMenuBar}
 */
export function createStandardMenuBar() {
    const menubar = new VNMenuBar();
    
    // File menu
    const fileMenu = new VNMenu();
    fileMenu.append({ id: IDM.FILE_NEW, text: '&New', shortcut: 'Ctrl+N' });
    fileMenu.append({ id: IDM.FILE_OPEN, text: '&Open...', shortcut: 'Ctrl+O' });
    fileMenu.append({ id: IDM.FILE_SAVE, text: '&Save', shortcut: 'Ctrl+S' });
    fileMenu.append({ id: IDM.FILE_SAVEAS, text: 'Save &As...' });
    fileMenu.appendSeparator();
    fileMenu.append({ id: IDM.FILE_EXIT, text: 'E&xit', shortcut: 'Alt+F4' });
    
    menubar.append({ text: '&File', submenu: fileMenu });
    
    // Edit menu
    const editMenu = new VNMenu();
    editMenu.append({ id: IDM.EDIT_UNDO, text: '&Undo', shortcut: 'Ctrl+Z' });
    editMenu.append({ id: IDM.EDIT_REDO, text: '&Redo', shortcut: 'Ctrl+Y' });
    editMenu.appendSeparator();
    editMenu.append({ id: IDM.EDIT_CUT, text: 'Cu&t', shortcut: 'Ctrl+X' });
    editMenu.append({ id: IDM.EDIT_COPY, text: '&Copy', shortcut: 'Ctrl+C' });
    editMenu.append({ id: IDM.EDIT_PASTE, text: '&Paste', shortcut: 'Ctrl+V' });
    editMenu.appendSeparator();
    editMenu.append({ id: IDM.EDIT_SELECTALL, text: 'Select &All', shortcut: 'Ctrl+A' });
    
    menubar.append({ text: '&Edit', submenu: editMenu });
    
    // View menu
    const viewMenu = new VNMenu();
    viewMenu.append({ id: IDM.VIEW_TOOLBAR, text: '&Toolbar', checked: true });
    viewMenu.append({ id: IDM.VIEW_STATUSBAR, text: '&Status Bar', checked: true });
    viewMenu.appendSeparator();
    viewMenu.append({ id: IDM.VIEW_FULLSCREEN, text: '&Full Screen', shortcut: 'F11' });
    
    menubar.append({ text: '&View', submenu: viewMenu });
    
    // Help menu
    const helpMenu = new VNMenu();
    helpMenu.append({ id: IDM.HELP_CONTENTS, text: '&Contents', shortcut: 'F1' });
    helpMenu.appendSeparator();
    helpMenu.append({ id: IDM.HELP_ABOUT, text: '&About...' });
    
    menubar.append({ text: '&Help', submenu: helpMenu });
    
    return menubar;
}

export default {
    MF,
    VNMenuItem,
    VNMenu,
    VNPopupMenu,
    VNMenuBar,
    IDM,
    createStandardMenuBar
};
