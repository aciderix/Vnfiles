/**
 * VNTextObject - Text display object for VN Engine
 * 
 * Handles text rendering and HTML content display
 * Mirrors TVNTextObject and TVNHtmlText from the original engine
 */

class VNTextObject extends EventEmitter {
    constructor(engine, options = {}) {
        super();
        this.engine = engine;
        
        this.id = options.id || `text_${Date.now()}`;
        this.text = options.text || '';
        this.x = options.x || 0;
        this.y = options.y || 0;
        this.width = options.width || null;
        this.height = options.height || null;
        this.font = options.font || 'Arial';
        this.fontSize = options.fontSize || 16;
        this.color = options.color || '#ffffff';
        this.backgroundColor = options.backgroundColor || 'transparent';
        this.visible = options.visible !== false;
        this.isHtml = options.isHtml || false;
        
        this._element = null;
        this._attached = false;
    }

    /**
     * Create DOM element
     */
    _createElement() {
        this._element = document.createElement('div');
        this._element.id = `vn-text-${this.id}`;
        this._element.className = 'vn-text-object';
        
        this._updateStyles();
        this._updateContent();
    }

    /**
     * Update element styles
     */
    _updateStyles() {
        if (!this._element) return;
        
        Object.assign(this._element.style, {
            position: 'absolute',
            left: `${this.x}px`,
            top: `${this.y}px`,
            fontFamily: this.font,
            fontSize: `${this.fontSize}px`,
            color: this.color,
            backgroundColor: this.backgroundColor,
            display: this.visible ? 'block' : 'none',
            pointerEvents: 'auto'
        });
        
        if (this.width) {
            this._element.style.width = `${this.width}px`;
        }
        if (this.height) {
            this._element.style.height = `${this.height}px`;
        }
    }

    /**
     * Update content
     */
    _updateContent() {
        if (!this._element) return;
        
        if (this.isHtml) {
            // Parse and sanitize HTML (basic VN HTML subset)
            this._element.innerHTML = this._parseHtml(this.text);
        } else {
            this._element.textContent = this.text;
        }
    }

    /**
     * Parse VN HTML tags
     * Supports subset: <b>, <i>, <u>, <font>, <br>, <size>, <color>
     * @param {string} html - HTML string
     * @returns {string} Processed HTML
     */
    _parseHtml(html) {
        if (!html) return '';
        
        let processed = html;
        
        // Convert custom VN tags to standard HTML
        // SIZE tag: <SIZE="16">text</SIZE> -> <span style="font-size:16px">text</span>
        processed = processed.replace(/<SIZE="?(\d+)"?>(.*?)<\/SIZE>/gi, 
            '<span style="font-size:$1px">$2</span>');
        processed = processed.replace(/<SIZE=(\d+)>(.*?)<\/SIZE>/gi, 
            '<span style="font-size:$1px">$2</span>');
        
        // COLOR tag: <COLOR="#FFFFFF">text</COLOR> -> <span style="color:#FFFFFF">text</span>
        processed = processed.replace(/<COLOR="?(#?[0-9A-Fa-f]+)"?>(.*?)<\/COLOR>/gi, 
            '<span style="color:$1">$2</span>');
        processed = processed.replace(/<COLOR=(#?[0-9A-Fa-f]+)>(.*?)<\/COLOR>/gi, 
            '<span style="color:$1">$2</span>');
        
        // FONT tag with face and size
        processed = processed.replace(/<FONT\s+FACE="([^"]+)"(?:\s+SIZE="?(\d+)"?)?>(.*?)<\/FONT>/gi, 
            (match, face, size, content) => {
                let style = `font-family:${face}`;
                if (size) style += `;font-size:${size}px`;
                return `<span style="${style}">${content}</span>`;
            });
        
        // Standard HTML tags (allow through)
        // <b>, <i>, <u>, <br>, <p>, <div>, <span>
        
        // Remove potentially dangerous tags
        processed = processed.replace(/<script[^>]*>.*?<\/script>/gi, '');
        processed = processed.replace(/<style[^>]*>.*?<\/style>/gi, '');
        processed = processed.replace(/<iframe[^>]*>.*?<\/iframe>/gi, '');
        processed = processed.replace(/on\w+="[^"]*"/gi, '');
        processed = processed.replace(/on\w+='[^']*'/gi, '');
        
        return processed;
    }

    /**
     * Attach to DOM
     */
    attach() {
        if (this._attached) return;
        
        this._createElement();
        
        const container = document.getElementById('vn-text-layer');
        if (container) {
            container.appendChild(this._element);
            this._attached = true;
        }
    }

    /**
     * Detach from DOM
     */
    detach() {
        if (!this._attached || !this._element) return;
        
        this._element.remove();
        this._attached = false;
    }

    /**
     * Destroy object
     */
    destroy() {
        this.detach();
        this._element = null;
        this.removeAllListeners();
    }

    /**
     * Set text content
     * @param {string} text - New text
     */
    setText(text) {
        this.text = text;
        this._updateContent();
    }

    /**
     * Set position
     * @param {number} x - X coordinate
     * @param {number} y - Y coordinate
     */
    setPosition(x, y) {
        this.x = x;
        this.y = y;
        this._updateStyles();
    }

    /**
     * Set font
     * @param {Object} fontOptions - Font options
     */
    setFont(fontOptions) {
        if (fontOptions.face) this.font = fontOptions.face;
        if (fontOptions.size) this.fontSize = fontOptions.size;
        if (fontOptions.color) this.color = fontOptions.color;
        this._updateStyles();
    }

    /**
     * Show object
     */
    show() {
        this.visible = true;
        if (this._element) {
            this._element.style.display = 'block';
        }
    }

    /**
     * Hide object
     */
    hide() {
        this.visible = false;
        if (this._element) {
            this._element.style.display = 'none';
        }
    }

    /**
     * Get state for saving
     * @returns {Object}
     */
    getState() {
        return {
            id: this.id,
            text: this.text,
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height,
            font: this.font,
            fontSize: this.fontSize,
            color: this.color,
            backgroundColor: this.backgroundColor,
            visible: this.visible,
            isHtml: this.isHtml
        };
    }

    /**
     * Restore state
     * @param {Object} state - Saved state
     */
    restoreState(state) {
        Object.assign(this, state);
        this._updateStyles();
        this._updateContent();
    }
}

/**
 * VNHtmlText - Extended HTML text object
 * For displaying rich HTML content in a scrollable area
 */
class VNHtmlText extends VNTextObject {
    constructor(engine, options = {}) {
        super(engine, { ...options, isHtml: true });
        this.scrollable = options.scrollable || false;
    }

    _createElement() {
        super._createElement();
        
        if (this.scrollable) {
            this._element.style.overflow = 'auto';
        }
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNTextObject, VNHtmlText };
}
