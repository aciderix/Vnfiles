/**
 * FIX #001: VND Parser - Real Binary Format
 * 
 * CRITICAL: The current VNFileFormat.js parser expects a different format than
 * the actual VND files from Europeo. This fix implements the REAL VND format
 * as discovered through radare2 analysis.
 * 
 * REAL VND FORMAT (from binary analysis):
 * ========================================
 * Offset 0x00: uint8   - Type marker (0x3a)
 * Offset 0x01: uint16  - Version (0x0101)
 * Offset 0x03: uint16  - Unknown (0x0000)
 * Offset 0x05: uint32  - String length for magic
 * Offset 0x09: string  - "VNFILE" (6 bytes)
 * Offset 0x0F: uint32  - String length for version
 * Offset 0x13: string  - Version string (e.g., "2.13")
 * Offset 0x17: uint32  - Unknown count
 * Offset 0x1B: uint32  - String length for app name
 * Offset 0x1F: string  - App name (e.g., "Europeo")
 * ... and so on with length-prefixed strings
 * 
 * Resolution at offset ~0x78: width (uint32), height (uint32)
 * Variables start after DLL path reference
 */

class VNDRealParser {
    constructor() {
        this.offset = 0;
        this.data = null;
    }

    /**
     * Read a uint8 from current position
     */
    readUint8() {
        const value = this.data[this.offset];
        this.offset += 1;
        return value;
    }

    /**
     * Read a uint16 (little-endian) from current position
     */
    readUint16() {
        const value = this.data[this.offset] | (this.data[this.offset + 1] << 8);
        this.offset += 2;
        return value;
    }

    /**
     * Read a uint32 (little-endian) from current position
     */
    readUint32() {
        const value = this.data[this.offset] | 
                     (this.data[this.offset + 1] << 8) |
                     (this.data[this.offset + 2] << 16) |
                     (this.data[this.offset + 3] << 24);
        this.offset += 4;
        return value >>> 0; // Ensure unsigned
    }

    /**
     * Read a length-prefixed string (uint32 length + chars)
     */
    readLString() {
        const length = this.readUint32();
        if (length === 0 || length > 10000) {
            return '';
        }
        let str = '';
        for (let i = 0; i < length; i++) {
            str += String.fromCharCode(this.data[this.offset + i]);
        }
        this.offset += length;
        return str;
    }

    /**
     * Parse a real VND file
     * @param {Uint8Array|ArrayBuffer} buffer - The VND file data
     * @returns {Object} Parsed VND structure
     */
    parse(buffer) {
        this.data = buffer instanceof ArrayBuffer ? new Uint8Array(buffer) : buffer;
        this.offset = 0;

        const result = {
            header: {},
            variables: [],
            scenes: [],
            hotspots: [],
            resources: [],
            commands: []
        };

        // Parse header
        result.header.typeMarker = this.readUint8(); // 0x3a
        result.header.version1 = this.readUint16();  // 0x0101
        result.header.unknown1 = this.readUint16();  // 0x0000
        
        // Magic string "VNFILE"
        result.header.magic = this.readLString();
        if (result.header.magic !== 'VNFILE') {
            throw new Error(`Invalid VND magic: expected VNFILE, got ${result.header.magic}`);
        }

        // File format version
        result.header.formatVersion = this.readLString();

        // Unknown count (possibly section count or flags)
        result.header.unknown2 = this.readUint32();

        // Application name
        result.header.appName = this.readLString();

        // Company name  
        result.header.company = this.readLString();

        // Serial/Product ID
        result.header.serial = this.readLString();

        // Full product name (may be empty in some files)
        result.header.fullName = this.readLString();

        // Registry key
        result.header.registryKey = this.readLString();

        // Resolution
        result.header.width = this.readUint32();
        result.header.height = this.readUint32();

        // Color depth
        result.header.colorDepth = this.readUint32();

        // Unknown values (flags, options)
        result.header.unknown3 = this.readUint32();
        result.header.unknown4 = this.readUint32();
        result.header.unknown5 = this.readUint32();
        result.header.unknown6 = this.readUint32();

        // DLL path
        result.header.dllPath = this.readLString();

        // Variable count
        const varCount = this.readUint32();
        result.header.variableCount = varCount;

        // Parse variables
        for (let i = 0; i < varCount; i++) {
            const name = this.readLString();
            const value = this.readUint32();
            result.variables.push({
                index: i,
                name: name,
                initialValue: value,
                currentValue: value
            });
        }

        // Mark end of variable section
        result.header.variablesEndOffset = this.offset;

        // Continue parsing scenes and other data...
        // This requires further analysis of the scene format

        console.log(`[VNDParser] Parsed ${result.variables.length} variables from VND`);
        
        return result;
    }

    /**
     * Get current parsing offset
     */
    getOffset() {
        return this.offset;
    }

    /**
     * Seek to a specific offset
     */
    seek(offset) {
        this.offset = offset;
    }

    /**
     * Get remaining bytes
     */
    remaining() {
        return this.data.length - this.offset;
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNDRealParser };
}
if (typeof window !== 'undefined') {
    window.VNDRealParser = VNDRealParser;
}
