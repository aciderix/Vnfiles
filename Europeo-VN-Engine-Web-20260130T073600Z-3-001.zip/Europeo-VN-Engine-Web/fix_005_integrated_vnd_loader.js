/**
 * FIX #005: Integrated VND Loader
 * 
 * Combines all VND parsing fixes into a single, complete loader.
 * This should be used to load real VND files from Europeo.
 * 
 * Features:
 * - Correct header parsing (fix_001)
 * - Complete parser structure (fix_002)
 * - VNFileFormat integration (fix_003)
 * - Scene/resource extraction (fix_004)
 */

class VNDLoader {
    constructor() {
        this.data = null;
        this.offset = 0;
        this.size = 0;
        
        // Parsed data
        this.header = {};
        this.variables = [];
        this.resources = {
            images: [],
            sounds: [],
            videos: [],
            projects: []
        };
        this.commands = [];
    }

    /**
     * Load a VND file
     * @param {ArrayBuffer|Uint8Array} buffer - The VND file data
     * @returns {Object} Complete parsed VND structure
     */
    load(buffer) {
        this.data = buffer instanceof ArrayBuffer ? new Uint8Array(buffer) : buffer;
        this.offset = 0;
        this.size = this.data.length;
        
        // Parse header
        this._parseHeader();
        
        // Parse variables
        this._parseVariables();
        
        // Extract resources and commands from remaining data
        this._extractSceneData();
        
        return this.getResult();
    }

    // ========== Read Helpers ==========

    _readUint8() {
        if (this.offset >= this.size) return 0;
        return this.data[this.offset++];
    }

    _readUint16() {
        if (this.offset + 2 > this.size) return 0;
        const val = this.data[this.offset] | (this.data[this.offset + 1] << 8);
        this.offset += 2;
        return val;
    }

    _readUint32() {
        if (this.offset + 4 > this.size) return 0;
        const val = this.data[this.offset] | 
                   (this.data[this.offset + 1] << 8) |
                   (this.data[this.offset + 2] << 16) |
                   (this.data[this.offset + 3] << 24);
        this.offset += 4;
        return val >>> 0;
    }

    _readLString() {
        const length = this._readUint32();
        if (length === 0) return '';
        if (length > 65536 || this.offset + length > this.size) {
            this.offset -= 4; // Rollback
            return null;
        }
        let str = '';
        for (let i = 0; i < length; i++) {
            str += String.fromCharCode(this.data[this.offset + i]);
        }
        this.offset += length;
        return str;
    }

    // ========== Parsing Methods ==========

    _parseHeader() {
        this.header.typeMarker = this._readUint8();  // 0x3a
        this.header.version1 = this._readUint16();   // 0x0101
        this.header.unknown1 = this._readUint16();
        
        this.header.magic = this._readLString();
        if (this.header.magic !== 'VNFILE') {
            throw new Error(`Invalid VND file: magic = "${this.header.magic}"`);
        }
        
        this.header.formatVersion = this._readLString();
        this.header.unknown2 = this._readUint32();
        this.header.appName = this._readLString();
        this.header.company = this._readLString();
        this.header.serial = this._readLString();
        this.header.fullName = this._readLString();
        this.header.registryKey = this._readLString();
        this.header.width = this._readUint32();
        this.header.height = this._readUint32();
        this.header.colorDepth = this._readUint32();
        
        // Unknown values
        for (let i = 0; i < 4; i++) {
            this.header[`unknown${i + 3}`] = this._readUint32();
        }
        
        this.header.dllPath = this._readLString();
    }

    _parseVariables() {
        const varCount = this._readUint32();
        this.variables = [];
        
        for (let i = 0; i < varCount; i++) {
            const name = this._readLString();
            if (name === null) break;  // Error reading
            
            const value = this._readUint32();
            this.variables.push({
                index: i,
                name: name,
                initialValue: value,
                currentValue: value
            });
        }
        
        this.header.variableCount = this.variables.length;
        this.header.sceneDataOffset = this.offset;
    }

    _extractSceneData() {
        const sceneData = this.data.slice(this.offset);
        
        // Convert to string for pattern matching
        let text = '';
        for (let i = 0; i < sceneData.length; i++) {
            text += String.fromCharCode(sceneData[i]);
        }
        
        // Extract resources
        const extractPattern = (regex, target) => {
            let match;
            while ((match = regex.exec(text)) !== null) {
                if (!target.includes(match[0])) {
                    target.push(match[0]);
                }
            }
        };
        
        extractPattern(/[\w\\]+\.bmp/gi, this.resources.images);
        extractPattern(/[\w\\]+\.wav/gi, this.resources.sounds);
        extractPattern(/[\w\\]+\.avi/gi, this.resources.videos);
        extractPattern(/[\w\\]+\.vnp/gi, this.resources.projects);
        
        // Extract commands
        const cmdPatterns = [
            /if\s+\w+\s*[<>=!]+\s*-?\d+\s+then\s+\w+[^\x00]{0,80}/gi,
            /set_var\s+\w+\s+-?\d+/gi,
            /inc_var\s+\w+\s+-?\d+/gi,
            /dec_var\s+\w+\s+-?\d+/gi,
            /addbmp\s+\w+[^\x00]{0,80}/gi,
            /delbmp\s+\w+/gi,
            /playwav\s+[\w\\.]+/gi,
            /playavi\s+[\w\\.]+[^\x00]{0,50}/gi,
            /scene\s+\w+/gi,
            /runprj\s+[\w\\.\s]+/gi,
        ];
        
        for (const pattern of cmdPatterns) {
            let match;
            while ((match = pattern.exec(text)) !== null) {
                const cmd = match[0].trim();
                if (!this.commands.includes(cmd) && cmd.length < 200) {
                    this.commands.push(cmd);
                }
            }
        }
    }

    // ========== Result ==========

    getResult() {
        return {
            header: this.header,
            variables: this.variables,
            resources: this.resources,
            commands: this.commands,
            stats: {
                variableCount: this.variables.length,
                imageCount: this.resources.images.length,
                soundCount: this.resources.sounds.length,
                videoCount: this.resources.videos.length,
                projectCount: this.resources.projects.length,
                commandCount: this.commands.length
            }
        };
    }

    /**
     * Get a variable by name
     */
    getVariable(name) {
        return this.variables.find(v => v.name === name);
    }

    /**
     * Set a variable value
     */
    setVariable(name, value) {
        const v = this.getVariable(name);
        if (v) {
            v.currentValue = value;
            return true;
        }
        return false;
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNDLoader };
}
if (typeof window !== 'undefined') {
    window.VNDLoader = VNDLoader;
}
