# Europeo VN Engine - Web Port

Complete web port of the Europeo Visual Novel Engine from Windows (Borland C++ 1996) to modern HTML5/JavaScript/CSS.

## 🎮 Features

### Core Engine
- **Scene Management** - Load, unload, and transition between scenes
- **Command Parser** - Execute VN script commands (scene, playbmp, playavi, etc.)
- **Variable System** - Store and manipulate game variables with full expression support
- **Event System** - Publish/subscribe event architecture

### Media Support
- **Images** - BMP, PNG, JPG, GIF with transparency support
- **Audio** - MP3, WAV, OGG for music and sound effects
- **Video** - MP4, WebM for cutscenes and animations
- **HTML Content** - Rich text with custom formatting tags

### UI Components
- **Dialog System** - Text display with typewriter effect and character names
- **Hotspots** - Clickable interactive areas with tooltip support
- **Text Objects** - Positioned text with custom fonts and colors
- **Image Objects** - Positioned images with layering support

### Persistence
- **Save/Load System** - Multiple save slots with localStorage
- **Auto-save** - Automatic save at key points
- **Export/Import** - Save data export for backup

### Controls
- **Volume Control** - Master, music, and SFX volume
- **Text Speed** - Adjustable typewriter speed
- **Auto-play** - Automatic text advancement
- **Fullscreen** - Toggle fullscreen mode

## 📁 Project Structure

```
vn-engine-web/
├── index.html              # Main HTML file
├── styles/
│   └── main.css           # Complete stylesheet
├── src/
│   ├── core/
│   │   ├── VNEngine.js    # Main engine class
│   │   ├── VNScene.js     # Scene management
│   │   ├── VNVariable.js  # Variable system
│   │   ├── VNCommandParser.js  # Command execution
│   │   └── VNSaveLoad.js  # Persistence
│   ├── media/
│   │   ├── VNMedia.js     # Media base class
│   │   ├── VNAudio.js     # Audio system
│   │   └── VNVideo.js     # Video playback
│   ├── ui/
│   │   ├── VNDialog.js    # Dialog box
│   │   ├── VNTextObject.js # Text display
│   │   ├── VNImageObject.js # Image display
│   │   └── VNHotspot.js   # Interactive areas
│   ├── utils/
│   │   └── EventEmitter.js # Event system
│   └── main.js            # Entry point
├── assets/
│   ├── data/              # Project files (JSON)
│   ├── images/            # Image assets
│   ├── audio/             # Audio files
│   └── video/             # Video files
└── demo/                  # Demo content
```

## 🚀 Quick Start

### 1. Basic Setup
Open `index.html` in a web browser (requires a local server for full functionality).

### 2. Load a Project
Add the project parameter to the URL:
```
index.html?project=sample_project.json
```

### 3. Configure in HTML
Edit the config in `index.html`:
```html
<script type="application/json" id="vn-config">
{
    "gameId": "my_game",
    "basePath": "assets",
    "project": "my_project.json",
    "debug": false
}
</script>
```

## 📝 Script Commands

### Scene Commands
| Command | Description | Example |
|---------|-------------|---------|
| `scene` | Change scene | `scene change "forest"` |
| `goto_scene` | Jump to scene | `goto_scene "chapter2"` |

### Media Commands
| Command | Description | Example |
|---------|-------------|---------|
| `playbmp` | Show image | `playbmp "bg.png"` |
| `showbmp` | Display image at position | `showbmp "char.png" x=100 y=50` |
| `hidebmp` | Hide image | `hidebmp "char.png"` |
| `playavi` | Play video | `playavi "intro.mp4"` |
| `playmid` | Play music | `playmid "theme.mp3" loop` |
| `playwav` | Play sound | `playwav "click.wav"` |

### Text Commands
| Command | Description | Example |
|---------|-------------|---------|
| `playtext` | Display dialog | `playtext "Hello world"` |
| `addtext` | Add text object | `addtext "label" "text" x=100` |
| `showobj` | Show object | `showobj "label"` |
| `hideobj` | Hide object | `hideobj "label"` |

### Variable Commands
| Command | Description | Example |
|---------|-------------|---------|
| `set_var` | Set variable | `set_var score=100` |
| `add` | Add to variable | `add score 10` |
| `sub` | Subtract | `sub health 5` |
| `mul` | Multiply | `mul damage 2` |
| `div` | Divide | `div total 2` |

### Control Flow
| Command | Description | Example |
|---------|-------------|---------|
| `if` | Conditional | `if score>10` |
| `else` | Else branch | `else` |
| `endif` | End conditional | `endif` |
| `wait` | Delay execution | `wait 2000` |
| `goto` | Jump to label | `goto start` |
| `gosub` | Call subroutine | `gosub init` |
| `return` | Return from sub | `return` |

### Save/Load
| Command | Description | Example |
|---------|-------------|---------|
| `save` | Save game | `save 0` |
| `load` | Load game | `load 0` |

## 🎨 Project File Format

Projects use JSON format:

```json
{
    "name": "My Visual Novel",
    "version": "1.0.0",
    "config": {
        "gameId": "my_vn",
        "width": 800,
        "height": 600
    },
    "startScene": 0,
    "scenes": [
        {
            "name": "intro",
            "background": "backgrounds/intro.png",
            "music": "music/theme.mp3",
            "script": [
                { "cmd": "dialog", "name": "Hero", "text": "Hello!" }
            ]
        }
    ],
    "variables": {
        "score": 0
    }
}
```

## 🔧 API Reference

### VNEngine

```javascript
const engine = new VNEngine({
    gameId: 'my_game',
    basePath: 'assets'
});

await engine.init();
await engine.loadProject('project.json');

// Scene management
await engine.loadScene('intro');

// Media
await engine.setBackground('bg.png');
await engine.playMusic('theme.mp3');
await engine.playSound('click.wav');

// Objects
engine.addTextObject('title', 'Hello World', { x: 400, y: 100 });
await engine.addImageObject('char', 'character.png', { x: 200, y: 50 });

// Variables
engine.variables.set('score', 100);
const score = engine.variables.get('score');

// Save/Load
await engine.saveGame(0);
await engine.loadGame(0);
```

## 🔄 Original to Web Mapping

| Original (Windows) | Web Port |
|--------------------|----------|
| `TVNEngine` | `VNEngine` |
| `TVNScene` | `VNScene` |
| `TVNVar` | `VNVariable` |
| `TVNCommandMessage` | `VNCommandParser` |
| `TVNMediaCtrl` | `VNAudio`, `VNVideo` |
| `TVNImageObject` | `VNImageObject` |
| `TVNTextObject` | `VNTextObject` |
| `TVNHotspot` | `VNHotspot` |

### File Format Conversions
| Original | Web |
|----------|-----|
| .BMP | .PNG |
| .AVI | .MP4 |
| .MID | .MP3 |
| .WAV | .WAV/.MP3 |
| .PCX | .PNG |

## 📜 License

This is a reverse-engineered web port for educational and preservation purposes.

## 🙏 Credits

- Original Europeo VN Engine (1996)
- Web port: AI-assisted reverse engineering from binary analysis
