/**
 * FIX #002: Complete VND Parser with Scenes, Commands, Resources
 * 
 * Based on radare2 analysis of actual VND files from Europeo
 * 
 * VND FILE STRUCTURE:
 * ===================
 * 1. HEADER SECTION
 *    - Type marker (uint8): 0x3a
 *    - Version (uint16): 0x0101
 *    - Unknown (uint16)
 *    - Magic string: "VNFILE" (length-prefixed)
 *    - Format version: "2.13" (length-prefixed)
 *    - Unknown count (uint32)
 *    - App name, company, serial, full name, registry key (length-prefixed strings)
 *    - Resolution: width, height (uint32 each)
 *    - Color depth (uint32)
 *    - Unknown values (4x uint32)
 *    - DLL path (length-prefixed)
 * 
 * 2. VARIABLES SECTION
 *    - Variable count (uint32)
 *    - For each variable:
 *      - Name (length-prefixed string)
 *      - Initial value (uint32)
 * 
 * 3. SCENE DATA SECTION
 *    - Scene count (uint32)
 *    - For each scene:
 *      - Scene name (length-prefixed)
 *      - Background resource (length-prefixed)
 *      - Sound resource (length-prefixed)
 *      - Hotspot count (uint32)
 *      - Command count (uint32)
 *      - Commands/actions data
 * 
 * 4. RESOURCE REFERENCES
 *    - WAV files (sounds)
 *    - BMP files (images)
 *    - AVI files (videos)
 *    - VNP files (sub-projects)
 */

class VNDCompleteParser {
    constructor() {
        this.data = null;
        this.offset = 0;
        this.size = 0;
    }

    canRead(n) {
        return this.offset + n <= this.size;
    }

    readUint8() {
        if (!this.canRead(1)) return 0;
        const val = this.data[this.offset];
        this.offset += 1;
        return val;
    }

    readUint16() {
        if (!this.canRead(2)) return 0;
        const val = this.data[this.offset] | (this.data[this.offset + 1] << 8);
        this.offset += 2;
        return val;
    }

    readUint32() {
        if (!this.canRead(4)) return 0;
        const val = this.data[this.offset] | 
                   (this.data[this.offset + 1] << 8) |
                   (this.data[this.offset + 2] << 16) |
                   (this.data[this.offset + 3] << 24);
        this.offset += 4;
        return val >>> 0;
    }

    readInt32() {
        const val = this.readUint32();
        return val > 0x7FFFFFFF ? val - 0x100000000 : val;
    }

    readLString() {
        if (!this.canRead(4)) return '';
        const length = this.readUint32();
        if (length === 0 || length > 65536 || !this.canRead(length)) {
            return '';
        }
        let str = '';
        for (let i = 0; i < length; i++) {
            str += String.fromCharCode(this.data[this.offset + i]);
        }
        this.offset += length;
        return str;
    }

    readBytes(length) {
        if (!this.canRead(length)) return new Uint8Array(0);
        const bytes = this.data.slice(this.offset, this.offset + length);
        this.offset += length;
        return bytes;
    }

    seek(offset) {
        this.offset = offset;
    }

    remaining() {
        return this.size - this.offset;
    }

    /**
     * Parse complete VND file
     */
    parse(buffer) {
        this.data = buffer instanceof ArrayBuffer ? new Uint8Array(buffer) : buffer;
        this.offset = 0;
        this.size = this.data.length;

        const result = {
            header: this.parseHeader(),
            variables: this.parseVariables(),
            scenes: [],
            resources: {
                images: [],
                sounds: [],
                videos: [],
                projects: []
            },
            rawSceneData: null
        };

        // Store remaining data for scene parsing
        const sceneDataStart = this.offset;
        result.rawSceneData = {
            offset: sceneDataStart,
            size: this.remaining()
        };

        // Try to parse scene structure
        result.scenes = this.parseScenes();

        // Extract resource references
        this.extractResources(result);

        return result;
    }

    parseHeader() {
        const header = {};
        
        header.typeMarker = this.readUint8();
        header.version1 = this.readUint16();
        header.unknown1 = this.readUint16();
        header.magic = this.readLString();
        header.formatVersion = this.readLString();
        header.unknown2 = this.readUint32();
        header.appName = this.readLString();
        header.company = this.readLString();
        header.serial = this.readLString();
        header.fullName = this.readLString();
        header.registryKey = this.readLString();
        header.width = this.readUint32();
        header.height = this.readUint32();
        header.colorDepth = this.readUint32();
        header.unknown3 = this.readUint32();
        header.unknown4 = this.readUint32();
        header.unknown5 = this.readUint32();
        header.unknown6 = this.readUint32();
        header.dllPath = this.readLString();

        return header;
    }

    parseVariables() {
        const varCount = this.readUint32();
        const variables = [];

        for (let i = 0; i < varCount; i++) {
            const name = this.readLString();
            const value = this.readUint32();
            variables.push({
                index: i,
                name: name,
                initialValue: value,
                currentValue: value
            });
        }

        return variables;
    }

    parseScenes() {
        const scenes = [];
        const startOffset = this.offset;

        // The scene section starts with a count
        const sceneCount = this.readUint32();
        
        // Sanity check
        if (sceneCount === 0 || sceneCount > 1000) {
            this.offset = startOffset;
            return scenes;
        }

        for (let i = 0; i < sceneCount && this.remaining() > 10; i++) {
            try {
                const scene = this.parseScene();
                if (scene) {
                    scenes.push(scene);
                }
            } catch (e) {
                console.warn(`Error parsing scene ${i}: ${e.message}`);
                break;
            }
        }

        return scenes;
    }

    parseScene() {
        const scene = {
            name: '',
            background: '',
            music: '',
            hotspots: [],
            commands: [],
            texts: []
        };

        // Scene name
        scene.name = this.readLString();
        if (!scene.name) return null;

        // Background image
        scene.background = this.readLString();

        // Background music
        scene.music = this.readLString();

        // Hotspot count
        const hotspotCount = this.readUint32();
        
        for (let i = 0; i < hotspotCount && i < 100; i++) {
            const hotspot = this.parseHotspot();
            if (hotspot) {
                scene.hotspots.push(hotspot);
            }
        }

        // Command count
        const commandCount = this.readUint32();
        
        for (let i = 0; i < commandCount && i < 1000; i++) {
            const command = this.parseCommand();
            if (command) {
                scene.commands.push(command);
            }
        }

        return scene;
    }

    parseHotspot() {
        return {
            id: this.readUint32(),
            x: this.readInt32(),
            y: this.readInt32(),
            width: this.readUint32(),
            height: this.readUint32(),
            cursor: this.readUint32(),
            action: this.readLString()
        };
    }

    parseCommand() {
        const type = this.readUint8();
        const params = this.readLString();
        return { type, params };
    }

    extractResources(result) {
        // Scan raw data for resource patterns
        const dataStr = String.fromCharCode.apply(null, this.data);
        
        // Find .bmp files
        const bmpRegex = /[a-zA-Z0-9_\\]+\.bmp/gi;
        let match;
        while ((match = bmpRegex.exec(dataStr)) !== null) {
            if (!result.resources.images.includes(match[0])) {
                result.resources.images.push(match[0]);
            }
        }

        // Find .wav files
        const wavRegex = /[a-zA-Z0-9_\\]+\.wav/gi;
        while ((match = wavRegex.exec(dataStr)) !== null) {
            if (!result.resources.sounds.includes(match[0])) {
                result.resources.sounds.push(match[0]);
            }
        }

        // Find .avi files
        const aviRegex = /[a-zA-Z0-9_\\]+\.avi/gi;
        while ((match = aviRegex.exec(dataStr)) !== null) {
            if (!result.resources.videos.includes(match[0])) {
                result.resources.videos.push(match[0]);
            }
        }

        // Find .vnp files (sub-projects)
        const vnpRegex = /[a-zA-Z0-9_\\]+\.vnp/gi;
        while ((match = vnpRegex.exec(dataStr)) !== null) {
            if (!result.resources.projects.includes(match[0])) {
                result.resources.projects.push(match[0]);
            }
        }
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNDCompleteParser };
}
if (typeof window !== 'undefined') {
    window.VNDCompleteParser = VNDCompleteParser;
}
