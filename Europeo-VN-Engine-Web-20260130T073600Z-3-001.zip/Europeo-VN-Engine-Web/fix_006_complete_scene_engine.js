/**
 * FIX #006: Complete Scene Engine
 * 
 * Full scene parsing, hotspot handling, and command execution
 * Based on radare2 binary analysis of all 19 VND files
 */

class VNSceneEngine {
    constructor(engine) {
        this.engine = engine;
        this.currentScene = null;
        this.scenes = new Map();
        this.hotspots = new Map();
        this.fonts = new Map();
        this.texts = [];
        this.resources = {
            images: new Map(),
            sounds: new Map(),
            videos: new Map()
        };
        this.sceneVariables = new Map();
    }

    /**
     * Parse the scene section from VND data
     * @param {DataView} view - DataView of VND file
     * @param {number} offset - Start offset of scene section
     */
    parseSceneSection(view, offset) {
        let pos = offset;
        const decoder = new TextDecoder('latin1');
        
        // Skip padding (zeros at start)
        while (pos < view.byteLength && view.getUint8(pos) === 0) {
            pos++;
        }
        
        // Parse scene variables (additional variables after main section)
        const sceneVars = this.parseSceneVariables(view, pos);
        pos = sceneVars.endOffset;
        
        // Parse resource references
        const resources = this.parseResourceRefs(view, pos);
        pos = resources.endOffset;
        
        // Parse scene definitions
        const scenes = this.parseSceneDefinitions(view, pos);
        
        return {
            sceneVariables: sceneVars.variables,
            resources: resources.refs,
            scenes: scenes.scenes
        };
    }

    /**
     * Parse scene-specific variables
     */
    parseSceneVariables(view, offset) {
        const variables = new Map();
        let pos = offset;
        
        // Scene variables are: length(uint32) + name(string) + value(uint32)
        while (pos + 8 < view.byteLength) {
            const nameLen = view.getUint32(pos, true);
            
            // Sanity check - variable names should be reasonable length
            if (nameLen === 0 || nameLen > 50) break;
            
            pos += 4;
            
            // Read name
            const nameBytes = new Uint8Array(view.buffer, view.byteOffset + pos, nameLen);
            const name = new TextDecoder('latin1').decode(nameBytes).replace(/\0/g, '');
            pos += nameLen;
            
            // Read value
            const value = view.getUint32(pos, true);
            pos += 4;
            
            // Check if this looks like a variable (uppercase letters)
            if (/^[A-Z0-9_]+$/i.test(name)) {
                variables.set(name, value);
                this.sceneVariables.set(name, value);
            } else {
                // Not a variable, backtrack
                pos -= nameLen + 8;
                break;
            }
        }
        
        return { variables, endOffset: pos };
    }

    /**
     * Parse resource references like <res0001>
     */
    parseResourceRefs(view, offset) {
        const refs = [];
        let pos = offset;
        
        // Look for <resXXXX> patterns
        const data = new Uint8Array(view.buffer, view.byteOffset + pos, Math.min(1000, view.byteLength - pos));
        const text = new TextDecoder('latin1').decode(data);
        
        const matches = text.matchAll(/<res(\d+)>/g);
        for (const match of matches) {
            refs.push({
                id: parseInt(match[1]),
                offset: pos + match.index
            });
        }
        
        return { refs, endOffset: pos + (refs.length > 0 ? text.indexOf('>') + 1 : 0) };
    }

    /**
     * Parse scene definitions including fonts, texts, hotspots
     */
    parseSceneDefinitions(view, offset) {
        const scenes = [];
        let pos = offset;
        const remaining = new Uint8Array(view.buffer, view.byteOffset + pos);
        const text = new TextDecoder('latin1').decode(remaining);
        
        // Parse fonts: "size style #color FontName"
        const fontRegex = /(\d+)\s+(\d+)\s+(#[0-9a-fA-F]{6})\s+([A-Za-z][A-Za-z0-9 ]+?)(?=\x00|\d{2,})/g;
        for (const match of text.matchAll(fontRegex)) {
            this.fonts.set(this.fonts.size, {
                size: parseInt(match[1]),
                style: parseInt(match[2]),
                color: match[3],
                family: match[4].trim()
            });
        }
        
        // Parse text positions: "x y w h flags text"
        const textRegex = /(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([A-Za-zÀ-ÿ][^\x00]{3,50})/g;
        for (const match of text.matchAll(textRegex)) {
            this.texts.push({
                x: parseInt(match[1]),
                y: parseInt(match[2]),
                width: parseInt(match[3]),
                height: parseInt(match[4]),
                flags: parseInt(match[5]),
                content: match[6].trim()
            });
        }
        
        // Parse hotspot definitions
        const hotspotRegex = /hotspot\s+(\d+)/gi;
        for (const match of text.matchAll(hotspotRegex)) {
            const id = parseInt(match[1]);
            if (!this.hotspots.has(id)) {
                this.hotspots.set(id, {
                    id: id,
                    commands: []
                });
            }
        }
        
        // Parse scene commands
        const sceneRegex = /scene\s+(\d+)/gi;
        for (const match of text.matchAll(sceneRegex)) {
            const id = parseInt(match[1]);
            scenes.push({ id, offset: pos + match.index });
        }
        
        return { scenes };
    }

    /**
     * Load and display a scene by ID
     */
    async loadScene(sceneId) {
        console.log(`[VNSceneEngine] Loading scene ${sceneId}`);
        
        const scene = this.scenes.get(sceneId);
        if (!scene) {
            console.warn(`Scene ${sceneId} not found`);
            return false;
        }
        
        this.currentScene = scene;
        
        // Load background image
        if (scene.background) {
            await this.loadImage(scene.background);
        }
        
        // Play background sound
        if (scene.sound) {
            await this.playSound(scene.sound);
        }
        
        // Render texts
        for (const text of scene.texts || []) {
            this.renderText(text);
        }
        
        // Setup hotspots
        for (const hotspot of scene.hotspots || []) {
            this.setupHotspot(hotspot);
        }
        
        // Execute scene commands
        for (const command of scene.commands || []) {
            await this.executeCommand(command);
        }
        
        return true;
    }

    /**
     * Setup a hotspot with click handler
     */
    setupHotspot(hotspot) {
        const { id, x, y, width, height, commands, tipText } = hotspot;
        
        const element = document.createElement('div');
        element.className = 'vn-hotspot';
        element.id = `hotspot-${id}`;
        element.style.cssText = `
            position: absolute;
            left: ${x}px;
            top: ${y}px;
            width: ${width}px;
            height: ${height}px;
            cursor: pointer;
        `;
        
        if (tipText) {
            element.title = tipText;
        }
        
        element.addEventListener('click', async () => {
            console.log(`[Hotspot ${id}] Clicked`);
            for (const cmd of commands) {
                await this.executeCommand(cmd);
            }
        });
        
        element.addEventListener('mouseenter', () => {
            if (this.engine.onHotspotEnter) {
                this.engine.onHotspotEnter(id, tipText);
            }
        });
        
        element.addEventListener('mouseleave', () => {
            if (this.engine.onHotspotLeave) {
                this.engine.onHotspotLeave(id);
            }
        });
        
        this.hotspots.set(id, { element, ...hotspot });
        
        if (this.engine.container) {
            this.engine.container.appendChild(element);
        }
    }

    /**
     * Execute a VN command
     */
    async executeCommand(command) {
        const { type, args } = this.parseCommand(command);
        
        switch (type) {
            case 'scene':
                await this.loadScene(parseInt(args[0]));
                break;
            case 'hotspot':
                // Hotspot reference
                break;
            case 'playbmp':
                await this.loadImage(args[0]);
                break;
            case 'playwav':
                await this.playSound(args[0]);
                break;
            case 'playavi':
                await this.playVideo(args[0]);
                break;
            case 'playtext':
                this.displayText(args.join(' '));
                break;
            case 'set_var':
                this.setVariable(args[0], parseInt(args[1]));
                break;
            case 'inc_var':
                this.incrementVariable(args[0], parseInt(args[1]) || 1);
                break;
            case 'dec_var':
                this.decrementVariable(args[0], parseInt(args[1]) || 1);
                break;
            case 'if':
                await this.executeConditional(args);
                break;
            case 'runprj':
                await this.runProject(args[0]);
                break;
            case 'font':
                this.setFont(args);
                break;
            case 'addbmp':
                await this.addImage(args);
                break;
            case 'delbmp':
                this.removeImage(args[0]);
                break;
            case 'showbmp':
                this.showImage(args[0]);
                break;
            case 'hidebmp':
                this.hideImage(args[0]);
                break;
            case 'closewav':
                this.stopSound(args[0]);
                break;
            case 'closeavi':
                this.stopVideo();
                break;
            case 'quit':
                this.quit();
                break;
            default:
                console.log(`[VNSceneEngine] Unknown command: ${type}`, args);
        }
    }

    /**
     * Parse a command string
     */
    parseCommand(cmdStr) {
        if (typeof cmdStr === 'object') return cmdStr;
        
        const parts = cmdStr.trim().split(/\s+/);
        return {
            type: parts[0].toLowerCase(),
            args: parts.slice(1)
        };
    }

    /**
     * Execute conditional command
     */
    async executeConditional(args) {
        // Parse: "variable op value then command [else command]"
        const cmdStr = args.join(' ');
        const match = cmdStr.match(/(\w+)\s*(=|<|>|<=|>=|!=)\s*(\d+)\s+then\s+(.+?)(?:\s+else\s+(.+))?$/);
        
        if (!match) {
            console.warn('Invalid conditional:', cmdStr);
            return;
        }
        
        const [, varName, op, value, thenCmd, elseCmd] = match;
        const varValue = this.getVariable(varName);
        const targetValue = parseInt(value);
        
        let condition = false;
        switch (op) {
            case '=': condition = varValue === targetValue; break;
            case '<': condition = varValue < targetValue; break;
            case '>': condition = varValue > targetValue; break;
            case '<=': condition = varValue <= targetValue; break;
            case '>=': condition = varValue >= targetValue; break;
            case '!=': condition = varValue !== targetValue; break;
        }
        
        if (condition && thenCmd) {
            await this.executeCommand(thenCmd);
        } else if (!condition && elseCmd) {
            await this.executeCommand(elseCmd);
        }
    }

    // Variable management
    getVariable(name) {
        return this.engine.variables?.get(name) || this.sceneVariables.get(name) || 0;
    }
    
    setVariable(name, value) {
        if (this.engine.variables) {
            this.engine.variables.set(name, value);
        }
        this.sceneVariables.set(name, value);
    }
    
    incrementVariable(name, amount) {
        const current = this.getVariable(name);
        this.setVariable(name, current + amount);
    }
    
    decrementVariable(name, amount) {
        const current = this.getVariable(name);
        this.setVariable(name, current - amount);
    }

    // Media methods
    async loadImage(filename) {
        const url = this.resolveResourcePath(filename);
        console.log(`[VNSceneEngine] Loading image: ${url}`);
        
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                this.resources.images.set(filename, img);
                if (this.engine.onImageLoaded) {
                    this.engine.onImageLoaded(filename, img);
                }
                resolve(img);
            };
            img.onerror = reject;
            img.src = url;
        });
    }

    async playSound(filename, loop = false) {
        const url = this.resolveResourcePath(filename);
        console.log(`[VNSceneEngine] Playing sound: ${url}`);
        
        const audio = new Audio(url);
        audio.loop = loop;
        this.resources.sounds.set(filename, audio);
        
        try {
            await audio.play();
        } catch (e) {
            console.warn('Audio playback failed:', e);
        }
        
        return audio;
    }

    stopSound(filename) {
        const audio = this.resources.sounds.get(filename);
        if (audio) {
            audio.pause();
            audio.currentTime = 0;
        }
    }

    async playVideo(filename) {
        const url = this.resolveResourcePath(filename);
        console.log(`[VNSceneEngine] Playing video: ${url}`);
        
        if (this.engine.onVideoPlay) {
            this.engine.onVideoPlay(filename, url);
        }
    }

    stopVideo() {
        if (this.engine.onVideoStop) {
            this.engine.onVideoStop();
        }
    }

    renderText(textObj) {
        const { x, y, width, height, content, font } = textObj;
        
        const element = document.createElement('div');
        element.className = 'vn-text';
        element.textContent = content;
        element.style.cssText = `
            position: absolute;
            left: ${x}px;
            top: ${y}px;
            width: ${width}px;
            height: ${height}px;
            font-family: ${font?.family || 'Comic Sans MS'};
            font-size: ${font?.size || 18}px;
            color: ${font?.color || '#ffffff'};
        `;
        
        if (this.engine.container) {
            this.engine.container.appendChild(element);
        }
        
        return element;
    }

    displayText(text) {
        if (this.engine.onTextDisplay) {
            this.engine.onTextDisplay(text);
        }
    }

    setFont(args) {
        // font size style color family
        this.currentFont = {
            size: parseInt(args[0]) || 18,
            style: parseInt(args[1]) || 0,
            color: args[2] || '#ffffff',
            family: args.slice(3).join(' ') || 'Comic Sans MS'
        };
    }

    async runProject(vnpPath) {
        // Normalize path (convert Windows paths)
        const normalizedPath = vnpPath.replace(/\\/g, '/').replace(/^\.\.\//, '');
        console.log(`[VNSceneEngine] Running project: ${normalizedPath}`);
        
        if (this.engine.onProjectChange) {
            this.engine.onProjectChange(normalizedPath);
        }
    }

    resolveResourcePath(filename) {
        // Base path for assets
        const basePath = this.engine.assetBasePath || 'assets/';
        return basePath + filename.toLowerCase();
    }

    quit() {
        console.log('[VNSceneEngine] Quit requested');
        if (this.engine.onQuit) {
            this.engine.onQuit();
        }
    }

    // Add/remove/show/hide images
    async addImage(args) {
        const [id, filename, x, y] = args;
        const img = await this.loadImage(filename);
        
        const element = document.createElement('img');
        element.id = `img-${id}`;
        element.src = img.src;
        element.style.cssText = `
            position: absolute;
            left: ${x}px;
            top: ${y}px;
        `;
        
        if (this.engine.container) {
            this.engine.container.appendChild(element);
        }
    }

    removeImage(id) {
        const element = document.getElementById(`img-${id}`);
        if (element) {
            element.remove();
        }
    }

    showImage(id) {
        const element = document.getElementById(`img-${id}`);
        if (element) {
            element.style.display = 'block';
        }
    }

    hideImage(id) {
        const element = document.getElementById(`img-${id}`);
        if (element) {
            element.style.display = 'none';
        }
    }
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNSceneEngine };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.VNSceneEngine = VNSceneEngine;
}
