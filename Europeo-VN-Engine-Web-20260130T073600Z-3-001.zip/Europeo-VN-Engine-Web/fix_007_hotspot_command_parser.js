/**
 * FIX #007: Complete Hotspot & Command Parser
 * 
 * Parses hotspot definitions and all command types from VND files
 * Based on radare2 analysis: hotspots are conditional (var = val then hotspot N)
 */

class VNHotspotParser {
    constructor() {
        this.hotspots = new Map();
        this.textElements = [];
        this.commands = [];
    }

    /**
     * Parse all hotspot definitions from scene data
     * @param {string} text - Decoded scene text
     */
    parseHotspots(text) {
        const results = {
            conditionalHotspots: [],
            textPositions: [],
            commands: []
        };

        // Parse conditional hotspots: "variable = value then hotspot N"
        const conditionalRegex = /(\w+)\s*(=|!=|<|>|<=|>=)\s*(\d+|<\w+>)\s+then\s+hotspot\s+(\d+)/gi;
        for (const match of text.matchAll(conditionalRegex)) {
            results.conditionalHotspots.push({
                variable: match[1],
                operator: match[2],
                value: match[3],
                hotspotId: parseInt(match[4])
            });
        }

        // Parse text positions: "X Y W H flags text"
        // These define clickable text areas
        const posRegex = /(\d{1,4})\s+(\d{1,4})\s+(\d{1,4})\s+(\d{1,4})\s+(\d+)\s+([A-Za-zÀ-ÿ<>][^\x00\x01\x02\x03]{2,80})/g;
        for (const match of text.matchAll(posRegex)) {
            const [, x, y, w, h, flags, content] = match;
            
            // Filter out binary garbage
            if (content.length > 2 && !/[\x00-\x1f]/.test(content)) {
                results.textPositions.push({
                    x: parseInt(x),
                    y: parseInt(y),
                    width: parseInt(w),
                    height: parseInt(h),
                    flags: parseInt(flags),
                    text: content.trim()
                });
            }
        }

        // Parse all command types
        results.commands = this.parseAllCommands(text);

        return results;
    }

    /**
     * Parse all VN command types
     */
    parseAllCommands(text) {
        const commands = [];

        // Scene navigation
        for (const m of text.matchAll(/scene\s+(\d+)/gi)) {
            commands.push({ type: 'scene', args: [parseInt(m[1])] });
        }

        // Variable operations
        for (const m of text.matchAll(/set_var\s+(\w+)\s+(\d+)/gi)) {
            commands.push({ type: 'set_var', args: [m[1], parseInt(m[2])] });
        }
        for (const m of text.matchAll(/inc_var\s+(\w+)\s+(\d+)/gi)) {
            commands.push({ type: 'inc_var', args: [m[1], parseInt(m[2])] });
        }
        for (const m of text.matchAll(/dec_var\s+(\w+)\s+(\d+)/gi)) {
            commands.push({ type: 'dec_var', args: [m[1], parseInt(m[2])] });
        }

        // Media playback
        for (const m of text.matchAll(/playbmp\s+(\S+\.bmp)(?:\s+(\d+)\s+(\d+))?/gi)) {
            commands.push({ 
                type: 'playbmp', 
                args: [m[1], parseInt(m[2] || 0), parseInt(m[3] || 0)]
            });
        }
        for (const m of text.matchAll(/playwav\s+(\S+\.wav)(?:\s+(\d+))?/gi)) {
            commands.push({ 
                type: 'playwav', 
                args: [m[1], parseInt(m[2] || 0)]
            });
        }
        for (const m of text.matchAll(/playavi\s+(\S+\.avi)(?:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+))?/gi)) {
            commands.push({ 
                type: 'playavi', 
                args: [m[1], parseInt(m[2] || 0), parseInt(m[3] || 0), parseInt(m[4] || 640), parseInt(m[5] || 480)]
            });
        }
        for (const m of text.matchAll(/playmid\s+(\S+\.mid)/gi)) {
            commands.push({ type: 'playmid', args: [m[1]] });
        }

        // Image management
        for (const m of text.matchAll(/addbmp\s+(\S+\.bmp)\s+(\d+)\s+(\d+)\s+(\d+)/gi)) {
            commands.push({
                type: 'addbmp',
                args: [m[1], parseInt(m[2]), parseInt(m[3]), parseInt(m[4])]
            });
        }
        for (const m of text.matchAll(/delbmp\s+(\d+)/gi)) {
            commands.push({ type: 'delbmp', args: [parseInt(m[1])] });
        }
        for (const m of text.matchAll(/showbmp\s+(\d+)/gi)) {
            commands.push({ type: 'showbmp', args: [parseInt(m[1])] });
        }
        for (const m of text.matchAll(/hidebmp\s+(\d+)/gi)) {
            commands.push({ type: 'hidebmp', args: [parseInt(m[1])] });
        }

        // Text display
        for (const m of text.matchAll(/playtext\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([^\x00\x01]+?)(?=\x00|\x01|$)/gi)) {
            commands.push({
                type: 'playtext',
                args: {
                    x: parseInt(m[1]),
                    y: parseInt(m[2]),
                    width: parseInt(m[3]),
                    height: parseInt(m[4]),
                    flags: parseInt(m[5]),
                    text: m[6].trim()
                }
            });
        }

        // Font
        for (const m of text.matchAll(/font\s+(\d+)\s+(\d+)\s+(#[0-9a-fA-F]{6})\s+([A-Za-z][A-Za-z\s]+)/gi)) {
            commands.push({
                type: 'font',
                args: {
                    size: parseInt(m[1]),
                    style: parseInt(m[2]),
                    color: m[3],
                    family: m[4].trim()
                }
            });
        }

        // Project/module
        for (const m of text.matchAll(/runprj\s+([^\s\x00]+\.vnp)(?:\s+(\d+))?/gi)) {
            commands.push({
                type: 'runprj',
                args: [m[1], parseInt(m[2] || 0)]
            });
        }

        // Cursor
        for (const m of text.matchAll(/defcursor\s+(\S+\.cur)/gi)) {
            commands.push({ type: 'defcursor', args: [m[1]] });
        }

        // Close commands
        for (const m of text.matchAll(/closewav/gi)) {
            commands.push({ type: 'closewav', args: [] });
        }
        for (const m of text.matchAll(/closeavi/gi)) {
            commands.push({ type: 'closeavi', args: [] });
        }
        for (const m of text.matchAll(/closemid/gi)) {
            commands.push({ type: 'closemid', args: [] });
        }

        // Conditional execution
        for (const m of text.matchAll(/(\w+)\s*(=|!=|<|>|<=|>=)\s*(\d+|<\w+>)\s+then\s+(\w+)\s+([^\x00\x01]+?)(?:\s+else\s+(\w+)\s+([^\x00\x01]+?))?(?=\x00|\x01|$)/gi)) {
            commands.push({
                type: 'conditional',
                condition: {
                    variable: m[1],
                    operator: m[2],
                    value: m[3]
                },
                thenAction: { type: m[4], args: m[5].trim().split(/\s+/) },
                elseAction: m[6] ? { type: m[6], args: m[7]?.trim().split(/\s+/) || [] } : null
            });
        }

        return commands;
    }

    /**
     * Create clickable hotspot from text position
     */
    createHotspotElement(textPos, id) {
        const { x, y, width, height, text } = textPos;
        
        const element = document.createElement('div');
        element.className = 'vn-hotspot vn-text-hotspot';
        element.id = `hotspot-${id}`;
        element.dataset.text = text;
        
        element.style.cssText = `
            position: absolute;
            left: ${x}px;
            top: ${y}px;
            width: ${width - x}px;
            height: ${height - y}px;
            cursor: pointer;
            /* Debug: uncomment to see hotspot areas */
            /* background: rgba(255,0,0,0.2); border: 1px solid red; */
        `;
        
        return element;
    }

    /**
     * Evaluate a condition
     */
    evaluateCondition(condition, getVariable) {
        const { variable, operator, value } = condition;
        const varValue = getVariable(variable);
        
        // Handle variable references like <score>
        let targetValue;
        if (value.startsWith('<') && value.endsWith('>')) {
            targetValue = getVariable(value.slice(1, -1));
        } else {
            targetValue = parseInt(value);
        }
        
        switch (operator) {
            case '=': return varValue === targetValue;
            case '!=': return varValue !== targetValue;
            case '<': return varValue < targetValue;
            case '>': return varValue > targetValue;
            case '<=': return varValue <= targetValue;
            case '>=': return varValue >= targetValue;
            default: return false;
        }
    }
}

/**
 * Hotspot Manager - handles runtime hotspot activation
 */
class VNHotspotManager {
    constructor(engine) {
        this.engine = engine;
        this.parser = new VNHotspotParser();
        this.activeHotspots = new Map();
        this.pendingConditions = [];
    }

    /**
     * Load hotspots from parsed scene data
     */
    loadFromSceneData(text) {
        const parsed = this.parser.parseHotspots(text);
        
        // Store conditional hotspots for evaluation
        this.pendingConditions = parsed.conditionalHotspots;
        
        // Create text-based hotspots
        parsed.textPositions.forEach((pos, index) => {
            if (this.isClickableText(pos)) {
                this.createTextHotspot(pos, index);
            }
        });
        
        return parsed;
    }

    /**
     * Determine if a text position is a clickable hotspot
     */
    isClickableText(textPos) {
        const { text, flags } = textPos;
        
        // Common interactive patterns
        const interactivePatterns = [
            /quitter/i,
            /sortie/i,
            /vers\s/i,
            /suivant/i,
            /précédent/i,
            /retour/i,
            /aide/i,
            /info/i,
            /jouer/i,
            /commencer/i
        ];
        
        return interactivePatterns.some(p => p.test(text));
    }

    /**
     * Create a text-based hotspot
     */
    createTextHotspot(textPos, id) {
        const element = this.parser.createHotspotElement(textPos, id);
        
        element.addEventListener('click', () => {
            this.handleHotspotClick(id, textPos);
        });
        
        element.addEventListener('mouseenter', () => {
            element.style.opacity = '0.8';
            if (this.engine.onHotspotHover) {
                this.engine.onHotspotHover(id, textPos.text);
            }
        });
        
        element.addEventListener('mouseleave', () => {
            element.style.opacity = '1';
        });
        
        this.activeHotspots.set(id, {
            element,
            data: textPos
        });
        
        if (this.engine.container) {
            this.engine.container.appendChild(element);
        }
    }

    /**
     * Handle hotspot click
     */
    handleHotspotClick(id, data) {
        console.log(`[Hotspot ${id}] Clicked: ${data.text}`);
        
        // Check if this text triggers a specific action
        const text = data.text.toLowerCase();
        
        if (/quitter/i.test(text)) {
            this.engine.executeCommand({ type: 'quit', args: [] });
        } else if (/sortie|vers\s/i.test(text)) {
            // Navigation - need scene context
            if (this.engine.onNavigate) {
                this.engine.onNavigate(data.text);
            }
        }
        
        // Fire generic click event
        if (this.engine.onHotspotClick) {
            this.engine.onHotspotClick(id, data);
        }
    }

    /**
     * Evaluate and activate conditional hotspots
     */
    evaluateConditions(getVariable) {
        for (const cond of this.pendingConditions) {
            const shouldActivate = this.parser.evaluateCondition(cond, getVariable);
            
            if (shouldActivate) {
                console.log(`[Hotspot] Activating hotspot ${cond.hotspotId}`);
                // Trigger hotspot activation
                if (this.engine.onHotspotActivate) {
                    this.engine.onHotspotActivate(cond.hotspotId);
                }
            }
        }
    }

    /**
     * Clear all hotspots
     */
    clear() {
        for (const [id, hotspot] of this.activeHotspots) {
            hotspot.element.remove();
        }
        this.activeHotspots.clear();
        this.pendingConditions = [];
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNHotspotParser, VNHotspotManager };
}
if (typeof window !== 'undefined') {
    window.VNHotspotParser = VNHotspotParser;
    window.VNHotspotManager = VNHotspotManager;
}
