/**
 * FIX #004: Complete Scene Section Parser
 * 
 * Based on radare2 analysis of france.vnd
 * 
 * SCENE SECTION FORMAT (after variables):
 * =======================================
 * 
 * After all variables, there's a scene data section containing:
 * 
 * 1. SCENE HEADER (~16 bytes of padding/flags)
 * 2. SCENE RESOURCES
 *    - Sound file (length-prefixed string): e.g., "france.wav"
 *    - Padding bytes
 *    - Background image (length-prefixed): e.g., "caisse.bmp"
 * 
 * 3. SCENE ELEMENTS
 *    Each element has:
 *    - Position data (x, y, width, height as int32)
 *    - Flags/type (uint32)
 *    - Content (length-prefixed string)
 * 
 * 4. COMMANDS
 *    - Conditional commands like "if score < 0 then runprj ..."
 *    - Action commands like "set_var", "addbmp", etc.
 * 
 * 5. TEXT ELEMENTS
 *    - Font definition: "18 0 #ffffff Comic sans MS"
 *    - Text content with position: "10 340 125 365 0 Des informations"
 */

class VNDSceneParser {
    constructor() {
        this.data = null;
        this.offset = 0;
        this.size = 0;
    }

    /**
     * Parse scene section from VND data
     * @param {Uint8Array} data - Full VND file data
     * @param {number} sceneOffset - Offset where scene section starts (after variables)
     * @returns {Object} Parsed scene data
     */
    parse(data, sceneOffset) {
        this.data = data;
        this.offset = sceneOffset;
        this.size = data.length;

        const result = {
            scenes: [],
            resources: {
                sounds: [],
                images: [],
                videos: [],
                projects: []
            },
            commands: [],
            texts: [],
            elements: []
        };

        // Scan through data looking for length-prefixed strings
        while (this.offset < this.size - 4) {
            const length = this.peekUint32();
            
            // Valid string length?
            if (length > 0 && length < 500 && this.offset + 4 + length <= this.size) {
                const str = this.tryReadLString();
                if (str && this.isValidString(str)) {
                    this.classifyString(str, result);
                    continue;
                }
            }
            
            // Skip one byte and try again
            this.offset++;
        }

        // Post-process to identify scene boundaries
        this.identifyScenes(result);

        return result;
    }

    peekUint32() {
        return this.data[this.offset] |
               (this.data[this.offset + 1] << 8) |
               (this.data[this.offset + 2] << 16) |
               (this.data[this.offset + 3] << 24);
    }

    readUint32() {
        const val = this.peekUint32();
        this.offset += 4;
        return val >>> 0;
    }

    tryReadLString() {
        const startOffset = this.offset;
        const length = this.readUint32();
        
        if (length === 0 || length > 500 || this.offset + length > this.size) {
            this.offset = startOffset;
            return null;
        }
        
        let str = '';
        for (let i = 0; i < length; i++) {
            str += String.fromCharCode(this.data[this.offset + i]);
        }
        this.offset += length;
        
        return str;
    }

    isValidString(str) {
        // Check if string contains mostly printable characters
        let printable = 0;
        for (let i = 0; i < str.length; i++) {
            const code = str.charCodeAt(i);
            if ((code >= 32 && code < 127) || code === 10 || code === 13 || code === 9) {
                printable++;
            }
        }
        return printable / str.length > 0.8;
    }

    classifyString(str, result) {
        const lower = str.toLowerCase();
        
        // Resource files
        if (lower.includes('.bmp')) {
            result.resources.images.push(str);
        } else if (lower.includes('.wav')) {
            result.resources.sounds.push(str);
        } else if (lower.includes('.avi')) {
            result.resources.videos.push(str);
        } else if (lower.includes('.vnp')) {
            result.resources.projects.push(str);
        }
        // Commands
        else if (lower.includes(' then ') || lower.startsWith('if ') || 
                 lower.includes('set_var') || lower.includes('inc_var') ||
                 lower.includes('addbmp') || lower.includes('delbmp') ||
                 lower.includes('playwav') || lower.includes('playavi') ||
                 lower.includes('closewav') || lower.includes('scene ') ||
                 lower.includes('runprj') || lower === 'quit') {
            result.commands.push(str);
        }
        // Font definitions (contain # for color and font name)
        else if (str.includes('#') && (str.includes('Comic') || str.includes('Arial') || str.includes('MS'))) {
            result.texts.push({ type: 'font', value: str });
        }
        // Text content (starts with numbers for position)
        else if (/^\d+\s+\d+/.test(str) && str.length > 10) {
            result.texts.push({ type: 'text', value: str });
        }
        // Other elements
        else if (str.length > 2) {
            result.elements.push(str);
        }
    }

    identifyScenes(result) {
        // Group resources and commands into scenes based on patterns
        // This is a simplified version - full implementation would analyze
        // the binary structure more carefully
        
        if (result.resources.sounds.length > 0 || result.resources.images.length > 0) {
            const scene = {
                name: 'main',
                background: result.resources.images[0] || '',
                sound: result.resources.sounds[0] || '',
                images: result.resources.images,
                sounds: result.resources.sounds,
                commands: result.commands,
                texts: result.texts
            };
            result.scenes.push(scene);
        }
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { VNDSceneParser };
}
if (typeof window !== 'undefined') {
    window.VNDSceneParser = VNDSceneParser;
}
