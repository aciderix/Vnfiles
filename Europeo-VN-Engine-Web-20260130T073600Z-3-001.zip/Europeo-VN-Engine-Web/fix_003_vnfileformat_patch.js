/**
 * FIX #003: Patch for VNFileFormat.js
 * 
 * This adds a new loadFromVND() method that handles the REAL VND format
 * from Europeo, while keeping the existing methods for compatibility.
 * 
 * INSERT THIS CODE into VNFileFormat.js class VNProject
 * after the loadFromBinary() method
 */

// ============================================================
// ADD THIS METHOD TO class VNProject in VNFileFormat.js
// ============================================================

/**
 * Load from real VND file format (Europeo format)
 * This is the actual binary format used by the original game
 * @param {ArrayBuffer|Uint8Array} data - The VND file data
 */
loadFromVND(data) {
    const buffer = data instanceof ArrayBuffer ? new Uint8Array(data) : data;
    let offset = 0;
    
    const readUint8 = () => buffer[offset++];
    const readUint16 = () => {
        const val = buffer[offset] | (buffer[offset + 1] << 8);
        offset += 2;
        return val;
    };
    const readUint32 = () => {
        const val = buffer[offset] | 
                   (buffer[offset + 1] << 8) |
                   (buffer[offset + 2] << 16) |
                   (buffer[offset + 3] << 24);
        offset += 4;
        return val >>> 0;
    };
    const readLString = () => {
        const length = readUint32();
        if (length === 0 || length > 65536) return '';
        let str = '';
        for (let i = 0; i < length; i++) {
            str += String.fromCharCode(buffer[offset + i]);
        }
        offset += length;
        return str;
    };
    
    // Parse header
    const typeMarker = readUint8();  // 0x3a
    const version1 = readUint16();   // 0x0101
    const unknown1 = readUint16();   // 0x0000
    
    const magic = readLString();
    if (magic !== 'VNFILE') {
        throw new Error(`Invalid VND magic: expected VNFILE, got "${magic}"`);
    }
    
    const formatVersion = readLString();  // e.g., "2.13"
    const unknown2 = readUint32();
    
    this.projectName = readLString();  // e.g., "Europeo"
    this.author = readLString();       // e.g., "Sopra Multimedia"
    
    const serial = readLString();
    const fullName = readLString();
    const registryKey = readLString();
    
    this.width = readUint32();    // 640
    this.height = readUint32();   // 480
    this.colorDepth = readUint32();  // 16
    
    // Unknown values
    const unknown3 = readUint32();
    const unknown4 = readUint32();
    const unknown5 = readUint32();
    const unknown6 = readUint32();
    
    this.dllPath = readLString();
    
    // Parse variables
    const varCount = readUint32();
    this.variables = [];
    for (let i = 0; i < varCount; i++) {
        const name = readLString();
        const value = readUint32();
        this.variables.push({
            index: i,
            name: name,
            type: 'int',
            initialValue: value,
            currentValue: value
        });
    }
    
    // Store remaining data offset for scene parsing
    this._vndDataOffset = offset;
    this._vndBuffer = buffer;
    
    // Extract resources from remaining data
    this._extractVNDResources(buffer, offset);
    
    // Set version info
    this.version = formatVersion;
    this.signature = 'VNFILE';
    
    console.log(`[VNProject] Loaded VND: ${this.projectName}, ` +
                `${this.width}x${this.height}, ` +
                `${this.variables.length} variables`);
}

/**
 * Extract resource references from VND data
 * @private
 */
_extractVNDResources(buffer, startOffset) {
    this.resources = {
        images: [],
        sounds: [],
        videos: [],
        projects: []
    };
    
    // Convert to string for pattern matching
    const dataStr = String.fromCharCode.apply(null, buffer.slice(startOffset));
    
    // Find .bmp files
    const bmpRegex = /[\w\\]+\.bmp/gi;
    let match;
    while ((match = bmpRegex.exec(dataStr)) !== null) {
        if (!this.resources.images.includes(match[0])) {
            this.resources.images.push(match[0]);
        }
    }
    
    // Find .wav files
    const wavRegex = /[\w\\]+\.wav/gi;
    while ((match = wavRegex.exec(dataStr)) !== null) {
        if (!this.resources.sounds.includes(match[0])) {
            this.resources.sounds.push(match[0]);
        }
    }
    
    // Find .avi files
    const aviRegex = /[\w\\]+\.avi/gi;
    while ((match = aviRegex.exec(dataStr)) !== null) {
        if (!this.resources.videos.includes(match[0])) {
            this.resources.videos.push(match[0]);
        }
    }
    
    // Find .vnp files
    const vnpRegex = /[\w\\]+\.vnp/gi;
    while ((match = vnpRegex.exec(dataStr)) !== null) {
        if (!this.resources.projects.includes(match[0])) {
            this.resources.projects.push(match[0]);
        }
    }
    
    console.log(`[VNProject] Found resources: ` +
                `${this.resources.images.length} images, ` +
                `${this.resources.sounds.length} sounds, ` +
                `${this.resources.videos.length} videos`);
}

/**
 * Auto-detect format and load
 * @param {ArrayBuffer|Uint8Array} data
 */
loadAuto(data) {
    const buffer = data instanceof ArrayBuffer ? new Uint8Array(data) : data;
    
    // Check for VND format (starts with 0x3a and has "VNFILE")
    if (buffer[0] === 0x3a) {
        // Check for VNFILE magic at offset 9
        const magic = String.fromCharCode(
            buffer[9], buffer[10], buffer[11], 
            buffer[12], buffer[13], buffer[14]
        );
        if (magic === 'VNFILE') {
            return this.loadFromVND(buffer);
        }
    }
    
    // Try existing binary format
    return this.loadFromBinary(buffer);
}

// ============================================================
// END OF PATCH
// ============================================================
