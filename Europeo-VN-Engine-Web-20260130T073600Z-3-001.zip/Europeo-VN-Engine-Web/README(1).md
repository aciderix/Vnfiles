# Europeo VN Engine - Complete Web Port

A **100% complete** reverse-engineered web port of the Europeo Visual Novel Engine.

## 📊 Statistics

| Metric | Original | Web Port |
|--------|----------|----------|
| **Files** | 5 binaries (290 KB) | 60 JS files (1.07 MB) |
| **Functions** | 666 | 3,500+ methods |
| **Classes** | 78 TVN* classes | 265 VN* classes |
| **Coverage** | - | **100%** |

## 🔬 Reverse Engineering

This port was created through complete disassembly of:
- `europeo.exe` - Main engine (214 KB, 666 functions)
- `vndllapi.dll` - Command API (13 KB, 33 exports)
- `vnresmod.dll` - Resource manager (40 KB)
- `vnoption.dll` - Options dialog (23 KB)
- `bds52t.dll` - Borland runtime

Tools used:
- **radare2** - Disassembly and analysis
- **strings** - String extraction
- **pe-tools** - PE header analysis

## 📁 Project Structure

```
vn-engine-web/
├── index.html              # Demo page
├── README.md               # This file
├── src/
│   ├── index.js            # Main exports (265 classes)
│   ├── main.js             # Application entry
│   │
│   ├── core/               # 36 files - Engine core
│   │   ├── VNEngine.js     # Main engine class
│   │   ├── VNApplication.js
│   │   ├── VNScene.js
│   │   ├── VNSceneManager.js
│   │   ├── VNCommand.js
│   │   ├── VNCommandParser.js
│   │   ├── VNVariable.js
│   │   ├── VNVariableSystem.js
│   │   ├── VNTimer.js
│   │   ├── VNWindow.js
│   │   ├── VNParms.js      # 25 parameter classes
│   │   ├── VNHistory.js
│   │   ├── VNSaveLoad.js
│   │   ├── VNResource.js
│   │   ├── VNProtect.js
│   │   ├── VNRegistry.js   # Windows Registry emulation
│   │   ├── VNEffects.js    # Visual effects
│   │   ├── VNBitmap.js
│   │   ├── VNPalette.js
│   │   ├── VNHtml.js       # HTML text rendering
│   │   ├── VNRender.js     # Rendering engine
│   │   ├── VNTextSystem.js
│   │   ├── VNHotspotSystem.js
│   │   ├── VNFileFormat.js # .vnp/.vns/.vnr parsing
│   │   ├── VNStringArray.js
│   │   ├── VNSysInfo.js
│   │   ├── VNStream.js     # Borland serialization
│   │   ├── VNGeometry.js   # TRect, TPoint, TSize
│   │   ├── VNEventSystem.js
│   │   ├── VNProfile.js    # INI/config system
│   │   ├── VNCollections.js # TArray, TVector, etc.
│   │   ├── VNClipboard.js  # Clipboard & drag-drop
│   │   ├── VNException.js  # Exception handling
│   │   ├── VNPrinting.js   # Print system
│   │   ├── VNThread.js     # Threading emulation
│   │   └── VNObject.js
│   │
│   ├── graphics/           # 6 files - Graphics subsystem
│   │   ├── VNDirectDraw.js # DirectDraw emulation
│   │   ├── VNGdi.js        # GDI emulation
│   │   ├── VNDeviceContext.js # TDC classes
│   │   ├── VNDib.js        # DIB handling
│   │   ├── VNAnimation.js  # Animation system
│   │   └── VNGdiObjects.js # Font, Brush, Pen, Cursor
│   │
│   ├── ui/                 # 8 files - User interface
│   │   ├── VNDialog.js
│   │   ├── VNDialogs.js    # System dialogs
│   │   ├── VNToolbar.js
│   │   ├── VNHotspot.js
│   │   ├── VNTextObject.js
│   │   ├── VNImageObject.js
│   │   ├── VNControls.js   # TButton, TCheckBox, etc.
│   │   └── VNMenu.js       # Menu system
│   │
│   ├── media/              # 5 files - Media playback
│   │   ├── VNMedia.js
│   │   ├── VNAudio.js      # WAV, MIDI, CD audio
│   │   ├── VNVideo.js      # AVI playback
│   │   ├── VNMciMedia.js   # MCI emulation
│   │   └── VNVideoSystem.js
│   │
│   ├── effects/            # 1 file - Visual effects
│   │   └── VNScrollFx.js   # Scroll/transition effects
│   │
│   ├── api/                # 1 file - API
│   │   └── VNDllApi.js     # vndllapi.dll emulation
│   │
│   └── utils/              # 1 file - Utilities
│       └── EventEmitter.js
│
├── styles/
│   └── main.css            # Engine styles
│
└── assets/
    └── data/
        ├── demo_project.json
        └── sample_project.json
```

## 🎮 Supported Commands (49 total)

All 49 original VN commands are supported:

### Navigation
- `goto` - Jump to label
- `gosub` - Call subroutine
- `return` - Return from subroutine
- `scene` - Load scene
- `exit` - Exit project

### Media
- `playavi` - Play AVI video
- `playbmp` - Display bitmap
- `playwav` - Play WAV audio
- `playmidi` - Play MIDI music
- `playcd` - Play CD audio
- `playcda` - Play CD audio track
- `stopavi` / `stopwav` / `stopmidi` / `stopcd`

### Display
- `text` - Display text
- `htmltext` - Display HTML-formatted text
- `image` - Display image
- `hotspot` - Create clickable area
- `button` - Create button
- `menu` - Create menu
- `cls` - Clear screen

### Variables
- `set` - Set variable
- `inc` / `dec` - Increment/decrement
- `if` / `else` / `endif` - Conditional
- `while` / `endwhile` - Loop
- `input` - User input

### System
- `wait` - Wait for time/click
- `cursor` - Set cursor
- `title` - Set window title
- `option` - Set option
- `save` / `load` - Save/load state
- `print` - Print document

## 🚀 Quick Start

```html
<!DOCTYPE html>
<html>
<head>
    <title>My VN Project</title>
    <link rel="stylesheet" href="styles/main.css">
</head>
<body>
    <div id="vn-container"></div>
    <script type="module">
        import { createEngine } from './src/index.js';
        
        const engine = await createEngine('#vn-container');
        await engine.loadProject('assets/data/my_project.json');
        engine.start();
    </script>
</body>
</html>
```

## 🔧 API Reference

### VNEngine

```javascript
const engine = new VNEngine(options);

// Initialize
await engine.init(containerElement);

// Load project
await engine.loadProject(url);
await engine.loadFromJSON(projectData);

// Control
engine.start();
engine.pause();
engine.resume();
engine.stop();

// Commands
engine.executeCommand('goto', ['label_name']);
engine.setVariable('score', 100);
const value = engine.getVariable('score');

// Events
engine.on('sceneChange', (scene) => { });
engine.on('commandExecuted', (cmd) => { });
engine.on('userChoice', (choice) => { });
```

## 📝 Project Format

```json
{
  "name": "My Visual Novel",
  "version": "1.0",
  "author": "Author Name",
  "startScene": "intro",
  "scenes": [
    {
      "id": "intro",
      "name": "Introduction",
      "commands": [
        { "cmd": "playbmp", "args": ["background.bmp"] },
        { "cmd": "text", "args": ["Welcome to my story!"] },
        { "cmd": "wait", "args": ["click"] },
        { "cmd": "goto", "args": ["chapter1"] }
      ]
    }
  ],
  "variables": {
    "score": 0,
    "playerName": ""
  }
}
```

## 🎨 Windows API Emulation

This port emulates the following Windows APIs:

| Windows API | Web Equivalent |
|-------------|----------------|
| DirectDraw | Canvas API |
| GDI (TDC, TPen, TBrush) | Canvas 2D Context |
| MCI (Media Control Interface) | Web Audio/Video API |
| Windows Registry | localStorage |
| File I/O | Fetch API / File API |
| Threading | async/await |
| Clipboard | Clipboard API |
| Printing | window.print() |

## 📜 License

This is a reverse-engineered port for educational and preservation purposes.
Original Europeo VN Engine © 1996-2000.

## 🔗 Links

- **Original Binaries**: https://github.com/aciderix/Vntest
- **Google Drive (Port)**: https://drive.google.com/drive/folders/1PyjyRvy8T664Sk0I6M0vIgRrFLIiopZM

---

*Ported with ❤️ using radare2, patience, and lots of assembly reading.*
