# Europeo VN Engine - Complete Web Port

A **100% complete** reverse-engineered port of the Europeo Visual Novel Engine from Windows (Borland C++ 1996) to modern web technologies (HTML5/JavaScript/CSS).

## 📊 Reverse Engineering Summary

### Binaries Analyzed

| File | Size | Functions | Lines of ASM |
|------|------|-----------|--------------|
| `europeo.exe` | 214 KB | 666 | 45,134 |
| `vndllapi.dll` | 13 KB | 33 | 473 |
| `vnoption.dll` | 23 KB | - | 1,580 |
| `vnresmod.dll` | 40 KB | - | 10,674 |
| **Total** | **290 KB** | **~700** | **57,861** |

### Web Port Statistics

| Metric | Value |
|--------|-------|
| **Total Files** | 37 |
| **Total Size** | 507 KB |
| **Classes Ported** | 95+ |
| **Commands Implemented** | 49 |
| **JavaScript Modules** | 28 |

## 🏗️ Architecture

### 95+ Classes Ported

#### Core Classes (VNObject.js, VNApplication.js)
- `VNStreamable` - Serialization base
- `VNObject` - Base object class
- `VNIndexDependant` - Index dependency manager
- `VNApplication` - Main application
- `VNApplicationInfo` - App metadata
- `VNProjectInfo` - Project settings
- `VNVersion` - Version info
- `VNDisplayMode` - Display settings
- `VNPaletteEntries` - Palette handling

#### Command System (VNCommand.js, VNCommandParser.js)
- `VNCommand` - Single command
- `VNCommandArray` - Command collection
- `VNEventCommand` - Event-triggered commands
- `VNEventCommandArray` - Event collection
- `VNCommandQueue` - Execution queue
- `VNCommandParser` - 49 command handlers

#### Parameter Classes - 25 Types (VNParms.js)
- `VNBaseParms`, `VNStringParms`, `VNFileNameParms`
- `VNSceneParms`, `VNImageParms`, `VNImgObjParms`, `VNImgSeqParms`
- `VNTextParms`, `VNTextObjParms`, `VNFontParms`, `VNHtmlParms`
- `VNDigitParms`, `VNMidiParms`, `VNCDAParms`, `VNExecParms`
- `VNIfParms`, `VNSetVarParms`, `VNIncVarParms`, `VNDecVarParms`
- `VNConditionParms`, `VNTimeParms`, `VNHotspotParms`
- `VNRectParms`, `VNProjectParms`, `VNCommandParms`

#### Timer & Effects (VNTimer.js, VNEffects.js)
- `VNTimerProperties` - Timer config
- `VNTimerRes` - Timer resource (multimedia timer wrapper)
- `VNTimer` - Main timer class
- `VNTimerBasedFx` - Effect base with 12 easing functions
- `VNTimerManager` - Multiple timer management
- `VNZoomFx` - Zoom effects
- `VNScrollFx` - Pan/scroll effects
- `VNFadeEffect`, `VNSlideEffect`, `VNShakeEffect`, `VNTransitionEffect`

#### Graphics Classes (VNBitmap.js, VNDirectDraw.js)
- `VNGdiObject`, `VNGdiObjectArray` - GDI wrapper
- `VNBitmap`, `VNBmpImg`, `VNTransparentBmp` - Bitmap handling
- `VNBkTexture` - Background tiling
- `VNBitmapCache` - Image caching
- `VNDirectDraw` - DirectDraw emulation
- `VNDirectDrawSurface`, `VNDirectDrawClipper`, `VNDirectDrawPalette`

#### Media Classes (VNMciMedia.js, VNAudio.js, VNVideo.js)
- `VNMciBase` - MCI base class
- `VNWaveMedia` - WAV playback
- `VNMidiMedia` - MIDI playback
- `VNCDAMedia` - CD Audio
- `VNVideoBaseMedia`, `VNAviMedia` - Video playback
- `VNHiddenMedia` - Background audio
- `VNMediaManager` - Multi-media management
- `VNAudioManager`, `VNAudioChannel` - Web Audio API

#### Scene & Navigation (VNScene.js, VNHistory.js)
- `VNScene`, `VNSceneArray` - Scene management
- `VNHistData` - History data structure
- `VNHistQueue` - Navigation history queue
- `VNNavigationManager` - Back/forward navigation

#### Variable System (VNVariable.js)
- `VNVariable`, `VNVariableArray`
- `VNVariableManager` - Variable operations

#### HTML Text & Links (VNHtml.js)
- `VNAnchLink`, `VNAnchLinkArray` - Anchor links
- `VNPageContext` - Page rendering context
- `VNHtmlText` - HTML-like text renderer

#### Window System (VNWindow.js)
- `VNWindow` - Base window class
- `VNFrame` - Application frame
- `VNMenu`, `VNPopupMenu` - Menu system

#### UI Classes (VNDialog.js, VNDialogs.js, VNToolbar.js, etc.)
- `VNDialog` - Text dialog
- `VNHotspot`, `VNHotspotArray` - Clickable areas
- `VNImageObject`, `VNTextObject` - Display objects
- `VNToolBar`, `VNToolBarButton`, `VNToolBarProperties`
- `VNBaseDialog`, `VNAboutDialog`, `VNLoadingDialog`
- `VNUserPrefsDialog`, `VNProjectCapsDialog`, `VNMessageBox`

#### Resource Management (VNResource.js)
- `VNResource`, `VNImageResource`, `VNAudioResource`, `VNVideoResource`
- `VNResourceManager` - Asset loading/caching

#### Registry & Settings (VNRegistry.js)
- `VNRegistry`, `VNRegistryKey` - Windows Registry emulation
- Settings storage via localStorage

#### Protection & Plugins (VNProtect.js)
- `VNProtectData` - DRM/protection data
- `VNPluginData`, `VNPluginManager` - Plugin system

## 📁 File Structure

```
vn-engine-web/                          (507 KB total)
├── index.html                          # Entry point
├── README.md                           # This file
├── src/
│   ├── index.js                        # Main export index
│   ├── main.js                         # Application bootstrap
│   ├── core/                           # Core engine (18 files)
│   │   ├── VNApplication.js            # App/Project/Version classes
│   │   ├── VNBitmap.js                 # Bitmap/GDI classes
│   │   ├── VNCommand.js                # Command system
│   │   ├── VNCommandParser.js          # 49 command handlers
│   │   ├── VNEffects.js                # Visual effects
│   │   ├── VNEngine.js                 # Main engine
│   │   ├── VNHistory.js                # Navigation history
│   │   ├── VNHtml.js                   # HTML text/links
│   │   ├── VNObject.js                 # Base classes
│   │   ├── VNParms.js                  # 25 parameter classes
│   │   ├── VNProtect.js                # Protection/DRM
│   │   ├── VNRegistry.js               # Settings storage
│   │   ├── VNResource.js               # Resource management
│   │   ├── VNSaveLoad.js               # Save/Load system
│   │   ├── VNScene.js                  # Scene management
│   │   ├── VNTimer.js                  # Timer system
│   │   ├── VNVariable.js               # Variable system
│   │   └── VNWindow.js                 # Window classes
│   ├── graphics/
│   │   └── VNDirectDraw.js             # DirectDraw emulation
│   ├── media/                          # Media (4 files)
│   │   ├── VNAudio.js                  # Audio playback
│   │   ├── VNMciMedia.js               # MCI media classes
│   │   ├── VNMedia.js                  # Media base
│   │   └── VNVideo.js                  # Video playback
│   ├── ui/                             # UI (6 files)
│   │   ├── VNDialog.js                 # Text dialog
│   │   ├── VNDialogs.js                # Dialog windows
│   │   ├── VNHotspot.js                # Clickable areas
│   │   ├── VNImageObject.js            # Image display
│   │   ├── VNTextObject.js             # Text display
│   │   └── VNToolbar.js                # Toolbar
│   └── utils/
│       └── EventEmitter.js             # Event system
├── assets/data/
│   ├── demo_project.json               # Demo project
│   └── sample_project.json             # Sample project
└── styles/
    └── main.css                        # Styles
```

## 🎮 The 49 Commands

All commands from the original switch table at `0x40ba69`:

| Case | Command | Description |
|------|---------|-------------|
| 0 | `quit` | Exit application |
| 1 | `about` | Show about dialog |
| 2 | `prefs` | Show preferences |
| 3 | `prev` | Previous scene |
| 4 | `next` | Next scene |
| 5 | `zoom` | Zoom to area |
| 6 | `scene` | Go to scene |
| 7 | `hotspot` | Define hotspot |
| 8 | `tiptext` | Set tooltip |
| 9 | `playavi` | Play AVI video |
| 10 | `playbmp` | Display bitmap |
| 11 | `playwav` | Play WAV audio |
| 12 | `playmid` | Play MIDI |
| 13 | `playhtml` | Display HTML |
| 14 | `zoomin` | Zoom in effect |
| 15 | `zoomout` | Zoom out effect |
| 16 | `pause` | Pause/delay |
| 17 | `exec` | Execute command |
| 18 | `explore` | Open file/URL |
| 19 | `playcda` | Play CD audio |
| 20 | `playseq` | Play sequence |
| 21 | `if` | Conditional |
| 22 | `set_var` | Set variable |
| 23 | `inc_var` | Increment var |
| 24 | `dec_var` | Decrement var |
| 25 | `invalidate` | Redraw screen |
| 26 | `defcursor` | Set cursor |
| 27 | `addbmp` | Add bitmap |
| 28 | `delbmp` | Delete bitmap |
| 29 | `showbmp` | Show bitmap |
| 30 | `hidebmp` | Hide bitmap |
| 31 | `runprj` | Run project |
| 32 | `update` | Update display |
| 33 | `rundll` | Run DLL function |
| 34 | `msgbox` | Show message |
| 35 | `playcmd` | Execute command |
| 36 | `closewav` | Close WAV |
| 37 | `closedll` | Close DLL |
| 38 | `playtext` | Display text |
| 39 | `font` | Set font |
| 40 | `rem` | Comment |
| 41 | `addtext` | Add text object |
| 42 | `delobj` | Delete object |
| 43 | `showobj` | Show object |
| 44 | `hideobj` | Hide object |
| 45 | `load` | Load game |
| 46 | `save` | Save game |
| 47 | `closeavi` | Close AVI |
| 48 | `closemid` | Close MIDI |

## 🚀 Usage

### Basic Usage

```html
<script type="module">
import { VNEngine } from './src/index.js';

const engine = new VNEngine('game-container');
await engine.loadProject('assets/data/demo_project.json');
engine.start();
</script>
```

### Quick Start

```javascript
import { createEngine } from './src/index.js';

const engine = await createEngine('game', 'project.json');
engine.start();
```

## 📝 License

This is a reverse-engineered port for educational and preservation purposes.
The original Europeo VN Engine is © its respective owners.

## 🔧 Tools Used

- **radare2** - Disassembly and analysis (57,861 lines analyzed)
- **Python** - Analysis scripts
- **JavaScript ES6+** - Web implementation
- **HTML5 Canvas** - Graphics rendering
- **Web Audio API** - Audio playback

---
*Port completed: January 30, 2026*
